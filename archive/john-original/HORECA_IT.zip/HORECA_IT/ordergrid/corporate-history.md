# OrderGrid — Corporate History

**Research Date**: 2026-04-30
**Researcher**: AI due-diligence agent
**Sources**: KBO Public Search, ordergrid.com, Crunchbase, LinkedIn, Tracxn, Prospeo

---

## Research Finding: Name Collision with Canadian SaaS Company

Research reveals a significant name collision:

### OrderGrid Inc. — CANADA (AI inventory/ordering)
- Headquartered in Toronto/Scarborough, Ontario, Canada
- Founded ~2012 by Andrina Calder and Kris Calder (some sources also list Anatoliy Melnichuk)
- AI-powered B2B SaaS platform for inventory management, demand forecasting, automated replenishment, and order fulfillment for food retail/distribution
- Operates globally in 9 markets (Canada, US, Mexico, France, Italy, UK, Ireland, UAE, Hong Kong) — Belgium not listed
- Funded (amounts not disclosed); unfunded per some sources (Tracxn)
- **This is a different company from any Belgian "OrderGrid"**

### OrderGrid — Belgium, Antwerp (B2B Ordering / Foodservice)
- Listed in SolStein's research brief as "B2B Ordering, Antwerp, BE — Digital ordering platform for foodservice distribution"
- **No verifiable Belgian company record found** in KBO, Crunchbase, LinkedIn, or other databases under the name "OrderGrid"
- No Belgian website or domain for OrderGrid found
- No Belgian KBO registration identified

**Note on Belgian B2B foodservice ordering landscape**: The Belgian market has active players including OrderBilly (which acquired Smartendr in 2025, dominating the Belgian ordering app market). It is possible that the "OrderGrid" entry in the research brief refers to a company that has since rebranded or been acquired.

---

## Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity (BE) | Unknown | KBO — no match | Unknown |
| KBO enterprise number | Unknown | Not found | Unknown |
| HQ address | Antwerp, Belgium | Research brief | Unknown |
| Founding year | Unknown | Not found | Unknown |
| Founders (Belgian entity) | Unknown | Not found | Unknown |
| Product | Digital ordering platform for foodservice distribution | Research brief | Unknown |
| Revenue | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Canadian company OrderGrid | Based in Toronto, ON, Canada; AI inventory SaaS | Crunchbase, ordergrid.com | Confirmed |
| Belgian market note | OrderBilly acquired Smartendr in 2025 (dominant in BE) | LinkedIn post (Gondola Foodservice) | Estimated |

---

## Corporate Structure

```mermaid
graph TD
    A[OrderGrid Belgium?<br/>Antwerp, BE<br/>Legal entity unknown] --> B[Unknown founders/management]
    B --> C[Research status: Unverifiable]
    D[OrderGrid Inc.<br/>Toronto, Canada<br/>AI inventory SaaS] --> E[DIFFERENT COMPANY — same name]
```

---

## Corporate Timeline

```mermaid
timeline
    title OrderGrid Belgium — Timeline (data insufficient)
    Unknown : Reported as Antwerp-based B2B foodservice ordering platform
    2025 : OrderBilly acquires Smartendr — dominates Belgian ordering market
    2026-04-30 : Research — no Belgian OrderGrid found; name collision with Canadian company
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Identity verification** | CRITICAL — name collides with Canadian AI company; Belgian entity unverifiable |
| **Market context** | Belgian B2B foodservice ordering is active (OrderBilly, Gondola Foodservice); OrderGrid may be defunct or rebranded |
| **Recommended action** | Primary research: check Gondola Foodservice contacts, Flemish food distribution sector networks, KBO search by NACE 46.39/47.11 in Antwerp |
