# OrderGrid — Deep Analysis

**Research Date**: 2026-04-30
**Category**: B2B Ordering / Foodservice Distribution Platform
**Country**: BE | **City**: Antwerp
**Research Quality**: Very Low — name collision with Canadian company; no Belgian entity found

---

> **⚠ IDENTITY ALERT**: The name "OrderGrid" primarily resolves to a Canadian AI inventory management company (Toronto, Ontario). No Belgian company named OrderGrid providing B2B foodservice digital ordering was found in KBO, Crunchbase, LinkedIn, or Belgian company databases. The Belgian B2B foodservice ordering market is dominated by OrderBilly (which acquired Smartendr in 2025).

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity (BE) | Unknown | KBO — no match | Unknown |
| KBO number | Unknown | Not found | Unknown |
| HQ | Antwerp, Belgium | Research brief | Unknown |
| Founded | Unknown | Not found | Unknown |
| CEO | Unknown | Not found | Unknown |
| Ownership | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Revenue | Unknown | Not found | Unknown |
| Funding | Unknown | Not found | Unknown |
| Canadian homonym | OrderGrid Inc., Toronto — different company | Crunchbase | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary markets | Belgium (assumed) | Research brief | Unknown |
| Product | Digital ordering platform for foodservice distribution | Research brief | Unknown |
| Belgian market context | OrderBilly (w/ Smartendr) dominant in BE B2B ordering market | LinkedIn/Gondola | Estimated |
| All other fields | Unknown | Not found | Unknown |

---

## 3–7. All Categories

All fields in sections 3 through 7: **Unknown** — no public data found for a Belgian company named OrderGrid.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot assess | Not found |
| Revenue scale fit | High | N/A | Cannot assess | Not found |
| Geographic fit | High | N/A | Cannot assess | Not found |
| Tech stack modernity | Medium | N/A | Cannot assess | Not found |
| Customer lock-in | Medium | N/A | Cannot assess | Not found |
| Vertical depth | Medium | N/A | Cannot assess | Not found |
| Integration potential | Low | N/A | Cannot assess | Not found |
| Growth trajectory | Low | N/A | Cannot assess | Not found |

**Composite Score**: N/A

**Confidence Band**: None

---

### Overall M&A Assessment

**Rating: INCOMPLETE — Company identity unverifiable**

The Belgian OrderGrid B2B foodservice ordering company cannot be confirmed as an active entity. The market context suggests the Belgian ordering platform space is consolidated around OrderBilly/Smartendr. It is possible that:
- OrderGrid was acquired by OrderBilly or a similar player
- The company has rebranded
- The research brief entry contains a data error

---

### Recommended Next Step

1. Contact Gondola Foodservice (Antwerp-based foodservice trade media) for knowledge of Belgian ordering platform companies
2. Check KBO for Antwerp-based NACE 62.01/62.09 or 46.39 companies with "ordering" or "foodservice" in trade name
3. Research OrderBilly's acquisition history — OrderGrid may have been absorbed
4. If unverifiable: remove from target list
