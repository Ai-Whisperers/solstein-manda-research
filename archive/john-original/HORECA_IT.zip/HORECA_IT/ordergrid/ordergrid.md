# OrderGrid

**Category**: B2B Ordering
**Country**: BE
**City**: Antwerp
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history OrderGrid @HORECA_IT/ordergrid/
@research-horeca-company OrderGrid @HORECA_IT/ordergrid/
```
