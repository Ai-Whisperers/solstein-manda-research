# Zonal — Deep Analysis

**Category**: Restaurant POS / Hospitality Technology Platform
**Country**: UK (Edinburgh, Scotland)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; acquired by Constellation Software / Volaris Group Feb 2026)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | ZONAL LIMITED | Companies House 00610655 | Confirmed |
| HQ | 1 Tanfield, Edinburgh, EH3 5DA | Wikipedia, PitchBook | Confirmed |
| Founded | 1979 | Wikipedia, zonal.co.uk | Confirmed |
| Founder | Ralph McLean | Wikipedia, zonal.co.uk | Confirmed |
| Former CEO | Stuart McLean (son of founder) | zonal.co.uk, Wikipedia | Confirmed |
| Current ownership | Volaris Group (Constellation Software Inc.) — acquired Feb 4, 2026 | Volaris Group press release | Confirmed |
| Employees | 700+ | Wikipedia | Confirmed |
| Revenue | Not publicly disclosed | — | Unknown |
| Business model | Hospitality technology platform: EPOS + reservations + loyalty + workforce + kitchen | zonal.co.uk | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market position | One of two dominant UK hospitality technology platforms | Industry consensus, Wikipedia | Estimated |
| Customer base | Major UK pub groups, restaurant chains, hotel operators | zonal.co.uk | Confirmed |
| UK HORECA verticals | Pubs, restaurants, hotels, leisure | zonal.co.uk | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | Minimal to none; primarily UK domestic | zonalusa.com (US expansion only) | Estimated |
| Geographic focus | United Kingdom (primary); US presence via Zonal USA | zonalusa.com | Confirmed |
| Customer count | Not disclosed | — | Unknown |

Zonal is deeply embedded in UK hospitality chains. Its customer roster includes large pub groups (JD Wetherspoon, Greene King) and restaurant chains (Pizza Hut UK, Prezzo). EU/Benelux presence is negligible.

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | EPoS (electronic point of sale) for hospitality | zonal.co.uk | Confirmed |
| Product suite | Aztec POS, Zonal Loyalty, Zonal Connect (reservations), Zonal Managed Services, Zonal Delivery | zonal.co.uk | Confirmed |
| Deployment | Hybrid (on-premise + cloud); cloud migration ongoing | zonal.co.uk | Estimated |
| Hardware | Own-brand terminals + integration with standard hardware | zonal.co.uk | Confirmed |
| Tech stack | Mixed; legacy on-premise with cloud-native components | Inferred from product | Estimated |
| Key differentiators | Deep UK hospitality expertise; multi-site chain management; full-stack platform | zonal.co.uk | Confirmed |
| Kitchen display | KDS integration | zonal.co.uk | Confirmed |
| Workforce | Workforce management module (via acquisitions) | zonal.co.uk | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pre-2026 ownership | McLean family (founder-owned for 46 years) | Wikipedia, Volaris press release | Confirmed |
| Acquisition | Volaris Group (Constellation Software) — Feb 4, 2026 | Volaris Group press release | Confirmed |
| Post-acquisition model | Autonomous subsidiary; "buy-and-hold" permanent ownership | volarisgroup.com | Confirmed |
| Stuart McLean status | Stepped down post-acquisition | zonal.co.uk | Confirmed |
| Interim CEO | Jesper Ulsted (Volaris Group Portfolio Leader) | zonal.co.uk, thebusinessdesk.com | Confirmed |
| Succession gap (pre-2026) | Family business without obvious non-family successor — likely sale driver | Inferred | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not publicly disclosed | — | Unknown |
| Profitability | Assumed profitable (Volaris targets EBITDA-positive businesses) | Constellation Software investment thesis | Estimated |
| Scotland Top 100 | Listed 2018 — indicates significant revenue scale | zonal.co.uk | Confirmed |
| Growth trajectory | Mature, stable; not a high-growth startup | Inferred from 46-year history | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK VAT compliance | Full UK VAT-compliant POS | zonal.co.uk | Confirmed |
| UK payment methods | Full UK payment stack (Chip & PIN, contactless, mobile pay) | zonal.co.uk | Confirmed |
| Allergen management | Allergen compliance module | zonal.co.uk | Estimated |
| Tipping compliance | Integration with UK tipping law requirements | zonal.co.uk | Estimated |
| Multi-site management | Core strength — pub groups and chains with 50–500 sites | zonal.co.uk | Confirmed |
| Loyalty programme | Zonal Loyalty — branded loyalty for hospitality chains | zonal.co.uk | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | POS software licences + hardware + managed services + SaaS transition | zonal.co.uk | Confirmed |
| ARR estimate | £30M–£80M+ (estimated; not disclosed) | Inferred from 700 employees / industry benchmarks | Estimated |
| Acquisition price | Not disclosed | Volaris Group press release | Unknown |
| Volaris/Constellation typical multiple | 2–5x EBITDA; typically pays below market for stable businesses | Constellation Software investor materials | Estimated |
| SolStein fit | No — UK-only; acquired; far above target range | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Owned by Constellation Software (Volaris) — never divests; permanently held | Volaris Group press release Feb 2026 |
| Revenue scale fit | High | 1 | 700 employees; estimated £30M–£80M+ revenue — far above SolStein's target | Industry benchmarks |
| Geographic fit | High | 1 | UK primary; US secondary; no NL/BE market presence confirmed | zonal.co.uk |
| Tech stack modernity | Medium | 3 | Hybrid on-premise/cloud; modernising but rooted in legacy POS architecture | zonal.co.uk |
| Customer lock-in | Medium | 5 | Deep chain integration; multi-site management; 46 years of customer relationships | Wikipedia |
| Vertical depth | Medium | 5 | Full-stack UK hospitality platform; dominant market position | zonal.co.uk |
| Integration potential | Low | 3 | Proprietary ecosystem; some API connectivity | zonal.co.uk |
| Growth trajectory | Low | 2 | Mature, stable business; likely single-digit growth | Inferred |

### Composite Score

**Weighted Composite: 2.1 / 5.0**

*(High-weight dimensions score 1: ownership, revenue scale, geographic fit)*

**Confidence Band**: Medium — structural facts (acquisition) confirmed; revenue and financials unknown.

### Overall M&A Assessment

Zonal is **not an acquisition target** for SolStein under any scenario. It has been acquired by Constellation Software / Volaris Group, which operates a permanent hold model and has never divested a portfolio company. Its value to SolStein is as a **technology and market benchmark** for what a mature UK hospitality platform looks like.

### Recommended Next Step

No pursuit. Monitor as competitive context. Note that Constellation Software acquisitions of European hospitality IT companies (including Zonal) reduce the supply of independent UK targets — reinforcing SolStein's NL/BE focus.

---

*Sources: Companies House (00610655), Volaris Group press release (4 Feb 2026), zonal.co.uk, Wikipedia (Zonal company), thebusinessdesk.com, zonalusa.com, PitchBook.*
