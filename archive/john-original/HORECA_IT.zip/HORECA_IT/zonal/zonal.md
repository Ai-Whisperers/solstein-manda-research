# Zonal

**Category**: Restaurant POS
**Country**: UK
**City**: Edinburgh
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Zonal @HORECA_IT/zonal/
@research-horeca-company Zonal @HORECA_IT/zonal/
```
