# Zonal — Corporate History

**Category**: Restaurant POS / Hospitality Technology Platform
**Country**: UK (Edinburgh, Scotland)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; acquired February 2026)

---

## Summary Assessment

Zonal is a **family-founded, Edinburgh-based** hospitality technology provider with over 45 years of history, serving the UK hospitality market with EPOS, reservations, loyalty, and workforce management solutions. In **February 2026**, the company was acquired by **Volaris Group** (a subsidiary of Constellation Software Inc.), ending the McLean family ownership. With 700+ employees and a long-standing position as one of the UK's leading hospitality tech platforms, Zonal is a major **market benchmark** for the sector.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | ZONAL LIMITED (latest registered entity) | Companies House 00610655 | Confirmed |
| Companies House No. | 00610655 | gov.uk Companies House | Confirmed |
| Registered address | 1 Tanfield, Edinburgh, EH3 5DA | Wikipedia, PitchBook | Confirmed |
| Founded | 1979 | Wikipedia, Zonal website | Confirmed |
| Founded by | Ralph McLean | Wikipedia, Zonal website | Confirmed |
| Founding context | McLean family hotel/bar in Edinburgh; built first hospitality electronic till | Wikipedia, zonalusa.com | Confirmed |
| Family succession | Stuart McLean (son of Ralph) became CEO | Zonal.co.uk, Wikipedia | Confirmed |
| Employees (2026) | 700+ | Wikipedia | Confirmed |
| Acquisition by | Volaris Group (operating group of Constellation Software Inc.) | Volaris Group press release Feb 2026 | Confirmed |
| Acquisition date | 4 February 2026 | Volaris Group press release | Confirmed |
| Acquisition terms | Financial terms not disclosed | Volaris Group press release | Confirmed |
| Post-acquisition CEO | Jesper Ulsted (Volaris Group; interim CEO) | zonal.co.uk, thebusinessdesk.com | Confirmed |
| Stuart McLean status | Stepped down post-acquisition | zonal.co.uk news | Confirmed |
| Acquirer HQ | Toronto, Canada (Constellation Software / Volaris Group) | volarisgroup.com | Confirmed |
| Pre-acquisition status | Family-owned private company | Wikipedia, hackajob, Zonal website | Confirmed |
| Revenue | Not publicly disclosed | — | Unknown |
| Acquisition type | Volaris Group "buy-and-hold" — autonomous subsidiary model | volarisgroup.com | Confirmed |
| Scotland Top 100 | Listed in Scotland's Top 100 Private Companies (2018) | zonal.co.uk | Confirmed |

---

## Founding & Early History

Ralph McLean founded Zonal in **Edinburgh in 1979** as a direct solution to the challenges his own hotel and bar operations faced. Unable to find adequate electronic point-of-sale management tools, McLean built the first hospitality electronic till himself. This practical origin shaped Zonal's culture: deep understanding of the operator's perspective, built into every product.

The company grew steadily over four decades under McLean family stewardship. **Stuart McLean**, Ralph's son, eventually assumed the CEO role, continuing the family leadership tradition. Zonal expanded from a POS hardware/software provider into a full hospitality technology platform encompassing EPOS, reservations, loyalty programmes, workforce management, and kitchen management systems.

By the 2010s, Zonal had established itself as one of the **UK's two dominant hospitality technology platforms** (alongside Access Hospitality), serving major pub groups, restaurant chains, and hotel operators. The company appeared in **Scotland's Top 100 Private Companies** list in 2018.

---

## Acquisition History (BY Zonal)

| # | Company | Country | Approx. Date | Domain | Notes |
|---|---|---|---|---|---|
| 1 | Aztec (systems) | UK | ~2010 | Hospitality POS/EPoS | Expanded product capabilities |
| 2 | Undisclosed | UK | ~2013 | Hospitality technology | Per Wikipedia — acquisition noted without company name |

---

## Acquisition OF Zonal

| Event | Date | Acquirer | Seller | Terms |
|---|---|---|---|---|
| Acquisition | 4 February 2026 | Volaris Group (Constellation Software Inc.) | McLean family (founder-owned) | Not disclosed |

Volaris Group is known for acquiring **vertical market software businesses** as permanent, autonomous subsidiaries — the "buy-and-hold forever" model. Zonal fits this pattern as a profitable, deeply embedded UK hospitality tech platform with high customer retention and no desire to be flipped.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Constellation Software Inc.<br/>(Toronto Stock Exchange: CSU)"]
    B["Volaris Group<br/>(Operating group of Constellation Software)"]
    C["Zonal<br/>(Edinburgh, UK — autonomous subsidiary from Feb 2026)"]
    D["700+ employees<br/>UK hospitality market"]

    A -->|"Parent"| B
    B -->|"Acquired Feb 4, 2026"| C
    C --> D
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Zonal — Key Milestones
    1979 : Founded by Ralph McLean in Edinburgh; first hospitality electronic till
    2010 : Acquisition expands product capabilities (approx.)
    2013 : Second acquisition (approx.)
    2018 : Listed in Scotland's Top 100 Private Companies; celebrating 40th anniversary
    2026 : Acquired by Volaris Group (Constellation Software) on 4 Feb 2026; Stuart McLean steps down; Jesper Ulsted interim CEO
```

---

## M&A Feasibility Assessment

### Is Zonal an Acquisition Target for SolStein?

**Answer: No. Already acquired; Constellation/Volaris will not sell.**

| Factor | Assessment |
|---|---|
| **Scale** | 700+ employees; UK's dominant hospitality tech platform — far above SolStein's target range |
| **Ownership** | Now owned by Constellation Software / Volaris Group — permanent hold model |
| **Geography** | UK-only primary market; limited EU/Benelux presence |
| **Succession** | Stuart McLean has stepped down; Volaris interim CEO in place — no founder succession angle |
| **Exit pathway** | Constellation Software never divests acquired companies |

### Role for SolStein

1. **Technology reference**: Zonal defines the full-stack UK hospitality platform (EPOS + reservations + loyalty + workforce).
2. **Competitive benchmark**: UK hospitality operators on Zonal represent the established incumbent — NL/BE operators with no equivalent platform are the SolStein opportunity.
3. **Valuation benchmark**: Volaris/Constellation acquires at 3–5x EBITDA (distressed or mature businesses); Zonal's acquisition price was not disclosed.

---

*Sources: Companies House (00610655), Wikipedia (Zonal company), Volaris Group press release (4 Feb 2026), zonal.co.uk news, thebusinessdesk.com, zonalusa.com, hackajob.com, PitchBook.*
