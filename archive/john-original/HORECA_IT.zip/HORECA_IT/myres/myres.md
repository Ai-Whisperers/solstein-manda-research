# myRES

**Category**: Reservations
**Country**: DE
**City**: Frankfurt
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history myRES @HORECA_IT/myres/
@research-horeca-company myRES @HORECA_IT/myres/
```
