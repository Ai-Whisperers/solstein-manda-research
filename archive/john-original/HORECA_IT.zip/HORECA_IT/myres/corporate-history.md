# myRES — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — very limited public data

---

## Executive Summary

myRES is listed in the SolStein research brief as a Frankfurt-based online table reservation system. Extensive research could not identify any company or platform named "myRES" operating as a restaurant reservation system in Frankfurt, Germany. Web searches for "myRES Frankfurt" returned only unrelated results (a conference registration site, a general resource domain). This may be a very small or defunct company, or a naming confusion with another Frankfurt-based reservation platform.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | myRES | SolStein research brief | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Frankfurt, Hesse, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany | SolStein research brief | Estimated |
| Primary activity | Online table reservation system (reported) | SolStein research brief | Estimated |

---

## Research Methodology & Limitations

Searches conducted:
- "myRES Frankfurt table reservation Germany"
- "myres.de restaurant reservation system"
- myres.com (returns a general resource domain, not a restaurant company)

The restaurant reservation market in Germany is dominated by platforms such as TheFork (Tripadvisor), Quandoo, OpenTable, and resmio. A company named "myRES" is not identifiable in this competitive set.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — company existence not confirmed |
| **SolStein thesis fit** | Very poor — Germany-only, unconfirmed existence |
| **Research confidence** | Very low |

**Verdict**: Company identity and existence not confirmed. Cannot assess.

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| Web search results (inconclusive) | Multiple searches; no match found | Negative result |
