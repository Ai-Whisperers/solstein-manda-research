# SevenRooms — Deep Analysis

**Category**: Reservations / CRM / Guest Engagement
**Country**: USA (New York HQ); UK (London entity SEVENROOMS LTD)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (US HQ; DoorDash subsidiary since May 2025; $1.2B acquisition)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Operating name | SevenRooms | sevenrooms.com | Confirmed |
| US HQ | New York City, USA | sevenrooms.com | Confirmed |
| UK entity | SEVENROOMS LTD (Companies House 12427015) | tracxn.com | Confirmed |
| UK incorporation | 26 January 2020 | tracxn.com | Confirmed |
| Founded | 2011 | sevenrooms.com | Confirmed |
| Founders | Joel Montaniel (CEO), Allison Page, Kinesh Patel | sevenrooms.com/our-story | Confirmed |
| Ownership | DoorDash Inc. (acquired May 7, 2025 for $1.2B) | tracxn.com | Confirmed |
| Revenue (2024) | ~$43M | Getlatka | Estimated |
| Customers (2024) | ~1,000 | Getlatka | Estimated |
| Business model | SaaS subscription CRM/reservations per venue | sevenrooms.com | Confirmed |
| Product | Guest experience platform: reservations + CRM + waitlist + loyalty + F&B data | sevenrooms.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| US market | Primary; dominant in US high-end restaurant/hotel segment | sevenrooms.com | Confirmed |
| UK market | Active — D&D London, Jumeirah Group as UK clients | sevenrooms.com | Confirmed |
| EU market | Not dominant; secondary | sevenrooms.com | Estimated |
| NL/BE presence | Not confirmed | — | Unknown |
| HORECA verticals | Restaurants, hotels, bars, nightlife venues | sevenrooms.com | Confirmed |
| Target customer | Fine dining and mid-scale restaurants; luxury/boutique hotels | sevenrooms.com | Confirmed |
| DoorDash Reservations | US/Australia currently; international expansion planned | sevenrooms.com blog | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Reservations | Table booking, waitlist management | sevenrooms.com | Confirmed |
| CRM | First-party guest profile database (preferences, visit history, spend) | sevenrooms.com | Confirmed |
| F&B data | Hotel F&B + PMS integration for unified guest profiles | sevenrooms.com/hotels/ | Confirmed |
| Marketing | Email/SMS campaigns based on guest data; loyalty | sevenrooms.com | Confirmed |
| POS integration | Integrates with POS for spend tracking | sevenrooms.com | Confirmed |
| PMS integration | Integrates with hotel PMS for combined guest view | sevenrooms.com | Confirmed |
| Deployment | Cloud SaaS | sevenrooms.com | Confirmed |
| Tech stack | Cloud-native; API-first; mobile apps | sevenrooms.com | Confirmed |
| DoorDash integration | DoorDash Reservations powered by SevenRooms | sevenrooms.com blog | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Prior investors | Providence Strategic Growth (Series B, 2019); Danny Meyer's PE firm | sevenrooms.com press | Confirmed |
| Acquisition | DoorDash Inc. — May 7, 2025 — $1.2B | tracxn.com | Confirmed |
| Founder status | Joel Montaniel (CEO) likely continues under DoorDash | Standard acquisition terms | Estimated |
| Divestiture likelihood | Very low | DoorDash strategic fit | Estimated |
| UK entity | SEVENROOMS LTD (12427015) — active subsidiary | Companies House | Confirmed |

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Customers | Source | Confidence |
|---|---|---|---|---|
| 2019 | Early stage | — | Series B context | Estimated |
| 2024 | ~$43M | ~1,000 | Getlatka | Estimated |
| ACV (implied) | ~$43,000/customer/year | Derived | Estimated |

High ACV (~$43K/year per customer) confirms SevenRooms targets larger hospitality operators (not micro-SMB). The $1.2B acquisition at ~$43M ARR implies a ~28x revenue multiple — premium valuation for guest data/CRM platform with DoorDash strategic value.

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Guest data CRM | Market-defining first-party guest data platform | sevenrooms.com | Confirmed |
| Reservation management | Full reservation and waitlist management | sevenrooms.com | Confirmed |
| UK hospitality | Active UK presence; UK Industry Trends reports published | sevenrooms.com | Confirmed |
| Hotel F&B | Hotel restaurant CRM integration with PMS | sevenrooms.com/hotels/ | Confirmed |
| GDPR compliance | UK/EU GDPR compliant (required for UK entity) | sevenrooms.com | Confirmed |
| NL/BE equivalent | No known NL/BE deployment | — | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription per venue + optional add-ons | sevenrooms.com | Confirmed |
| ARR (2024) | ~$43M | Getlatka | Estimated |
| Acquisition price | $1.2B (DoorDash, May 2025) | tracxn.com | Confirmed |
| Revenue multiple at acquisition | ~28x ARR | Derived from $1.2B/$43M | Estimated |
| SolStein fit | No — DoorDash subsidiary; $1.2B acquisition; US HQ | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | DoorDash subsidiary (NYSE: DASH); fully corporate-owned | tracxn.com |
| Revenue scale fit | High | 2 | ~$43M ARR — above SolStein's ceiling ($15M); but post-acquisition moot | Getlatka |
| Geographic fit | High | 1 | US HQ; UK secondary; no NL/BE-specific strategy | sevenrooms.com |
| Tech stack modernity | Medium | 5 | Cloud-native CRM; API integrations with POS/PMS; mobile | sevenrooms.com |
| Customer lock-in | Medium | 5 | First-party guest data creates highest switching costs (all guest history in platform) | sevenrooms.com |
| Vertical depth | Medium | 5 | Market-defining guest CRM + reservations; hotel F&B + PMS integration | sevenrooms.com |
| Integration potential | Low | 5 | POS + PMS integrations; DoorDash ecosystem | sevenrooms.com |
| Growth trajectory | Low | 4 | DoorDash integration accelerates; international expansion planned | sevenrooms.com blog |

### Composite Score

**Weighted Composite: 2.5 / 5.0**

*(Ownership = 1, geographic fit = 1 — high-weight decisive blockers)*

**Confidence Band**: Medium — acquisition facts confirmed; revenue from Getlatka (estimated).

### Overall M&A Assessment

SevenRooms is **not an acquisition target** for SolStein — acquired by DoorDash for $1.2B in May 2025. Its acquisition at ~28x revenue is the **highest-multiple data point in this UK Tier 3 cohort**, reflecting the premium value of first-party guest data and CRM in hospitality.

**Immediate takeaway**: Any NL/BE restaurant or hotel reservation/CRM company at €1–5M ARR, founder-owned, with first-party guest data is a potential high-value SolStein acquisition target. The category commands exceptional multiples.

### Recommended Next Step

No pursuit. Use as guest CRM/reservations benchmark and valuation reference (28x ARR for premium guest data platform). Identify NL/BE equivalents: Resengo (NL reservations), Formitable (NL), Tablebooker (BE) — these are the SolStein opportunities in this category.

---

*Sources: sevenrooms.com, tracxn.com, Companies House (12427015), Getlatka, sevenrooms.com/press.*
