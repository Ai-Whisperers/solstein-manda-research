# SevenRooms

**Category**: Reservations/CRM
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history SevenRooms @HORECA_IT/sevenrooms/
@research-horeca-company SevenRooms @HORECA_IT/sevenrooms/
```
