# SevenRooms — Corporate History

**Category**: Reservations / CRM / Guest Engagement
**Country**: USA (New York — HQ); UK (London — registered entity and European presence)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (US HQ; acquired by DoorDash May 2025 for $1.2B)

---

## Summary Assessment

SevenRooms is a **New York–based guest experience and CRM platform** for restaurants, hotels, and nightlife venues. With UK entity (SEVENROOMS LTD, Companies House 12427015) incorporated in January 2020 for European operations, it is active in the UK market. In **May 2025**, SevenRooms was **acquired by DoorDash for $1.2 billion** — becoming part of the world's largest food delivery platform. Revenue was ~$43M (2024 estimate). Not a SolStein target; critical **guest CRM and reservations benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | SevenRooms | sevenrooms.com | Confirmed |
| US HQ | New York City, USA | sevenrooms.com, tracxn.com | Confirmed |
| UK entity | SEVENROOMS LTD | Companies House 12427015 | Confirmed |
| UK Companies House No. | 12427015 | tracxn.com | Confirmed |
| UK incorporation date | 26 January 2020 | tracxn.com | Confirmed |
| Founded | 2011 | sevenrooms.com | Confirmed |
| Founders | Joel Montaniel (CEO) + Allison Page + Kinesh Patel | sevenrooms.com/our-story | Confirmed |
| Acquired by | DoorDash Inc. | tracxn.com | Confirmed |
| Acquisition date | 7 May 2025 | tracxn.com | Confirmed |
| Acquisition value | $1.2 billion | tracxn.com | Confirmed |
| Revenue (2024) | ~$43M | Getlatka | Estimated |
| Customers | ~1,000 (2024) | Getlatka | Estimated |
| Key investors (pre-acquisition) | Providence Strategic Growth (Series B) | sevenrooms.com press | Confirmed |
| Key customer UK | D&D London (restaurant group) | sevenrooms.com press | Confirmed |
| Key customer UK 2 | Jumeirah Group (hotels) | sevenrooms.com press | Confirmed |
| Product | Guest experience platform: reservations + CRM + waitlist + loyalty + marketing | sevenrooms.com | Confirmed |
| 2025 UK Restaurant Industry Trends Report | Published | sevenrooms.com | Confirmed |

---

## Founding & Corporate History

**SevenRooms** was founded in **New York in 2011** by Joel Montaniel, Allison Page, and Kinesh Patel. The founders set out to give hospitality operators a CRM-first guest management platform — shifting the industry from "managing covers" to "managing guest relationships."

**Key differentiation**: Unlike table management systems (OpenTable, Resy), SevenRooms centred on **owning first-party guest data** — building rich guest profiles from every interaction (reservations, orders, preferences, spend history) to enable personalised service and direct marketing.

**UK presence**: SevenRooms incorporated **SEVENROOMS LTD** (Companies House 12427015) in **January 2020**, establishing a UK entity to serve the European market. Key UK clients include D&D London and Jumeirah Group. SevenRooms publishes UK-specific industry reports.

**Funding milestones:**
- Various early rounds; Providence Strategic Growth led $50M Series B
- Danny Meyer's (Union Square Hospitality) private equity firm (USHG PE) invested
- 2024: ~$43M revenue; ~1,000 customers
- **7 May 2025**: **DoorDash acquired SevenRooms for $1.2 billion** — integrating guest experience and reservations into DoorDash's restaurant commerce ecosystem

**Post-acquisition**: SevenRooms now operates as part of DoorDash, which is expanding internationally but primarily US-focused for reservations (DoorDash Reservations currently US/Australia only as of 2026).

---

## Funding History (Selected)

| Round | Date | Amount | Lead Investor | Notes |
|---|---|---|---|---|
| Series A | ~2014–2016 | Not disclosed | Various | Early growth |
| Series B | 2019 | $50M | Providence Strategic Growth | D&D London, Jumeirah among customers at this point |
| Acquisition | May 7, 2025 | $1.2B | DoorDash Inc. | Full acquisition |

---

## Corporate Structure (Post-Acquisition)

```mermaid
graph TD
    A["DoorDash Inc.<br/>(NYSE: DASH — San Francisco, CA)"]
    B["SevenRooms<br/>(New York — US HQ; worldwide operations)"]
    C["SEVENROOMS LTD<br/>(Companies House 12427015)<br/>(UK entity, incorporated Jan 2020)"]
    D["UK / European HORECA<br/>(D&D London, Jumeirah, etc.)"]

    A -->|"Acquired May 7, 2025 — $1.2B"| B
    B -->|"Subsidiary"| C
    C --> D
```

---

## Timeline of Critical Events

```mermaid
timeline
    title SevenRooms — Key Milestones
    2011 : Founded in New York by Joel Montaniel + Allison Page + Kinesh Patel
    2019 : $50M Series B (Providence Strategic Growth); D&D London + Jumeirah customers
    2020 : SEVENROOMS LTD incorporated in UK (Companies House 12427015, Jan 26, 2020)
    2024 : ~$43M revenue; ~1,000 customers; UK Restaurant Industry Trends Report published
    May 2025 : Acquired by DoorDash for $1.2 billion
    2026 : Part of DoorDash; DoorDash Reservations expanding; UK SevenRooms active
```

---

## M&A Feasibility Assessment

### Is SevenRooms an Acquisition Target for SolStein?

**Answer: No. Acquired by DoorDash for $1.2B (May 2025). Definitively inaccessible.**

| Factor | Assessment |
|---|---|
| **Ownership** | DoorDash (NYSE: DASH) — public company subsidiary |
| **Scale** | ~$43M revenue; $1.2B acquisition price — 80–1,200x above SolStein's target range |
| **Geography** | US HQ; UK/EU secondary; not NL/BE-focused |
| **Succession** | Professional management; no founder succession angle |
| **Exit pathway** | Would require DoorDash to divest — not applicable |

### Role for SolStein

1. **Guest CRM/reservations benchmark**: SevenRooms at $43M revenue and $1.2B acquisition value = ~28x revenue multiple for a premium guest CRM platform. Shows valuation of guest data and CRM in hospitality.
2. **DoorDash integration signal**: DoorDash acquiring SevenRooms signals convergence of delivery platforms and restaurant operations. Affects NL/BE dynamics (Thuisbezorgd/Just Eat Takeaway's position in NL/BE).
3. **NL/BE opportunity**: A NL/BE restaurant CRM/reservations platform (founder-owned, €1–5M ARR) would be a SolStein target in this category.

---

*Sources: sevenrooms.com, tracxn.com, Companies House (12427015), Getlatka, sevenrooms.com/press/sevenrooms-raises-50m-series-b.*
