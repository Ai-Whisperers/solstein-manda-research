# Aareon — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: None — misclassified company; not a HORECA software provider

---

## Critical Research Note

**Aareon AG is not a gastronomy or restaurant software company.** The SolStein research brief incorrectly categorizes it as "Gastronomy, Paderborn, DE — Restaurant and catering management." In reality, Aareon AG is:

- A leading **European property management SaaS company** serving real estate and housing companies
- Headquartered in **Mainz, Germany** (not Paderborn)
- Backed by **Advent International** (private equity)
- Generating revenues of **>€200M**
- Employing **2,000+** people across Europe

Aareon has no meaningful gastronomy or restaurant management product. The only gastronomy-adjacent element is a marketplace integration with MenuLabs (a digital menu platform), which is a minor feature of their partner ecosystem — not a core product.

**Recommendation**: This entry should either be removed from the HORECA IT landscape list or replaced with a correct gastronomy-focused DE company.

---

## 1. Company Fundamentals (Actual Profile)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Aareon AG | aareon.com; Wikipedia | Confirmed |
| HQ | Mainz, Germany | aareon.com; Wikipedia | Confirmed |
| Category | Property management SaaS (PropTech / Real Estate Tech) | aareon.com | Confirmed |
| Founded | Historical origin in Aareal Bank's IT division | Wikipedia | Confirmed |
| Ownership | PE-backed (Advent International) | Public reports | Confirmed |
| Employees | 2,000+ | Wikipedia | Estimated |
| Revenue | >€200M | Estimated from PE context | Estimated |
| Customers | Housing companies, real estate groups | aareon.com | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | PE-backed (Advent International); not founder-owned | Public reports |
| Revenue scale fit | High | 1 | >€200M revenue — far above SolStein's €1–15M range | Estimated |
| Geographic fit | High | 1 | Germany + other EU; no NL/BE primary focus | aareon.com |
| Tech stack modernity | Medium | 4 | Modern SaaS property management platform | aareon.com |
| Customer lock-in | Medium | 5 | Deep property management integrations; very high switching costs | aareon.com |
| Vertical depth | Medium | 1 | Real estate/property, NOT gastronomy/HORECA | aareon.com |
| Integration potential | Low | 3 | API marketplace (Aareon Connect) exists | aareon.com |
| Growth trajectory | Low | 4 | PE-backed growth trajectory; active M&A strategy | Public reports |

**Composite Score**: ~1.9 / 5.0 (failing primarily on vertical, scale, ownership, and geography)

**Confidence Band**: High — company existence and profile are well-established

**Overall M&A Assessment**: Aareon AG is definitively **NOT a SolStein target**. It operates in a completely different vertical (real estate/property management), at a completely different scale (>€200M ARR), and under PE ownership. The classification in the SolStein research brief is incorrect. No follow-up action needed for this entry within the HORECA context.

**Recommended Next Step**: Flag this entry to the research brief author as a classification error. Remove from HORECA IT landscape or replace with a correct DE gastronomy software reference company.

---

*Sources: aareon.com, Wikipedia (Aareon), Advent International portfolio listings*
