# Aareon — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Major PE-backed PropTech company — NOT a gastronomy software company; likely misclassified in research brief

---

## Executive Summary

**Important classification note**: The SolStein research brief categorizes Aareon as "Gastronomy, Paderborn, DE — Restaurant and catering management." This classification appears to be **incorrect**. Aareon AG is one of Europe's leading property management SaaS companies (Proptech/Real Estate Tech), headquartered in **Mainz** (not Paderborn), Germany. Aareon serves housing companies, real estate groups, and property managers — not restaurants or catering businesses. The company is PE-backed by Advent International and has revenues well in excess of €200M. It is orders of magnitude outside SolStein's acquisition criteria regardless of vertical.

Aareon does operate a marketplace (Aareon Connect) that includes some catering/food-related integrations (e.g., MenuLabs), but this is not its core business.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | Aareon AG | aareon.com; Wikipedia | Confirmed |
| Legal form | Aktiengesellschaft (AG) | Public records | Confirmed |
| Registered HQ | Mainz, Germany | Wikipedia; aareon.com | Confirmed |
| SolStein brief location | "Paderborn, DE" (incorrect) | SolStein research brief | Estimated |
| Country | Germany | Multiple sources | Confirmed |
| Primary activity | SaaS property management software for housing/real estate companies | aareon.com | Confirmed |
| SolStein brief categorization | "Restaurant and catering management" (INCORRECT) | SolStein research brief | Estimated |
| Website | aareon.com | aareon.com | Confirmed |

---

## Founding & Ownership History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| History | Aareon AG emerged from Aareal Bank's IT division; long history in German real estate software | Wikipedia; aareon.com | Confirmed |
| PE acquisition | Advent International acquired majority stake | Public reports | Confirmed |
| Current PE owner | Advent International (private equity) | Wikipedia; multiple sources | Confirmed |
| Revenue | >€200M (large-scale enterprise software company) | Public estimates | Estimated |
| Employees | 2,000+ | Wikipedia; aareon.com | Estimated |
| Countries | Germany (primary), plus Netherlands, UK, France, Scandinavia, other EU | aareon.com | Confirmed |
| Geographic fit for SolStein | Irrelevant — completely different vertical and scale | Assessment | Confirmed |

---

## Classification Discrepancy

| Aspect | SolStein Brief Claim | Actual | Source |
|---|---|---|---|
| City | Paderborn | Mainz, Germany | aareon.com; Wikipedia |
| Category | "Gastronomy / Restaurant and catering management" | Property Management SaaS (real estate) | aareon.com |
| Revenue | Implied small | >€200M | Estimated from PE context |
| Employees | Implied small | 2,000+ | Wikipedia |
| PE ownership | Not mentioned | PE-backed (Advent International) | Public reports |

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | NOT available — PE-backed major enterprise company |
| **Vertical match** | None — property management tech, not gastronomy/HORECA |
| **Scale** | Far exceeds SolStein's acquisition target range |
| **SolStein thesis fit** | Zero fit on all dimensions |

**Verdict**: Aareon AG is **not a gastronomy software company** and is **not a SolStein acquisition target**. The classification in the research brief appears to be a data error. Aareon serves housing and real estate companies, not restaurants or cafés. Recommend removing from HORECA landscape research or replacing with a correctly identified DE gastronomy software company.

---

## Sources

| Source | URL | Type |
|---|---|---|
| Aareon — About Us | https://www.aareon.com/about-us | Primary (company site) |
| Aareon Wikipedia article | https://en.wikipedia.org/wiki/Aareon | Secondary (encyclopedia) |
| Aareon Marketplace (MenuLabs integration noted) | https://marketplace.aareon.com/s/menulabs | Primary (marketplace) |
