# Zenchef — Deep Analysis

**Research Date**: 2026-04-30
**Category**: Restaurant Management / Reservations / Guest Marketing (SaaS)
**HQ**: Paris, France (SIREN 528 389 794)
**M&A Verdict**: ❌ NOT a SolStein acquisition target — PE-backed (PSG Equity), oversized, pan-European

---

## 1. Company Fundamentals

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Legal name | ZENCHEF SAS | annuaire-entreprises.data.gouv.fr | Confirmed |
| Founded | 2010 (as 1001 Menus) | Tracxn, Crunchbase, French register | Confirmed |
| Founders | Xavier Zeitoun, Thomas Zeitoun, Julien Balmont | Crunchbase, Visconti Partners podcast | Confirmed |
| CEO (current) | Thomas Jeanjean (group CEO post Jul 2025 merger) | PSG press release Jul 2025 | Confirmed |
| Previous CEO | Xavier Zeitoun (2010–2025) | Resengo acquisition blog, Zenchef press releases | Confirmed |
| Employees (pre-merger) | 200+ | Zenchef about page, Resengo blog | Confirmed |
| Employees (post-CoverManager) | 500+ | PSG/CoverManager press release | Confirmed |
| Revenue | Not publicly disclosed | PitchBook, Tracxn | Unknown |
| Estimated ARR | €15M–€40M (derived: 19k–36k restaurants × €700–€1,200 avg SaaS/year) | SolStein estimate from public restaurant counts | Estimated |
| Countries of operation | 20+ (post-Jul 2025 merger) | PSG press release | Confirmed |
| Primary markets | France, Netherlands, Belgium, Denmark, Germany, Portugal, Spain, LATAM | Resengo blog, PSG press release | Confirmed |
| Ownership | PSG Equity (majority since Sep 2022) | PSG press release Sep 2022 | Confirmed |
| Total funding | ~$58.8M across 4 rounds | Tracxn | Estimated |
| Key investors | PSG Equity, GP Bullhound, Edenred Capital Partners, Elaia, Kima Ventures, XAnge, METRO, L'Accélérateur | Tracxn, Crunchbase, Edenred press release | Confirmed |

---

## 2. HORECA Market Position

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Total restaurants on platform | 36,000+ (post-CoverManager, Jul 2025) | PSG/Zenchef press release | Confirmed |
| Total restaurants (pre-CoverManager) | 19,000+ | Zenchef about page, Tablebooker press release | Confirmed |
| Monthly reservations | 7.4M/month (pre-CoverManager) | Zenchef about page | Confirmed |
| Annual guest experiences | 650M+ (combined post-merger) | PSG/CoverManager press release | Confirmed |
| Belgium restaurants | 6,000+ (post-Tablebooker Feb 2024) | Zenchef Tablebooker press release | Confirmed |
| Netherlands restaurants | ~3,500 (via Formitable + Resengo) | Resengo acquisition blog (3,500 added) + Formitable | Estimated |
| Michelin-starred coverage | ~800 restaurants; 60% of Michelin-starred in France + Benelux; 50% in Spain | PSG/CoverManager press release | Confirmed |
| Notable clients | De Librije (NL), The Jane (BE), RIJKS (NL), Table by Bruno Verjus (FR), Geranium (DK), Alléno Paris (FR) | Zenchef website, press releases | Confirmed |
| Market position | Claims largest commission-free reservation platform in Europe | Zenchef Tablebooker press release | Confirmed |
| Primary competitor | TheFork (TripAdvisor-owned, commission-based) | Zenchef comparison page | Confirmed |
| Differentiation | Zero commission per reservation (SaaS-only), restaurateur owns guest data | Zenchef about page, all press releases | Confirmed |
| Belgium presence origin | Resengo (acquired Sep 2023, founded 20+ years ago) + Tablebooker (founded 2012, acquired Feb 2024) | Resengo/Tablebooker press releases | Confirmed |
| Netherlands presence origin | Formitable (merged Jan 2023, Amsterdam) + Resengo NL component | Formitable press release | Confirmed |

---

## 3. Product & Technology

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Core platform name | ZenchefOS | Zenchef about page, press releases | Confirmed |
| Platform type | All-in-one commission-free SaaS | Zenchef website | Confirmed |
| Reservations module | Online booking, table management, capacity management | Zenchef website | Confirmed |
| Guest CRM | Guest data ownership, relationship management, loyalty tools | Zenchef about page, PSG release | Confirmed |
| Marketing automation | Digital marketing, guest engagement, visibility tools | PSG Sep 2022 release, Zenchef website | Confirmed |
| Payments | Pay-at-table (Billee acquisition Jun 2021 added payment stack) | PSG Sep 2022 release, Crunchbase | Confirmed |
| Consumer app | Zenchef guest app (diner-facing reservation discovery) | PSG Sep 2022 release, Apple App Store | Confirmed |
| No-show management | No-show reduction tools (explicit feature) | Zenchef, CoverManager description | Confirmed |
| Revenue management | AI-driven yield management (roadmap post-merger) | PSG CoverManager press release | Estimated |
| Integrations | CoverManager integrates 140+ tech tools; Zenchef integration count not specified | CoverManager description in PSG release | Estimated |
| Tech stack | Not publicly disclosed; web SaaS, modern cloud-native likely given 2022 PSG investment | PitchBook (NAF 62.01Z = software dev) | Estimated |
| GDPR compliance | EU-based, French company; guest data ownership is core product value proposition | Zenchef privacy stance throughout website | Confirmed |
| Bancontact / iDEAL | Not explicitly mentioned; payment integrations via Billee stack assumed | Not confirmed | Unknown |
| Multi-language | FR, NL, EN confirmed (Resengo blog in EN, NL; Zenchef site multilingual) | Resengo blog, Zenchef website | Confirmed |

---

## 4. M&A Ownership & Succession

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Current controlling shareholder | PSG Equity (majority since Sep 2022) | PSG press release | Confirmed |
| PSG investment date | September 2022 | PSG press release | Confirmed |
| PSG investment amount | >€50M growth equity | PSG press release | Confirmed |
| PSG investment mandate | European expansion, product development, add-on acquisitions | PSG press release | Confirmed |
| Founder status | Xavier Zeitoun (co-founder) stepped back from group CEO role post Jul 2025; Thomas Jeanjean (non-founder) is group CEO | PSG Jul 2025 press release | Confirmed |
| GP Bullhound involvement | CoverManager investor joining the combined entity | capital-riesgo.es, Bullhound Capital article | Confirmed |
| PE overhang | Yes — PSG Equity is active PE/growth equity; typical hold 5–7 years; invested Sep 2022; exit window ~2027–2030 | Standard PE dynamics applied to Sep 2022 entry | Estimated |
| Succession dynamic | None — institutional PE control; no founder retirement dynamic; active platform build | PSG investment thesis | Confirmed |
| Distressed signal | None — actively consolidating, growing, well-funded | All sources | Confirmed |
| Acquirer profile | Would require corporate/PE buyer; not appropriate for SolStein | SolStein M&A thesis | Confirmed |

---

## 5. Financial Growth & Trajectory

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Revenue (2026) | Not publicly disclosed | — | Unknown |
| Revenue estimate | €15M–€40M ARR estimated based on restaurant count × blended SaaS ARPU | SolStein derivation | Estimated |
| SaaS pricing basis | Subscription per restaurant (commission-free model eliminates per-booking revenue) | Zenchef business model | Confirmed |
| Growth trajectory | Rapid consolidation: 4 acquisitions in 2021–2024; merger in 2025; restaurant count 7k→19k→36k | Press release timeline | Confirmed |
| Restaurant count growth | ~7,000 (pre-2022) → 15,000 (post-Formitable, Jan 2023) → 19,000 (post-Resengo/Tablebooker, Feb 2024) → 36,000 (post-CoverManager, Q3 2025) | Series of press releases | Confirmed |
| Headcount growth | 200+ (2023) → 500+ (2025) | Resengo blog, PSG press release | Confirmed |
| Geographic expansion | France → NL/BE (2023–2024) → Spain/LATAM (2025) | Acquisition timeline | Confirmed |
| Profitability | Not disclosed; PE-backed growth phase suggests investment-first | Standard PE growth equity dynamics | Estimated |
| Market size (addressable) | >€4B (per PSG CoverManager press release) | PSG/CoverManager press release | Confirmed |
| COVID impact | Near-existential crisis in 2020; survived via Click & Collect pivot | French Tech Journal, Visconti podcast | Confirmed |

---

## 6. HORECA Vertical Depth

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Vertical focus | Restaurant-only (excludes hotels, bars, nightclubs for Zenchef; CoverManager added nightclubs/beach clubs) | PSG press release, CoverManager description | Confirmed |
| Fine dining specialization | 60% of Michelin-starred restaurants in France + Benelux; top-tier positioning | PSG/CoverManager press release | Confirmed |
| Reservation lock-in | Deep integration into restaurant operations; guest data owned by restaurant | Zenchef value proposition | Confirmed |
| Anti-commission positioning | Explicit zero-commission model vs TheFork; strong switch-away narrative | Zenchef switch page, comparison pages | Confirmed |
| Tablebooker value-add | Includes Resto.be (B2C), RestoDays (gastronomy events), Restofactory (restaurant websites) | Zenchef Tablebooker press release | Confirmed |
| Resengo heritage | 20+ years in BE/NL market; founded early 2000s; founded by Dirk Gypen | Resengo acquisition blog | Confirmed |
| Guest data ownership | Core philosophy — restaurants own CRM data, not the platform | Zenchef about, all press releases | Confirmed |
| GDPR alignment | French/EU company; data sovereignty is product value prop | Zenchef model | Confirmed |
| Bancontact/iDEAL | Not confirmed; local payment methods assumed via Billee stack; Resengo/Tablebooker likely supported locally | — | Unknown |

---

## 7. Valuation & Business Model

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Revenue model | Monthly/annual SaaS subscription per restaurant; no per-reservation commission | Zenchef website, business model | Confirmed |
| Pricing (public) | Not listed publicly; varies by plan and restaurant size | Zenchef website | Unknown |
| Estimated ARPU | €700–€1,200/restaurant/year (industry benchmark for reservation SaaS at this scale) | SolStein estimate using industry comps | Estimated |
| Estimated ARR (pre-merger, 19k restaurants) | €13M–€23M (19,000 × €700–€1,200) | SolStein derivation | Estimated |
| Estimated ARR (post-merger, 36k restaurants) | €25M–€43M (36,000 × €700–€1,200) | SolStein derivation | Estimated |
| Valuation | Not disclosed; PSG growth equity at €50M+ implies enterprise value likely €80M–€200M+ at time of investment | Standard SaaS valuation multiples on estimated ARR | Estimated |
| Acquisition price for SolStein | Not applicable — scale, ownership, and structure make this infeasible | SolStein M&A thesis | Confirmed |
| Revenue multiple benchmarks | European restaurant SaaS peers trade at 4x–8x ARR; at €25M ARR midpoint → €100M–€200M EV | SaaS comparable analysis | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | 1 | PSG Equity majority since Sep 2022; active PE platform; no founder succession gap; actively consolidating | PSG press release Sep 2022 |
| **Revenue scale fit** | High | 1 | Estimated €25M–€43M ARR (post-merger); massively exceeds SolStein €1M–€15M ceiling | SolStein derivation from 36k restaurants |
| **Geographic fit** | High | 3 | Strong NL/BE presence (6,000+ BE restaurants; ~3,500 NL via Formitable/Resengo) BUT HQ France, 20+ country operator | PSG/Zenchef press releases |
| **Tech stack modernity** | Medium | 5 | Cloud-native SaaS (ZenchefOS); AI revenue management on roadmap; modern consumer app; €50M+ invested in product | PSG Sep 2022, CoverManager press release |
| **Customer lock-in** | Medium | 5 | Guest data ownership model; deep operational integration; anti-commission switching narrative actively used | Zenchef website, Tablebooker release |
| **Vertical depth** | Medium | 5 | Restaurant-only SaaS; Michelin-star concentration; 20+ years heritage (Resengo); full-stack from discovery to payment | PSG press release, Resengo blog |
| **Integration potential** | Low | 4 | ZenchefOS is modular platform; CoverManager integrates 140+ tools; API-forward assumed but not confirmed | CoverManager description, Zenchef website |
| **Growth trajectory** | Low | 5 | 4 acquisitions 2021–2024; restaurant count 7k→36k; 200→500 employees; 20-country expansion | Full acquisition timeline |

### Composite Score Calculation

| Weight | Score | Weighted |
|---|---|---|
| High × 3 | 1 + 1 + 3 = 5 avg | 5 × High weight (3) = 15 |
| Medium × 3 | 5 + 5 + 5 = 5 avg | 5 × Medium weight (2) = 10 |
| Low × 2 | 4 + 5 = 4.5 avg | 4.5 × Low weight (1) = 4.5 |

> **Simplified weighted composite** (High=3, Medium=2, Low=1 weight):
>
> `(1×3 + 1×3 + 3×3 + 5×2 + 5×2 + 5×2 + 4×1 + 5×1) / (3+3+3+2+2+2+1+1)`
>
> = `(3 + 3 + 9 + 10 + 10 + 10 + 4 + 5) / 17`
>
> = `54 / 17`

**Composite Score: 3.2 / 5.0**

**Confidence Band: Narrow** — high fraction of Confirmed data points; ownership and scale are unambiguous.

> The composite score of 3.2 is misleading: Geographic fit, tech quality, and vertical depth score well. But the two High-weighted dealbreakers (ownership and revenue scale) both score 1/5. Any target that fails both High-weight criteria is a **hard pass** regardless of composite.

---

### Overall Assessment

**Zenchef is a definitively unsuitable acquisition target for SolStein.**

Two irreconcilable blockers disqualify it:

1. **PE ownership (PSG Equity majority)**: SolStein requires founder-owned or family-owned targets. PSG is not a motivated seller; they are in active build/consolidate mode, having invested >€50M in 2022 and closed a major merger in 2025. A PE exit would require a corporate or financial buyer at scale, not SolStein.

2. **Revenue scale**: Estimated €25M–€43M ARR (post-merger) is 2×–4× above SolStein's €15M ceiling. Even the pre-merger Zenchef France entity alone was likely at or above €15M given 19,000 restaurants.

**Classification**: Tier 2 — Blocker (PE-backed, too large, wrong ownership structure).

---

### Recommended Next Step

**Do not pursue Zenchef.** Instead, use Zenchef's consolidation playbook as a targeting signal:

- Zenchef acquired Resengo, Formitable, and Tablebooker precisely because they were independent, founder-led NL/BE reservation platforms — exactly the SolStein target profile.
- Research any **remaining independent NL/BE reservation SaaS** players not yet absorbed by Zenchef or a competitor. Candidates to investigate:
  - Are there sub-5,000 restaurant platforms in NL/BE still operating independently?
  - Former Resengo-type businesses in the hospitality vertical that remain founder-owned?
- **Monitor Zenchef's divestiture risk**: If PSG exits (typical 5–7 year hold from 2022 → 2027–2029), a strategic buyer could carve out the Benelux operations. This is a remote but watch-worthy scenario for 2027+.

---

## Source Index

| Source | URL | Type |
|---|---|---|
| annuaire-entreprises.data.gouv.fr | https://annuaire-entreprises.data.gouv.fr/entreprise/zenchef-528389794 | Confirmed — French official registry |
| societe.com | https://www.societe.com/societe/zenchef-528389794.html | Confirmed — French company data |
| PSG Equity — Sep 2022 investment | https://psgequity.com/news/zenchef-announces-an-investment-of-over-50-million-from-psg-equity | Confirmed — primary |
| PSG Equity — CoverManager merger Jul 2025 | https://psgequity.com/news/covermanager-and-zenchef-join-forces-to-create-a-leading-european-restaurant-revenue-management-platform | Confirmed — primary |
| Zenchef about page | https://www.zenchef.com/about | Confirmed — primary |
| Zenchef Tablebooker press release | https://www.zenchef.com/tablebooker-joins-zenchef | Confirmed — primary |
| Resengo acquisition blog | https://pro.resengo.com/en/blog/zenchef-formitable-acquires-resengo/ | Confirmed — primary |
| Formitable merger page | https://formitable.com/nl/formitablezenchefpressrelease | Confirmed — primary |
| Crunchbase (1001 Menus) | https://www.crunchbase.com/organization/1001-menus | Estimated — secondary aggregator |
| Tracxn | https://tracxn.com/d/companies/zenchef | Estimated — secondary aggregator |
| PitchBook | https://pitchbook.com/profiles/company/60275-98 | Estimated — secondary aggregator |
| Edenred Capital Partners press release | https://media.edenred.com/edenred-capital-partners-acquires-equity-interest-zenchef/ | Confirmed — primary |
| TechCrunch 2015 | https://techcrunch.com/2015/11/04/zenchef/ | Confirmed — primary (contemporaneous) |
| manda.be — Tablebooker | https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/ | Estimated — secondary |
| horecatrends.com | https://www.horecatrends.com/en/tablebooker-from-belgium-joins-zenchef/ | Estimated — secondary |
| Bullhound Capital | https://bullhoundcapital.com/articles/covermanager-merges-with-zenchef/ | Confirmed — primary (investor) |
| Visconti Partners podcast | https://www.visconti.partners/en/ressource/devenir-leader-europeen-de-la-digitalisation-de-la-restauration | Estimated — secondary (podcast transcript) |
