# Zenchef — Corporate History

**Research Date**: 2026-04-30
**Category**: Restaurant Management / Reservations / Guest Marketing
**Country**: France (FR) — EU operations including NL/BE
**M&A Status**: PE-backed (PSG Equity majority since 2022) — **NOT a viable SolStein acquisition target**

---

## Summary

Zenchef is a Paris-based restaurant technology SaaS company, founded in 2010 as **1001 Menus**. It pivoted from digital menus to commission-free reservations and evolved into an all-in-one restaurant management platform. PSG Equity took a majority stake in September 2022 (€50M+ growth equity). Through a consolidation strategy in 2023–2025, Zenchef absorbed three Benelux reservation platforms (Formitable NL, Resengo NL/BE, Tablebooker BE) and in July 2025 merged with CoverManager (Spain/LATAM), creating a 36,000-restaurant, 500-employee European restaurant tech group. This is a PE-backed platform play — definitively outside SolStein's acquisition thesis.

---

## Data Point Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | ZENCHEF | annuaire-entreprises.data.gouv.fr | Confirmed |
| Former legal name | 1001 Menus | Crunchbase, societe.com | Confirmed |
| Legal form | SAS (Société par actions simplifiée) | annuaire-entreprises.data.gouv.fr | Confirmed |
| SIREN | 528 389 794 | annuaire-entreprises.data.gouv.fr | Confirmed |
| SIRET (head office) | 528 389 794 00041 | annuaire-entreprises.data.gouv.fr | Confirmed |
| VAT number | FR50 528 389 794 | annuaire-entreprises.data.gouv.fr | Confirmed |
| Registration date | 4 November 2010 | annuaire-entreprises.data.gouv.fr / societe.com | Confirmed |
| Registered address | 63 Avenue de Villiers, 75017 Paris, France | annuaire-entreprises.data.gouv.fr | Confirmed |
| NAF/APE code | 62.01Z (Computer programming) | annuaire-entreprises.data.gouv.fr | Confirmed |
| Founding year (operational) | 2010 | Tracxn, PitchBook, Crunchbase | Confirmed |
| Founders | Xavier Zeitoun, Thomas Zeitoun, Julien Balmont | Crunchbase, Visconti Partners podcast | Confirmed |
| CEO (2023–post-merger) | Xavier Zeitoun → Thomas Jeanjean (post-CoverManager) | PSG press release Jul 2025, Resengo blog | Confirmed |
| Majority shareholder | PSG Equity (since Sep 2022) | PSG Equity press release | Confirmed |
| KBO/Belgian entity | Not primary entity; Belgian operations via Resengo/Tablebooker subsidiaries | Zenchef website, manda.be | Estimated |
| Country of primary incorporation | France | annuaire-entreprises.data.gouv.fr | Confirmed |
| Total funding raised | ~$58.8M across 4 rounds | Tracxn | Estimated |
| Round 1 — Seed | ~2013, Kima Ventures (amount undisclosed) | Crunchbase, Tracxn | Estimated |
| Round 2 — Series A | Nov 2015, €6M led by Edenred Capital Partners | Edenred press release, TechCrunch | Confirmed |
| Round 2 investors | Edenred Capital Partners, XAnge, METRO, Elaia Partners, Kima Ventures, L'Accélérateur Capital Partners | Edenred press release, Clipperton | Confirmed |
| Round 3 — undisclosed | Date/amount undisclosed (pre-2022) | Tracxn (4 rounds noted) | Estimated |
| Round 4 — Growth Equity (Series C) | Sep 2022, >€50M, PSG Equity | PSG Equity press release | Confirmed |
| Billee acquisition | Jun 21, 2021 | Crunchbase acquisition profile | Confirmed |
| Formitable merger | January 2023 | Formitable press release, Resengo blog | Confirmed |
| Resengo acquisition | 12 September 2023 | Resengo blog press release | Confirmed |
| Tablebooker acquisition | 20 February 2024 | Zenchef press release | Confirmed |
| CoverManager merger | Announced 15 July 2025; close Q3 2025 | PSG Equity press release | Confirmed |
| Total restaurants (pre-CoverManager) | 19,000+ | Zenchef about page, Tablebooker release | Confirmed |
| Total restaurants (post-CoverManager) | 36,000+ | PSG/Zenchef Jul 2025 press release | Confirmed |
| Employees (pre-merger) | 200+ | Zenchef about page, Resengo blog | Confirmed |
| Employees (post-merger) | 500+ | PSG CoverManager press release | Confirmed |
| Monthly reservations | 7.4M/month (pre-CoverManager) | Zenchef about page | Confirmed |
| Annual guest experiences | 650M+ (post-merger combined) | PSG/CoverManager press release | Confirmed |
| Countries of operation | 20+ (post-CoverManager merger) | PSG/CoverManager press release | Confirmed |
| Offices | Paris, Amsterdam, Antwerp, Copenhagen, Berlin, Lisbon | Resengo acquisition blog | Confirmed |
| Revenue | Not publicly disclosed | PitchBook, Tracxn | Unknown |
| Valuation | Not publicly disclosed | PitchBook (behind paywall) | Unknown |
| Michelin-starred restaurants | ~800 combined; 60% of Michelin-starred in France + Benelux | PSG/CoverManager press release | Confirmed |
| TheFork relationship | Competitor (not spinoff, no corporate link) | Zenchef comparison page, TripAdvisor filings | Confirmed |
| LaFourchette link | None — LaFourchette is TheFork (TripAdvisor-owned); Zenchef is independent | Zenchef, TripAdvisor IR | Confirmed |
| Resengo founders | Dirk Gypen (CEO pre-acquisition) | Resengo acquisition press release | Confirmed |
| Tablebooker founders | Nicolas de Borrekens, Paul Slootmans (CEO) | Zenchef Tablebooker press release | Confirmed |
| Formitable origin | Amsterdam, Netherlands | Formitable/Zenchef press release | Confirmed |

---

## Corporate Timeline

```mermaid
timeline
    title Zenchef Corporate History
    section Founding & Early Growth
        2010 : Founded as 1001 Menus (Xavier Zeitoun, Thomas Zeitoun, Julien Balmont) — Paris, France — SAS registered 4 Nov 2010
        2013 : Early seed investment (Kima Ventures) — Digital menus product
        2015 : €6M Series A — Edenred Capital Partners leads, XAnge, METRO, Elaia, Kima, L'Accélérateur Capital Partners — Pivot to reservation technology
        2015 : Name change from 1001 Menus to Zenchef
    section Growth & Survival
        2020 : COVID-19 existential crisis — Restaurant closures halt revenue — Pivot to Click & Collect, digital payments
        2021 : Acquired Billee (payment platform, Jun 2021) — Resurrection narrative
    section PE Acceleration Phase
        2022 : €50M+ growth equity from PSG Equity (Sep 2022) — Series C — PSG takes majority — European expansion mandate
        2023 : Merger with Formitable (Jan 2023) — Dutch reservation platform, Amsterdam
        2023 : Acquisition of Resengo (Sep 2023) — Dutch-Belgian reservation platform — 3,500 restaurants added
        2024 : Acquisition of Tablebooker (Feb 2024) — Belgian reservation platform — 3,000 restaurants added — 6,000 BE restaurants total
    section European Platform Play
        2025 : Merger with CoverManager (announced Jul 2025, close Q3 2025) — Spanish/LATAM platform — 36,000+ restaurants combined — 500+ employees — Thomas Jeanjean becomes group CEO
```

---

## Corporate Structure Diagram

```mermaid
graph TD
    PSG["PSG Equity\n(Majority shareholder since Sep 2022)"]
    GP["GP Bullhound\n(CoverManager investor)"]
    Holding["NewCo Holding Company\n(formed Jul 2025)"]
    ZC["ZENCHEF SAS\nSIREN: 528 389 794\nParis, France"]
    CM["CoverManager S.L.\nSeville, Spain"]

    PSG --> Holding
    GP --> Holding
    Holding --> ZC
    Holding --> CM

    ZC --> F["Formitable\n(merged Jan 2023, NL)"]
    ZC --> R["Resengo\n(acquired Sep 2023, NL/BE)"]
    ZC --> TB["Tablebooker\n(acquired Feb 2024, BE)"]
    ZC --> B["Billee\n(acquired Jun 2021, FR)"]

    style PSG fill:#d32f2f,color:#fff
    style Holding fill:#e65100,color:#fff
    style ZC fill:#1565c0,color:#fff
    style CM fill:#2e7d32,color:#fff
```

---

## Ownership History

| Period | Ownership Structure | Key Event |
|---|---|---|
| 2010–2015 | Founders (Xavier Zeitoun, Thomas Zeitoun, Julien Balmont) + angels | Bootstrapped, seed funding |
| 2015–2022 | Founders + minority VCs (Edenred, XAnge, METRO, Elaia, Kima) | €6M Series A; founder-led growth |
| Sep 2022–Jul 2025 | PSG Equity **majority**; minority VCs; founders diluted | €50M growth equity; M&A mandate |
| Jul 2025–present | PSG Equity **majority** of NewCo holding; GP Bullhound participates; founders Thomas Jeanjean (CEO), José Antonio Pérez (Board) | CoverManager merger; combined group |

---

## M&A Feasibility Assessment

### Verdict: **NOT VIABLE** — PE-backed Platform Play

| Criterion | Assessment | Detail |
|---|---|---|
| **Ownership** | ❌ Fail | PSG Equity majority since Sep 2022; active PE platform consolidation in progress |
| **Revenue scale** | ❌ Fail | Far exceeds €15M ARR ceiling; 36,000 restaurants at SaaS pricing implies €20M–€60M+ ARR |
| **Geographic fit** | ⚠️ Partial | Strong NL/BE presence via Resengo/Formitable/Tablebooker, but HQ is Paris and now a 20-country operator |
| **Founder-owned** | ❌ Fail | Founders diluted; PSG is controlling shareholder; no succession dynamic |
| **Size** | ❌ Fail | 500+ employees, 36,000+ restaurants, 20+ countries — corporate buyer scale, not SolStein scale |
| **Strategic complexity** | ❌ Fail | Active mid-merger integration (CoverManager); not a clean acquisition target |

**Recommendation**: Classify as **Tier 2 Blocker** (PE-backed, too large, wrong ownership). Monitor as **competitive benchmark** — Zenchef's Benelux acquisitions (Resengo, Formitable, Tablebooker) confirm that NL/BE reservation platforms are attractive consolidation targets; look for the next Resengo-type company before Zenchef acquires it.

**Strategic insight for SolStein**: Zenchef's playbook validates the NL/BE reservation market. The acquired companies (Resengo, Formitable, Tablebooker) were exactly the type of businesses SolStein should target — independent, founder-led NL/BE reservation platforms. SolStein should identify remaining independent platforms in this space before Zenchef or similar consolidators absorb them.
