# Zenchef

**Category**: Restaurant Management
**Country**: BE
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history Zenchef @HORECA_IT/zenchef/
@research-horeca-company Zenchef @HORECA_IT/zenchef/
```
