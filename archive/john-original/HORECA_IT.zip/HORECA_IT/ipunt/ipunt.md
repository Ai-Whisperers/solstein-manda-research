# iPunt

**Category**: Restaurant POS
**Country**: BE
**City**: Antwerp
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history iPunt @HORECA_IT/ipunt/
@research-horeca-company iPunt @HORECA_IT/ipunt/
```
