# iPunt — Corporate History

**Research Date**: 2026-04-30
**Researcher**: AI due-diligence agent
**Sources**: KBO Public Search (no match), ipunt.be (domain parked at Vimexx), LinkedIn, Belgian POS databases

---

## Research Finding: Domain Parked — Company May Be Inactive

- **ipunt.be** domain is registered and parked at Vimexx (Dutch/Belgian hosting provider), with no active website content
- A parked domain at a registrar typically indicates the domain was registered but no website has been deployed, or the website has been taken down
- No KBO registration found for "iPunt" as a Belgian legal entity
- No LinkedIn company page found
- No Crunchbase or Tracxn profile found
- No product reviews on G2, Capterra, or Trustpilot

**Possible explanations**:
1. **Pre-launch company**: Domain registered but business not yet operational
2. **Defunct company**: Business has ceased; domain retained by registrar without active content
3. **Rebranded**: Company may have changed its brand name and moved to a different domain
4. **Small reseller**: Might be a one-person VAR or dealer reselling another POS brand under the iPunt name
5. **Alternate legal name**: Company may be registered under a different name in KBO

---

## Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | Unknown | KBO — no match | Unknown |
| KBO enterprise number | Unknown | Not found | Unknown |
| Domain status | ipunt.be — registered, parked at Vimexx (no content) | Direct URL test | Confirmed |
| HQ address | Antwerp, Belgium | Research brief | Unknown |
| Founding year | Unknown | Not found | Unknown |
| Founders | Unknown | Not found | Unknown |
| Product | Cloud-based POS for hospitality | Research brief | Unknown |
| Revenue / ARR | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Investment | Unknown | Not found | Unknown |
| Active status | Unclear — domain parked suggests limited/no current operations | URL test | Estimated |

---

## Corporate Structure

```mermaid
graph TD
    A[iPunt<br/>Antwerp, Belgium<br/>Legal entity unknown] --> B[Unknown founders/management]
    B --> C[Research status: Unverifiable]
    D[ipunt.be — Parked domain<br/>Registered at Vimexx] --> C
```

---

## Corporate Timeline

```mermaid
timeline
    title iPunt — Timeline (data insufficient)
    Unknown : Company reportedly operating as cloud POS for hospitality in Antwerp
    2026-04-30 : Research — ipunt.be parked; no active company records found
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Domain status** | Parked — suggests limited or no current operations |
| **KBO match** | None found |
| **M&A readiness** | Cannot assess |
| **Risk** | If company is defunct, no acquisition value |
| **Recommended action** | Primary research required: search KBO for Antwerp-based NACE 62.01/62.09 companies with cloud POS activities; check Horeca Vlaanderen member list |
