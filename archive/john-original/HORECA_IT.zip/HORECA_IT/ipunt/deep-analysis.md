# iPunt — Deep Analysis

**Research Date**: 2026-04-30
**Category**: Restaurant POS (Cloud-based)
**Country**: BE | **City**: Antwerp
**Research Quality**: Very Low — domain parked, no active company records

---

> **⚠ OPERATIONAL STATUS ALERT**: The domain ipunt.be is parked at Vimexx (Dutch/Belgian hosting) with no live website content. No KBO registration, LinkedIn profile, or product information was found for a company named iPunt in Belgium. The company may be pre-launch, defunct, or operating under a different name.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | KBO — no match | Unknown |
| KBO number | Unknown | Not found | Unknown |
| Domain status | ipunt.be parked at Vimexx — no content | URL test | Confirmed |
| HQ | Antwerp, Belgium | Research brief | Unknown |
| Founded | Unknown | Not found | Unknown |
| CEO | Unknown | Not found | Unknown |
| Ownership | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Revenue | Unknown | Not found | Unknown |
| Funding | Unknown | Not found | Unknown |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary markets | Belgium (assumed) | Research brief | Unknown |
| Product | Cloud-based POS for hospitality | Research brief | Unknown |
| All other fields | Unknown | Not found | Unknown |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Deployment | Cloud (from brief description) | Research brief | Unknown |
| Tech stack | Unknown | Not found | Unknown |
| Bancontact | Unknown | Not found | Unknown |
| Fiscal receipt (BE/GKS) | Unknown | Not found | Unknown |
| API | Unknown | Not found | Unknown |

---

## 4. M&A Ownership & Succession

All fields: **Unknown** — company existence not confirmed.

---

## 5. Financial Growth & Trajectory

All fields: **Unknown** — no data available.

---

## 6. HORECA Vertical Depth

All fields: **Unknown** — no product information found.

---

## 7. Valuation & Business Model

All fields: **Unknown** — cannot estimate without confirmed company identity.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot assess | Not found |
| Revenue scale fit | High | N/A | Cannot assess | Not found |
| Geographic fit | High | N/A | Cannot assess | Not found |
| Tech stack modernity | Medium | N/A | Cannot assess | Not found |
| Customer lock-in | Medium | N/A | Cannot assess | Not found |
| Vertical depth | Medium | N/A | Cannot assess | Not found |
| Integration potential | Low | N/A | Cannot assess | Not found |
| Growth trajectory | Low | N/A | Cannot assess | Not found |

**Composite Score**: N/A

**Confidence Band**: None — company status unconfirmed; domain parked

---

### Overall M&A Assessment

**Rating: INCOMPLETE / POSSIBLE DEFUNCT — Cannot assess without operational confirmation**

The parked domain ipunt.be is a significant red flag. A parked domain typically means either:
- The company never launched (domain squatting / brand protection)
- The company has ceased operations and the domain expired or was not renewed under an active site

If iPunt is defunct, there is no acquisition value. If pre-launch, it is too early to evaluate.

---

### Recommended Next Step

1. Verify operational status via Antwerp HORECA IT community outreach
2. KBO search for Antwerp companies in NACE 62.01/62.09 with "POS" or "hospitality" in description
3. Check domain registration history (WHOIS) to estimate when it was first registered and by whom
4. If confirmed defunct: remove from target list
