# Booking Experts — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Due Diligence — Full Company Profile & Attractiveness Scoring

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Booking Experts B.V. | bookingexperts.com/privacy-policy | Confirmed |
| KvK number | 55796850 | bookingexperts.com/privacy-policy | Confirmed |
| Headquarters | Pantheon 28, 7521 PR, Enschede, Netherlands | bookingexperts.com/privacy-policy | Confirmed |
| Secondary office | Amersfoort, Netherlands (opened ~2022) | jobs.bookingexperts.com/en/locations | Confirmed |
| Founded | 2011 (operations); 2012 (B.V. registered) | bookingexperts.com/about-us; creditsafe.com | Confirmed |
| CEO | Ali Ilboga (founder) | jobs.bookingexperts.com/en/people/1877658-ali-ilboga | Confirmed |
| COO | Maureen Ilboga | jobs.bookingexperts.com/en/people/1786751-maureen | Confirmed |
| CCO | Coen van Rhee | crunchbase.com/organization/booking-experts | Confirmed |
| CTO | Stefan (surname not publicly disclosed) | jobs.bookingexperts.com/en/departments/executives | Estimated |
| Head of International Growth | Dominique Noël | rocketreach.co/booking-experts-bv-management | Estimated |
| Head of Product | Mustafa Kurt | rocketreach.co/booking-experts-bv-management | Estimated |
| Head of Strategic Initiatives | Carlo Batenburg | rocketreach.co/booking-experts-bv-management | Estimated |
| Ownership type | Founder-owned, no external investors | tracxn.com; crunchbase.com | Confirmed |
| Total employees | 150+ (in 14 countries) | bookingexperts.com/about-us | Confirmed |
| Customers | 800+ leisure companies | bookingexperts.com/about-us | Confirmed |
| Users | 126,000+ platform users | bookingexperts.com/about-us | Confirmed |
| Revenue (estimated) | €8M–€12M ARR | Growjo.com ($13.4M), Prospeo.io ($8.4M), ZoomInfo ($5.4M) — triangulated estimate adjusted for EUR/USD | Estimated |
| Profitability | Likely profitable (bootstrapped, no losses reported, 15-yr track record) | Inference from no external funding required | Estimated |
| GDPR compliance | Yes — Dutch entity, privacy policy published | bookingexperts.com/privacy-policy | Confirmed |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary vertical | Vacation/holiday park management software (PMS) | bookingexperts.com | Confirmed |
| Secondary verticals | Campsites, glamping, resorts, hotels, rental organizations, project developers | bookingexperts.com/about-us | Confirmed |
| Primary market | Netherlands | bookingexperts.com; LinkedIn company page | Confirmed |
| International markets | 14 countries (names not fully disclosed; UK confirmed via ParcVu; Bonaire mentioned in testimonials) | bookingexperts.com/about-us; parcvu.com | Confirmed |
| Customer count | 800+ recreation companies | bookingexperts.com/about-us | Confirmed |
| User count | 126,000+ | bookingexperts.com/about-us | Confirmed |
| NL market position | Self-described as leading platform in Dutch recreation sector | bookingexperts.nl ("Het #1 platform voor de recreatiebranche") | Estimated |
| Key competitors (NL) | RecreatieSoftware, CampSite Manager, RMS Cloud, other PMS vendors | Tracxn; hoteltechreport.com comparisons | Estimated |
| Key competitor (UK) | ParcVu (now a strategic partner/investment) | parcvu.com | Confirmed |
| Customer segments | Holiday parks (primary), campsites, resorts, hotels, rental organizations | bookingexperts.com/about-us | Confirmed |
| UK market entry | Via ParcVu strategic investment (Sep 2024) | bookingexperts.com/blogs/booking-experts-and-parcvu | Confirmed |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | BEX PMS — cloud-based Property Management System | bookingexperts.com/reservation-system | Confirmed |
| Website builder | BEX CMS — website builder and real estate site generator | bookingexperts.com/bex-cms | Confirmed |
| Marketing service | Booking Boosters — SEO, SEA, affiliate, social media for recreation clients | bookingexperts.com/marketing | Confirmed |
| Channel management | Yes — multi-channel distribution (Booking.com, Airbnb, OTAs) | bookingexperts.com/channel-management | Confirmed |
| Booking engine | Yes — direct booking via park's own website | bookingexperts.com/booking-engine | Confirmed |
| Business intelligence | Yes — BEX BI and Booking Analytics (premium tool) | bookingexperts.com/business-inteligence | Confirmed |
| Owner portal | Yes — transparency dashboard for property owners | bookingexperts.com/owner-portal | Confirmed |
| App Store / marketplace | Yes — open developer App Store; third-party app integrations | bookingexperts.com/app-store | Confirmed |
| Multilingual support | Yes — BEX Linguist (automated guest communication in multiple languages) | bookingexperts.com/linguist | Confirmed |
| Payment integration | Mollie (confirmed partner); likely also Stripe/iDEAL | mollie.com/integrations/bookingexperts | Confirmed |
| API type | OpenAPI (REST); supports OAuth2 and API Key authentication | developers.bookingexperts.com | Confirmed |
| Webhooks | Yes — real-time event-driven integrations | developers.bookingexperts.com/docs/intro | Confirmed |
| Core technology stack | Ruby on Rails (backend); Kubernetes (K8S) orchestration; Terraform (IaC) | jobs.bookingexperts.com/en/departments/engineering | Confirmed |
| Deployment model | Cloud-native SaaS | jobs.bookingexperts.com/en/departments/engineering | Confirmed |
| Cloud provider | Not publicly named; cloud-native per engineering page | jobs.bookingexperts.com/en/departments/engineering | Estimated |
| On-premise option | No indication; cloud-only model | Multiple product pages | Estimated |
| CRM capability | Reservation management, guest communication — partial CRM | bookingexperts.com/reservation-system | Confirmed |
| Group/multi-park | Yes — Concerns & Groups / Multiparks product tier | bookingexperts.com/reservation-system/multiparks | Confirmed |

### Subscription / Pricing Model

| Tier | Price | Contract Term | Key Limits | Source |
|---|---|---|---|---|
| Starter | €295/month | 1 year minimum | Up to 20 objects, 3 channels, 6 users | bookingexperts.com/pricing | 
| Premium | From €495/month | 3 years minimum | Up to 10 channels, 3 locations, 20 users | bookingexperts.com/pricing |
| Ultimate | Price on request | 5 years minimum | Unlimited channels/integrations, owner portal, priority support | bookingexperts.com/pricing |
| Concerns & Groups | Price on request | Custom | Multi-location enterprise tier | bookingexperts.com/pricing |

> No per-booking commission charged — pure SaaS subscription model. Long minimum contract terms (3–5 years on upper tiers) create strong revenue visibility and switching friction.

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership | Ali Ilboga, founder — single controlling owner (estimated) | bookingexperts.com/about-us; LinkedIn | Confirmed |
| External investors | None | tracxn.com; crunchbase.com | Confirmed |
| PE involvement | None | Multiple sources | Confirmed |
| Family in management | Maureen Ilboga (COO) — same surname, likely spouse or family member | jobs.bookingexperts.com/en/people/1786751-maureen | Estimated |
| Succession plan | Not publicly stated; no C-suite succession plan disclosed | No public source | Unknown |
| Founder age estimate | Not publicly disclosed | No public source | Unknown |
| Succession signal — COO family | The presence of a family member as COO could indicate owner-managed continuity OR could mean the business is family-run without exit intent | Inference | Estimated |
| Outbound M&A activity | ParcVu investment (Sep 2024) — suggests capital is available and strategic thinking is active | bookingexperts.com/blogs/booking-experts-and-parcvu | Confirmed |
| Acquisition appetite | No inbound acquisition signals identified; no fundraising signals | Multiple sources | Estimated |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue estimate (2024–2026 range) | €8M–€12M ARR | Growjo, Prospeo, ZoomInfo — triangulated | Estimated |
| Revenue growth signal | Customer base grew from 60,000 users (our-story page, older version) to 126,000 users — ~2× growth in recent years | bookingexperts.com/about-us vs our-story page (60k users mentioned) | Estimated |
| Employee count (current) | 150+ | bookingexperts.com/about-us | Confirmed |
| Employee growth signal | Grew from ~51–100 to 150+ range; second office opened ~2022 | Multiple sources | Estimated |
| Customer count growth | From reference to 700+ companies (Tracxn/2024) to 800+ (about-us 2026) | tracxn.com; bookingexperts.com/about-us | Estimated |
| International expansion | 14 countries; ParcVu UK investment; Head of International Growth hired | bookingexperts.com/about-us; rocketreach | Confirmed |
| Product expansion | Booking Analytics (premium BI tool) launched; BEX Linguist (multilingual) added; Booking Boosters added 2017 | bookingexperts.com/about-us | Confirmed |
| Knowledge event | Hosted "Embrace 2026 Level Up" (March 2026) — recreation sector leadership conference | vakantiehuisvandetoekomst.nl | Confirmed |
| Headcount velocity | 150 employees across 14 countries suggests active international hiring | bookingexperts.com/about-us | Confirmed |

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary vertical | Recreation / vacation park PMS — deep specialist | bookingexperts.nl ("Het #1 platform voor de recreatiebranche") | Confirmed |
| Vertical coverage | Full recreation stack: reservations, channel management, CMS, marketing, BI, owner portal, payments | bookingexperts.com | Confirmed |
| Payment integrations | Mollie (primary confirmed partner); iDEAL (NL standard, inferred) | mollie.com/integrations/bookingexperts | Confirmed |
| OTA channel integrations | Booking.com, Airbnb, Expedia (inferred from channel management product) | bookingexperts.com/channel-management | Estimated |
| GDPR compliance | Dutch entity; privacy policy aligned with GDPR | bookingexperts.com/privacy-policy | Confirmed |
| Sector knowledge events | Hosts "Embrace" conference for recreation sector; "BEX Educate Pro" and "BEX Educate NextGen" training programs | bookingexperts.com; vakantiehuisvandetoekomst.nl | Confirmed |
| Switching costs | High — long-term contracts (3–5 yrs), deep system integration with parks' websites, channels, payments, and owner portals | bookingexperts.com/pricing | Confirmed |
| Defensibility | Specialization in recreation PMS creates a network effect; App Store ecosystem creates partner lock-in | bookingexperts.com/app-store | Estimated |
| Community / training | BEX Educate Pro (ongoing training for professionals), BEX Educate NextGen (next generation) | bookingexperts.com/bex-educate-pro | Confirmed |

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Business model | Pure SaaS subscription (no per-booking commission); annual/multi-year contracts | bookingexperts.com/pricing | Confirmed |
| Revenue streams | (1) PMS/BEX subscription; (2) BEX CMS subscription; (3) Booking Boosters (marketing agency fees); (4) BEX Linguist; (5) Booking Analytics premium | bookingexperts.com | Confirmed |
| ARR estimate | €8M–€12M (mid-point ~€10M) | Growjo, Prospeo, ZoomInfo — triangulated and EUR-adjusted | Estimated |
| ARR per customer (blended estimate) | ~€10,000–€15,000 per recreation company per year (blended across tiers) | Derived: 800 customers × €12,500 avg = €10M ARR | Estimated |
| Gross margin estimate | Likely 70–80% (cloud SaaS with recurring revenue; no COGS for hardware) | Industry benchmark for vertical SaaS | Estimated |
| EBITDA margin estimate | 20–35% (bootstrapped, no debt service, likely lean operations) | Industry benchmark for bootstrapped vertical SaaS | Estimated |
| Acquisition value range | **€15M–€35M** (2.0–3.5× ARR at ~€10M ARR; SaaS vertical specialist; no PE premium but mission-critical software) | SaaS M&A multiples 2024–2026 for vertical SMB SaaS; bootstrapped discount vs PE-backed | Estimated |
| Revenue quality | High — multi-year contracts (3–5 years for premium tiers) reduce churn risk significantly | bookingexperts.com/pricing | Confirmed |
| Churn risk | Low — deep integrations (channel manager, website, payments, owner portals) make switching extremely costly for parks | bookingexperts.com/pricing; product depth | Confirmed |
| Upside drivers | UK expansion via ParcVu; international hiring (14 countries); premium BI product launch | bookingexperts.com | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | **4** | Founder-owned with no PE; clean B.V. structure; family-managed (Maureen Ilboga as COO) slightly reduces sale urgency but no overhang blockers | tracxn.com; bookingexperts.com/about-us |
| **Revenue scale fit** | High | **4** | Estimated €8M–€12M ARR fits SolStein €1M–€15M target range; likely profitable given 15-yr bootstrapped track record; upper end of target range | Growjo; Prospeo; ZoomInfo |
| **Geographic fit** | High | **5** | HQ in Enschede, NL; primary market is Netherlands; 14 countries with NL as dominant base; perfect geographic fit | bookingexperts.com/about-us |
| **Tech stack modernity** | Medium | **5** | Ruby on Rails (modern, maintainable); Kubernetes + Terraform (cloud-native DevOps); OpenAPI with OAuth2; App Store marketplace; zero legacy on-premise | jobs.bookingexperts.com/en/departments/engineering; developers.bookingexperts.com |
| **Customer lock-in** | Medium | **5** | 3–5 year minimum contracts on upper tiers; deep integration with parks' websites, channels, payments, and owner portals; App Store ecosystem with third-party partners | bookingexperts.com/pricing |
| **Vertical depth** | Medium | **5** | Self-described "#1 platform" in NL recreation sector; full-stack solution (PMS + CMS + marketing + BI + payments + owner portal); sector-specific training (BEX Educate); 15 years of domain knowledge | bookingexperts.nl; bookingexperts.com/about-us |
| **Integration potential** | Low | **5** | Public OpenAPI; REST-based; OAuth2 and API Key auth; webhooks; App Store developer ecosystem already active | developers.bookingexperts.com |
| **Growth trajectory** | Low | **4** | User base doubled (60k → 126k); customer count growing (700+ → 800+); UK expansion via ParcVu; Head of International Growth hired; 14-country presence; slightly below 5 due to no verified revenue growth data | bookingexperts.com/about-us; rocketreach |

### Composite Score Calculation

| Dimension | Weight Factor | Score | Weighted Score |
|---|---|---|---|
| Ownership attractiveness | 3 | 4 | 12 |
| Revenue scale fit | 3 | 4 | 12 |
| Geographic fit | 3 | 5 | 15 |
| Tech stack modernity | 2 | 5 | 10 |
| Customer lock-in | 2 | 5 | 10 |
| Vertical depth | 2 | 5 | 10 |
| Integration potential | 1 | 5 | 5 |
| Growth trajectory | 1 | 4 | 4 |
| **Total** | **17** | | **78 / 85 max** |

**Composite Score**: **4.59 / 5.00** (78 ÷ 17 weighted dimensions)

---

### Confidence Band

| Metric | Value |
|---|---|
| Data points Confirmed | ~65% |
| Data points Estimated | ~30% |
| Data points Unknown | ~5% |
| **Confidence band** | **Medium-High** — core thesis confirmed; revenue and succession are the two largest unknowns |

---

### Overall M&A Assessment

**TIER 1 TARGET — HIGH ATTRACTIVENESS**

Booking Experts is the strongest M&A candidate identified in the Dutch HORECA IT landscape to date. It is:

- **Clean**: No PE, no debt, single founder-owned B.V., no complex holding structure
- **Profitable**: 15 years bootstrapped with no external capital required
- **Defensible**: Self-described NL market leader in recreation PMS; mission-critical software with 3–5 year contracts
- **Modern**: Cloud-native Ruby on Rails stack with Kubernetes/Terraform DevOps and a developer-facing OpenAPI
- **Sticky**: App Store ecosystem and deep park integrations make churning prohibitively expensive for customers
- **In-range**: Estimated €8M–€12M ARR sits at the top of SolStein's target range

The primary risks are:
1. **Valuation expectation**: A market-leading bootstrapped SaaS may command a 3–5× ARR multiple (€25M–€50M+), which exceeds SolStein's typical target range
2. **Founder not seeking exit**: The ParcVu outbound investment signals Ali Ilboga is building, not selling
3. **Family management**: Maureen Ilboga as COO could mean the business is a family asset with no exit intent
4. **Revenue uncertainty**: No public financials; €8M–€12M is an estimate with significant uncertainty

---

### Recommended Next Step

1. **Priority**: Establish back-channel introduction to Ali Ilboga — ideally via a shared recreation sector contact, industry event (Booking Experts hosts "Embrace" conference), or via the ParcVu relationship
2. **Framing**: Lead with partnership / platform consolidation narrative (similar to ParcVu model), NOT an acquisition approach
3. **Information request**: Obtain last 3 years of filed accounts via KvK (publicly available for B.V.) to verify revenue and profitability before any formal approach
4. **Timing**: Monitor for any signals of growth plateau, founder fatigue, or succession planning — these would dramatically improve acquisition probability
5. **Alternative entry**: Consider approaching as a customer or App Store partner first to build trust and understand the platform from the inside

---

*Sources consulted: bookingexperts.com/about-us, bookingexperts.com/pricing, bookingexperts.com/our-story, bookingexperts.com/privacy-policy, jobs.bookingexperts.com, developers.bookingexperts.com, tracxn.com/booking-experts, crunchbase.com/organization/booking-experts, growjo.com/company/Booking_Experts_B.V., prospeo.io/c/booking-experts, zoominfo.com/c/booking-experts-bv, rocketreach.co/booking-experts-bv-management, mollie.com/integrations/bookingexperts, bookingexperts.com/blogs/booking-experts-and-parcvu, parcvu.com/blog/parcvus-new-partnership-with-booking-experts, northdata.de (KvK 55796850), creditsafe.com/booking-experts-bv-nl03186915*
