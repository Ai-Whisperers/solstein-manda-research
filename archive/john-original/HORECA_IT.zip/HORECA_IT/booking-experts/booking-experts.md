# Booking Experts

**Category**: Vacation Rental/PMS
**Country**: NL
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history Booking Experts @HORECA_IT/booking-experts/
@research-horeca-company Booking Experts @HORECA_IT/booking-experts/
```
