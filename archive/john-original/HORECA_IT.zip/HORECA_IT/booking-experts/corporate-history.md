# Booking Experts — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Due Diligence — Corporate History & Ownership Trace

---

## 1. Identity & Legal Entity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Booking Experts B.V. | bookingexperts.com/privacy-policy | Confirmed |
| KvK number | 55796850 | bookingexperts.com/privacy-policy; creditsafe.com | Confirmed |
| Registered address | Pantheon 28, 7521 PR, Enschede, Netherlands | bookingexperts.com/privacy-policy | Confirmed |
| Legal form | Besloten Vennootschap (B.V.) — private limited company | northdata.de (KvK 55796850) | Confirmed |
| Entity registration date | 2012 (Booking Experts B.V.) | creditsafe.com/booking-experts-bv-nl03186915 | Estimated |
| Predecessor / prior trade name | Expert Webdesign | northdata.de (prior name listed same KvK); bookingexperts.com/about-us | Confirmed |
| Primary domain | bookingexperts.com / bookingexperts.nl | bookingexperts.com | Confirmed |

---

## 2. Founding History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year of business operations | 2011 | bookingexperts.com/about-us | Confirmed |
| Founding year of predecessor entity (Expert Webdesign) | 2002 | bookingexperts.com/about-us; jobs.bookingexperts.com/en/locations | Confirmed |
| Founder | Ali Ilboga | bookingexperts.com/about-us; tracxn.com | Confirmed |
| Founder background | Software developer; passion for technology and leisure industry | bookingexperts.com/about-us | Confirmed |
| Origin story | Expert Webdesign built recreation company websites but lacked integrated booking capability; led to creation of Booking Experts in 2011 | jobs.bookingexperts.com/en/locations | Confirmed |
| Original problem identified | Holiday parks lost bookings because guests had to call reception or use external OTAs; no direct booking on parks' own sites | jobs.bookingexperts.com/en/locations | Confirmed |

---

## 3. Ownership Structure

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Current ownership type | Founder-owned, privately held | tracxn.com; prospeo.io | Confirmed |
| External funding raised | None (unfunded) | tracxn.com; crunchbase.com (public profile, no rounds listed) | Confirmed |
| Private equity involvement | None identified | tracxn.com; multiple sources | Confirmed |
| Holding company structure | No holding company identified | northdata.de (KvK 55796850 — single entity) | Estimated |
| Family involvement | Maureen Ilboga (COO) — same surname as founder Ali Ilboga, suggesting family ownership/management | jobs.bookingexperts.com/en/people/1786751-maureen; mollie.com/success-stories/booking-experts | Estimated |
| Shareholder register | Not publicly disclosed (B.V. — not required to disclose) | KvK standard B.V. rules | Confirmed |

---

## 4. Name Changes & Rebrands

| Date | Event | Detail | Source | Confidence |
|---|---|---|---|---|
| 2002 | Founded as Expert Webdesign | Web design company serving recreation and other sectors | bookingexperts.com/about-us | Confirmed |
| 2011 | Rebranded / pivoted to Booking Experts | Launched cloud-based reservation system for recreation sector | bookingexperts.com/about-us | Confirmed |
| 2012 | Booking Experts B.V. formally registered | KvK registration of legal entity as Booking Experts B.V. | creditsafe.com | Estimated |
| 2017 | Booking Boosters launched | Separate marketing service brand established within/alongside the company | jobs.bookingexperts.com/en/locations | Confirmed |

> Note: northdata.de lists "Expert Webdesign" as a prior name under KvK 55796850, confirming continuity of the same legal entity through the rebrand.

---

## 5. M&A Events

| Date | Event Type | Target / Partner | Detail | Source | Confidence |
|---|---|---|---|---|---|
| September 2024 | Strategic investment (minority stake) | ParcVu (UK) | Booking Experts invested in ParcVu, a UK-based holiday park software provider with 35+ years of market experience. ParcVu branded itself "ParcVu powered by Booking Experts." | bookingexperts.com/blogs/booking-experts-and-parcvu; parcvu.com/blog | Confirmed |
| No other M&A events | — | — | No acquisitions received or made (other than ParcVu) found in public sources | Multiple sources | Estimated |

---

## 6. Investment Rounds & Investors

| Round | Date | Amount | Investors | Source | Confidence |
|---|---|---|---|---|---|
| None | — | — | No external investment rounds identified | tracxn.com (unfunded); crunchbase.com (no rounds) | Confirmed |

> Booking Experts has grown entirely bootstrapped since 2002 / 2011. All growth appears self-funded from recurring subscription revenues.

---

## 7. Key Leadership & Critical Events Timeline

| Year | Event | Significance |
|---|---|---|
| 2002 | Ali Ilboga founds Expert Webdesign | Origin of the company; primarily web design for recreation sector |
| 2011 | Expert Webdesign pivots and launches Booking Experts | Cloud reservation system born; company rebrands |
| 2012 | Booking Experts B.V. formally registered with KvK | Legal formalization under current entity name |
| 2017 | Booking Boosters marketing agency launched | Extension into recreation marketing (SEO, SEA, social); adds recurring revenue stream |
| ~2022 | Second office opened in Amersfoort (NL) | Geographic expansion within Netherlands; reflects growth |
| 2024 (mid) | Company reaches 800+ recreation company customers | Scale milestone; near 126k users |
| Sep 2024 | Strategic investment in ParcVu (UK) | First known international M&A/investment; signals UK expansion ambition |
| 2026 | Company reports 150+ employees in 14 countries | International presence confirmed |

---

## 8. Corporate Structure Diagram

```mermaid
graph TD
    A["Ali Ilboga\n(Founder & CEO)"] --> B["Booking Experts B.V.\nKvK 55796850\nEnschede, NL"]
    B --> C["BEX PMS\n(Core Reservation Platform)"]
    B --> D["BEX CMS\n(Website Builder)"]
    B --> E["Booking Boosters\n(Marketing Agency, est. 2017)"]
    B --> F["ParcVu (UK)\n(Strategic Investment, Sep 2024)"]

    G["Maureen Ilboga\n(COO)"] --> B
    H["Coen van Rhee\n(CCO)"] --> B
    I["Stefan\n(CTO)"] --> B

    style B fill:#1a73e8,color:#fff,stroke:#1558b0
    style F fill:#f9ab00,color:#000,stroke:#e37400
    style A fill:#34a853,color:#fff,stroke:#1e8449
```

---

## 9. Historical Timeline Diagram

```mermaid
timeline
    title Booking Experts — Corporate Timeline
    2002 : Expert Webdesign founded by Ali Ilboga
         : Web design for recreation sector
    2011 : Pivoted to Booking Experts
         : Cloud reservation system launched
         : Ali Ilboga as Director/Owner (Jan 2011)
    2012 : Booking Experts B.V. registered (KvK 55796850)
         : Legal entity formally established
    2017 : Booking Boosters marketing agency launched
         : Recreation-focused SEO/SEA/social marketing
    2022 : Amersfoort office opened
         : Second NL location; 100+ employees milestone
    2024 : 800+ recreation companies on platform
         : Strategic investment in ParcVu (UK, Sep 2024)
         : UK market entry via partnership/investment
    2026 : 150+ employees in 14 countries
         : 126k users; 800+ leisure companies
```

---

## 10. M&A Feasibility Assessment — From Corporate History

| Dimension | Assessment | Rationale | Confidence |
|---|---|---|---|
| Ownership clarity | **High** | Single founder (Ali Ilboga) with no known external investors; clean B.V. structure; family-run management (Maureen Ilboga, COO) | Confirmed |
| PE overhang | **None** | Zero external funding identified across all databases (Crunchbase, Tracxn, Prospeo) | Confirmed |
| Succession risk | **Moderate–High** | Founder is both CEO and likely controlling shareholder; no obvious next-generation successor identified; Maureen Ilboga as COO could be a succession candidate or co-owner — softens acquisition rationale | Estimated |
| M&A openness signals | **Ambiguous** | ParcVu investment (Sep 2024) shows capital deployment willingness and strategic thinking; however, this was an outbound investment, not a sale signal | Confirmed |
| Name/brand stability | **High** | Single rebrand (Expert Webdesign → Booking Experts) in 2011; brand stable for 15 years | Confirmed |
| Legal simplicity | **High** | Single B.V. entity; no complex holding structure identified; clean KvK record | Estimated |
| Valuation premium risk | **Moderate** | Bootstrapped, likely profitable; founder may have high price expectations given market leadership position | Estimated |

### Overall M&A History Assessment

Booking Experts presents a **clean, founder-controlled corporate history** with no PE overhang, no distressed financing, and a single legal entity. The company has never been acquired and has never raised external capital. The September 2024 ParcVu investment demonstrates that Ali Ilboga is willing to allocate capital strategically — suggesting he is commercially active and not simply running a lifestyle business. However, this outbound investment also signals that he may be pursuing independent growth rather than seeking an exit. The family presence (Maureen Ilboga as COO) reduces the probability of an unsolicited approach succeeding without careful relationship-building.

**Recommended approach**: Relationship-driven outreach to Ali Ilboga, framing any discussion around partnership first (similar to the ParcVu model) before moving to acquisition conversation.

---

*Sources consulted: bookingexperts.com/about-us, bookingexperts.com/privacy-policy, northdata.de (KvK 55796850), creditsafe.com/booking-experts-bv, tracxn.com/booking-experts, crunchbase.com/organization/booking-experts, jobs.bookingexperts.com, parcvu.com/blog/parcvus-new-partnership-with-booking-experts, mollie.com/success-stories/booking-experts*
