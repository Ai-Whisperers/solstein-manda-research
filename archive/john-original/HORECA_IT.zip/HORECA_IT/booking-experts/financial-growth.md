# Financial & Growth Deep-Dive — Booking Experts B.V.

**Research Date**: 2026-04-30
**Data Availability**: Low–Medium (private Dutch B.V.; KvK filings confirmed filed but P&L data behind paywall; revenue reconstructed from employee proxy, pricing model, and third-party estimates)

---

## Revenue Timeline

| Year | Revenue | Currency | EUR Equivalent | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| 2026 (est.) | €11.5M–€14M | EUR | €11.5M–€14M | ~20–22% | 150 emp × €100K proxy; customer-ARR model (800 customers × ~€1,100/mo avg) | Estimated (proxy) |
| 2025 | €10M–€12M | EUR | €10M–€12M | ~20–25% | Growjo $13.4M (≈€12.4M); Prospeo $8.4M (≈€7.8M); blended estimate | Estimated |
| 2024 | €8.5M–€10.5M | EUR | €8.5M–€10.5M | ~15–20% | ~100-employee period; customer count ~750–800; pricing model calc | Estimated (proxy) |
| 2023 | €7M–€9M | EUR | €7M–€9M | ~18–22% | ~60–84 employees (Growjo snapshot); 700–750 customers; pricing model | Estimated (proxy) |
| 2022 | €5.5M–€7M | EUR | €5.5M–€7M | ~15–20% | ~50–60 employees; Amersfoort office opened; second office signals growth | Estimated (proxy) |
| 2021 | €4M–€6M | EUR | €4M–€6M | — | ~35–50 employees; App Store launched; 10th anniversary | Estimated (proxy) |

> **Notes on Revenue Estimation Methodology**:
> - KvK 55796850 has filed balance sheets for 31/12/2024 and 31/12/2022 (confirmed by Northdata), but revenue/P&L data is not publicly accessible (paywalled; Dutch B.V. in this size tier typically files abbreviated accounts)
> - Growjo estimate ($13.4M ≈ €12.4M) and Prospeo estimate ($8.4M ≈ €7.8M) use ML regression on employee count + web signals; snapshot date uncertain (likely 2024 data)
> - ZoomInfo estimate ($5.4M ≈ €5.0M) is likely stale (based on old headcount of 11–50 employees)
> - Pricing model cross-check: 800 customers × blended avg €1,100/month = €10.6M ARR; plus Booking Boosters marketing fees (~15–20% uplift) = €12–13M total revenue — consistent with Growjo
> - Employee proxy: Dutch vertical SaaS benchmark €100K–€150K revenue/employee; 150 employees → €15M–€22.5M is the high-proxy ceiling; lower end (€100K/employee) chosen given SaaS gross margin normalization

**Revenue CAGR (3yr, 2022→2025, midpoints)**: ~24%
**Revenue CAGR (5yr, 2020→2025)**: Not calculable — no pre-2021 data

### Revenue Trend Chart

```mermaid
xychart-beta
    title "Booking Experts Revenue Trend (EUR M, estimated midpoints)"
    x-axis [2021, 2022, 2023, 2024, 2025]
    y-axis "EUR Millions" 0 --> 14
    line [5.0, 6.25, 8.0, 9.5, 11.0]
```

---

## Profitability

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| EBITDA (current) | Unknown — no public filing | KvK filing not publicly accessible | Unknown |
| EBITDA Margin (estimate) | 20–35% | Industry benchmark for bootstrapped vertical SaaS with no debt service | Estimated |
| Net Profit / Loss | Not disclosed; inferred positive given 15-yr bootstrapped track record and zero external capital needed | Inference — no fundraising = self-sustaining | Estimated |
| Recurring Revenue % | ~90–100% | Pure SaaS subscription model; no per-booking commission; multi-year contracts | Confirmed (business model) |
| SaaS / Subscription Revenue % | ~80–85% (rest: Booking Boosters marketing agency, one-time setup fees) | bookingexperts.com/pricing; bookingexperts.com/marketing | Confirmed (business model) |
| Revenue per Employee (EUR) | ~€67K–€93K (at €10M–€14M rev / 150 employees) | Calculated | Estimated |

> Revenue per employee is slightly below Dutch SaaS median (~€120K) due to the Booking Boosters marketing agency division (labour-intensive) inflating headcount relative to SaaS-only revenue.

---

## Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Sep 2024 | Strategic investment (outbound — Booking Experts invested INTO ParcVu) | Undisclosed | Booking Experts B.V. (as investor) | Not disclosed | bookingexperts.com/blogs/booking-experts-and-parcvu; parcvu.com/about | Confirmed |
| 2002–present | Bootstrapped — zero external rounds raised | — | None | Not applicable | tracxn.com; crunchbase.com/organization/booking-experts | Confirmed |

**Total Raised**: Bootstrapped — no external funding received. All growth self-funded from recurring subscription revenues since 2002/2011.
**Latest Valuation**: Not applicable — private/bootstrapped. M&A estimate from deep-analysis: €15M–€35M (2.0–3.5× ARR at ~€10M ARR).
**Current Investors**: Founder-owned (Ali Ilboga). No PE, no VC, no angel investors identified.
**War Chest Signals**: ParcVu investment in Sep 2024 demonstrates available cash for strategic deployment. Balance sheets filed with KvK for 31/12/2024 and 31/12/2022 — cash on hand and equity not publicly disclosed. Likely operationally profitable given bootstrapped 24-year track record.

---

## Employee Timeline

| Year | Headcount | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- |
| 2026 (current) | 150+ | ~36–50% vs 2024 | bookingexperts.com/about-us | Confirmed |
| 2025 | ~120–135 | ~20–35% | Interpolated from 100+ (2024) and 150+ (2026) | Estimated |
| 2024 | 100+ | ~25–40% | jobs.bookingexperts.com/en (timeline: "In 2024, we grew to a team of over 100 people") | Confirmed |
| 2023 | ~60–84 | ~25–53% | Confirmed at 60 (early 2023 milestone); Growjo snapshot ~84 (mid/late 2023) | Confirmed (60 milestone); Estimated (84 snapshot) |
| 2022 | ~50–60 | ~15–25% | Amersfoort office opened + Enschede office move = growth signals; Growjo prior period implies ~55 | Estimated |
| 2021 | ~40–50 | — | 10th anniversary year; pre-App Store launch; no explicit headcount data | Estimated |

**Employee CAGR (3yr, 2023→2026 at confirmed midpoints)**: ~36% (60 → 150 employees)
**Current Open Positions**: 9 active roles listed on jobs.bookingexperts.com (April 2026) — Software Engineer, Technical Partner Manager, Business Development (UK), Product Compliance Manager, DevOps Engineer, Product Designer, Product Manager Integrations, Product Manager, open application
**Hiring Hotspots**: Enschede (HQ, primary), Zwolle (new 2024 office), Chester/UK (ParcVu / Business Development UK role active)

### Employee Growth Chart

```mermaid
xychart-beta
    title "Booking Experts Employee Growth"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "Headcount" 0 --> 160
    line [45, 55, 72, 110, 128, 150]
```

---

## Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2011 | Company founded | Netherlands | Enschede HQ; NL holiday park market primary from day 1 | bookingexperts.com/about-us | Confirmed |
| ~2019–2022 | Gradual international expansion | 14 countries (unspecified) | Company reports 14-country presence by 2026; specific timeline per country not disclosed | bookingexperts.com/about-us | Estimated |
| 2022 | Second NL office | Netherlands | Amersfoort office opened for central NL client coverage | jobs.bookingexperts.com/en | Confirmed |
| 2022 | New HQ | Netherlands | Move to Kennispark Enschede — larger facility for growth | jobs.bookingexperts.com/en | Confirmed |
| Sep 2024 | Strategic investment in ParcVu | United Kingdom | Booking Experts invested into ParcVu (UK holiday park software, 35+ yr history). ParcVu rebranded "ParcVu powered by Booking Experts". UK market entry via established platform. | bookingexperts.com/blogs/booking-experts-and-parcvu; parcvu.com/about | Confirmed |
| 2024 | Market expansion | Germany, France | "Great progress in Germany, France, and England" — first confirmed continental European international push beyond legacy 14 countries | jobs.bookingexperts.com/en (timeline) | Confirmed |
| 2024 | New NL office | Netherlands (Zwolle) | Third NL office in Zwolle; supports national scale-up | jobs.bookingexperts.com/en | Confirmed |
| 2024 | UK entity | United Kingdom | "Booking Experts Ltd." registered at Bromley, UK (Companies House 12054674) — UK subsidiary for ParcVu/UK operations | northdata.com search results | Estimated |

**Primary Market**: Netherlands (NL) — self-described "#1 platform for the Dutch recreation sector"
**International Revenue %**: Not disclosed. International expansion active but NL still dominant (estimated 75–85% NL revenue)
**Expansion Trajectory**: Accelerating — from NL-focused platform to active UK/DE/FR push in 2024. The ParcVu investment is the primary international vector; Head of International Growth role active in the org chart. 14-country presence suggests organic international adoption preceding the 2024 structured push.

---

## M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Sep 2024 | ParcVu (UK holiday park software) — strategic investment by Booking Experts | Undisclosed | UK holiday park market access; 35+ yr UK customer relationships; ParcVu rebranded "ParcVu powered by Booking Experts" | Enter UK market with established local brand; accelerate Booking Experts platform adoption in UK; give ParcVu EU market access via Booking Experts infrastructure | bookingexperts.com/blogs/booking-experts-and-parcvu; parcvu.com/about; leisure360.be | Confirmed |

**Divestitures**: None identified
**M&A Pattern**: Single outbound strategic investment (ParcVu, Sep 2024) — consistent with an organic-growth-first company making its first international platform bet. The deal structure (investment + rebrand rather than outright acquisition) mirrors a "land and expand" approach to UK market entry. ParcVu's "about" page now describes itself as "part of Booking Experts", suggesting effective operational integration if not formal full acquisition. No further M&A events found in any public database.

---

## SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | Cloud-native SaaS — no on-premise option | jobs.bookingexperts.com/en/departments/engineering; multiple product pages | Confirmed |
| Cloud Revenue % (current) | 100% — no on-premise option exists | Product pages; engineering job descriptions | Confirmed |
| Recurring Revenue % | ~90–100% — pure subscription; no per-booking commission; multi-year contracts | bookingexperts.com/pricing | Confirmed |
| Payment Integrations | Mollie (confirmed partner — iDEAL, Bancontact, credit card); Stripe inferred from stack | mollie.com/integrations/bookingexperts; bookingexperts.com/pricing | Confirmed (Mollie); Estimated (Stripe) |
| Platform Stack | Ruby on Rails (backend); Kubernetes (orchestration); Terraform (IaC); PostgreSQL inferred | jobs.bookingexperts.com/en/departments/engineering | Confirmed |
| API / Integration Model | OpenAPI (REST) with OAuth2 and API Key auth; webhooks; open developer App Store (partner ecosystem) | developers.bookingexperts.com; bookingexperts.com/app-store | Confirmed |
| Migration Status | Complete — cloud-native from founding (2011); no legacy migration in progress | Product architecture; engineering job descriptions | Confirmed |

---

## Growth Scorecard

| Dimension | Score (1-10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | **7** | Estimated 3yr CAGR ~22–24% (proxy-based); consistent with Growjo $13.4M from a ~€5M 2021 base; fits 7–8 band (20–30% CAGR) but limited data confidence |
| Funding Momentum | **3** | Bootstrapped — no external funding raised; profitable self-funded growth earns a 3 per rubric ("bootstrap with evident profitability"); ParcVu outbound investment shows capital capacity, not incoming funding |
| Employee Growth | **9** | 3yr CAGR ~36% (60 → 150 employees, 2023→2026); aggressive hiring across NL (3 offices), UK, DE, FR; exceeds 25% threshold for score 9–10 |
| Geographic Expansion | **8** | UK (via ParcVu, Sep 2024), Germany, France all entered in 2024; new Zwolle NL office; 14-country presence; Head of International Growth role active; scores 8 for "2–3 new countries, new offices, active international push" |
| M&A Activity | **5** | 1 strategic investment/acquisition (ParcVu, Sep 2024) — clear market-entry rationale (UK) and capability-building; scores 5 per rubric ("1–2 small acquisitions, or strategic investment/partnership") |
| SaaS Maturity | **10** | Cloud-native from founding (2011); 100% recurring SaaS subscription; OpenAPI REST with OAuth2 + webhooks; Mollie iDEAL/Bancontact; App Store ecosystem; Ruby on Rails + Kubernetes + Terraform; zero legacy on-premise; fully satisfies all score-10 criteria |
| **COMPOSITE SCORE** | **7.0** | **Rocket** — Explosive organic employee growth, aggressive international expansion, mature SaaS architecture; funding score anchors composite at the low end of Rocket threshold |

**Classification Thresholds**:

- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

> **Classification**: **ROCKET (7.0)** — Booking Experts sits at the exact Rocket/Riser boundary. The low Funding Momentum score (3) for being bootstrapped structurally anchors the composite. Operationally, the employee growth, SaaS maturity, and geographic push are firmly in Rocket territory. The bootstrapped score reflects absence of VC capital — not underperformance. A founder-funded Rocket with exceptional SaaS fundamentals.

### Growth Scorecard Chart

```mermaid
xychart-beta
    title "Booking Experts Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [7, 3, 9, 8, 5, 10]
```

---

## Key Financial Intelligence Summary

| Insight | Detail | Implication for SolStein |
| --- | --- | --- |
| Revenue not publicly filed | KvK balance sheets filed (12/2024, 12/2022) but P&L not accessible; Dutch B.V. micro/small exemption likely | **Action**: Request last 3 years filed accounts directly via KvK purchase (€15/document) before any formal approach |
| ARR estimate range is wide | €8M–€12M (midpoint €10M) — triangulated from 4 independent methods; Growjo high at €12.4M | **Risk**: Revenue could be at €8M floor (Prospeo) or €13M ceiling (Growjo); significant valuation swing |
| 150 employees > revenue implies | Rev/employee ~€67–93K — below NL SaaS median; inflated by Booking Boosters marketing staff | **Upside**: Excluding Booking Boosters, core PMS SaaS margins likely higher; consider segment carve-out valuation |
| ParcVu is strategic, not cosmetic | ParcVu rebranded as "powered by Booking Experts"; UK entity registered; UK BD sales role active | **Signal**: Ali Ilboga is actively building, not preparing for exit — acquisition approach requires relationship-first framing |
| 3-5 year contract terms | Upper tiers lock customers for 3–5 years minimum | **Upside**: Revenue visibility is exceptional; churn risk near zero on active cohorts; NRR likely >110% |
| No external funding in 24 years | Confirms management discipline and likely strong cash generation | **Confirmation**: No investor to negotiate with; sole founder (Ali Ilboga) controls 100% of the deal decision |

---

## Data Gaps & Research Limitations

| Gap | Description | How to Close |
| --- | --- | --- |
| Official revenue / P&L | KvK filings exist but are not free-access | Purchase jaarrekeningen via kvk.nl/bestellen/ (€15/document); 2022 and 2024 balance sheets confirmed filed |
| EBITDA and net margin | Not publicly disclosed | Obtainable from KvK filing if P&L included (not guaranteed for small B.V.) |
| ParcVu deal structure & size | "Investment" vs "acquisition" terminology inconsistent across sources; price undisclosed | Request from Companies House UK (Booking Experts Ltd., Companies House 12054674) for any share transfer filings |
| Historical revenue 2018–2020 | No data pre-2021 found in any public source | KvK historical filings (2018–2020) if available; Wayback Machine for old press releases |
| Exact customer count by year | Only milestone snapshots (700+ in 2024, 800+ in 2026) | Not closeable from public sources without insider data |

---

*Sources consulted: bookingexperts.com/about-us, bookingexperts.com/pricing, jobs.bookingexperts.com/en (company timeline), developers.bookingexperts.com, growjo.com/company/Booking_Experts_B.V., prospeo.io/c/booking-experts, zoominfo.com/c/booking-experts-bv, tracxn.com/booking-experts, crunchbase.com/organization/booking-experts, northdata.com (KvK 55796850 — balance sheet filings confirmed for 12/2022 and 12/2024), parcvu.com/about, bookingexperts.com/blogs/booking-experts-and-parcvu, leisure360.be/en/productnieuws/booking-experts-sluit-strategisch-partnership, mollie.com/integrations/bookingexperts, kvk.nl/en/ordering-products/financial-statements/*
