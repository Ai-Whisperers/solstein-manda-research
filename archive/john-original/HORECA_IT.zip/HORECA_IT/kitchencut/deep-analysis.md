# Kitchen CUT — Deep Analysis

**Category**: Kitchen / F&B Operations Management (Recipe, Stock, Procurement, Allergens)
**Country**: UK (Henley-on-Thames, Oxfordshire, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; bootstrapped; strong product profile, wrong geography)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | KITCHEN CUT LIMITED | Companies House 07757271 | Confirmed |
| HQ | Henley-on-Thames, Oxfordshire, UK | LinkedIn, kitchencut.com | Confirmed |
| Founded | 2011 | PitchBook, Getlatka | Confirmed |
| Founder | John Wood | johnwoodconsultancy.com | Confirmed |
| CEO | Bill Winthrop | Getlatka | Estimated |
| Ownership | Bootstrapped; founder/management-owned | Getlatka, PitchBook | Confirmed |
| Employees | ~19–20 | PitchBook, Getlatka | Estimated |
| Revenue (2024) | ~$2.8M | Getlatka | Estimated |
| Customers | ~2,000 | Getlatka | Estimated |
| External funding | $0 | Getlatka, PitchBook | Confirmed |
| Business model | SaaS subscription (per site / per user) | kitchencut.com | Confirmed |
| Product | Cloud F&B back-of-house platform: menu engineering, recipe costing, stock, procurement, allergens | kitchencut.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Primary | kitchencut.com | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | Not a stated market | kitchencut.com | Estimated |
| HORECA verticals | Hotels, restaurants, contract caterers, hospitality groups | kitchencut.com | Confirmed |
| Customer count | ~2,000 | Getlatka | Estimated |
| Target customer | Multi-site hospitality operators; hotels; contract caterers | kitchencut.com | Confirmed |
| Market position | Niche UK back-of-house provider; one of few cloud-native F&B ops platforms | kitchencut.com | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Menu engineering | Recipe-level profitability analysis | kitchencut.com | Confirmed |
| Recipe costing | Real-time ingredient cost tracking | kitchencut.com | Confirmed |
| Stock control | Inventory management + waste tracking | kitchencut.com | Confirmed |
| Procurement | Supplier management + purchase orders | kitchencut.com | Confirmed |
| Allergen management | 14-allergen tracking; nutritional labelling | kitchencut.com | Confirmed |
| Integrations | 400+ EPOS, accounting, and delivery integrations | kitchencut.com | Confirmed |
| Deployment | Cloud SaaS | kitchencut.com | Confirmed |
| Tech stack | Cloud-native; API-first | kitchencut.com | Estimated |
| Key differentiator | Integrated back-of-house: recipe → stock → procurement → reporting | kitchencut.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Ownership | Bootstrapped; John Wood (founder) + Bill Winthrop (CEO) | Getlatka, Crunchbase | Estimated |
| PE backing | None | Getlatka | Confirmed |
| Founder transition | John Wood appears to have shifted to consultancy role | johnwoodconsultancy.com | Estimated |
| Succession signal | Possible — founder transitioning; CEO Bill Winthrop may be successor | johnwoodconsultancy.com | Estimated |
| Exit interest | Unknown — no public signals | — | Unknown |

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Employees | Customers | Source | Confidence |
|---|---|---|---|---|---|
| 2024 | ~$2.8M | ~20 | ~2,000 | Getlatka | Estimated |
| Revenue per employee | ~$140K | Derived | Estimated |
| Revenue per customer | ~$1,400/year | Derived | Estimated |

Revenue per customer of ~$1,400/year (~£1,100) is reasonable for a back-of-house SaaS platform. The lean team suggests strong margins. No growth rate data available.

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK allergen compliance | Full Natasha's Law / UK FIR 14-allergen system | kitchencut.com | Confirmed |
| UK VAT compliance | VAT-aware cost and pricing management | kitchencut.com | Estimated |
| UK food hygiene | Integration with food safety records | kitchencut.com | Estimated |
| Contract catering | Strong track record in contract catering and education | kitchencut.com | Confirmed |
| Menu labelling | Nutritional and allergen labelling | kitchencut.com | Confirmed |
| Gross profit analysis | Real-time GP analysis by recipe and menu section | kitchencut.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | Monthly/annual SaaS subscription per site | kitchencut.com | Confirmed |
| ARR estimate | ~£2.2M (based on $2.8M revenue) | Getlatka | Estimated |
| Acquisition value | £5M–£15M (2–6x ARR for niche bootstrapped SaaS) | Industry comparable | Estimated |
| Profitability | Likely profitable (lean team, bootstrapped) | Inferred | Estimated |
| SolStein fit | Geography = UK only; otherwise strong profile | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 4 | Bootstrapped founder-managed; no PE; possible succession signal (founder to consultancy) | Getlatka, johnwoodconsultancy.com |
| Revenue scale fit | High | 4 | ~$2.8M ARR — within SolStein's €1–15M target range | Getlatka |
| Geographic fit | High | 1 | UK (Oxfordshire) only; no NL/BE market strategy | kitchencut.com |
| Tech stack modernity | Medium | 5 | Cloud-native; 400+ integrations; modern API-first | kitchencut.com |
| Customer lock-in | Medium | 5 | Back-of-house data (recipes, costs, stock) creates very high switching costs | kitchencut.com |
| Vertical depth | Medium | 5 | Deep back-of-house F&B: recipe + stock + procurement + allergen | kitchencut.com |
| Integration potential | Low | 5 | 400+ EPOS/accounting integrations | kitchencut.com |
| Growth trajectory | Low | 3 | Organic growth; bootstrapped; steady but not high-growth | Getlatka |

### Composite Score

**Weighted Composite: 3.2 / 5.0**

*(High scores on ownership, revenue, tech stack, lock-in, vertical depth — pulled down by geographic fit = 1)*

**Confidence Band**: Low-Medium — revenue from Getlatka (estimated); ownership/succession partially confirmed.

### Overall M&A Assessment

Kitchen CUT scores the **highest composite in the UK Tier 3 cohort so far** — but remains a non-target for SolStein because its geography (UK, Oxfordshire) is outside the NL/BE focus area. If SolStein's investment thesis ever expands to include UK targets, Kitchen CUT would warrant a closer look: bootstrapped, profitable, £2M+ ARR, deep HORECA vertical, founder transitioning.

**Immediate action**: Use Kitchen CUT as the **benchmark specification** for a NL/BE back-of-house F&B platform search. Companies like Horeko (NL) and Apicbase (BE) serve this category and should be evaluated against this profile.

### Recommended Next Step

No pursuit (UK only). Use as ideal-profile reference for NL/BE back-of-house F&B management company search.

---

*Sources: Companies House (07757271), kitchencut.com, PitchBook, Getlatka, johnwoodconsultancy.com, Crunchbase.*
