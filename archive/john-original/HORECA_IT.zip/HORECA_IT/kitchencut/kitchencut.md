# KitchenCut

**Category**: Kitchen
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history KitchenCut @HORECA_IT/kitchencut/
@research-horeca-company KitchenCut @HORECA_IT/kitchencut/
```
