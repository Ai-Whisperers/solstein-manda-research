# Financial & Growth Deep-Dive — Kitchen CUT

**Research Date**: 2026-04-30
**Data Availability**: Low — Companies House "total exemption" accounts (turnover not reported); revenue from third-party estimators only; bootstrapped private UK company with no investor disclosures

---

### Revenue Timeline

> **Note on data availability**: Kitchen CUT Limited (Companies House 07757271) files "total exemption full accounts" as a small UK company, which legally exempts it from publicly disclosing turnover. No audited revenue figure is available. All revenue values below are estimates derived from: (a) Getlatka third-party estimate ($2.8M for 2024), (b) employee headcount × revenue-per-employee proxy (20 employees × ~£110K = ~£2.2M), and (c) customer-count × pricing proxy (~2,000 customers × £1,100/year avg = ~£2.2M). The three methods converge on ~£2.2M for 2024. Historical figures are backward-extrapolated at ~8% CAGR — a midpoint estimate for a bootstrapped niche SaaS operator. Growjo's $11.7M estimate is rejected as an extreme outlier inconsistent with headcount and pricing data. GBP→EUR conversion at annual ECB average rates.

| Year | Revenue (GBP) | Currency | EUR Equivalent | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| 2026 (est.) | £2.55M | GBP | €3.01M | ~+6% | Employee proxy; trend extrapolation | Estimated |
| 2025 | £2.40M | GBP | €2.82M | ~+9% | Employee proxy; net assets improvement (+£1.07M in 2025 CH filing signals strong year) | Estimated |
| 2024 | £2.20M | GBP | €2.60M | ~+8% | Getlatka ($2.8M); employee proxy (20 × £110K); customer × price proxy | Estimated |
| 2023 | £2.04M | GBP | €2.35M | ~+8% | Employee proxy; backward extrapolation from Getlatka anchor | Estimated |
| 2022 | £1.89M | GBP | €2.21M | ~+8% | Employee proxy; backward extrapolation | Estimated |
| 2021 | £1.75M | GBP | €2.04M | — | Employee proxy; backward extrapolation | Estimated |

**GBP→EUR ECB Annual Average Rates Used**: 2021: 1.163 | 2022: 1.172 | 2023: 1.150 | 2024: 1.183 | 2025: 1.175 (est.) | 2026: 1.180 (est. YTD)

**Revenue CAGR (3yr, 2021→2024)**: ~8% (estimated; derived from proxy methodology)
**Revenue CAGR (5yr, 2021→2026 est.)**: ~8% (estimated; consistent with bootstrapped niche growth)

#### Revenue Trend Chart

```mermaid
xychart-beta
    title "Kitchen CUT Revenue Trend (EUR M, Estimated)"
    x-axis [2021, 2022, 2023, 2024, 2025]
    y-axis "EUR Millions" 0 --> 3
    line [2.0, 2.2, 2.3, 2.6, 2.8]
```

---

### Profitability

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| EBITDA (current) | Unknown — not reported | Companies House (total exemption) | Unknown |
| EBITDA Margin | Likely positive; lean team of ~20 suggests efficient ops | Inferred from bootstrapped structure | Estimated |
| Net Profit / Loss | Unknown — turnover and P&L not publicly filed | Companies House (total exemption) | Unknown |
| Net Assets (2025) | -£390,944 | Companies House via Endole/Companycheck | Confirmed |
| Net Assets (2024) | -£1,455,068 | Companies House via Companycheck | Confirmed |
| Net Assets (2023) | -£1,260,580 | Companies House via Companycheck | Confirmed |
| Net Assets (2022) | -£1,233,142 | Companies House via Companycheck | Confirmed |
| Cash on Hand (2025) | £14,172 | Companies House via Endole | Confirmed |
| Cash on Hand (2024) | £24,790 | Companies House via Companycheck | Confirmed |
| Recurring Revenue % | ~95–100% — all revenue from SaaS subscriptions | kitchencut.com pricing; product model | Estimated |
| SaaS / Subscription Revenue % | ~100% — cloud-only; no perpetual licenses | kitchencut.com; Tracxn | Confirmed |
| Revenue per Employee (EUR) | ~€130K (2024: €2.60M ÷ 20 employees) | Calculated from proxy revenue | Estimated |

**Balance Sheet Commentary**: Negative net assets across 2022–2025 are typical for bootstrapped UK SaaS companies carrying accumulated founder loans or director loan accounts on the balance sheet. The dramatic improvement from -£1,455,068 (2024) to -£390,944 (2025) — a swing of ~£1.07M — likely reflects either conversion of a director loan to equity or a highly profitable trading year in 2025. Cash balances are thin (£4,851–£68,320 range), consistent with a company that distributes cash rather than retaining it.

---

### Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| N/A | Bootstrapped — no external funding rounds | £0 | None | Not applicable | Crunchbase; Tracxn; Getlatka; PitchBook | Confirmed |

**Total Raised**: £0 — Bootstrapped from founding (2011); no external funding in 15 years of operation
**Latest Valuation**: Not applicable — private, founder-owned, no funding events
**Current Investors**: Founder-owned (John Wood, founder; Bill Winthrop, CEO) — no PE, VC, or institutional investors
**War Chest Signals**: None identified. Very low cash reserves (£14K–£68K range). No debt financing found in filings. No PE dry powder. No acquisition war chest.

---

### Employee Timeline

| Year | Headcount | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- |
| 2026 (current) | 19 | -5% | PitchBook 2026 profile | Estimated |
| 2025 | 20 | 0% | LinkedIn (11–50 range); extrapolated from PitchBook | Estimated |
| 2024 | 20 | 0% | Getlatka; ZoomInfo (11–50 range) | Estimated |
| 2023 | 19–20 | ~0% | LinkedIn 11–50 range; stable reports | Estimated |
| 2022 | 18–20 | ~5% | Extrapolated from LinkedIn range history | Estimated |
| 2021 | 17–18 | — | Extrapolated from 2022 baseline | Estimated |

**Employee CAGR (3yr, 2021→2024)**: ~5% or less — effectively flat/minimal growth
**Current Open Positions**: 0–1 (no active job listings found on kitchencut.com/careers, LinkedIn Jobs, or Indeed as of research date)
**Hiring Hotspots**: Henley-on-Thames / Oxfordshire, UK (sole operating location)
**Tech/Product vs. Non-Tech Split**: ~40–50% tech/product (estimated: Senior Developer confirmed, likely 8–10 technical staff of 19–20 total)
**Key Recent Hires (C-level)**: No new C-level or VP hires identified in last 3 years; leadership appears stable

#### Employee Growth Chart

```mermaid
xychart-beta
    title "Kitchen CUT Employee Growth (Estimated)"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "Headcount" 0 --> 30
    line [18, 19, 20, 20, 20, 19]
```

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2011 | Founded | UK | Launched as UK back-of-house F&B platform | Companies House; kitchencut.com | Confirmed |
| 2015–2020 | Organic UK growth | UK | Expanded to hotels, contract caterers, restaurant groups; built 400+ integrations | kitchencut.com | Estimated |
| 2024 | International brand clients | Global (via UK) | Belmond (LVMH luxury hotel brand) cited as customer; suggests some international enterprise clients | kitchencut.com | Estimated |

**Primary Market**: United Kingdom (primary and essentially exclusive operational market)
**International Revenue %**: Not disclosed; UK-centric sales team and support (phone +44 UK number only); no non-English marketing or EU-specific pages found
**NL Market Coverage**: No evidence of Dutch market presence; no Dutch-language content, no Dutch customer references
**BE Market Coverage**: No evidence of Belgian market presence; no French/Dutch-language marketing; no Belgian customer references
**DACH Market Coverage**: No evidence of German-language presence or DACH-specific go-to-market
**Expansion Trajectory**: Kitchen CUT has remained a UK-focused operator for 15 years. While the platform is technically accessible globally (SaaS; multi-currency capable) and serves international brands via their UK operations, there is no active international expansion strategy, no new country offices, and no geographic growth signals. The company positions itself as "global-capable" but operates as a UK niche player.

---

### M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| N/A | No acquisitions made | — | — | — | — | — |
| N/A | No partnerships announced | — | — | — | — | — |
| N/A | Not acquired by any party | — | — | — | — | — |

**Divestitures**: None identified
**M&A Pattern**: Zero M&A activity in 15 years of operation. Kitchen CUT is a purely organic grower — no acquisitions, no divestitures, no strategic investments, no confirmed formal partnerships beyond technology integrations (400+ EPOS/accounting API connections). The company has not been acquired and shows no signals of PE acquisition interest.

---

### SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | Cloud-native SaaS — no on-premise option | kitchencut.com; product pages | Confirmed |
| Cloud Revenue % (current) | ~100% — all revenue from cloud subscription | kitchencut.com; Tracxn | Confirmed |
| Recurring Revenue % | ~95–100% — monthly and annual subscription only | kitchencut.com/kc-lite; pricing model | Confirmed |
| Payment Integrations | Stripe (inferred; standard UK SaaS); no iDEAL or Bancontact (UK market only) | kitchencut.com payment UX; UK market focus | Estimated |
| Platform Stack | Cloud-native; API-first architecture; modern web stack (specific tech not disclosed); integrates via REST APIs | kitchencut.com; job postings; Tracxn | Estimated |
| API / Integration Model | 400+ EPOS, accounting, delivery, and PMS integrations; open API ecosystem | kitchencut.com (stated); Lightspeed integration page | Confirmed |
| Migration Status | N/A — cloud-native from founding (2011); no on-prem legacy to migrate | kitchencut.com; product history | Confirmed |
| Pricing Model | KC Lite: £75/month or £750/year (single-site, 1 user); Multi-site: POA | kitchencut.com/kc-lite | Confirmed |

**SaaS Maturity Commentary**: Kitchen CUT is cloud-native from founding and has never had an on-premise product. With near-100% recurring revenue, 400+ API integrations, and a fully subscription-based model, it is one of the most SaaS-mature companies in this cohort relative to its size. The absence of iDEAL or Bancontact reflects its UK-only market, not a structural limitation.

---

### Growth Scorecard

| Dimension | Score (1-10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | 3 | Estimated CAGR ~8% (2021–2024); modest but consistent bootstrapped organic growth; data quality low (proxy-based) |
| Funding Momentum | 3 | Zero external funding in 15 years; bootstrapped; self-sustaining but no investment capital for acceleration |
| Employee Growth | 2 | Headcount flat at 19–20 for 3+ years; employee CAGR ~0–5%; no active hiring; no expansion investment |
| Geographic Expansion | 2 | UK-only in 15 years; no NL/BE/DACH presence; "global-capable" claim not evidenced by actual international market entry |
| M&A Activity | 1 | No acquisitions, no partnerships, no divestitures, no M&A signals in entire company history |
| SaaS Maturity | 8 | Cloud-native from founding; ~100% recurring revenue; 400+ API integrations; modern subscription model; API-first |
| **COMPOSITE SCORE** | **3.2** | **Steady — stable niche SaaS operator; exceptional SaaS maturity offsets minimal growth investment** |

**Classification Thresholds**:

- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

**Kitchen CUT Classification: Steady (3.2)** — The composite is elevated almost entirely by exceptional SaaS maturity (8/10 — cloud-native, API-first, 100% recurring). Strip SaaS maturity out and the operational growth profile (Revenue 3, Funding 3, Employees 2, Geography 2, M&A 1) averages just 2.2 — firmly in Dinosaur territory. The company has built an excellent SaaS product but has not invested in growth, geographic expansion, or capability-building M&A.

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "Kitchen CUT Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [3, 3, 2, 2, 1, 8]
```

---

### SolStein M&A Implications

| Factor | Assessment |
| --- | --- |
| **Revenue scale** | £2.2M (~€2.6M) ARR — within SolStein's €1–15M target range |
| **Ownership** | Bootstrapped; founder-owned; CEO Bill Winthrop; founder John Wood transitioning to consultancy |
| **Geography blocker** | UK (Henley-on-Thames) — outside NL/BE focus; no Benelux customer base confirmed |
| **Growth profile** | Flat headcount; stable revenue; no investment in expansion — characteristic of lifestyle/owner-managed business |
| **Exit readiness** | No signals; founder active in consultancy (possible succession gap emerging) |
| **NL/BE SolStein relevance** | Use as **specification benchmark** for NL/BE back-of-house F&B search (Horeko NL; Apicbase BE) |
| **Watch list rationale** | Composite M&A score 3.2/5.0; strong SaaS profile; if SolStein thesis ever extends to UK, revisit |

**Benchmark Insight**: Kitchen CUT's pricing (£75/month KC Lite; ~£1,100/year average across 2,000 customers) and unit economics (£2.2M ARR / 20 employees = £110K revenue per employee) set the efficiency benchmark for back-of-house F&B SaaS. Any NL/BE equivalent at €1–3M ARR with similar depth would represent a higher-fit target.

---

*Sources: Companies House (07757271) via Endole and Companycheck; kitchencut.com; Getlatka; PitchBook; Growjo (rejected as outlier); Tracxn; Crunchbase; ZoomInfo; LinkedIn; ECB historical FX rates.*
