# KitchenCut — Corporate History

**Category**: Kitchen / F&B Operations Management
**Country**: UK (Henley-on-Thames, Oxfordshire, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; bootstrapped, founder-operated)

---

## Summary Assessment

Kitchen CUT is a **bootstrapped, founder-operated** F&B operations management software company based in Henley-on-Thames, Oxfordshire. Founded in 2011, it provides cloud-based menu engineering, recipe costing, stock control, procurement, and allergen management for hospitality operators. With ~20 employees, ~$2.8M revenue (2024), and no external funding, it is a profitable niche SaaS operator — but UK-only and outside SolStein's NL/BE geographic focus. Useful as a **kitchen management software benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Kitchen CUT | kitchencut.com | Confirmed |
| Legal entity | KITCHEN CUT LIMITED | Companies House 07757271 | Confirmed |
| Companies House No. | 07757271 | gov.uk Companies House | Confirmed |
| HQ | Henley-on-Thames, Oxfordshire, UK | LinkedIn, kitchencut.com | Confirmed |
| Founded | 2011 | PitchBook, Getlatka | Confirmed |
| Founder | John Wood | johnwoodconsultancy.com, Crunchbase | Confirmed |
| CEO | Bill Winthrop | Getlatka | Estimated |
| Employees | ~19–20 | PitchBook, Getlatka | Estimated |
| Revenue (2024) | ~$2.8M | Getlatka | Estimated |
| Customers | ~2,000 | Getlatka | Estimated |
| External funding | $0 (bootstrapped) | Getlatka, PitchBook | Confirmed |
| Companies House accounts | Filed Dec 31, 2025 (FY accounts) | Companies House | Confirmed |
| Product | Cloud F&B ops: menu engineering, recipe costing, stock, procurement, allergen/nutrition | kitchencut.com | Confirmed |
| Integrations | 400+ APIs (EPOS, accounting, delivery) | kitchencut.com | Confirmed |
| Target customers | Hotels, restaurants, contract caterers, hospitality groups | kitchencut.com | Confirmed |

---

## Founding & History

**John Wood**, a hospitality consultant, founded **Kitchen CUT in 2011** to solve a perennial problem in F&B operations: the lack of integrated, affordable back-of-house software connecting recipe management, stock control, procurement, and allergen compliance. Unlike front-of-house POS systems, the back-of-house management layer had been largely neglected by cloud SaaS providers.

Kitchen CUT built a cloud-native F&B operations platform with integrations to 400+ EPOS and accounting systems. **Bill Winthrop** joined or took over as CEO (exact transition date not confirmed), while John Wood transitioned to consultancy (as evidenced by his separate consulting website referencing Kitchen CUT).

The company has grown organically to ~$2.8M revenue with ~20 employees and ~2,000 customers by 2024 — a lean, profitable operation. No external investors have been taken on. Companies House filings remain current (accounts filed December 2025 for FY ending prior).

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["John Wood (Founder)"]
    B["Bill Winthrop (CEO)"]
    C["KITCHEN CUT LIMITED<br/>(Companies House 07757271)<br/>(Henley-on-Thames, Oxfordshire)"]
    D["~2,000 hospitality customers<br/>(hotels, restaurants, caterers)"]

    A -->|"Founder"| C
    B -->|"CEO"| C
    C --> D
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Kitchen CUT — Key Milestones
    2011 : Founded by John Wood in UK; cloud back-of-house F&B management platform
    2015-2020 : Organic growth; 400+ EPOS integrations; UK hospitality customer base built
    2024 : ~$2.8M revenue; ~20 employees; ~2,000 customers; zero external funding
    2025 : Companies House accounts filed Dec 2025; active operations
```

---

## M&A Feasibility Assessment

### Is Kitchen CUT an Acquisition Target for SolStein?

**Answer: Not suitable — UK (Oxfordshire); outside SolStein's NL/BE geography.**

| Factor | Assessment |
|---|---|
| **Geography** | UK only — Henley-on-Thames; no NL/BE presence |
| **Scale** | ~$2.8M revenue — within SolStein's ARR range |
| **Ownership** | Bootstrapped founder/owner-managed — positive ownership structure |
| **Succession** | John Wood (founder) appears to have transitioned to consultancy — possible succession signal |
| **Vertical** | Back-of-house F&B operations — strong vertical depth |

Kitchen CUT would be **very attractive** on most SolStein dimensions (bootstrapped, founder-owned, £1–3M ARR, deep HORECA vertical) if it were in NL/BE. Its UK geography is the primary blocker.

### Role for SolStein

1. **Kitchen management benchmark**: Defines cloud back-of-house F&B ops (recipe costing + stock + procurement + allergen) — the product category for SolStein's NL/BE equivalent search.
2. **NL/BE opportunity**: A NL/BE equivalent of Kitchen CUT (founder-owned, €1–3M ARR, back-of-house F&B management) would be a high-fit SolStein target. Companies like Horeko (NL) may be comparable.
3. **Revenue benchmark**: ~$2.8M revenue / ~20 employees / ~2,000 customers = efficient SaaS metrics.

---

*Sources: Companies House (07757271), kitchencut.com, PitchBook, Getlatka, johnwoodconsultancy.com, Crunchbase.*
