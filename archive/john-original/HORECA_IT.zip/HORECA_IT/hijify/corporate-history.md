# HiJiffy — Corporate History & Ownership

**Category**: Guest Engagement / AI Hotel Chatbot
**Country of incorporation**: Portugal
**Operational presence**: Portugal (HQ), Spain, UK, France — NL/BE minimal
**Research Date**: 2026-04-30
**Research Status**: Done

---

## Data Point Register

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | HiJiffy (trading name; full legal TBC from PT commercial register) | hijiffy.com | Estimated |
| Country of incorporation | Portugal | Tracxn, Portugal Ventures portfolio | Confirmed |
| Headquarters | Vidigueira, Portugal (registered); Lisbon offices | hijiffy.com/about, hijiffy.com/contact-us | Confirmed |
| Additional offices | Lisbon, Porto, Barcelona | hijiffy.com/about | Confirmed |
| Belgian entity/office | None found | hijiffy.com/contact-us, web search | Confirmed (absent) |
| NL entity/office | None found | hijiffy.com/contact-us, web search | Confirmed (absent) |
| Founding year (official) | 2016 (website), 2015 (Tracxn) | hijiffy.com/about vs tracxn.com | Estimated — 2016 per founders |
| Co-founder / CEO | Tiago Araújo | hijiffy.com/about, LinkedIn | Confirmed |
| Co-founder / COO | Pedro Gonçalves | hijiffy.com/about, LinkedIn | Confirmed |
| Co-founder / CTO | José Mendonça | hijiffy.com/about, LinkedIn | Confirmed |
| Founders still active | Yes — all three remain in operating roles | LinkedIn profiles, company website | Confirmed |
| Prior background | Digital marketing agency in Lisbon | irishtechnews.ie | Estimated |
| Incorporation accelerators | Lisbon Challenge, NUMA Barcelona | irishtechnews.ie | Estimated |
| Ownership type | VC-backed (Portuguese institutional VCs) | Tracxn, Crunchbase | Confirmed |
| Total funding raised | ~$6.77M (≈€6.2M) across 3 rounds | Tracxn | Confirmed |
| Seed Round 1 (Nov 2020) | ~$3.14M — Portugal Ventures (lead) | Tracxn | Confirmed |
| Seed Round 2 (Jun 2023) | ~$4.8M (€3.8M) — Caixa Capital Risc (lead), Lince Capital, Portugal Ventures | hijiffy.com/news, thesaasnews.com | Confirmed |
| Grant (Jun 2023) | ~$1.04M — European Commission (Horizon 2020) | hijiffy.com/news, Tracxn | Confirmed |
| Last funding date | Jun 21, 2023 | Tracxn | Confirmed |
| Post-money valuation (Jun 2023) | Not publicly disclosed | — | Unknown |
| M&A offer received | April 2025 (not completed) | GetLatka | Estimated |
| PE ownership | None | Tracxn | Confirmed |
| Acquisitions made | None | Tracxn | Confirmed |
| Employees (Mar 2026) | 64 | Tracxn (Mar 31, 2026) | Confirmed |
| Employees (2025) | ~57 | GetLatka | Estimated |
| Revenue 2025 | ~$6.3M (≈€5.8M) | GetLatka | Estimated |
| Revenue growth claim | "Annual growth above 100%" (CEO, Jun 2023) | hijiffy.com/news | Estimated |
| Hotel customers | 2,600+ in 50+ countries | hijiffy.com/about | Confirmed |
| Primary markets | UK, France, Portugal, Spain | hijiffy.com/news (Jun 2023) | Confirmed |
| NL/BE customer presence | Some customers (Enlyft lists NL/BE users) | enlyft.com, whiteskyhospitality.com | Estimated |
| Sifted 50 Southern Europe 2024 | Ranked #11 (fastest-growing) | Instagram/@hijiffy, sifted.eu | Confirmed |
| Key partnership: Booking.com | Sep 2024 integration | travolution.com | Confirmed |
| Key partnership: Expedia Group | Mar 2025 integration | traveldailymedia.com | Confirmed |
| Key partnership: RoomRaccoon (NL) | Jul 2025 | travolution.com | Confirmed |
| Core product | Aplysia OS — AI Guest Communications Hub | hijiffy.com | Confirmed |
| Stage (Tracxn) | Seed | Tracxn | Confirmed |

---

## Corporate Timeline

```mermaid
timeline
    title HiJiffy Corporate Timeline
    2015/2016 : Founded in Lisbon, Portugal
              : Co-founders: Tiago Araújo (CEO), Pedro Gonçalves (COO), José Mendonça (CTO)
              : Origins in digital marketing agency
    2017–2019 : Product development
              : Lisbon Challenge & NUMA Barcelona accelerators
              : Early hotel chatbot deployments
    2020      : Seed Round 1 — ~$3.1M
              : Lead investor: Portugal Ventures
              : Asia partnership (Delivering Group)
    2021      : Active expansion to UK and France
              : Post-pandemic demand for automation accelerates adoption
    2022      : Virtual Concierge product launch (Apr)
              : AI voice assistant beta (Dec)
              : Salesforce CRM integration
    2023      : Seed Round 2 — €3.8M (Jun)
              : Lead: Caixa Capital Risc; also Lince Capital, Portugal Ventures
              : EU Horizon 2020 grant (~€1M)
              : Brand refresh ("Aplysia OS" launched)
              : 2,100+ hotels served; 50+ countries
    2024      : Sifted 50 Southern Europe — ranked #11
              : Booking.com integration partnership (Sep)
              : Aplysia 3 with RAG technology released
    2025      : Expedia Group integration (Mar)
              : RoomRaccoon (NL PMS) partnership (Jul)
              : Revenue reaches ~$6.3M
              : ~57–64 employees
              : M&A offer received (Apr) — not completed
    2026      : 2,600+ hotels, 64 employees
              : Operating independently; no PE; VC-backed
```

---

## Corporate Structure

```mermaid
graph TD
    A["HiJiffy (Portugal)\n[Seed stage, ~64 employees]"] --> B["Tiago Araújo — CEO/Co-founder"]
    A --> C["Pedro Gonçalves — COO/Co-founder"]
    A --> D["José Mendonça — CTO/Co-founder"]

    E["Portugal Ventures\n(Portuguese state VC)"] -->|"Minority stake\n(2020 + 2023)"| A
    F["Caixa Capital Risc\n(Portuguese banking VC)"] -->|"Lead investor\n(Jun 2023)"| A
    G["Lince Capital\n(Portuguese VC)"] -->|"Minority stake\n(Jun 2023)"| A
    H["European Commission\n(Horizon 2020)"] -->|"Grant ~€1M\n(Jun 2023)"| A

    A --> I["HQ: Vidigueira / Lisbon, Portugal"]
    A --> J["Office: Porto, Portugal"]
    A --> K["Office: Barcelona, Spain"]
    A --> L["Remote team: PT, ES, FR, DE, UK"]

    style A fill:#4a90d9,color:#fff
    style E fill:#f0a500,color:#fff
    style F fill:#f0a500,color:#fff
    style G fill:#f0a500,color:#fff
    style H fill:#6cb26c,color:#fff
```

---

## Ownership Analysis

HiJiffy is **not founder-owned in the SolStein sense**. Three Portuguese institutional VCs (Portugal Ventures, Caixa Capital Risc, Lince Capital) hold minority stakes following two funding rounds totalling ~$6.77M. The co-founders remain operationally active and likely retain majority control (stake percentages not publicly disclosed), but the VC structure means:

- Any acquisition requires VC consent and likely structured return expectations
- Portugal Ventures is a government-backed fund (Caixa Geral de Depósitos) — exit preferences may differ from commercial VCs
- No PE overhang in the traditional sense, but three institutional co-owners complicate a clean bilateral acquisition

The April 2025 "M&A offer" noted by GetLatka suggests the company has already fielded acqui-hire or full acquisition interest and opted not to proceed. This may indicate founders are not ready to exit, or price expectations exceeded buyer appetite.

---

## Belgium / Netherlands Presence Assessment

| Aspect | Finding | Confidence |
|---|---|---|
| Belgian legal entity | None found | Confirmed (absent) |
| NL legal entity | None found | Confirmed (absent) |
| Physical office in BE or NL | None — offices in PT and ES only | Confirmed (absent) |
| NL/BE as named primary market | No — primary markets are UK, FR, PT, ES | Confirmed |
| NL/BE hotel customers | Some (Enlyft data, RoomRaccoon NL partnership Jul 2025) | Estimated |
| NL PMS integration (RoomRaccoon) | Confirmed partnership Jul 2025 | Confirmed |
| Belgian hotel customers | Possible via international platform; not specifically marketed | Unknown |

The original brief noted a "Belgian office/operations presence (Ghent)." Research finds **no evidence** of a HiJiffy Belgian office. A LinkedIn post mentioning "new HQ in Ghent" referenced pi Life Sciences (a different company). HiJiffy has no physical Benelux presence as of April 2026.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Ownership complexity** | Three institutional VC co-owners — acquisition requires structured exit; not a simple bilateral founder deal |
| **Founder readiness** | Founders active and engaged; no public succession signals; declined M&A offer (Apr 2025) |
| **Geographic fit for SolStein** | Poor — company is Portuguese/Spanish/French/UK focused; NL/BE is incidental, not strategic |
| **Revenue fit** | Within range (€5.8M) but growing rapidly — valuation likely above SolStein's typical range |
| **Deal complexity** | High — multi-party VC exit, cross-border (PT→NL), AI SaaS valuation premium likely 4–8× ARR |
| **Overall feasibility** | **Low** — VC-backed, non-NL/BE primary market, no succession signal, likely in growth mode not exit mode |

**Recommended classification**: Tier 2 — Secondary / Watch List (blocker: VC-backed, wrong geography as primary market)

---

## Sources

| Source | URL | Type |
|---|---|---|
| HiJiffy About page | https://www.hijiffy.com/about | Primary (company) |
| HiJiffy Contact page | https://www.hijiffy.com/contact-us | Primary (company) |
| HiJiffy €3.8M funding news | https://www.hijiffy.com/news/hijiffy-raises-3-8-million-euros-in-funding | Primary (company) |
| Tracxn company profile | https://tracxn.com/d/companies/hijiffy/... | Secondary (database) |
| Portugal Ventures portfolio | https://www.portugalventures.pt/en/portfolio/hijiffy/ | Secondary (investor) |
| GetLatka revenue data | https://getlatka.com/companies/hijiffy.com | Secondary (estimated) |
| Crunchbase profile | https://www.crunchbase.com/organization/hijiffy | Secondary (database) |
| Phocuswire funding article | https://www.phocuswire.com/hijiffy-ai-chatbot-funding | Secondary (press) |
| Travolution — RoomRaccoon | https://www.travolution.com/news/roomracoon-partners-with-ai-platform-hijiffy/ | Secondary (press) |
| Sifted 50 Southern Europe 2024 | https://sifted.eu/leaderboards/southern-europe-2024 | Secondary (ranking) |
