# HiJiffy — Deep Analysis

**Category**: Guest Engagement / AI Hotel Chatbot
**Country**: Portugal (HQ); Spain (office); NL/BE — incidental customer presence only
**Research Date**: 2026-04-30

---

## 1. Company Fundamentals

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Full name | HiJiffy (trading name; Portuguese legal entity) | hijiffy.com | Estimated |
| Founded | 2016 (official website), 2015 (Tracxn) | hijiffy.com/about, Tracxn | Estimated |
| HQ | Vidigueira, Portugal (registered); Lisbon (operational) | hijiffy.com/contact-us | Confirmed |
| Offices | Lisbon, Porto (PT), Barcelona (ES) | hijiffy.com/about | Confirmed |
| Countries active | Remote team in PT, ES, FR, DE, UK; customers in 50+ countries | hijiffy.com/about | Confirmed |
| Employees | 64 as of Mar 31, 2026; ~57 in 2025 | Tracxn (Mar 2026), GetLatka | Confirmed / Estimated |
| Revenue (2025) | ~$6.3M (≈€5.8M) | GetLatka | Estimated |
| Ownership | VC-backed: Portugal Ventures, Caixa Capital Risc, Lince Capital | Tracxn, Phocuswire | Confirmed |
| Co-founders | Tiago Araújo (CEO), Pedro Gonçalves (COO), José Mendonça (CTO) | hijiffy.com/about | Confirmed |
| Founders still active | Yes — all three in operating roles | LinkedIn, company website | Confirmed |
| Stage | Seed (last round Jun 2023) | Tracxn | Confirmed |
| Total funding | ~$6.77M (≈€6.2M) in 3 rounds | Tracxn | Confirmed |

**Summary**: HiJiffy is a Portuguese-founded, Lisbon-headquartered AI hospitality tech company. All three co-founders remain operationally active. The company is VC-backed by three Portuguese institutional investors — it is not founder-owned in the classic bootstrapped sense. Revenue is approximately €5.8M in 2025, within the SolStein target range, but growing rapidly.

---

## 2. HORECA Market Position

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Total hotel customers | 2,600+ hotels worldwide | hijiffy.com/about | Confirmed |
| Countries served | 50+ countries | hijiffy.com/about | Confirmed |
| Primary markets | UK, France, Portugal, Spain | hijiffy.com/news (Jun 2023) | Confirmed |
| NL/BE presence | Incidental — some customers; no dedicated market effort named | Enlyft, whiteskyhospitality.com | Estimated |
| NL PMS partner | RoomRaccoon (NL) integration partnership announced Jul 2025 | travolution.com | Confirmed |
| Booking.com integration | Sep 2024 | travolution.com | Confirmed |
| Expedia integration | Mar 2025 | traveldailymedia.com | Confirmed |
| Competitive ranking | Tracxn: 2nd among 114 active competitors globally | Tracxn | Estimated |
| Sifted 50 rank | #11 fastest-growing startup in Southern Europe (2024) | sifted.eu, Instagram | Confirmed |
| Awards | HotelTechReport finalist (Hotel Chatbot); Level III GCSC; UNWTO Most Innovative Solution | hijiffy.com/about | Confirmed |
| Notable customers | Macdonald Hotels & Resorts (UK), chain hotels in ES, PT, FR | hijiffy.com/news | Confirmed |

**NL/BE assessment**: NL and BE are NOT named primary markets. The RoomRaccoon (NL) partnership in July 2025 may signal an NL expansion push, but no dedicated sales or office presence is confirmed. HiJiffy's NL/BE hotel footprint is incidental to its European expansion rather than a strategic focus area.

---

## 3. Product & Technology

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Core product | Aplysia OS — proprietary AI Guest Communications Hub | hijiffy.com | Confirmed |
| AI foundation | LLMs (GPT-4), NLP, RAG (Retrieval-Augmented Generation, Aplysia 3) | hijiffy.com/our-artificial-intelligence | Confirmed |
| Automation rate | 85%+ of guest queries resolved automatically | hijiffy.com | Confirmed |
| Languages supported | 130+ (Aplysia Pro/Premium plans) | hijiffy.com/plans-and-pricing | Confirmed |
| Channels | WhatsApp, Facebook Messenger, Instagram, Google Business, website chatbot, voice | hijiffy.com | Confirmed |
| Console | Unified web/desktop/mobile inbox for hoteliers | hijiffy.com | Confirmed |
| PMS integrations | 80+ hospitality systems (PMS, booking engines, CRM) | hijiffy.com | Confirmed |
| Key integrations | Booking.com, Expedia, Salesforce, RoomRaccoon, Apaleo, WebRezPro | Tracxn news, store.apaleo.com | Confirmed |
| Guest journey | Pre-booking → booking → in-stay → post-stay (reviews/loyalty) | hijiffy.com | Confirmed |
| Upsell capability | Automated WhatsApp campaigns for upsells, room upgrades | hijiffy.com/plans-and-pricing | Confirmed |
| Pre check-in | Digital pre-check-in forms via messaging | hijiffy.com | Confirmed |
| Voice assistant | Beta AI voice product (Dec 2022+) | travolution.com | Confirmed |
| Sentiment analysis | Emotion detection for prioritization/escalation | hijiffy.com/our-artificial-intelligence | Confirmed |
| RAG (Aplysia 3) | Hotel-specific knowledge base via 2 documents (brand + property) | hijiffy.com/resources/product-highlights/aplysia-3 | Confirmed |
| Campaigns Manager | Outbound WhatsApp campaign management (launched Jan 2025) | travolution.com | Confirmed |
| Rate Comparison | Live OTA rate display in chatbot to drive direct bookings | hijiffy.com/news | Confirmed |
| Architecture | Cloud-native SaaS | hijiffy.com | Confirmed |
| Tech stack modernity | High — GPT-4, RAG, cloud-native, proprietary hospitality AI engine | Multiple sources | Confirmed |

**Summary**: HiJiffy has a purpose-built, cloud-native AI platform deeply specialized for hotel guest communications. The Aplysia OS is a genuinely differentiated product — not a generic chatbot. The 80+ PMS integrations and OTA partnerships create real switching costs. Technology is modern and actively evolving (Aplysia 3 with RAG in 2024).

---

## 4. M&A Ownership & Succession

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Ownership type | VC-backed — three institutional PT investors | Tracxn, Crunchbase | Confirmed |
| Investors | Portugal Ventures (gov-backed), Caixa Capital Risc (banking VC), Lince Capital | Phocuswire, Tracxn | Confirmed |
| PE overhang | None | Tracxn | Confirmed |
| Founder exit signals | None — all three founders active; declined M&A offer Apr 2025 | GetLatka, LinkedIn | Estimated |
| Succession gap | Not apparent — founders in their ~30s–40s, actively leading | LinkedIn | Estimated |
| M&A offer history | One M&A offer noted (Apr 2025) — not completed | GetLatka | Estimated |
| Investor exit timeframe | Portugal Ventures seed fund (2020) approaching typical 7–10yr horizon | Portugal Ventures fund timeline | Estimated |
| Acquisition complexity | High — requires alignment of 3 VC co-owners + 3 founders | — | Estimated |
| Board composition | Likely includes investor representatives — not public | — | Unknown |

**Key finding**: HiJiffy is VC-backed with three institutional co-owners. This is a fundamental blocker for SolStein's thesis of "founder-owned, no PE overhang." The founders are not signalling exit readiness — they declined an approach in April 2025. Any acquisition would be a structured multi-party transaction, not a clean bilateral founder deal.

---

## 5. Financial Growth & Trajectory

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Revenue 2025 | ~$6.3M (≈€5.8M) | GetLatka | Estimated |
| Revenue growth rate | CEO claimed "annual growth above 100%" (Jun 2023) | hijiffy.com/news | Estimated |
| Sifted 50 rank | #11 in Southern Europe 2024 (based on 3-year revenue growth) | sifted.eu | Confirmed |
| Employee growth | ~57 (2025) → 64 (Mar 2026) = +12% headcount in ~12 months | GetLatka, Tracxn | Estimated |
| Implied 2023 revenue | ~$1.5–$3M (if 100%+ growth to $6.3M by 2025) | Estimate | Estimated |
| Funding runway | Last funded Jun 2023; at ~64 employees + ~€5.8M revenue, likely near breakeven | Estimate | Estimated |
| New product launches | Campaigns Manager (Jan 2025), Expedia integration (Mar 2025), RoomRaccoon (Jul 2025) | Tracxn news | Confirmed |
| Growth signals | Strong — OTA integrations, new product features, partnership pipeline accelerating | Tracxn | Confirmed |
| Trajectory | High-growth startup; not in harvest/plateau mode | Multiple | Confirmed |

**Summary**: HiJiffy exhibits strong growth signals — Sifted 50 ranking, rapid OTA/PMS partnership expansion, headcount growth, and claimed 100%+ annual revenue growth. Revenue at ~€5.8M fits the SolStein range but is trending toward €10M+ within 1–2 years. Valuation at typical AI-SaaS multiples (4–8× ARR) would imply €23–46M acquisition price — above SolStein's likely comfort zone for this geography/fit profile.

---

## 6. HORECA Vertical Depth

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Vertical focus | Hotels only (not restaurants, bars, or other HORECA) | hijiffy.com | Confirmed |
| Guest journey depth | Pre-booking → booking → pre-check-in → in-stay → post-stay | hijiffy.com | Confirmed |
| Revenue levers for hotels | Direct booking uplift, upsell revenue, staff cost reduction | hijiffy.com/success-stories | Confirmed |
| PMS depth | 80+ integrations — deep operational coupling | hijiffy.com | Confirmed |
| Upsell automation | WhatsApp campaigns for room upgrades, F&B, spa | hijiffy.com/plans-and-pricing | Confirmed |
| Post-stay | Review solicitation, loyalty program updates | hijiffy.com | Confirmed |
| Hotel segments | Independent hotels, boutique chains, resort groups | hijiffy.com/success-stories | Confirmed |
| Enterprise hotel groups | Macdonald Hotels (UK), chains in ES/PT/FR | hijiffy.com/news | Confirmed |
| Not HORECA-wide | Restaurant/bar/catering not addressed | hijiffy.com | Confirmed |

**Summary**: HiJiffy has genuine vertical depth within the hotel sub-segment of HORECA. The product is purpose-built for hotel guest communications across the full guest lifecycle. It is not a broader HORECA play — restaurants and food service are out of scope. This makes it a strong fit for hotel-focused acquirers but less relevant to a multi-segment HORECA IT roll-up.

---

## 7. Valuation & Business Model

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Business model | SaaS subscription per hotel property | hijiffy.com/plans-and-pricing | Confirmed |
| Pricing basis | Per-room tiers (not per-user) | hijiffy.com | Confirmed |
| Plan tiers | Basic (~€105/mo), Pro (~€170/mo), Premium (~€350/mo), Enterprise (custom) | softwarefinder.com | Estimated |
| Setup fee | €599 (Premium) per 5 properties | hijiffy.com/plans-and-pricing | Confirmed |
| Average revenue per hotel (est.) | €150–€300/month per property (blended) | Estimate from pricing + customer count | Estimated |
| ARR calculation check | 2,600 hotels × €225 avg/mo × 12 = ~€7M (rough cross-check of €5.8M estimate) | Estimate | Estimated |
| Revenue (2025) | ~€5.8M | GetLatka | Estimated |
| Revenue model | Recurring subscription + setup fees | hijiffy.com | Confirmed |
| Enterprise custom pricing | Group hotel chains — revenue likely skewed to larger accounts | hijiffy.com | Estimated |
| Acquisition valuation (est.) | €23M–€46M at 4–8× ARR | Comparable SaaS transactions | Estimated |
| Last known post-money valuation | Not publicly disclosed | — | Unknown |
| Tracxn post-money hint | ~$9M (Jun 2023, blended) | Tracxn (partial data) | Estimated |
| Break-even likelihood | Likely near break-even at €5.8M revenue / 64 staff | Estimate | Estimated |

**Summary**: The business model is clean recurring SaaS — predictable, scalable, and directly tied to hotel room count (creating natural upsell path). Estimated ARR of €5.8M is within the SolStein €1–15M target range. However, acquisition price at market-rate SaaS multiples for a high-growth AI company likely ranges €23–46M — material capital requirement, and Portuguese VC investors will demand structured returns.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | **2** | VC-backed (3 Portuguese institutional investors); founders declined M&A approach Apr 2025; no PE overhang but structured exit required | Tracxn, GetLatka |
| **Revenue scale fit** | High | **3** | €5.8M ARR fits the €1–15M range; but rapidly approaching top of range and exit price likely €23–46M | GetLatka |
| **Geographic fit** | High | **2** | Primary markets are UK, FR, PT, ES — NL/BE is incidental; no office or dedicated market presence in Benelux | hijiffy.com/about, hijiffy.com/news |
| **Tech stack modernity** | Medium | **5** | Cloud-native, GPT-4, RAG (Aplysia 3), 80+ integrations, proprietary hospitality AI OS — best-in-class | hijiffy.com/our-artificial-intelligence |
| **Customer lock-in** | Medium | **4** | 2,600+ hotels, 80+ PMS integrations, full guest journey platform — high switching costs; multi-year SaaS | hijiffy.com |
| **Vertical depth** | Medium | **4** | Purpose-built for hotel guest communications across full lifecycle; deep hotel-only specialization | hijiffy.com |
| **Integration potential** | Low | **4** | REST API, 80+ hospitality system integrations, Booking.com + Expedia + Apaleo — open ecosystem | store.apaleo.com, hijiffy.com |
| **Growth trajectory** | Low | **5** | Sifted 50 #11, claimed 100%+ annual growth, rapid partner expansion (OTAs, PMS), Campaigns Manager launch | sifted.eu, Tracxn |

### Score Calculation

| Weight Class | Dimensions | Scores | Weighted Contribution |
|---|---|---|---|
| High (×3) | Ownership, Revenue scale, Geographic fit | 2, 3, 2 | (2+3+2) × 3 = 21 |
| Medium (×2) | Tech stack, Customer lock-in, Vertical depth | 5, 4, 4 | (5+4+4) × 2 = 26 |
| Low (×1) | Integration potential, Growth trajectory | 4, 5 | (4+5) × 1 = 9 |
| **Total** | | | **56 points** |
| **Max possible** | | | (5×3)×3 + (5×3)×2 + (5×2)×1 = 45+30+10 = 85 |
| **Composite Score** | | | **56 / 85 = 2.94 / 5.0** |

### Confidence Band

| Metric | Value |
|---|---|
| Total data points | 48 |
| Confirmed | 30 |
| Estimated | 15 |
| Unknown | 3 |
| Confidence fraction | 63% Confirmed → **Medium confidence band** |
| Score range | 2.6 – 3.3 / 5.0 |

---

### Overall Assessment

**Composite Score: 2.94 / 5.0 — Confidence band: Medium (2.6–3.3)**

HiJiffy is a technically excellent, high-growth AI hospitality platform that fails the SolStein M&A thesis on its three highest-weight criteria:

1. **Ownership (Score 2)**: Three VC co-owners + active founders not signalling exit. The April 2025 declined M&A offer suggests the company is not in exit mode. Any acquisition would require complex multi-party negotiation with Portuguese institutional investors.

2. **Geographic fit (Score 2)**: The company explicitly names UK, France, Portugal, and Spain as primary markets. NL/BE is incidental. HiJiffy serves some Benelux hotels but has no dedicated commercial presence, no local office, and no named NL/BE market strategy beyond the RoomRaccoon PMS partnership (July 2025).

3. **Revenue scale / price fit (Score 3)**: Revenue is within range at €5.8M, but the growth trajectory and AI premium will price any acquisition at €23–46M+ at market SaaS multiples — significantly above what a bilateral founder acquisition would cost.

The product, tech, and growth story are genuinely impressive (Scores 4–5 on tech/lock-in/vertical/growth). HiJiffy would be a strong strategic asset — but for a well-capitalized strategic buyer with a European hotel chain customer base, not for SolStein's Benelux-focused, founder-deal acquisition strategy.

---

### Recommended Next Step

**Classify as Tier 2 (Secondary / Watch List) with blockers: VC-backed, non-NL/BE primary market.**

No immediate outreach warranted. Monitor for:
- Investor exit signals (Portugal Ventures 2020 fund approaching 7–10yr horizon ~2027–2030)
- Potential Series A raise indicating VC liquidity event planning
- Any announced NL/BE market expansion or dedicated Benelux commercial hire
- Acquisition of HiJiffy by a strategic hotel tech consolidator (would remove them from the landscape)

If SolStein's acquisition mandate expands to include PT/ES-based companies with pan-European hotel reach, revisit with updated geographic weighting.
