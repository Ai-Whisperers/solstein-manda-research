# HiJiffy

**Category**: Guest Engagement
**Country**: BE
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history HiJiffy @HORECA_IT/hijify/
@research-horeca-company HiJiffy @HORECA_IT/hijify/
```
