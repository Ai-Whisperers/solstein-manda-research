# Lighthouse (formerly OTA Insight) — Corporate History

**Category**: Revenue Intelligence / Hotel Data & BI
**Country**: UK (London, England — European HQ; originally Belgium)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK/Belgium HQ; KKR-backed; unicorn scale)

---

## Summary Assessment

Lighthouse (formerly **OTA Insight**) is a **KKR-backed hotel revenue intelligence platform** that rebranded on **9 November 2023** from OTA Insight to Lighthouse. With **$494M total funding** (Series C: $370M led by KKR in November 2024), 70,000+ hospitality properties across 185 countries, and a data platform processing 400TB of travel data daily, Lighthouse is a unicorn-scale company. Originally founded in **Ghent, Belgium**, now London-HQ'd. Outside SolStein's criteria in every dimension. Critical **revenue intelligence benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Current name | Lighthouse | mylighthouse.com | Confirmed |
| Former name | OTA Insight | mylighthouse.com | Confirmed |
| Rebrand date | 9 November 2023 | mylighthouse.com | Confirmed |
| HQ | London, UK (European operations base) | mylighthouse.com | Confirmed |
| Founding location | Ghent, Belgium | Background research | Estimated |
| Founded | ~2012 | Tracxn, various press | Estimated |
| Ownership | KKR (Series C lead, Nov 2024) + prior investors | mylighthouse.com | Confirmed |
| Total funding raised | ~$494M | startupintros.com | Confirmed |
| Series C | November 2024: $369–370M (KKR lead) | mylighthouse.com | Confirmed |
| Properties served | 70,000+ hospitality properties | mylighthouse.com | Confirmed |
| Countries | 185 | mylighthouse.com | Confirmed |
| Data processed daily | 400+ terabytes | mylighthouse.com | Confirmed |
| Hotels in dataset | 725,000+ | mylighthouse.com | Confirmed |
| STR properties in dataset | 19M+ short-term rentals | mylighthouse.com | Confirmed |
| Key acquisitions | Transparent (STR analytics) + Kriya RevGen (consolidated under Lighthouse brand) | mylighthouse.com (rebrand announcement) | Confirmed |
| Prior investors (pre-Series C) | Not fully listed in research | — | Unknown |
| Revenue | Not publicly disclosed | — | Unknown |
| Employees | Not disclosed; estimated 500–1,000+ at this scale | — | Estimated |

---

## Founding & Corporate History — OTA Insight Era

OTA Insight was founded approximately in **2012** with a core product: real-time hotel rate shopping and OTA (Online Travel Agency) rate parity monitoring. Hotels could see how their rates compared to competitors on Booking.com, Expedia, and other OTAs in real-time — the foundation of revenue management.

The company was founded with Belgian roots (Ghent) and grew into a globally dominant hotel rate intelligence platform, eventually establishing London as its primary European office. Over the 2010s, OTA Insight expanded from rate shopping into market intelligence (occupancy, demand forecasting), business intelligence, and eventually STR (short-term rental) analytics through acquisitions.

**Key acquisitions (pre-rebrand)**:
- **Transparent** — STR analytics platform (acquired before 2023)
- **Kriya RevGen** — Revenue management system (acquired before 2023)

These acquisitions led to the **rebrand to Lighthouse on 9 November 2023** — the new name reflecting the company's evolution from a narrow rate-shopping tool to a "unified commercial platform" for hotel revenue strategy.

**November 2024**: **KKR** (global PE/alternative investment firm) led a **$369–370M Series C** investment — bringing total raised to ~$494M and cementing Lighthouse's unicorn/near-unicorn status.

---

## Funding History

| Round | Date | Amount | Lead Investor | Notes |
|---|---|---|---|---|
| Seed/early | ~2013–2018 | Not disclosed | European VCs | Initial product: hotel rate shopping |
| Series A | Not disclosed | Not disclosed | — | — |
| Series B | Not disclosed | Not disclosed | — | — |
| Series C | November 2024 | $370M | KKR | Total raised reaches ~$494M |
| **Total raised** | | **~$494M** | | startupintros.com |

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["KKR (Series C lead — Nov 2024)"]
    B["Prior investors (undisclosed)"]
    C["Lighthouse<br/>(formerly OTA Insight)<br/>(London, UK HQ)"]
    D["Transparent<br/>(STR analytics — acquired)"]
    E["Kriya RevGen<br/>(Revenue management — acquired)"]
    F["70,000+ hotels<br/>185 countries<br/>725,000+ hotels in dataset"]

    A -->|"$370M Series C"| C
    B -->|"Prior rounds"| C
    C -->|"Integrated"| D
    C -->|"Integrated"| E
    C --> F
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Lighthouse (OTA Insight) — Key Milestones
    2012 : Founded in Ghent, Belgium as OTA Insight; hotel rate shopping platform
    2013-2020 : Growth phase; rate intelligence + market analytics; European expansion; London HQ
    2021-2022 : Acquired Transparent (STR) and Kriya RevGen; platform expansion
    Nov 2023 : Rebranded from OTA Insight to Lighthouse; unified commercial platform launched
    Nov 2024 : $370M Series C (KKR lead); total raised ~$494M; 70,000+ properties; 185 countries
    2026 : Active; 400TB+ daily data; 725,000+ hotels in dataset; 19M+ STR properties
```

---

## M&A Feasibility Assessment

### Is Lighthouse an Acquisition Target for SolStein?

**Answer: No. KKR-backed; ~$500M raised; global unicorn-scale. Definitively out of range.**

| Factor | Assessment |
|---|---|
| **Scale** | $370M Series C alone; 70,000+ properties globally — 100–500x above SolStein |
| **Ownership** | KKR (global PE giant) — no founder-owned angle |
| **Geography** | Global (185 countries); not NL/BE-focused |
| **Succession** | Professional management; no succession gap |
| **Exit pathway** | IPO or strategic acquisition at unicorn valuation |

### Role for SolStein

1. **Revenue intelligence benchmark**: Lighthouse defines hotel revenue intelligence — rate shopping, market analytics, demand forecasting, STR data. Any NL/BE hotel data company is benchmarked against this.
2. **Belgium origin**: Lighthouse originated in Ghent (Belgium) — a reminder that world-class hospitality tech emerges from the Benelux region; regional heritage does not imply regional market focus.
3. **Valuation reference**: KKR invested at premium SaaS multiples in hospitality data — validates the category's value.
4. **Competitive context**: Lighthouse serves large hotel groups and chains; independent NL/BE hotels using basic revenue management tools represent an opportunity for smaller revenue management companies.

---

*Sources: mylighthouse.com (rebrand announcement Nov 2023, Series C announcement Nov 2024), startupintros.com, builtincolorado.com, phocuswire.com.*
