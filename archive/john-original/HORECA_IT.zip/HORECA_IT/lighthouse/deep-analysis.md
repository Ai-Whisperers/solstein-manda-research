# Lighthouse (formerly OTA Insight) — Deep Analysis

**Category**: Revenue Intelligence / Hotel Data & BI
**Country**: UK (London HQ; founded Belgium)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (KKR-backed; unicorn scale; rebrand Nov 2023)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Current legal name | Lighthouse (formerly OTA Insight) | mylighthouse.com | Confirmed |
| Rebrand date | 9 November 2023 | mylighthouse.com | Confirmed |
| HQ | London, UK | mylighthouse.com | Confirmed |
| Founding location | Ghent, Belgium (~2012) | Background research | Estimated |
| Founded | ~2012 | Multiple press | Estimated |
| Ownership | KKR (Series C lead, Nov 2024) + prior investors | mylighthouse.com | Confirmed |
| Total funding | ~$494M | startupintros.com | Confirmed |
| Latest round | $370M Series C (KKR lead, Nov 2024) | mylighthouse.com | Confirmed |
| Properties served | 70,000+ | mylighthouse.com | Confirmed |
| Countries | 185 | mylighthouse.com | Confirmed |
| Data processed | 400TB+ daily | mylighthouse.com | Confirmed |
| Business model | SaaS hotel revenue intelligence subscription | mylighthouse.com | Confirmed |
| Product | Rate insight, market insight, benchmark insight, parity insight, destination insight | mylighthouse.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Global presence | 185 countries | mylighthouse.com | Confirmed |
| UK market | Significant (London HQ); UK hotels primary | mylighthouse.com | Confirmed |
| NL/BE presence | Significant (originated in Belgium; EU strong) | Background | Confirmed |
| EU position | Strong — European-origin company with global scale | mylighthouse.com | Confirmed |
| Target customer | Hotels (chains, independents, groups); STR operators | mylighthouse.com | Confirmed |
| Hotel dataset | 725,000+ hotels globally | mylighthouse.com | Confirmed |
| STR dataset | 19M+ short-term rental properties | mylighthouse.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Rate Insight | Real-time rate shopping across OTAs | mylighthouse.com | Confirmed |
| Market Insight | Market demand and occupancy analytics | mylighthouse.com | Confirmed |
| Benchmark Insight | Performance benchmarking vs. competitors | mylighthouse.com | Confirmed |
| Parity Insight | Rate parity monitoring | mylighthouse.com | Confirmed |
| Destination Insight | Destination-level demand intelligence | mylighthouse.com | Confirmed |
| Transparent | STR analytics (acquired product) | mylighthouse.com | Confirmed |
| Kriya RevGen | Revenue management system (acquired product) | mylighthouse.com | Confirmed |
| Deployment | Cloud SaaS; API-first data platform | mylighthouse.com | Confirmed |
| Data processing | 400TB+ daily; AI/ML analytics | mylighthouse.com | Confirmed |
| AI features | AI-driven pricing recommendations | mylighthouse.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Current backer | KKR (Series C lead, Nov 2024) | mylighthouse.com | Confirmed |
| Investment amount | $370M (Nov 2024) | mylighthouse.com | Confirmed |
| Prior investors | Not fully disclosed | — | Unknown |
| Total raised | ~$494M | startupintros.com | Confirmed |
| Founder status | Not publicly prominent; professional management | — | Estimated |
| Exit horizon | IPO or strategic sale at $1B+ valuation | KKR investment thesis | Estimated |
| Succession gap | None — institutional ownership and management | — | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not publicly disclosed | — | Unknown |
| Scale indication | 70,000+ properties × estimated £1,000–3,000/year ARR | Derived | Estimated |
| Implied ARR estimate | £70M–£210M (at 70,000 properties) | Derived | Estimated |
| Growth | Strong; $370M Series C indicates aggressive growth/M&A plans | KKR investment | Estimated |
| M&A strategy | Active acquirer (Transparent, Kriya RevGen) — further acquisitions likely | mylighthouse.com | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Hotel revenue management | Market-defining platform; real-time rate + demand intelligence | mylighthouse.com | Confirmed |
| STR analytics | 19M+ STR properties; Airbnb/Vrbo benchmarking | mylighthouse.com | Confirmed |
| OTA parity | Rate parity monitoring across 100s of OTAs | mylighthouse.com | Confirmed |
| EU/UK hotel markets | Deep data coverage; Belgium origin + London HQ | mylighthouse.com | Confirmed |
| NL/BE hotel market | Likely strong (European-origin company) | Estimated | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription per property/per module | mylighthouse.com | Confirmed |
| ARR estimate | £70M–£210M (derived from 70,000 properties) | Derived | Estimated |
| Valuation (implied) | $1B–$3B+ (at $370M Series C from KKR) | VC norms | Estimated |
| Acquisition price | Would require $1B+ — not applicable for SolStein | — | Confirmed |
| SolStein fit | No — KKR-backed; unicorn scale; 185 countries | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | KKR-backed with $494M total raised; no founder-owned angle | mylighthouse.com |
| Revenue scale fit | High | 1 | Estimated £70M–£210M ARR — 5–200x above SolStein's target | Derived |
| Geographic fit | High | 3 | EU-origin (Belgium); London HQ; strong EU presence — but global not NL/BE-focused | mylighthouse.com |
| Tech stack modernity | Medium | 5 | API-first data platform; AI recommendations; 400TB daily processing | mylighthouse.com |
| Customer lock-in | Medium | 5 | Revenue intelligence deeply embedded in hotel commercial strategy | mylighthouse.com |
| Vertical depth | Medium | 5 | Market-defining hotel revenue intelligence; 725,000 hotel dataset | mylighthouse.com |
| Integration potential | Low | 5 | API-first; OTA integrations; PMS integrations | mylighthouse.com |
| Growth trajectory | Low | 5 | $370M Series C; strong growth; STR + hotel data expansion | mylighthouse.com |

### Composite Score

**Weighted Composite: 2.6 / 5.0**

*(High scores on product dimensions; ownership = 1 and revenue scale = 1 override for SolStein)*

**Confidence Band**: Medium — key facts (rebrand, funding) confirmed; revenue estimated.

### Overall M&A Assessment

Lighthouse is **not an acquisition target** for SolStein by any measure. It is a KKR-backed, near-unicorn scale hotel revenue intelligence platform, $500M funded, serving 70,000+ properties across 185 countries. Its Belgian origin is a historical curiosity — the company has long outgrown its Benelux roots.

**Strategic importance**: Lighthouse acquired and integrated STR analytics (Transparent) and revenue management (Kriya RevGen) — showing that hotel intelligence companies grow by adding adjacent data products. If a NL/BE hotel revenue analytics company exists at €1–5M ARR, founder-owned, it would be a SolStein target in this category.

### Recommended Next Step

No pursuit. Use as hotel revenue intelligence benchmark. Note Belgian origin as evidence that world-class hospitality data companies can emerge from Benelux — but Lighthouse itself is global and inaccessible.

---

*Sources: mylighthouse.com (rebrand and Series C announcements), startupintros.com, builtincolorado.com, phocuswire.com.*
