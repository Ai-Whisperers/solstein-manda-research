# Lighthouse

**Category**: Revenue/Data
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Lighthouse @HORECA_IT/lighthouse/
@research-horeca-company Lighthouse @HORECA_IT/lighthouse/
```
