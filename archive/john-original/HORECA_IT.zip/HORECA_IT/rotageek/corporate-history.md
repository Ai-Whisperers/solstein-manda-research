# RotaGeek — Corporate History

**Category**: Workforce / Staff Scheduling (Hospitality & Retail)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; acquired by ELMO Group Jun 2025)

---

## Summary Assessment

RotaGeek is a **UK workforce scheduling company** founded by former NHS A&E doctor Chris McCullough (with Nick Mann and Prof. Roy Pounder), originally developed for NHS hospital shift scheduling. It expanded into hospitality and retail, serving brands like Pret a Manger, William Hill, and Lush. It raised £6M Series B in 2020 and was **acquired by ELMO Group** (parent of Breathe HR) in **June 2025**. Now part of a larger HR tech company. Not a SolStein target.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | RotaGeek | rotageek.com | Confirmed |
| Legal entity | RotaGeek Limited | Companies House (inferred from app stores) | Estimated |
| HQ | London, UK | rotageek.com | Confirmed |
| Founded | Not confirmed (pre-2018 per funding history) | — | Estimated |
| Founders | Chris McCullough (CEO, former NHS A&E doctor); Nick Mann (CTO); Prof. Roy Pounder | rotageek.com/blog, breathehr.com | Confirmed |
| Founding context | NHS hospital scheduling → expanded to hospitality/retail | rotageek.com | Confirmed |
| Acquired by | ELMO Group (parent of Breathe HR) | breathehr.com | Confirmed |
| Acquisition date | June 2025 | breathehr.com | Confirmed |
| Acquirer profile | ELMO Group: Australian HR software company with Breathe HR UK division | breathehr.com | Confirmed |
| PE backing (2018) | Mobeus (investment) | rotageek.com/blog | Confirmed |
| Series B | May 2020: £6M (led by Calculus Capital, Mobeus continuing) | rotageek.com/blog | Confirmed |
| Series C / late round | 2022: £3M (amount per company news) | rotageek.com/news | Confirmed |
| Key UK customers | Pret a Manger, William Hill, Lush | breathehr.com | Confirmed |
| Product | AI-powered demand-led workforce scheduling | rotageek.com | Confirmed |
| Sectors | Hospitality, retail, healthcare | rotageek.com | Confirmed |
| Revenue | Not disclosed | — | Unknown |
| Employees | Not disclosed | — | Unknown |

---

## Founding & History

**Chris McCullough**, an A&E doctor, co-founded RotaGeek with **Nick Mann** and **Professor Roy Pounder** to solve the chronic problem of inefficient shift scheduling in NHS hospitals. The NHS scheduling problem — matching complex clinical skill requirements to variable demand patterns — proved to be a generalisable platform problem.

RotaGeek applied demand-led, AI-powered scheduling to hospitality and retail: environments with similar complexity (high variability, large shift workforces, UK employment law compliance, multiple skills).

**Funding milestones:**
- **2018**: Mobeus (UK PE/growth investor) invests — Series A equivalent
- **May 2020**: £6M Series B (Calculus Capital leads; Mobeus continues); global expansion target
- **2022**: £3M further round

**June 2025**: **ELMO Group** (Australia-based, parent of Breathe HR UK) acquired RotaGeek to expand its UK market presence and integrate AI-powered scheduling into its HR platform ecosystem. RotaGeek becomes a scheduling product within the ELMO/Breathe HR offering.

---

## Investor/Ownership Timeline

| Period | Backer | Notes |
|---|---|---|
| 2018 | Mobeus (UK) | Initial PE/growth investment |
| 2020 | Calculus Capital (lead) + Mobeus | £6M Series B |
| 2022 | Existing + new investors | £3M growth round |
| Jun 2025 | ELMO Group / Breathe HR | Full acquisition |

---

## Corporate Structure (Post-Acquisition)

```mermaid
graph TD
    A["ELMO Group<br/>(Australia — Breathe HR parent)"]
    B["Breathe HR<br/>(UK HR software)"]
    C["RotaGeek Limited<br/>(London, UK — acquired Jun 2025)"]
    D["UK hospitality / retail / healthcare<br/>workforce scheduling customers"]

    A -->|"Parent"| B
    A -->|"Acquired Jun 2025"| C
    B -->|"Integration with"| C
    C --> D
```

---

## Timeline of Critical Events

```mermaid
timeline
    title RotaGeek — Key Milestones
    Pre-2018 : Founded by Chris McCullough + Nick Mann + Prof. Roy Pounder; NHS scheduling → HORECA pivot
    2018 : Mobeus invests (Series A equivalent)
    2020 : £6M Series B (Calculus Capital lead, May 2020); global expansion
    2022 : £3M growth round
    2025 : Acquired by ELMO Group (Breathe HR parent) in June 2025
```

---

## M&A Feasibility Assessment

### Is RotaGeek an Acquisition Target for SolStein?

**Answer: No. Already acquired by ELMO Group (Jun 2025).**

| Factor | Assessment |
|---|---|
| **Ownership** | ELMO Group (Australian HR software company) — not for sale |
| **Geography** | UK only |
| **Scale** | Unknown but below SolStein's enterprise threshold |
| **Succession** | Chris McCullough may have exited with acquisition |
| **Exit pathway** | ELMO Group integration — no divestiture expected |

### Role for SolStein

1. **Workforce scheduling benchmark**: RotaGeek defines AI demand-led scheduling for UK hospitality — the product category SolStein considers for NL/BE.
2. **M&A pattern**: Workforce scheduling companies are acquired by larger HR platforms (ELMO/Breathe). NL/BE equivalents (Planax, Cures Werkt) may follow same pattern.
3. **Founder exit pattern**: Physician-founded tech company → PE → acquisition — demonstrates founder exits in workforce scheduling space.

---

*Sources: rotageek.com/blog, breathehr.com (ELMO Group acquisition press release), rotageek.com/news, entrepreneur.com (Apr 2026 interview with Chris McCullough).*
