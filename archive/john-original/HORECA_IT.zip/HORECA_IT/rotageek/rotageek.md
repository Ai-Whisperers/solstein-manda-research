# RotaGeek

**Category**: Workforce
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history RotaGeek @HORECA_IT/rotageek/
@research-horeca-company RotaGeek @HORECA_IT/rotageek/
```
