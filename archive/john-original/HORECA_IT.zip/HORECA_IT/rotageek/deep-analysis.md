# RotaGeek — Deep Analysis

**Category**: Workforce / Staff Scheduling (Hospitality & Retail)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; acquired by ELMO Group Jun 2025)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | RotaGeek Limited | Companies House (inferred) | Estimated |
| HQ | London, UK | rotageek.com | Confirmed |
| Founded | Pre-2018 (exact year not confirmed) | Mobeus funding timeline | Estimated |
| Founders | Chris McCullough (CEO); Nick Mann (CTO); Prof. Roy Pounder | breathehr.com, rotageek.com | Confirmed |
| Ownership | ELMO Group (Australia; acquired Jun 2025) | breathehr.com | Confirmed |
| Total funding raised | £9M+ (£6M Series B + £3M + Mobeus initial) | rotageek.com | Confirmed |
| Revenue | Not disclosed | — | Unknown |
| Employees | Not disclosed | — | Unknown |
| Business model | SaaS workforce scheduling subscription (per employee/per location) | rotageek.com | Confirmed |
| Product | AI demand-led staff scheduling; rota management; forecasting | rotageek.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Primary | rotageek.com | Confirmed |
| Key hospitality clients | Pret a Manger | breathehr.com | Confirmed |
| Key retail clients | William Hill, Lush | breathehr.com | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | 2020 Series B announced global expansion; actual EU penetration unknown | rotageek.com/blog | Estimated |
| HORECA verticals | Restaurants, hospitality, pubs (as sub-set of broader retail/healthcare) | rotageek.com | Confirmed |
| Target customer | Multi-site chains with large shift workforces | rotageek.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Demand-led scheduling | AI forecasting of labour demand from sales/customer data | rotageek.com | Confirmed |
| Rota generation | Auto-generated rotas compliant with Working Time Regulations | rotageek.com | Confirmed |
| Mobile app | Employee app for shift viewing/swaps | rotageek.com | Confirmed |
| Predictive forecasting | Demand forecasting from historical and real-time data | rotageek.com | Confirmed |
| Integrations | POS, payroll, HR systems | rotageek.com | Confirmed |
| Tech stack | Cloud SaaS; mobile-first | rotageek.com | Confirmed |
| AI | Demand-led scheduling AI (not LLM; operational ML) | rotageek.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Prior backers | Mobeus (2018), Calculus Capital (2020), additional investors (2022) | rotageek.com | Confirmed |
| Current owner | ELMO Group (since Jun 2025) | breathehr.com | Confirmed |
| Chris McCullough status | May remain as CEO/advisor post-acquisition (per Apr 2026 Entrepreneur interview) | entrepreneur.com | Estimated |
| Founder exit | Likely full or partial exit at ELMO acquisition | Inferred | Estimated |
| Divestiture likelihood | Very low — ELMO core acquisition | breathehr.com | Estimated |

---

## 5. Financial Growth & Trajectory

| Period | Details | Source | Confidence |
|---|---|---|---|
| 2020 | £6M Series B; global expansion focus | rotageek.com | Confirmed |
| 2022 | £3M additional round | rotageek.com | Confirmed |
| 2025 | Acquired by ELMO Group | breathehr.com | Confirmed |
| Revenue trajectory | Pre-acquisition growth; now integrated into ELMO | — | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK labour law | Working Time Regulations, NMW, break rules | rotageek.com | Confirmed |
| UK auto-enrolment | Pension auto-enrolment integration | rotageek.com | Estimated |
| Hospitality scheduling | Multi-shift, variable demand scheduling for hospitality | rotageek.com | Confirmed |
| Labour cost optimisation | Real-time labour cost against sales forecasts | rotageek.com | Confirmed |
| Rising wage bill | Published content on NIC/NLW cost management 2025/26 | rotageek.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | Per-employee or per-location SaaS subscription | rotageek.com | Confirmed |
| ARR estimate | Unknown | — | Unknown |
| Acquisition price | Not disclosed | breathehr.com | Unknown |
| SolStein fit | No — acquired; UK only | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | ELMO Group-owned; not accessible | breathehr.com |
| Revenue scale fit | High | 2 | Unknown revenue; funded startup suggests £1–5M ARR; within range | Inferred |
| Geographic fit | High | 1 | UK only | rotageek.com |
| Tech stack modernity | Medium | 5 | Cloud-native; AI demand scheduling; mobile | rotageek.com |
| Customer lock-in | Medium | 4 | Scheduling creates high operational dependency | rotageek.com |
| Vertical depth | Medium | 4 | Deep UK hospitality/retail scheduling expertise | rotageek.com |
| Integration potential | Low | 4 | POS + payroll integrations; ELMO/Breathe HR integration | rotageek.com |
| Growth trajectory | Low | 3 | Acquired; growth now within ELMO group | breathehr.com |

### Composite Score

**Weighted Composite: 2.2 / 5.0**

*(Ownership = 1, geographic fit = 1 — high-weight blockers)*

**Confidence Band**: Low — revenue unknown; acquisition outcome known.

### Overall M&A Assessment

RotaGeek is **not a SolStein target** — acquired by ELMO Group. Its value is as a **workforce scheduling benchmark** and evidence that UK hospitality scheduling companies (PE-backed, £5M+ ARR estimated) are acquired by HR platform companies. The NL/BE equivalents (Planax, Cures Werkt) may follow a similar path — representing SolStein's window to acquire before they get picked up by HR platform buyers.

### Recommended Next Step

No pursuit. Use as workforce scheduling benchmark. Prioritise evaluation of NL/BE workforce scheduling companies as SolStein targets before they attract HR platform acquisition interest.

---

*Sources: rotageek.com/blog, breathehr.com, rotageek.com/news, entrepreneur.com (Apr 2026).*
