# Kafoodle

**Category**: Menu/Allergens
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Kafoodle @HORECA_IT/kafoodle/
@research-horeca-company Kafoodle @HORECA_IT/kafoodle/
```
