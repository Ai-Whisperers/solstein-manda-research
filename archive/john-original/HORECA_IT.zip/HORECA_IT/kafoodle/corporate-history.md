# Kafoodle — Corporate History

**Category**: Menu Management / Allergen Compliance
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; acquired by 365 Retail Markets 2023)

---

## Summary Assessment

Kafoodle is a **London-based food-tech company** specialising in digital allergen and menu management software for hospitality, healthcare, and education. Founded in 2014, it raised ~$2.6–3.6M before being **acquired by 365 Retail Markets** (US-based unattended retail and foodservice technology company) on **18 April 2023**. It is now a subsidiary of a larger corporate entity. Not a SolStein target; useful as an **allergen/menu management benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Kafoodle Limited | Companies House (inferred from LinkedIn: "Kafoodle Limited") | Estimated |
| Companies House No. | Not confirmed in public searches | — | Unknown |
| HQ | London, UK | PitchBook, tracxn.com | Confirmed |
| Founded | 2014 | PitchBook, tracxn.com | Confirmed |
| LinkedIn launch date | 2016 (per LinkedIn company page) | LinkedIn | Estimated |
| Founder(s) | Not identified in public sources | — | Unknown |
| Acquired by | 365 Retail Markets | PitchBook | Confirmed |
| Acquisition date | 18 April 2023 | PitchBook | Confirmed |
| Acquirer HQ | Troy, Michigan, USA | 365retailmarkets.com | Confirmed |
| Acquirer type | US unattended retail and foodservice technology company | 365retailmarkets.com | Confirmed |
| Pre-acquisition funding | $2.6M–$3.61M total | PitchBook / tracxn.com | Estimated |
| Key investors | Nexus Investment Ventures, Triple Point Ventures, JLR Star | PitchBook | Estimated |
| Grant funding | Innovate UK (specific project) | LinkedIn | Confirmed |
| Employees (pre-acquisition) | Small team; not disclosed | — | Unknown |
| Product | Digital menu management + allergen compliance software | kafoodle.com | Confirmed |
| Sectors | Hospitality, healthcare, education | kafoodle.com | Confirmed |
| Current status | Active subsidiary of 365 Retail Markets | kafoodle.com | Confirmed |

---

## Founding & History

Kafoodle was founded in **London in 2014** (some sources indicate 2016 as LinkedIn launch date — the 2014 date refers to incorporation or concept stage). The company targeted the growing regulatory requirement for allergen transparency in UK food service establishments — driven by the UK's **Food Information Regulations (2014)** and later the **Natasha's Law (2021)** requirements for pre-packaged foods.

The company raised small-scale venture funding from Nexus Investment Ventures, Triple Point Ventures (UK impact investor), and JLR Star, along with an Innovate UK project grant. Total capital raised was approximately £2–3M.

By 2023, the company was acquired by **365 Retail Markets**, a US technology company serving micro-markets, cafes, and foodservice. The acquisition brought Kafoodle's menu management and allergen tech into a larger unattended retail / foodservice platform serving corporate dining and healthcare.

As of 2026, Kafoodle operates as a **subsidiary of 365 Retail Markets**, continuing to serve hospitality, healthcare, and education customers in the UK with allergen management, nutritional labelling, and digital menu software — with a recent addition of carbon labelling (via My Emissions integration).

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["365 Retail Markets<br/>(Troy, Michigan, USA)"]
    B["Kafoodle Limited<br/>(London, UK — subsidiary from Apr 2023)"]
    C["Hospitality / Healthcare / Education<br/>UK customers"]

    A -->|"Acquired Apr 18, 2023"| B
    B --> C
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Kafoodle — Key Milestones
    2014 : Founded in London; allergen management software for UK HORECA
    2016 : LinkedIn company launch / public profile; Innovate UK project grant
    2021 : Natasha's Law (UK) creates tailwinds for allergen compliance software
    2023 : Acquired by 365 Retail Markets (USA) on Apr 18, 2023
    2026 : Active subsidiary; carbon labelling integration; allergen/nutritional compliance platform
```

---

## M&A Feasibility Assessment

### Is Kafoodle an Acquisition Target for SolStein?

**Answer: No. Already acquired by 365 Retail Markets.**

| Factor | Assessment |
|---|---|
| **Ownership** | Subsidiary of US company (365 Retail Markets) — not for sale |
| **Geography** | UK primary; no NL/BE focus |
| **Scale** | Small (exact revenue unknown) |
| **Succession** | Corporate parent; no founder succession angle |
| **Exit pathway** | Would require 365 Retail Markets to divest — unlikely |

### Role for SolStein

1. **Allergen/menu management benchmark**: Kafoodle demonstrates the product category (digital allergen and menu management) that becomes mandatory as EU allergen regulations evolve.
2. **EU regulatory signal**: NL/BE will face similar allergen transparency requirements — a NL/BE allergen management company could be a SolStein target.
3. **Acquisition pattern**: Small UK allergen software companies get acquired by US foodservice tech companies — validates the M&A thesis for similar NL/BE players.

---

*Sources: PitchBook (Kafoodle profile), tracxn.com, kafoodle.com, LinkedIn (Kafoodle Limited), crunchbase.com.*
