# Kafoodle — Deep Analysis

**Category**: Menu Management / Allergen Compliance
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; acquired by 365 Retail Markets Apr 2023)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Kafoodle Limited | LinkedIn, PitchBook | Estimated |
| HQ | London, UK | PitchBook, tracxn.com | Confirmed |
| Founded | 2014 | PitchBook, tracxn.com | Confirmed |
| Founders | Not publicly identified | — | Unknown |
| Ownership | 365 Retail Markets (USA) — acquired Apr 18, 2023 | PitchBook | Confirmed |
| Employees | Small team; not disclosed | — | Unknown |
| Revenue | Not disclosed | — | Unknown |
| Total funding (pre-acquisition) | ~$2.6M–$3.61M | PitchBook, tracxn.com | Estimated |
| Business model | SaaS subscription for allergen/menu management | kafoodle.com | Confirmed |
| Product | Kafoodle Kitchen: allergen, nutritional, menu management + digital menus + carbon labelling | kafoodle.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK sectors served | Hospitality, healthcare, education | kafoodle.com | Confirmed |
| UK HORECA focus | Restaurants, cafes, contract catering, hotels | kafoodle.com | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | Not a stated market | kafoodle.com | Estimated |
| Regulatory drivers | UK Food Information Regulations 2014; Natasha's Law 2021 | UK law | Confirmed |
| Customer count | Not disclosed | — | Unknown |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | Digital allergen and nutritional management platform | kafoodle.com | Confirmed |
| Allergen features | 14-allergen tracking (EU/UK standard), staff training, compliance reporting | kafoodle.com | Confirmed |
| Digital menu | QR code digital menus with live allergen/dietary filters | kafoodle.com | Confirmed |
| Carbon labelling | Integration with My Emissions for carbon footprint per dish | myemissions.co, kafoodle.com | Confirmed |
| Deployment | Cloud SaaS | kafoodle.com | Confirmed |
| Tech stack | Web-based; cloud | kafoodle.com | Estimated |
| Key differentiator | Allergen-first design; Natasha's Law compliance; multi-sector | kafoodle.com | Confirmed |
| Recipe database | Centralised recipe management with automatic allergen propagation | kafoodle.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Current owner | 365 Retail Markets (Troy, Michigan, USA) | PitchBook | Confirmed |
| Acquisition date | 18 April 2023 | PitchBook | Confirmed |
| Pre-acquisition investors | Nexus Investment Ventures, Triple Point Ventures, JLR Star, Innovate UK | PitchBook | Estimated |
| Founder status | Not publicly known; likely acquired alongside the business | — | Unknown |
| Divestiture likelihood | Low — 365 Retail Markets integrating Kafoodle into foodservice platform | Inferred | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not disclosed | — | Unknown |
| Pre-acquisition fundraise | ~£2–3M total (small-scale VC + Innovate UK) | PitchBook/tracxn | Estimated |
| Profitability | Unknown | — | Unknown |
| Growth trajectory | Modest; allergen compliance market growing with regulations | Regulatory environment | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK allergen compliance | Full 14-allergen system per UK/EU FIR regulations | kafoodle.com | Confirmed |
| Natasha's Law compliance | PPDS allergen labelling for pre-packed food | kafoodle.com | Confirmed |
| EU allergen regulation | EU FIC Regulation 1169/2011 compliant | kafoodle.com | Confirmed |
| Nutritional labelling | Calorie and nutrient calculation per dish | kafoodle.com | Confirmed |
| Carbon labelling | Via My Emissions integration | myemissions.co | Confirmed |
| Multi-site management | Centralised recipe management across sites | kafoodle.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription (per venue or per recipe database) | kafoodle.com | Confirmed |
| ARR estimate | £200K–£1M (small team; niche allergen software) | Estimated | Estimated |
| Acquisition price | Not disclosed | PitchBook | Unknown |
| SolStein fit | No — UK only; acquired; niche allergen category | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Owned by 365 Retail Markets (USA); not for sale | PitchBook |
| Revenue scale fit | High | 2 | Likely sub-£1M ARR — below SolStein's ideal range even if available | Estimated |
| Geographic fit | High | 1 | UK only; no NL/BE market presence | kafoodle.com |
| Tech stack modernity | Medium | 4 | Cloud SaaS; allergen-first design; good UX | kafoodle.com |
| Customer lock-in | Medium | 4 | Compliance software creates high switching costs (regulatory liability) | kafoodle.com |
| Vertical depth | Medium | 4 | Deep allergen/menu expertise; multi-sector; regulatory-driven | kafoodle.com |
| Integration potential | Low | 4 | QR digital menus; POS integrations; carbon labelling | kafoodle.com |
| Growth trajectory | Low | 3 | Regulatory tailwinds; niche market ceiling | Regulatory environment |

### Composite Score

**Weighted Composite: 2.2 / 5.0**

*(Ownership = 1, geographic fit = 1 — both high-weight; definitively excludes SolStein pursuit)*

**Confidence Band**: Low — revenue and financials fully unknown; corporate structure confirmed at acquisition level.

### Overall M&A Assessment

Kafoodle is **not a SolStein target** — it has been acquired by a US company and is UK-only. Its value is as a **product benchmark** for allergen/menu management software and a **regulatory signal** that EU allergen transparency requirements (already in UK law) are moving toward similar mandates in NL/BE.

### Recommended Next Step

No pursuit. Identify NL/BE allergen management software companies (if any exist at founder-owned, €1–5M ARR scale) as possible SolStein candidates.

---

*Sources: PitchBook (Kafoodle profile), tracxn.com, kafoodle.com, LinkedIn (Kafoodle Limited), crunchbase.com, myemissions.co.*
