# Horeko — Corporate History

**Research Date**: 2026-04-30
**Researcher**: SolStein M&A Research
**Status**: Acquired — NOT an available M&A target

---

## Executive Summary

Horeko (legal entity: HRK Solutions B.V.) was a Dutch cloud-based kitchen and workforce management software company serving hospitality businesses in the Netherlands and Belgium. The company was founded in 2008/2009 by Marvin van Dongen and grew to serve 1,500+ clients before receiving minority investment from CNBB Equity Partners in 2019. On 4 July 2022, Exact Holding B.V. acquired Horeko. The product now operates as **Exact Horeko** within Exact's portfolio. Horeko is **not available** as an M&A target for SolStein.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | HRK Solutions B.V. | PartnerNavigator.com | Confirmed |
| Trade name | Horeko | horeko.com, Exact press release | Confirmed |
| KvK registration number | 77254171 | PartnerNavigator.com (via KvK) | Confirmed |
| Legal form | Besloten Vennootschap (B.V.) | PartnerNavigator.com | Confirmed |
| Registered address | Spaceshuttle 60, 3824 ML Amersfoort, Netherlands | horeko.com, Prospeo.io | Confirmed |
| Earlier address | Gorinchem, Netherlands | SoftwareAdvice.com profile | Estimated |
| Country | Netherlands | Multiple sources | Confirmed |
| Primary activity | Cloud-based kitchen & workforce management software for hospitality | horeko.com, Exact press release | Confirmed |
| VAT number | Unknown | No public source found | Unknown |
| IBAN / financial details | Unknown | Not publicly disclosed | Unknown |

> **Note**: KvK 02040518 ("Horeko B.V.", Lelystad) is a completely different and unrelated entity — a hospitality venue operator that went bankrupt in 2010 (Transfirm.nl). Do not conflate with the software company.

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | 2008 (Tech.eu, PartnerNavigator) / 2009 (company website) | Tech.eu (2022-07-04), horeko.com | Estimated |
| Best estimate founding year | 2008 | Tech.eu article: "they've been at it since 2008" | Estimated |
| Founder | Marvin van Dongen | Exact press release, CBInsights, Crunchbase | Confirmed |
| Co-founders | Unknown | No public source found | Unknown |
| Original location | Gorinchem, Netherlands | SoftwareAdvice.com | Estimated |
| Initial product focus | Recipe management and kitchen cost control for hospitality | Company website, product descriptions | Confirmed |
| Initial market | Netherlands | Exact press release | Confirmed |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pre-investment ownership | Founder-owned (Marvin van Dongen) | Implied by CNBB transaction structure | Estimated |
| CNBB Equity Partners investment | September 2019 (minority stake; two participations noted) | Dealmaker.nl, LinkedIn CNBB post | Estimated |
| CNBB Equity Partners description | Benelux-based growth equity firm (Antwerp / Rotterdam) | cnbb.be | Confirmed |
| Nature of CNBB investment | Growth equity / minority stake | LinkedIn post from CNBB: "proud to have supported" | Estimated |
| Acquisition by Exact | 4 July 2022 | Exact press release, Tech.eu | Confirmed |
| Acquirer full name | Exact Holding B.V. | Exact press release | Confirmed |
| Acquisition terms | Undisclosed | Exact press release | Confirmed |
| Post-acquisition brand | Exact Horeko | exact.com/nl/producten/exact-horeko | Confirmed |
| Current operating status | Integrated product line within Exact; no longer independent | exact.com support page, app.horeko.com | Confirmed |

---

## M&A History Timeline

```mermaid
timeline
    title Horeko Corporate Timeline
    2008 : Founded by Marvin van Dongen
         : Initial focus — kitchen cost management NL
    2009 : Company website references "since 2009"
         : Soft-launched cloud product for hospitality
    2012–2018 : Organic growth phase
              : Expanded to NL + BE markets
              : Grew to multi-module platform (Kitchen + Employee)
    2019 : CNBB Equity Partners investment
         : Growth equity; two participations
         : Accelerated product development and sales
    2022 : Acquired by Exact Holding B.V. (4 July)
         : Terms undisclosed
         : Rebranded as Exact Horeko
    2023–present : Fully integrated into Exact portfolio
                 : Support under Exact infrastructure
```

---

## Corporate Structure

```mermaid
graph TD
    A["Exact Holding B.V.<br/>(Acquirer, NL — PE-backed by KKR since 2015)"]
    B["Exact Software Nederland B.V.<br/>(Operating subsidiary)"]
    C["HRK Solutions B.V.<br/>trade name: Horeko<br/>KvK 77254171<br/>Amersfoort, NL"]
    D["Exact Horeko<br/>(Product brand)"]

    A --> B
    B --> C
    C --> D

    style C fill:#f9f,stroke:#333
    style D fill:#bbf,stroke:#333
```

> Exact Holding B.V. is itself owned by KKR (since 2015) and Francisco Partners. Horeko is therefore now indirectly PE-owned at multiple levels.

---

## Name Changes & Entity Notes

| Date | Event | Source | Confidence |
|---|---|---|---|
| 2008/2009 | Founded as HRK Solutions B.V. with trade name Horeko | PartnerNavigator.com | Confirmed |
| 2022-07-04 | Acquired by Exact; brand renamed Exact Horeko | Exact press release | Confirmed |
| 2022–present | Domain horeko.com redirects to Exact support page | horeko.com (verified 2026-04-30) | Confirmed |

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | NOT AVAILABLE — fully acquired by Exact Holding B.V. in July 2022 |
| **Ownership structure** | Now owned by Exact (KKR/Francisco Partners PE-backed) |
| **SolStein thesis fit** | Fails primary criterion: no longer founder-owned or independent |
| **Carve-out possibility** | Theoretically possible (carve-out from Exact), but highly unlikely at this stage |
| **Alternative** | Use as competitive/valuation benchmark for comparable kitchen-management targets |

**Verdict**: Horeko is a **confirmed acquisition blocker**. It was exactly the type of company SolStein targets (founder-owned, niche HORECA kitchen management, NL/BE market, cloud-native, high switching costs, ~€5M ARR) — but it was acquired in July 2022 by Exact before SolStein's evaluation. This case reinforces the importance of acting quickly on targets that fit the thesis.

---

## Sources

| Source | URL | Type |
|---|---|---|
| Exact press release — acquisition announcement | https://www.exact.com/news/exact-will-unburden-the-hospitality-industry-with-acquisition-of-horeko | Primary (press release) |
| Tech.eu acquisition coverage | https://tech.eu/2022/07/04/order-up-belgium-s-horeko-acquired-by-the-exact-right-buyer/ | Secondary (news) |
| PartnerNavigator — HRK Solutions B.V. profile | https://portal.partnernavigator.com/database/company/hrk-solutions-bv-horeko | Secondary (company DB) |
| CBInsights — Horeko people | https://www.cbinsights.com/company/horeko/people | Secondary (company DB) |
| Crunchbase — Horeko profile | https://www.crunchbase.com/organization/horeko | Secondary (company DB) |
| Prospeo — Horeko overview | https://prospeo.io/c/horeko | Secondary (company DB) |
| ZoomInfo — Horeko profile | https://www.zoominfo.com/c/horeko/372838893 | Secondary (company DB) |
| PitchBook — Horeko 2026 profile | https://pitchbook.com/profiles/company/99966-61 | Secondary (company DB) |
| CNBB Equity Partners LinkedIn post | https://nl.linkedin.com/posts/cnbb-equity-partners_horeko-acquired-by-exact-cnbb-is-proud-activity-6949751436020752384-UNfI | Secondary (social) |
| Dealmaker.nl — CNBB deals | https://www.dealmaker.nl/company/cnbb-equity-partners/deals | Secondary (deal DB) |
| Horeko.com (now redirects to Exact) | https://horeko.com/en/ | Primary (company site) |
| Exact Horeko product page | https://www.exact.com/nl/producten/exact-horeko | Primary (product page) |
| Transfirm.nl — Horeko B.V. KvK 02040518 | https://www.transfirm.nl/nl/organisatie/02040518-000019570422-horeko-b.v. | Note: unrelated entity (bankrupt 2010) |
