# Horeko — Deep Analysis

**Research Date**: 2026-04-30
**Researcher**: SolStein M&A Research
**Verdict**: NOT an available M&A target — acquired by Exact Holding B.V. on 4 July 2022

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | HRK Solutions B.V. | PartnerNavigator.com | Confirmed |
| Trade name | Horeko | horeko.com, Exact press release | Confirmed |
| KvK number | 77254171 | PartnerNavigator.com | Confirmed |
| Founded | 2008 (Tech.eu) / 2009 (company website) | Tech.eu 2022-07-04; horeko.com | Estimated |
| Founder | Marvin van Dongen | Exact press release; CBInsights | Confirmed |
| Headquarters | Spaceshuttle 60, 3824 ML Amersfoort, Netherlands | horeko.com; Prospeo | Confirmed |
| Previous location | Gorinchem, Netherlands | SoftwareAdvice profile | Estimated |
| Current parent | Exact Holding B.V. (acquired July 2022) | Exact press release | Confirmed |
| Employee count (pre-acquisition) | ~29 (ZoomInfo) / 21–50 range (Prospeo) | ZoomInfo; Prospeo.io | Estimated |
| Current employee count (Exact Horeko) | Unknown — integrated into Exact | No post-acquisition headcount disclosed | Unknown |
| Revenue (pre-acquisition estimate) | ~€4.8–5M ARR | ZoomInfo ($5.2M); Prospeo ($5.4M) | Estimated |
| Profitability | Unknown — terms undisclosed | No public financial filings | Unknown |
| Business model | SaaS subscription (monthly/annual) | exact.com/nl/producten/exact-horeko | Confirmed |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary market | Netherlands | Exact press release | Confirmed |
| Secondary market | Belgium | Exact press release; horeko.com/be | Confirmed |
| Customer count (pre-acquisition) | 1,500+ companies | Exact press release (July 2022) | Confirmed |
| Customer verticals | Restaurants, cafeterias, hotels, franchise chains | Exact press release | Confirmed |
| Target size | Medium and small hospitality businesses (primary); large multi-location operations (upmarket positioning) | Exact press release; KitchenNmbrs.app analysis | Confirmed |
| Competitive positioning | Mid-market enterprise kitchen ERP; more feature-rich than simple food-cost apps, less complex than full ERP | KitchenNmbrs.app comparison | Estimated |
| Key competitors (pre-acquisition) | Apicbase (BE), FoodNotify, KitchenNmbrs, Lightspeed, Nory | Market analysis | Estimated |
| NL market share | Unknown — no public data | No reliable source | Unknown |
| Retention / churn | Unknown — no public data | No reliable source | Unknown |
| NPS / satisfaction | Positive reviews across Capterra, GetApp, SoftwareAdvice | Capterra; GetApp; SoftwareAdvice | Estimated |

---

## 3. Product & Technology

### Product Modules

| Module | Price (pre-acquisition) | Key Features | Source | Confidence |
|---|---|---|---|---|
| **Kitchen Manager** | €175/month | Recipe management, cost price calculation, menu engineering, allergen management, HACCP registration (temperature logs, shelf-life labels, defrost/production dates), waste registration, inventory management, supplier price integration | exact.com pricing page; GetApp; SoftwareAdvice | Confirmed |
| **Employee Manager** | €70/month | Staff scheduling, workforce planning, time registration (PIN/biometric/RFID), leave management, labor cost reporting, mobile clock-in | exact.com pricing page; GetApp | Confirmed |
| **Restaurant Management Suite** | €245/month | Combined Kitchen Manager + Employee Manager | exact.com pricing page | Confirmed |
| Setup / implementation fee | €500–€1,500 (one-time) | Onboarding and configuration | KitchenNmbrs.app | Estimated |

### Technology Stack

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Deployment model | Cloud-based SaaS | horeko.com; GetApp | Confirmed |
| Mobile support | iOS and Android apps (kitchen operators + employees) | Google Play (Exact Horeko app); GetApp | Confirmed |
| API / integration architecture | REST API integrations with POS and third-party systems | Integration pages; Restomax.be | Estimated |
| POS integrations | unTill, Lightspeed Retail, Aloha EPOS, Vectron, Clixx, Booq | GetApp; Restomax.be integration page | Confirmed |
| Other integrations | Nmbrs (payroll/HR), Bakers Brigade, Bid Food, Countler, Delidis, Scanfie, Restomax, DataProfit | GetApp; Restomax.be; dataprofit.com | Confirmed |
| Underlying technology | Unknown — no public stack disclosure | No reliable source | Unknown |
| Data hosting | Unknown — likely Netherlands-based cloud | Not publicly disclosed | Unknown |
| Multi-location support | Yes — designed for chains with central purchasing | KitchenNmbrs.app; product descriptions | Confirmed |
| Offline capability | Unknown | No reliable source | Unknown |

### Regulatory & Compliance Features

| Feature | Description | Source | Confidence |
|---|---|---|---|
| Allergen management | Full EU Regulation 1169/2011 allergen labelling support — tracks 14 regulated allergens per recipe and ingredient | GetApp; SoftwareSuggest; KitchenNmbrs.app | Confirmed |
| HACCP registration | Digital HACCP task logging, temperature records, shelf-life labels, critical control point tracking | GetApp; SoftwareAdvice; KitchenNmbrs.app | Confirmed |
| Food safety labelling | Production date, defrost date, use-by date labels | GetApp | Confirmed |
| GDPR compliance | Standard Dutch SaaS GDPR compliance assumed; no specific certifications found | Assumed (Dutch company) | Estimated |
| Food cost calculation | Recipe costing, dish margin calculation, menu engineering | Exact press release; KitchenNmbrs.app | Confirmed |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pre-acquisition ownership | Marvin van Dongen (founder/CEO) + CNBB Equity Partners (minority) | Exact press release; LinkedIn CNBB post; Dealmaker.nl | Confirmed |
| CNBB Equity Partners role | Growth equity minority investor; two participations in 2019 | Dealmaker.nl; LinkedIn CNBB post (July 2022) | Estimated |
| Founder succession signal | Marvin van Dongen actively led acquisition process; quoted in press release | Exact press release | Confirmed |
| Post-acquisition founder role | Unknown — likely stepped down or transitional role post-integration | Not publicly disclosed | Unknown |
| Current ownership | Exact Holding B.V. (owned by KKR + Francisco Partners PE funds) | Exact corporate disclosures | Confirmed |
| Independence status | Fully absorbed — no longer an independent legal entity for commercial purposes | horeko.com now redirects to Exact support | Confirmed |
| SolStein M&A feasibility | BLOCKED — owned by large PE-backed acquirer (Exact/KKR) | Multiple sources | Confirmed |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pre-acquisition estimated ARR | ~€4.8–5M | ZoomInfo ($5.2M); Prospeo ($5.4M) converted at ~1.08 EUR/USD | Estimated |
| Customer count at acquisition | 1,500+ | Exact press release (July 2022) | Confirmed |
| Implied ARPC (annual revenue per customer) | ~€3,200/year (~€267/month) | Derived from ARR ÷ customer count | Estimated |
| CNBB investment impact | Likely accelerated sales and product development (2019–2022) | Investment thesis inference | Estimated |
| Revenue CAGR | Unknown — no historical financials available | No public source | Unknown |
| Headcount growth trajectory | Unknown | No public data | Unknown |
| Post-acquisition revenue | Now part of Exact; not separately reported | Exact does not break out Horeko revenue | Unknown |
| Pricing benchmark | €70–245/month per location (modules); comparable to Apicbase, FoodNotify at similar tiers | exact.com pricing; market comparison | Confirmed |

**Revenue trajectory interpretation**: With 1,500+ customers at ~€267/month average, Horeko's ~€5M ARR is consistent with a healthy NL/BE mid-market SaaS business. The CNBB investment in 2019 and subsequent acquisition by Exact in 2022 (3-year hold) suggests CNBB achieved a successful exit and Horeko was growing attractively enough to draw a strategic acquirer.

---

## 6. HORECA Vertical Depth

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| **Allergen compliance** | Full EU Reg. 1169/2011 allergen management: 14 allergens tracked at recipe and ingredient level; allergen tags on labels | GetApp; SoftwareSuggest; KitchenNmbrs.app | Confirmed |
| **HACCP compliance** | Digital HACCP logs, temperature registrations, critical control points, audit trails | GetApp; SoftwareAdvice | Confirmed |
| **Food safety labelling** | Production/use-by/defrost date labels generated via Kitchen Manager | GetApp | Confirmed |
| **Recipe management** | Full recipe costing, sub-recipe support, bulk conversion, menu engineering, food cost % tracking | Exact press release; product descriptions | Confirmed |
| **Inventory management** | Integrated stock management with supplier price synchronization via API | dataprofit.com; KitchenNmbrs.app | Confirmed |
| **Purchasing / procurement** | Supplier integration (Bid Food, Bakers Brigade); automated price updates | GetApp; Restomax.be | Confirmed |
| **Workforce management** | Full scheduling, time registration (biometric/PIN/RFID), leave, labor cost reporting | GetApp; exact.com | Confirmed |
| **Payment integrations** | Via POS integrations (unTill, Lightspeed, Aloha, Vectron) — no direct payment processing | GetApp; Restomax.be | Confirmed |
| **Multi-location / franchise** | Designed for chains with central purchasing and outlet-level reporting | KitchenNmbrs.app; product descriptions | Confirmed |
| **GDPR / data privacy** | Netherlands-registered SaaS; standard GDPR compliance assumed | Regulatory inference | Estimated |
| **F&B analytics** | DataProfit integration for advanced analytics; built-in margin reporting | dataprofit.com integration page | Confirmed |

**Vertical depth assessment**: Horeko had deep HORECA vertical specialization. The combination of allergen compliance, HACCP registration, recipe costing, inventory management, and workforce planning in a single cloud platform made it a genuine kitchen ERP for mid-sized NL/BE hospitality operators. This is precisely the type of "sticky" niche product that creates high switching costs and recurring revenue — exactly the vertical depth SolStein values.

---

## 7. Valuation & Business Model

### Business Model

| Aspect | Detail | Source | Confidence |
|---|---|---|---|
| Revenue model | Monthly SaaS subscription (module-based) | exact.com pricing; product pages | Confirmed |
| Pricing tiers | Employee Manager: €70/mo; Kitchen Manager: €175/mo; Suite: €245/mo | exact.com/nl/producten/exact-horeko/features-en-prijzen | Confirmed |
| Per-location pricing | Implied — multi-location pricing available on request | KitchenNmbrs.app | Estimated |
| Contract terms | Monthly or annual subscriptions offered | SoftwareAdvice; product descriptions | Estimated |
| Setup fees | €500–€1,500 one-time | KitchenNmbrs.app | Estimated |
| Free trial | Not standard — demo-based sales process | Product pages | Estimated |
| Distribution | Direct sales + partner/integrator channel (Restomax, etc.) | Restomax.be integration page | Estimated |

### Valuation at Acquisition (July 2022)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Acquisition price | Undisclosed | Exact press release | Confirmed |
| Estimated ARR at acquisition | ~€4.8–5M | ZoomInfo; Prospeo | Estimated |
| Typical SaaS valuation multiple (NL mid-market, 2022) | 4–8× ARR for profitable niche SaaS | Market benchmarks (2022 vintage) | Estimated |
| Implied acquisition value range | €20M–€40M | Derived estimate only | Estimated |
| Strategic premium factor | Exact paid strategic premium — Horeko fills HORECA gap in Exact's SME portfolio | Exact press release rationale | Estimated |
| PitchBook implied valuation (Prospeo) | ~$17.3M (~€16M) — likely pre-acquisition estimate, not transaction price | Prospeo.io | Estimated |

> **Important caveat**: All valuation estimates are derived. The actual transaction price was not disclosed. The Prospeo/PitchBook figure likely reflects a pre-acquisition or minority stake valuation, not the full acquisition price. A strategic acquirer like Exact would typically pay above financial buyer multiples.

---

## 8. M&A Attractiveness Scorecard

> **Critical note**: Horeko was acquired by Exact Holding B.V. on 4 July 2022. The scorecard below reflects Horeko **as it existed pre-acquisition** (2021–early 2022) to serve as a benchmark for comparable kitchen-management targets SolStein may evaluate. All scores are for historical reference only — Horeko is **not an active target**.

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 3 | Founder-led but had minority PE (CNBB) — partially diluted from ideal pure founder-owned. Van Dongen was active and drove the sale, suggesting succession willingness. Pre-PE (2018) would have scored 5. | Exact press release; CNBB LinkedIn post |
| Revenue scale fit | High | 4 | ~€5M ARR fits squarely in SolStein's €1M–€15M target range. Profitable assumed (PE-backed, clean exit). | ZoomInfo; Prospeo |
| Geographic fit | High | 5 | Exclusively NL + BE market; 1,500+ customers in Benelux. Perfect geographic alignment. | Exact press release |
| Tech stack modernity | Medium | 5 | Cloud-native SaaS from inception; iOS/Android apps; REST API integrations; multi-location architecture. No legacy infrastructure noted. | GetApp; Google Play; horeko.com |
| Customer lock-in | Medium | 5 | Deep operational embedding: recipes, allergen data, HACCP records, employee scheduling all in one platform. Switching costs are very high — data migration is complex and disruptive. | Product feature analysis; KitchenNmbrs.app |
| Vertical depth | Medium | 5 | Full kitchen ERP: allergens, HACCP, recipe costing, inventory, purchasing, workforce — all in one NL/BE-focused product. One of the deepest HORECA kitchen platforms in Benelux at time of acquisition. | Product feature analysis; Exact press release |
| Integration potential | Low | 4 | REST API integrations with major POS systems (unTill, Lightspeed, Aloha, Vectron); payroll (Nmbrs); suppliers; analytics (DataProfit). Open ecosystem approach. | GetApp; Restomax.be |
| Growth trajectory | Low | 4 | 1,500+ customers, CNBB growth investment in 2019, successful exit to strategic acquirer in 2022. Trajectory was clearly positive — attractive enough for Exact. | Exact press release; deal history |

### Composite Score

| Metric | Value |
|---|---|
| **Weighted composite score** | **4.4 / 5.0** |
| **Confidence band** | Medium — ~55% Confirmed, ~35% Estimated, ~10% Unknown |
| **Overall Assessment** | Horeko was an **excellent SolStein fit** on all dimensions except availability. It scores in the top tier of the NL HORECA IT landscape. The acquisition by Exact validates the thesis: this was exactly the kind of target that strategic buyers compete for. |
| **Recommended Next Step** | Use Horeko as the **benchmark** for comparable kitchen/recipe/allergen software targets in NL/BE. Identify similar pre-acquisition stage companies (e.g., Foodcase, Apicbase pre-scale, or emerging kitchen management SaaS) before they attract PE or strategic interest. |

### Score Calculation (Weighted Average)

| Dimension | Weight Factor | Score | Weighted Points |
|---|---|---|---|
| Ownership attractiveness | 3 (High) | 3 | 9 |
| Revenue scale fit | 3 (High) | 4 | 12 |
| Geographic fit | 3 (High) | 5 | 15 |
| Tech stack modernity | 2 (Medium) | 5 | 10 |
| Customer lock-in | 2 (Medium) | 5 | 10 |
| Vertical depth | 2 (Medium) | 5 | 10 |
| Integration potential | 1 (Low) | 4 | 4 |
| Growth trajectory | 1 (Low) | 4 | 4 |
| **Total** | **17** | — | **74** |
| **Composite (74 ÷ 17)** | — | — | **4.35 ≈ 4.4 / 5.0** |

---

## Strategic Implications for SolStein

1. **Horeko is unavailable** — no further acquisition pursuit warranted.
2. **Horeko validates the thesis** — a kitchen/recipe/allergen SaaS in NL with ~€5M ARR, 1,500+ customers, and high switching costs attracted both PE (CNBB 2019) and a strategic acquirer (Exact 2022). This is exactly the profile SolStein should pursue before similar exits occur.
3. **Timing is critical** — Horeko likely had a 3–4 year window between becoming acquisition-ready (2018–2019) and being acquired (2022). SolStein should identify comparable targets now and act before PE or strategics arrive.
4. **Comparable targets to evaluate**: Foodcase (NL, inventory), emerging kitchen SaaS startups in NL/BE, any standalone allergen-compliance SaaS without PE backing.
5. **Valuation benchmark**: A Horeko-comparable NL HORECA kitchen SaaS at €4–6M ARR with high switching costs and founder ownership likely commands **€20–40M** in a strategic transaction. SolStein should model targets in this range.

---

## Sources

| Source | URL | Type | Confidence Level Used |
|---|---|---|---|
| Exact acquisition press release | https://www.exact.com/news/exact-will-unburden-the-hospitality-industry-with-acquisition-of-horeko | Primary | Confirmed |
| Tech.eu acquisition article | https://tech.eu/2022/07/04/order-up-belgium-s-horeko-acquired-by-the-exact-right-buyer/ | Secondary news | Confirmed |
| PartnerNavigator — HRK Solutions B.V. | https://portal.partnernavigator.com/database/company/hrk-solutions-bv-horeko | Secondary DB | Confirmed |
| Exact Horeko product + pricing page | https://www.exact.com/nl/producten/exact-horeko/features-en-prijzen | Primary | Confirmed |
| horeko.com (archived / redirected) | https://horeko.com/en/ebooks-whitepapers/author/horeko | Primary (historical) | Confirmed |
| ZoomInfo — Horeko | https://www.zoominfo.com/c/horeko/372838893 | Secondary DB | Estimated |
| Prospeo — Horeko overview | https://prospeo.io/c/horeko | Secondary DB | Estimated |
| CBInsights — Horeko people | https://www.cbinsights.com/company/horeko/people | Secondary DB | Confirmed |
| Crunchbase — Horeko | https://www.crunchbase.com/organization/horeko | Secondary DB | Estimated |
| PitchBook — Horeko 2026 profile | https://pitchbook.com/profiles/company/99966-61 | Secondary DB | Estimated |
| CNBB Equity Partners LinkedIn post | https://nl.linkedin.com/posts/cnbb-equity-partners_horeko-acquired-by-exact-cnbb-is-proud-activity-6949751436020752384-UNfI | Secondary social | Estimated |
| Dealmaker.nl — CNBB deals | https://www.dealmaker.nl/company/cnbb-equity-partners/deals | Secondary deal DB | Estimated |
| GetApp — Horeko features | https://www.getapp.com/retail-consumer-services-software/a/horeko/ | Secondary review | Confirmed |
| SoftwareAdvice — Horeko | https://www.softwareadvice.com/scheduling/horeko-profile/ | Secondary review | Confirmed |
| Capterra — Horeko | https://www.capterra.com/p/182663/Horeko/ | Secondary review | Confirmed |
| Restomax.be — Horeko integrations | https://www.restomax.be/en/integrations-horeko | Secondary partner | Confirmed |
| DataProfit — Horeko integration | https://dataprofit.com/en/integrations/horeko | Secondary partner | Confirmed |
| KitchenNmbrs.app — competitive analysis | https://kitchennmbrs.app/en/knowledge-base/software-comparison-alternatives/wat-is-horeko-en-voor-welk-type-horecabedrijf-is-het-bedoeld | Secondary competitor | Estimated |
| Google Play — Exact Horeko app | https://play.google.com/store/apps/details?id=com.Horeko&hl=en_US | Primary (app store) | Confirmed |
