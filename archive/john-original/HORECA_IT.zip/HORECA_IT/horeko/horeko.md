# Horeko

**Category**: Kitchen/F&B
**Country**: NL
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history Horeko @HORECA_IT/horeko/
@research-horeca-company Horeko @HORECA_IT/horeko/
```
