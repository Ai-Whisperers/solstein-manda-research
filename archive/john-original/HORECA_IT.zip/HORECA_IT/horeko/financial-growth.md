# Financial & Growth Deep-Dive — Horeko (HRK Solutions B.V.)

**Research Date**: 2026-04-30
**Researcher**: SolStein M&A Research
**Status**: Post-acquisition — data reflects pre-acquisition period (2019–2022)
**Data Availability**: Low — private Dutch B.V.; no public financial filings found; KvK annual accounts not publicly indexed; all revenue figures are third-party estimates or derived proxies

> **Critical context**: Horeko was acquired by Exact Holding B.V. on 4 July 2022. This analysis covers the pre-acquisition period only. Post-acquisition financials are consolidated into Exact Group and not separately disclosed. All growth metrics reflect Horeko as an independent company.

---

## Revenue Timeline

| Year | Revenue (Est.) | Currency | EUR Equivalent | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| 2022 (at acq.) | ~€4.8–5.0M ARR | EUR | €4.8–5.0M | +13–17% est. | ZoomInfo ($5.2M); Prospeo ($5.4M) converted @ ~1.08 EUR/USD | Estimated |
| 2021 | ~€4.2–4.4M ARR | EUR | €4.2–4.4M | +15–20% est. | Proxy: 1,400+ customers × ~€267/mo ARPC (derived) | Estimated (proxy) |
| 2020 | ~€3.6–3.8M ARR | EUR | €3.6–3.8M | –5 to –10% est. | COVID impact: NL HORECA mandatory closures Q2–Q4 2020; customer churn/pause likely | Estimated (proxy) |
| 2019 (at invest.) | ~€3.8–4.0M ARR | EUR | €3.8–4.0M | +10–15% est. | Proxy: 1,200+ customers (consultancy.nl, Sep 2019) × ~€267/mo ARPC | Estimated (proxy) |
| 2018 | ~€3.0–3.5M ARR | EUR | €3.0–3.5M | Unknown | No source; inferred from CNBB investment rationale | Unknown |
| 2017 | Unknown | EUR | Unknown | Unknown | No source | Unknown |

**Revenue CAGR (3yr, 2019–2022)**: ~8–10% (Estimated — modest growth for a bootstrapped niche SaaS with COVID disruption in 2020)
**Revenue CAGR (5yr)**: Not calculable — no reliable data before 2019

**ARPC derivation note**: €267/month derived from ~€5M ARR ÷ 1,500 customers ÷ 12 months. Reflects blended mix of Employee Manager (€70/mo), Kitchen Manager (€175/mo), and suite customers (€245/mo). Historical ARPC assumed similar; likely slightly lower pre-2022 as product pricing may have increased post-CNBB investment.

**COVID 2020 impact note**: The Netherlands enforced mandatory HORECA closure from mid-March to June 2020, and further restrictions through late 2021. Horeko's SaaS revenue would have been partially protected by subscription contracts, but churn or payment deferrals are likely. The 2020 dip is modelled conservatively; the company may have had contractual protections that partially offset customer losses.

### Revenue Trend Chart

```mermaid
xychart-beta
    title "Horeko Estimated Revenue Trend (EUR M)"
    x-axis [2018, 2019, 2020, 2021, 2022]
    y-axis "EUR Millions" 0 --> 6
    line [3.2, 3.9, 3.7, 4.3, 4.9]
```

> Chart uses midpoint estimates. All values are estimated proxies — no confirmed revenue data is publicly available for any year. See confidence column above.

---

## Profitability

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| EBITDA (pre-acquisition) | Unknown — not publicly disclosed | No public filing | Unknown |
| EBITDA Margin | Unknown — implied positive; CNBB exit to strategic acquirer suggests profitability | Inference from clean exit | Estimated |
| Net Profit / Loss | Unknown | KvK accounts not publicly available | Unknown |
| Recurring Revenue % | ~100% | All revenue from monthly SaaS subscriptions | Confirmed |
| SaaS / Subscription Revenue % | ~100% | Product is exclusively SaaS; no perpetual licence model | Confirmed |
| Revenue per Employee (EUR) | ~€169K–€215K/year | Calculated: ~€4.9M ÷ ~25–29 employees at acquisition | Estimated |
| Profitability signal | Positive — profitable enough for CNBB to take minority equity (not distress capital) and for Exact to acquire at strategic price | CNBB investment rationale; clean Exact exit | Estimated |

**Profitability interpretation**: HRK Solutions B.V. was a private Dutch B.V. with no obligation to publish detailed P&L if it qualified for a micro or small-company filing exemption. No financial statements were publicly indexed. However, the combination of: (a) bootstrapped to 1,200 customers before CNBB; (b) CNBB's growth equity (not rescue) investment; and (c) a clean strategic exit to Exact in 2022, strongly implies the company was EBITDA-positive at time of sale. HORECA SaaS companies in the NL/BE market with high switching costs typically operate at 20–35% EBITDA margins once at scale.

---

## Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| 2008/2009–2019 | Bootstrapped | — | None (founder-funded) | N/A | Implied by pre-CNBB ownership structure; Marvin van Dongen + Daan Stoter | Estimated |
| September 2019 | Growth equity (minority stake) | Undisclosed | CNBB Venture Partners | Undisclosed | Consultancy.nl; Dealmaker.nl; LinkedIn CNBB post | Estimated |
| July 2022 | Full acquisition | Undisclosed (estimated €20–40M strategic premium) | Exact Holding B.V. | Undisclosed | Exact press release; ZoomInfo/Prospeo revenue base × 4–8× SaaS multiple | Estimated |

**Total External Raised**: CNBB minority stake only — undisclosed amount. Estimated €1–5M based on typical CNBB deal sizes for NL/BE mid-market SaaS at this ARR level. No other rounds identified.

**Latest Valuation**: Undisclosed — Prospeo/PitchBook listed ~$17.3M (~€16M) pre-acquisition. Estimated transaction value €20–40M based on ~€5M ARR × 4–8× SaaS multiple (2022 vintage NL mid-market); strategic acquirer like Exact would typically pay 6–10× for vertical-fit targets.

**Current Investors**: Exact Holding B.V. (100% owner since July 2022), itself owned by KKR + Francisco Partners since 2015.

**War Chest Signals**: None applicable — Horeko was the acquired party, not the acquirer. Post-acquisition, Exact's PE backing (KKR) provides capital for integration and continued development.

**CNBB profile**: CNBB Venture Partners (Antwerp/Rotterdam) is a Benelux growth equity firm focused exclusively on software companies. Their investment in Horeko in September 2019 marked the only external capital infusion before the Exact acquisition. Baker Tilly Corporate Finance advised Horeko on the CNBB deal. CNBB's 3-year hold (2019–2022) and successful exit to Exact represents a clean, short-cycle PE return — consistent with a company that was already profitable and growing when CNBB entered.

**Second founder departure**: Co-founder Daan Stoter (commercial director) left at end of 2019 following the CNBB investment, leaving Marvin van Dongen as sole operational owner. This succession event preceded and may have facilitated the eventual full exit to Exact.

---

## Employee Timeline

| Year | Headcount | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- |
| 2026 (current) | ~23 (post-integration attrition) | N/A | RocketReach (post-acquisition profile) | Estimated |
| 2022 (at acquisition) | ~25–29 | +15–20% est. | ZoomInfo (~29); Prospeo (21–50 range) | Estimated |
| 2021 | ~22–25 | +10–15% est. | Derived from ZoomInfo snapshot; LinkedIn job postings active | Estimated (proxy) |
| 2020 | ~18–22 | –5 to +5% est. | COVID year — HORECA clients under pressure; hiring freeze likely | Estimated (proxy) |
| 2019 (at CNBB invest.) | ~15–20 | +10–15% est. | Pre-CNBB; two founders + early team; 1,200+ customers supported | Estimated (proxy) |
| 2018 | ~12–17 | Unknown | No source; inferred from earlier-stage company | Unknown |

**Employee CAGR (3yr, 2019–2022)**: ~17–22% (Estimated — strong for a small NL SaaS; reflects CNBB-funded professionalisation push)

**Current Open Positions**: None — product fully integrated into Exact; hiring via Exact Amersfoort office

**Hiring Hotspots (pre-acquisition)**: Amersfoort, Netherlands (sole office); roles included implementation consultants, .NET software engineers, product specialists, and customer success

**Post-acquisition note**: RocketReach shows ~23 employees in the Horeko profile post-acquisition, slightly below the ~29 ZoomInfo pre-acquisition estimate. Integration into Exact likely consolidated some back-office and support functions into Exact's central team, reducing standalone headcount.

### Employee Growth Chart

```mermaid
xychart-beta
    title "Horeko Estimated Employee Growth"
    x-axis [2018, 2019, 2020, 2021, 2022, 2026]
    y-axis "Headcount" 0 --> 35
    line [15, 18, 20, 23, 27, 23]
```

> Chart uses midpoint estimates. 2026 reflects post-acquisition profile. All values are estimated.

---

## Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2008/2009 | Founded; initial market | Netherlands | Kitchen management software launched for NL HORECA operators | horeko.com; corporate-history.md | Confirmed |
| ~2012–2018 | Organic geographic expansion | Belgium | Belgian customers added; horeko.com/be operational; BE restaurant chains onboarded | Exact press release (confirms NL+BE at acquisition) | Estimated |
| 2019 | CNBB investment — international aspiration | NL + BE | Van Dongen stated "ons potentieel is zeker groter dan de lage landen" (our potential exceeds the Low Countries); international growth cited as a goal | Consultancy.nl (Sep 2019) | Confirmed |
| 2019–2022 | No international expansion executed | NL + BE only | Despite aspiration, no evidence of DACH or UK market entry before acquisition | No press releases or product localisation found | Estimated |
| July 2022 | Acquired by Exact | NL + BE | Exact's rationale: fill HORECA gap in Benelux SME portfolio; no international expansion mandate | Exact press release | Confirmed |

**Primary Market**: Netherlands (70–80% of customers estimated)
**Secondary Market**: Belgium (20–30% of customers estimated; horeko.com/be confirmed)
**International Revenue %**: Not disclosed; believed negligible (<5%) — no DACH, UK, or other market entry found
**Expansion Trajectory**: Horeko aimed for international expansion post-CNBB investment but remained a Benelux-only operator through the 2022 acquisition. The NL/BE focus reflects a disciplined go-to-market rather than failed internationalisation — the product's regulatory depth (NL/BE-specific HACCP labelling, allergen regulations, Nmbrs payroll integration) tied it closely to the Benelux market.

---

## M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| September 2019 | CNBB Venture Partners investment in Horeko | Minority equity (undisclosed) | Growth capital + strategic board support; professionalisation of go-to-market | Accelerate product development and market penetration; CNBB specialises in growing SaaS companies | Consultancy.nl; Dealmaker.nl | Estimated |
| 4 July 2022 | **Horeko acquired by Exact Holding B.V.** | Undisclosed (est. €20–40M) | Full acquisition — Horeko becomes Exact Horeko | Exact gained a kitchen/workforce management SaaS to complete its HORECA SME portfolio in NL/BE | Exact press release; Tech.eu | Confirmed |

**Acquisitions made by Horeko**: None — Horeko did not make any acquisitions during its independent existence.

**Divestitures**: None.

**M&A Pattern**: Horeko was exclusively an acquired party, not an acquirer. Its M&A history is a single, defining event: the July 2022 strategic exit to Exact. The 3-year CNBB hold (2019–2022) followed the typical Benelux growth equity playbook: minority investment → professionalisation → strategic exit. The clean exit validates the company's quality as an acquisition target.

---

## SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | Cloud-native SaaS — web app + iOS + Android mobile apps | horeko.com; GetApp; Google Play | Confirmed |
| Cloud Revenue % (current) | ~100% — no on-premise version ever existed | Product architecture; no legacy installer found | Confirmed |
| Recurring Revenue % | ~100% — monthly subscription only; no one-time perpetual licences | exact.com pricing page; product descriptions | Confirmed |
| Payment Integrations | Not publicly disclosed for subscription billing; POS integrations include unTill, Lightspeed, Aloha, Vectron | GetApp; Restomax.be | Confirmed |
| Platform Stack | Unknown — proprietary cloud; .NET backend suspected (Exact Horeko .NET engineer job postings post-acquisition) | Indeed.com job posting (Exact Horeko .NET) | Estimated |
| API / Integration Model | REST API integrations with POS (unTill, Lightspeed, Aloha, Vectron, Clixx, Booq), payroll (Nmbrs), suppliers (Bid Food, Bakers Brigade), analytics (DataProfit), PMS (Restomax) | GetApp; Restomax.be; dataprofit.com | Confirmed |
| Migration Status | Not applicable — born cloud-native; no legacy migration required | Product history | Confirmed |
| Mobile Maturity | Full iOS + Android apps for kitchen operators and employees (clock-in, scheduling, HACCP logging) | Google Play (Exact Horeko app); App Store | Confirmed |
| Multi-tenancy / Multi-location | Yes — designed for chains and franchise groups with central purchasing | KitchenNmbrs.app; product descriptions | Confirmed |

**SaaS maturity assessment**: Horeko was cloud-native from day one — Marvin van Dongen originally built the kitchen management system during his student years and launched it as a cloud product. There was never an on-premise phase, no legacy debt, and no migration required. By the time of the CNBB investment, the platform had REST APIs, mobile apps, and a growing integration ecosystem. This is a fully mature SaaS architecture — among the most modern profiles in the NL/BE HORECA IT landscape.

---

## Growth Scorecard

| Dimension | Score (1–10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | **4** | Est. CAGR ~8–10% (2019–2022); customer count grew 1,200→1,500 (~7.7% CAGR); COVID impacted 2020; modest but steady for bootstrapped niche SaaS |
| Funding Momentum | **3** | Single minority growth equity round (CNBB, Sep 2019, undisclosed <€5M est.); no VC, no Series A/B; bootstrapped origin; clean but modest funding history |
| Employee Growth | **6** | Est. employee CAGR ~17–22% (2019–2022); ~15–18 → ~27–29 employees; strong relative growth for small company; CNBB-funded professionalisation drove hiring acceleration |
| Geographic Expansion | **3** | NL primary + BE secondary; Benelux-only through acquisition; international aspiration stated at CNBB close (Sep 2019) but not executed; no DACH/UK entry |
| M&A Activity | **1** | No acquisitions made; purely organic growth strategy; was itself the acquisition target in 2022 |
| SaaS Maturity | **9** | Cloud-native from founding (~2008/2009); 100% recurring revenue; iOS+Android apps; REST API ecosystem (10+ integrations); no on-premise legacy; multi-location architecture |
| **COMPOSITE SCORE** | **4.3** | **Steady** — Stable, profitable niche SaaS operator with excellent vertical depth and tech maturity, but modest revenue growth and no M&A ambition |

**Classification Thresholds**:

- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

**Classification**: **Steady** (4.3 / 10) — Horeko was a healthy, profitable, cloud-native niche SaaS with deep vertical embedding and very high switching costs. Its modest growth trajectory reflects a disciplined NL/BE market focus rather than ambition failure. The 9/10 SaaS maturity score is exceptional for a company of this size and vintage. The low M&A score (1/10) and geographic score (3/10) reflect that Horeko grew organically within its established geography — a rational strategy for a small bootstrapped operator in a niche vertical.

### Growth Scorecard Chart

```mermaid
xychart-beta
    title "Horeko Growth Scorecard (1–10)"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [4, 3, 6, 3, 1, 9]
```

---

## SolStein M&A Interpretation

### Why Horeko Scored "Steady" But Was Strategically Compelling

The 4.3 composite Growth Scorecard score might suggest an unremarkable company — but this would be a misreading. The "Steady" classification reflects **what Horeko was**, not what it was worth. Exact paid an estimated €20–40M for a ~€5M ARR business because of the scorecard dimensions that don't measure growth rate: 100% cloud-native architecture, 100% recurring revenue, 1,500+ deeply embedded customers in a niche Benelux vertical, and near-100% switching costs once kitchen recipes, HACCP logs, allergen data, and employee scheduling are operational.

**SolStein lesson**: For acquisition targets in the €1M–€15M ARR range, a "Steady" Growth Score is not disqualifying — it may indicate a profitable, cash-generative business with untapped growth potential that the right acquirer (like SolStein) could unlock. The "Rocket" and "Riser" companies are typically already PE-backed and priced for their growth trajectory. The "Steady" companies offer better entry multiples with equivalent strategic depth.

### Data Confidence Assessment

| Category | Confidence |
| --- | --- |
| Revenue timeline | Low — all figures are third-party estimates or derived proxies; no KvK filing found |
| Funding history | Medium — CNBB round confirmed; amount undisclosed |
| Employee timeline | Low — ranges only; no official headcount by year |
| Geographic expansion | High — NL+BE confirmed; no international expansion confirmed absent |
| M&A activity | High — acquisition by Exact fully confirmed; no outbound M&A found |
| SaaS maturity | High — cloud-native architecture confirmed across multiple sources |

---

## Sources

| Source | URL | Type | Used For | Confidence Level |
| --- | --- | --- | --- | --- |
| Exact acquisition press release | https://www.exact.com/news/exact-will-unburden-the-hospitality-industry-with-acquisition-of-horeko | Primary | Customer count (1,500+); acquisition terms; product scope | Confirmed |
| Tech.eu — Horeko acquisition | https://tech.eu/2022/07/04/order-up-belgium-s-horeko-acquired-by-the-exact-right-buyer/ | Secondary news | Acquisition date; product description | Confirmed |
| Consultancy.nl — CNBB investment | https://www.consultancy.nl/nieuws/25128/venture-investering-in-horeca-softwareleverancier-horeko | Secondary news | CNBB investment date (Sep 2019); 1,200+ customers at investment; co-founders; Baker Tilly advisory; international aspiration | Confirmed |
| ZoomInfo — Horeko | https://www.zoominfo.com/c/horeko/372838893 | Secondary DB | Revenue estimate ($5.2M); employee range (11–50) | Estimated |
| Prospeo — Horeko | https://prospeo.io/c/horeko | Secondary DB | Revenue estimate ($5.4M); employee range (21–50) | Estimated |
| RocketReach — Horeko | https://rocketreach.co/horeko-profile_b5c0d5b7f42e0850 | Secondary DB | Post-acquisition employee count (~23) | Estimated |
| Crunchbase — Horeko | https://www.crunchbase.com/organization/horeko | Secondary DB | Employee range (11–50); CNBB round confirmation | Estimated |
| CNBB Equity Partners LinkedIn post | https://nl.linkedin.com/posts/cnbb-equity-partners_horeko-acquired-by-exact-cnbb-is-proud-activity-6949751436020752384-UNfI | Secondary social | CNBB exit confirmation; "proud to have supported" language | Estimated |
| Dealmaker.nl — CNBB deals | https://www.dealmaker.nl/company/cnbb-equity-partners/deals | Secondary deal DB | CNBB investment details; two participations noted | Estimated |
| KitchenNmbrs.app — competitive analysis | https://kitchennmbrs.app/en/knowledge-base/software-comparison-alternatives/wat-is-horeko-en-voor-welk-type-horecabedrijf-is-het-bedoeld | Secondary competitor | Pricing; market positioning; setup fees | Estimated |
| GetApp — Horeko features | https://www.getapp.com/retail-consumer-services-software/a/horeko/ | Secondary review | POS integrations; features; cloud architecture | Confirmed |
| Indeed.nl — Exact Horeko .NET job | https://nl.indeed.com/viewjob?jk=fe871f84a9b00c93 | Secondary (job post) | Technology stack signal (.NET) | Estimated |
| PartnerNavigator — HRK Solutions B.V. | https://portal.partnernavigator.com/database/company/hrk-solutions-bv-horeko | Secondary DB | KvK 77254171; legal entity name | Confirmed |
| KvK jaarrekening (not obtained) | https://www.kvk.nl/producten-bestellen/jaarrekeningen/ | Primary (ordered) | Financial filings for KvK 77254171 not publicly indexed; would require paid order | Unknown |
