# Access Hospitality (Access Group) — Corporate History

**Category**: PMS / Restaurant / Hospitality Management Suite
**Country**: UK (London, England — head office; Loughborough for Access Group)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; major PE-backed consolidator)

---

## Summary Assessment

Access Hospitality is the **hospitality division of The Access Group**, one of the UK's largest business software companies (£1.15B revenue, 9,500+ employees). Backed by **Hg** and **TA Associates**, The Access Group has pursued an aggressive M&A strategy, acquiring Guestline (Jul 2023), SHR Group (Jun 2024), QikServe (Sep 2024), Omnifi, ResDiary, and Wireless Social. Access Hospitality alone reached **£118.8M revenue in FY2024**. It is a **major competitor and benchmark** for HORECA IT, not an acquisition candidate.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Parent legal entity | Access Technology Group Ltd | Companies House / Wikipedia | Confirmed |
| Parent HQ | Loughborough, Leicestershire, UK | Wikipedia | Confirmed |
| Hospitality division name | Access Hospitality | theaccessgroup.com | Confirmed |
| Founded (The Access Group) | 1991 | Wikipedia | Confirmed |
| PE backer 1 | Hg (investment from 2015 / recapitalisation 2022) | Wikipedia | Confirmed |
| PE backer 2 | TA Associates (minority, from 2022 investment round) | Wikipedia | Confirmed |
| Total Access Group employees | 9,500+ | Wikipedia | Confirmed |
| Total Access Group revenue (FY2025) | £1.15B | Wikipedia | Confirmed |
| Access Hospitality revenue (FY2024) | £118.8M | Access Group Annual Report FY2024 | Confirmed |
| Access Hospitality revenue (FY2023) | £64.7M | Access Group Annual Report FY2024 | Confirmed |
| Access Hospitality hotels served | 5,000+ | theaccessgroup.com | Confirmed |
| Access Hospitality businesses served | 20,000+ | theaccessgroup.com | Confirmed |
| Key acquisition: Guestline | Acquired Jul 11, 2023 from Riverside Company | phocuswire.com, accessgroup.com | Confirmed |
| Key acquisition: SHR Group | Acquired Jun 6, 2024 from Serent Capital | businesswire.com | Confirmed |
| Key acquisition: QikServe | Acquired Sep 2024 | Access FY2025 annual report | Confirmed |
| Key acquisition: ResDiary | Acquired FY2024 | Access FY2024 annual report | Confirmed |
| Key acquisition: Wireless Social | Acquired FY2024 | Access FY2024 annual report | Confirmed |
| Key acquisition: Omnifi | Acquired 2021 (Order & Pay platform) | theaccessgroup.com/brands/omnifi | Confirmed |
| Key acquisition: Paytronix | Announced Nov 2024 (US guest engagement) | theaccessgroup.com | Confirmed |

---

## Founding & Corporate History

The Access Group was founded in **1991** in the UK as a business software company. Over 30+ years, it evolved from an accounting/ERP software provider into a multi-vertical software conglomerate serving 150,000+ organisations globally.

The **Access Hospitality** division was built through targeted acquisitions of UK hospitality software companies. By 2023–2024, the division had become one of the most active HORECA IT consolidators in Europe.

**Key private equity timeline:**
- **2015**: Hg invests, takes majority stake
- **2021**: Hg-led recapitalisation; TA Associates joins as minority investor
- **2022**: Further growth capital; continued acquisition programme

**Access Hospitality acquisition programme (chronological):**
1. **Omnifi** (2021) — Digital Order & Pay platform for hospitality
2. **Guestline** (Jul 11, 2023) — Cloud hotel PMS (from Riverside Company PE)
3. **ResDiary** (FY2024) — Table booking and management software
4. **Wireless Social** (FY2024) — Guest WiFi, analytics and marketing
5. **SHR Group** (Jun 6, 2024) — Hotel CRS, IBE, RMS (Houston, TX; from Serent Capital)
6. **QikServe** (Sep 2024) — Digital kiosk and mobile order & pay
7. **Paytronix** (announced Nov 2024) — US digital guest engagement

This M&A pace doubled Access Hospitality revenue from £64.7M (FY2023) to £118.8M (FY2024).

---

## Guestline Acquisition Detail

Guestline was an independent cloud hotel PMS company founded in 1991 (or 1997 per some sources), based in Shrewsbury. It was backed by **The Riverside Company** from 2016. Access acquired it from Riverside on **11 July 2023**. Guestline supported 2,900+ venues in 23 countries at time of acquisition.

*Note: Guestline has its own separate entry in this research (see `guestline/`).*

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Hg (majority PE backer)"]
    B["TA Associates (minority PE backer)"]
    C["Access Technology Group Ltd<br/>(The Access Group)<br/>Loughborough, UK"]
    D["Access Hospitality Division<br/>(London-led)"]
    E["Guestline (Jul 2023)"]
    F["SHR Group (Jun 2024)"]
    G["QikServe (Sep 2024)"]
    H["ResDiary (FY2024)"]
    I["Wireless Social (FY2024)"]
    J["Omnifi (2021)"]
    K["Paytronix (announced Nov 2024)"]

    A -->|"Majority stake"| C
    B -->|"Minority stake"| C
    C --> D
    D --> E
    D --> F
    D --> G
    D --> H
    D --> I
    D --> J
    D --> K
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Access Group / Access Hospitality — Key Milestones
    1991 : The Access Group founded UK
    2015 : Hg invests; majority PE backing
    2021 : Hg recapitalisation; TA Associates joins; Omnifi acquired
    2023 : Guestline acquired from Riverside (Jul 2023); Access Hospitality revenue £64.7M
    2024 : ResDiary + Wireless Social acquired; SHR Group acquired Jun 2024; QikServe acquired Sep 2024; Paytronix deal announced Nov 2024; Access Hospitality revenue £118.8M
    2025 : Total Access Group revenue £1.15B; 9,500+ employees; 20,000+ hospitality customers
```

---

## M&A Feasibility Assessment

### Is Access Hospitality an Acquisition Target for SolStein?

**Answer: No. An active competitor and consolidator, not a target.**

| Factor | Assessment |
|---|---|
| **Scale** | £1.15B group revenue; £118.8M hospitality — 8–100x above SolStein's target range |
| **Ownership** | Hg + TA Associates PE-backed; IPO or trade sale expected eventually at group level |
| **Geography** | UK/US focused; limited NL/BE market presence |
| **Succession** | Professional management (not founder-led); no succession gap |
| **Exit pathway** | PE exit at group level (not individual division); likely IPO or secondary PE buyout |

### Role for SolStein

1. **Consolidation risk**: Access Hospitality is actively acquiring UK and US HORECA IT companies — reducing the supply of independent UK targets for SolStein.
2. **Technology benchmark**: Access Hospitality defines what a full-stack UK hospitality software suite looks like.
3. **Valuation benchmark**: Access acquired Guestline (cloud hotel PMS, 2,900+ venues) without disclosing price; SHR Group and others give deal comparables.
4. **NL/BE opportunity**: Companies not yet acquired by Access in NL/BE represent SolStein's opening.

---

*Sources: The Access Group Annual Reports FY2024/FY2025, Wikipedia (The Access Group), theaccessgroup.com, phocuswire.com (Guestline acquisition), businesswire.com (SHR Group), insidermedia.com.*
