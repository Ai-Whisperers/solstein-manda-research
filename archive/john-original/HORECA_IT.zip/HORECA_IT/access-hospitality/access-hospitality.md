# Access Hospitality

**Category**: PMS/Restaurant
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Access Hospitality @HORECA_IT/access-hospitality/
@research-horeca-company Access Hospitality @HORECA_IT/access-hospitality/
```
