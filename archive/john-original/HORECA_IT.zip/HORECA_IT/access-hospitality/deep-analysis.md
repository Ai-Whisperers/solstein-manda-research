# Access Hospitality (Access Group) — Deep Analysis

**Category**: PMS / Restaurant / Hospitality Management Suite
**Country**: UK (London/Loughborough, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; PE-backed consolidator)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Division | Access Hospitality (division of The Access Group) | theaccessgroup.com | Confirmed |
| Parent entity | Access Technology Group Ltd | Wikipedia | Confirmed |
| Parent HQ | Loughborough, Leicestershire, UK | Wikipedia | Confirmed |
| Founded (group) | 1991 | Wikipedia | Confirmed |
| Ownership | Hg (majority) + TA Associates (minority) PE-backed | Wikipedia | Confirmed |
| Group employees | 9,500+ | Wikipedia | Confirmed |
| Group revenue (FY2025) | £1.15B | Wikipedia | Confirmed |
| Hospitality revenue (FY2024) | £118.8M | Access Annual Report FY2024 | Confirmed |
| Hospitality revenue (FY2023) | £64.7M | Access Annual Report FY2024 | Confirmed |
| Hotels served | 5,000+ | theaccessgroup.com | Confirmed |
| Hospitality businesses served | 20,000+ | theaccessgroup.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market position | One of UK's two dominant hospitality software platforms (with Zonal) | Industry consensus | Estimated |
| HORECA verticals | Hotels, pubs, restaurants, leisure, cafes, QSR | theaccessgroup.com | Confirmed |
| NL/BE presence | Limited; primarily UK and US | theaccessgroup.com | Estimated |
| US presence | Via SHR Group (Houston TX) + Paytronix acquisition | businesswire.com | Confirmed |
| EU/international | 23 countries via Guestline (at acquisition) | phocuswire.com | Confirmed |
| Target customer | Mid-market to enterprise hospitality chains | theaccessgroup.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core products | Access Collins (reservations), Guestline (PMS), Access Evo (AI platform), Access Workspace | theaccessgroup.com | Confirmed |
| Payments | Integrated payment processing | theaccessgroup.com | Confirmed |
| Order & Pay | Omnifi (acquired 2021) | theaccessgroup.com/brands/omnifi | Confirmed |
| Table management | ResDiary (acquired FY2024) | Access Annual Report FY2024 | Confirmed |
| Guest WiFi | Wireless Social (acquired FY2024) | Access Annual Report FY2024 | Confirmed |
| Kiosk / mobile ordering | QikServe (acquired Sep 2024) | Access Annual Report FY2025 | Confirmed |
| Hotel PMS | Guestline (acquired Jul 2023) | phocuswire.com | Confirmed |
| CRS / IBE / RMS | SHR Group (acquired Jun 2024) | businesswire.com | Confirmed |
| AI platform | Access Evo (AI-enabled cross-product platform) | Access Annual Report FY2025 | Confirmed |
| Deployment | Cloud-native (for acquired cloud products); hybrid legacy in some | theaccessgroup.com | Estimated |
| Tech stack | Multi-stack (acquired companies retain separate stacks being integrated) | Inferred from M&A pace | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| PE backer (majority) | Hg (since 2015; recapitalised 2021) | Wikipedia | Confirmed |
| PE backer (minority) | TA Associates (since 2021) | Wikipedia | Confirmed |
| PE exit likely? | Yes — eventual IPO or secondary buyout at group level | Standard PE lifecycle | Estimated |
| Division sale possible? | Unlikely — Access Hospitality is a growth platform within the group | theaccessgroup.com | Estimated |
| Succession signal | Professional CEO; not founder-led; no succession gap | Wikipedia | Confirmed |
| Acquisition appetite | Very active — 7 HORECA acquisitions in 2021–2024 | Multiple sources | Confirmed |

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Growth | Source | Confidence |
|---|---|---|---|---|
| FY2023 (Hospitality) | £64.7M | — | Access Annual Report FY2024 | Confirmed |
| FY2024 (Hospitality) | £118.8M | +84% (M&A driven) | Access Annual Report FY2024 | Confirmed |
| FY2025 (Group) | £1.15B | +ongoing | Wikipedia | Confirmed |

Revenue doubling is primarily inorganic (Guestline, SHR Group, QikServe). Organic growth within existing products estimated at 15–25% per annum.

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK VAT compliance | Full across all products | theaccessgroup.com | Confirmed |
| UK payment methods | Full UK stack + international | theaccessgroup.com | Confirmed |
| Allergen management | Allergen module (via multiple products) | theaccessgroup.com | Confirmed |
| Tipping compliance | Integration with TiPJAR for tip compliance | theaccessgroup.com blog | Confirmed |
| Workforce management | Separate Access People division (not hospitality-specific) | theaccessgroup.com | Confirmed |
| Regulatory compliance | GDPR, UK data protection, UK employment law | theaccessgroup.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscriptions + professional services + managed services | theaccessgroup.com | Confirmed |
| ARR estimate (hospitality) | £110M+ (predominantly subscription) | Derived from FY2024 revenue | Estimated |
| Group valuation (last known) | ~£4–5B (estimated for Hg exit scenario) | Industry press; undisclosed | Estimated |
| Acquisition price per target | Typically undisclosed; moderate multiples for mid-market SaaS | Pattern from Guestline/SHR deals | Estimated |
| SolStein fit | No — group/division at 8–80x above SolStein's target range | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | PE-backed (Hg + TA Associates); professional management; not accessible | Wikipedia |
| Revenue scale fit | High | 1 | £118.8M hospitality revenue — 8–100x above SolStein's €1–15M target | Access Annual Report FY2024 |
| Geographic fit | High | 1 | UK/US primary; minimal confirmed NL/BE presence | theaccessgroup.com |
| Tech stack modernity | Medium | 4 | Cloud-native products (Guestline, ResDiary); AI platform (Access Evo) | Access Annual Report FY2025 |
| Customer lock-in | Medium | 5 | 20,000+ hospitality businesses; deep multi-product integration | theaccessgroup.com |
| Vertical depth | Medium | 5 | Most complete UK HORECA stack: PMS + POS + reservations + WiFi + kiosk + payments | theaccessgroup.com |
| Integration potential | Low | 4 | API-first for new products; Guestline marketplace | phocuswire.com |
| Growth trajectory | Low | 4 | Hospitality revenue +84% YoY (inorganic); strong platform momentum | Access Annual Report FY2024 |

### Composite Score

**Weighted Composite: 2.3 / 5.0**

*(High-weight dimensions score 1: ownership, revenue scale, geographic fit — decisive for SolStein)*

**Confidence Band**: High — all material facts confirmed from company annual reports and press releases.

### Overall M&A Assessment

Access Hospitality is **the benchmark competitor** in UK HORECA IT — not an acquisition target. Its aggressive buy-and-build strategy, PE backing, and UK/US geographic focus make it irrelevant as a SolStein target. However, every company Access acquires was previously an independent SolStein-type target: Guestline, ResDiary, Wireless Social, QikServe. The NL/BE equivalents of these companies remain accessible and represent SolStein's opportunity.

### Recommended Next Step

No pursuit. Use as competitive intelligence: track which NL/BE HORECA IT companies Access Hospitality is evaluating for acquisition (to identify contested and uncontested opportunities for SolStein).

---

*Sources: The Access Group Annual Reports FY2024/FY2025 (theaccessgroup.com), Wikipedia (The Access Group), phocuswire.com, businesswire.com, insidermedia.com.*
