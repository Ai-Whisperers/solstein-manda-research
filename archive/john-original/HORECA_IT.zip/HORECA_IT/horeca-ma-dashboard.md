# SolStein HORECA IT — M&A Attractiveness Dashboard

**Generated**: 2026-04-30
**Companies Analyzed**: 57 scored of 73 in universe
**Data Source**: Per-company M&A research via `research-horeca-company` prompt

---

## M&A Classification Matrix

### Prime Targets (Composite Score 4.0–5.0)

Best-fit acquisition targets: founder-owned or exit-ready, strong vertical depth, NL/BE/DE geography, modern tech, and high SolStein integration potential.

| Company | Country | Category | Composite | Ownership | Revenue Fit | Geo Fit | Tech | Lock-in | Vertical | Confidence |
|---|---|---|---|---|---|---|---|---|---|---|
| Booking Experts | NL | Vacation Rental/PMS | 4.59 | 4 | 4 | 5 | 5 | 5 | 5 | Medium-High |
| TableFever | BE | Reservations | 4.30 | 5 | 3 | 5 | 3 | 4 | 4 | — |

### Watch List (Composite Score 3.0–3.9)

Strong in some dimensions but held back by ownership complexity, revenue scale, or geographic mismatch. Worth monitoring for change events.

| Company | Country | Category | Composite | Ownership | Revenue Fit | Geo Fit | Tech | Lock-in | Vertical | Confidence |
|---|---|---|---|---|---|---|---|---|---|---|
| unTill | NL | POS/Restaurant | 3.90 | 3 | 3 | 5 | 3 | 4 | 5 | — |
| Apicbase | BE | Kitchen/F&B | 3.50 | 2 | 3 | 4 | 5 | 4 | 5 | Medium |
| Kitchen CUT | UK | Kitchen | 3.20 | 4 | 4 | 1 | 5 | 5 | 5 | Low-Medium |
| Mews Systems | NL | Hotel PMS | 3.06 | 1 | 1 | 2 | 5 | 5 | 5 | Medium-High |
| Deliverect | BE | Online Ordering | 3 | 1 | 1 | 2 | 5 | 5 | 5 | — |

### Low Score (Composite Score 1.0–2.9)

Currently not aligned with SolStein's acquisition criteria. Logged for completeness and competitive awareness.

| Company | Country | Category | Composite | Ownership | Revenue Fit | Geo Fit | Tech | Lock-in | Vertical | Confidence |
|---|---|---|---|---|---|---|---|---|---|---|
| HiJiffy | NL | Guest Engagement / AI Hotel Chatbot | 2.94 | 2 | 3 | 2 | 5 | 4 | 4 | — |
| Lighthouse (formerly OTA Insight) | UK | Revenue/Data | 2.60 | 1 | 1 | 3 | 5 | 5 | 5 | Medium |
| SiteMinder | UK | Hotel PMS/Distribution | 2.50 | 1 | 1 | 2 | 5 | 5 | 5 | High |
| Slerp | UK | Online Ordering | 2.50 | 2 | 3 | 1 | 5 | 3 | 3 | Low |
| Tenzo | UK | Analytics | 2.50 | 2 | 3 | 1 | 5 | 3 | 3 | Low |
| TiPJAR | UK | Gratuities/Digital Tips | 2.50 | 2 | 3 | 1 | 5 | 4 | 3 | Low-Medium |
| HotelPARTNER | CH | Revenue Management | 2.40 | 3 | 2 | 1 | 3 | 4 | 3 | Medium |
| OrderYOYO | NL | Online Ordering | 2.40 | 1 | 1 | 2 | 4 | 4 | 3 | Narrow (FY2024 financial statements publicly available; PE deal terms partially disclosed) |
| FoodNotify | AT | F&B Procurement | 2.30 | N/A | N/A | 1 | 4 | 3 | 4 | Low |
| Lightspeed Hospitality | NL | POS/Restaurant | 2.30 | 1 | 1 | 2 | 5 | 4 | 4 | Narrow (publicly disclosed financials; strong data quality) |
| Triometric | Hotel distribution analytics and business intelligence | Analytics | 2.10 | 3 | 2 | 1 | 3 | 4 | 1 | Very Low |
| Valk Solutions | NL | Retail Omnichannel | 2.10 | 1 | 2 | 3 | 5 | 4 | 1 | Medium-High (most data points confirmed; own revenue unknown but doesn't change verdict). |
| Beambox | UK | Guest WiFi | 2 | 4 | 1 | 1 | 4 | 3 | 2 | Low |
| Foodcase | NL | Inventory | 2 | 3 | 2 | 4 | 1 | 2 | 1 | Narrow (structural disqualifiers are confirmed |
| GuestU | NL | Guest Engagement | 2 | 1 | 1 | 1 | 4 | 3 | 3 | Narrow (structural disqualifiers are confirmed, not estimated) |
| Reservix GmbH | DE | Ticketing/Events | 2 | 2 | 3 | 1 | 3 | 4 | 1 | Low |
| Wavem | BE | Restaurant Software | 2 | 3 | 1 | 3 | N/A | N/A | 2 | Very Low |
| GASTROpoint | DE | POS System | 1.20 | 2 | 1 | 1 | N/A | N/A | 2 | Very Low |
| kassensysteme.de | DE |  | 1.20 | N/A | 1 | 1 | 1 | N/A | 2 | Very Low |
| Kassensysteme TSE | DE | POS System | 1.10 | N/A | 1 | 1 | 1 | 2 | 2 | Very Low |
| Apfelroute | DE | Restaurant Software | 1 | N/A | 1 | 1 | N/A | N/A | N/A | Very Low |
| BrewUp | DE | Brewery Software | 1 | N/A | 1 | 1 | N/A | 3 | 2 | Very Low |
| Fabella | DE | Restaurant Software | 1 | N/A | 1 | 1 | N/A | N/A | N/A | Very Low |
| myRES | DE | Reservations | 1 | N/A | 1 | 1 | N/A | N/A | N/A | Very Low |
| PAUL (IndustryArena) | DE |  | 1 | N/A | 1 | 1 | N/A | N/A | 2 | Very Low |
| Schnell ein Tisch | DE | Reservations | 1 | N/A | 1 | 1 | N/A | 1 | 2 | Very Low |
| Sonnen PC | DE | POS System | 1 | N/A | 1 | 1 | N/A | N/A | N/A | Very Low |
| Systor | DE | Hospitality IT | 1 | N/A | 1 | 1 | N/A | N/A | N/A | Very Low |

---

## M&A Attractiveness Leaderboard

All companies with a composite score, ranked by M&A attractiveness. Score is a weighted average across 8 acquisition dimensions (scale: 1–5).

| Rank | Company | Country | Category | Revenue Est. | Composite | Confidence | Status |
|---|---|---|---|---|---|---|---|
| 1 | Booking Experts | NL | Vacation Rental/PMS | €10M | 4.59 | Medium-High | Tier 1 |
| 2 | Horeko | NL | Kitchen/F&B | N/A | 4.40 | Medium | Off-Market |
| 3 | TableFever | BE | Reservations | N/A | 4.30 | — | Tier 1 |
| 4 | unTill | NL | POS/Restaurant | N/A | 3.90 | — | Watch |
| 5 | Apicbase | BE | Kitchen/F&B | N/A | 3.50 | Medium | Watch |
| 6 | Formitable | NL | Reservations | N/A | 3.40 | Narrow | Off-Market |
| 7 | Tablebooker | BE | Reservations | N/A | 3.40 | Low | Off-Market |
| 8 | Kitchen CUT | UK | Kitchen | N/A | 3.20 | Low-Medium | Watch |
| 9 | Zenchef | FR | Restaurant Management | N/A | 3.20 | — | Off-Market |
| 10 | Mews Systems | NL | Hotel PMS | N/A | 3.06 | Medium-High | Watch |
| 11 | Deliverect | BE | Online Ordering | N/A | 3 | — | Watch |
| 12 | HiJiffy | NL | Guest Engagement / AI Hotel Chatbot | N/A | 2.94 | — | Low Score |
| 13 | Resengo | NL | Reservations | €4M | 2.90 | Wide (revenue, exact valuation, and most financials undisclosed) | Off-Market |
| 14 | Lighthouse (formerly OTA Insight) | UK | Revenue/Data | N/A | 2.60 | Medium | Low Score |
| 15 | SiteMinder | UK | Hotel PMS/Distribution | N/A | 2.50 | High | Low Score |
| 16 | Slerp | UK | Online Ordering | €4M | 2.50 | Low | Low Score |
| 17 | Tenzo | UK | Analytics | €1M | 2.50 | Low | Low Score |
| 18 | TiPJAR | UK | Gratuities/Digital Tips | N/A | 2.50 | Low-Medium | Low Score |
| 19 | eviivo | UK | Hotel PMS | €9M | 2.50 | Very Low | Off-Market |
| 20 | SevenRooms | US | Reservations/CRM | N/A | 2.50 | Medium | Off-Market |
| 21 | HotelPARTNER | CH | Revenue Management | €10M | 2.40 | Medium | Low Score |
| 22 | OrderYOYO | NL | Online Ordering | N/A | 2.40 | Narrow (FY2024 financial statements publicly available; PE deal terms partially disclosed) | Low Score |
| 23 | Guestline | UK | Hotel PMS | N/A | 2.40 | Medium | Off-Market |
| 24 | orderbird AG (Garmondo) | DE | POS System | N/A | 2.40 | Medium | Off-Market |
| 25 | FoodNotify | AT | F&B Procurement | N/A | 2.30 | Low | Low Score |
| 26 | Lightspeed Hospitality | NL | POS/Restaurant | N/A | 2.30 | Narrow (publicly disclosed financials; strong data quality) | Low Score |
| 27 | Access Hospitality (Access Group) | UK | PMS/Restaurant | N/A | 2.30 | High | Off-Market |
| 28 | Epos Now | UK | POS/Restaurant | N/A | 2.30 | Medium | Off-Market |
| 29 | Kafoodle | UK | Menu/Allergens | N/A | 2.20 | Low | Off-Market |
| 30 | Orderbird (ex-Garmondo) / SumUp Context | DE | POS System | €500M | 2.20 | Medium | Off-Market |
| 31 | RotaGeek | UK | Workforce | N/A | 2.20 | Low | Off-Market |
| 32 | Triometric | Hotel distribution analytics and business intelligence | Analytics | N/A | 2.10 | Very Low | Low Score |
| 33 | Valk Solutions | NL | Retail Omnichannel | N/A | 2.10 | Medium-High (most data points confirmed; own revenue unknown but doesn't change verdict). | Low Score |
| 34 | BePOS | BE | Restaurant POS | N/A | 2.10 | Narrow-to-medium (40% Confirmed, 35% Estimated, 25% Unknown) | Off-Market |
| 35 | Fourth | UK | Workforce/F&B | N/A | 2.10 | Low-Medium | Off-Market |
| 36 | Gastrofix GmbH | DE | POS/Restaurant | N/A | 2.10 | Low-Medium | Off-Market |
| 37 | Revel Systems | US | POS System | N/A | 2.10 | Medium | Off-Market |
| 38 | Zonal | UK | Restaurant POS | N/A | 2.10 | Medium | Off-Market |
| 39 | Beambox | UK | Guest WiFi | €0M | 2 | Low | Low Score |
| 40 | Foodcase | NL | Inventory | €1M | 2 | Narrow (structural disqualifiers are confirmed | Low Score |
| 41 | GuestU | NL | Guest Engagement | €24M | 2 | Narrow (structural disqualifiers are confirmed, not estimated) | Low Score |
| 42 | Reservix GmbH | DE | Ticketing/Events | €30M | 2 | Low | Low Score |
| 43 | Wavem | BE | Restaurant Software | €0M | 2 | Very Low | Low Score |
| 44 | Omnifi | UK | Guest WiFi | N/A | 2 | Low | Off-Market |
| 45 | Aareon | DE | PropTech (NOT HORECA) | €200M | 1.90 | High | Off-Market |
| 46 | Cubilis | BE | Hotel PMS/Channel | N/A | 1.80 | Narrow on ownership/geography/vertical (Confirmed); Wide on financials/tech stack (Estimated/Unknown) | Off-Market |
| 47 | GASTROpoint | DE | POS System | €1M | 1.20 | Very Low | Low Score |
| 48 | kassensysteme.de | DE |  | N/A | 1.20 | Very Low | Low Score |
| 49 | Kassensysteme TSE | DE | POS System | N/A | 1.10 | Very Low | Low Score |
| 50 | Apfelroute | DE | Restaurant Software | N/A | 1 | Very Low | Low Score |
| 51 | BrewUp | DE | Brewery Software | N/A | 1 | Very Low | Low Score |
| 52 | Fabella | DE | Restaurant Software | N/A | 1 | Very Low | Low Score |
| 53 | myRES | DE | Reservations | N/A | 1 | Very Low | Low Score |
| 54 | PAUL (IndustryArena) | DE |  | N/A | 1 | Very Low | Low Score |
| 55 | Schnell ein Tisch | DE | Reservations | N/A | 1 | Very Low | Low Score |
| 56 | Sonnen PC | DE | POS System | N/A | 1 | Very Low | Low Score |
| 57 | Systor | DE | Hospitality IT | N/A | 1 | Very Low | Low Score |

### Composite Score Chart

```mermaid
xychart-beta
    title "M&A Composite Scores (Top 15 — /5.0)"
    x-axis [BookingExperts, Horeko, TableFever, unTill, Apicbase, Formitable, Tablebooker, KitchenCUT, Zenchef, MewsSystems, Deliverect, HiJiffy, Resengo, Lighthouse, SiteMinder]
    y-axis "Score /5.0" 0 --> 5
    bar [4.59, 4.4, 4.3, 3.9, 3.5, 3.4, 3.4, 3.2, 3.2, 3.06, 3.0, 2.94, 2.9, 2.6, 2.5]
```

---

## Ownership Structure Analysis

Ownership profile of all scored companies. Founder-owned companies are the primary M&A targets — they move faster, have simpler governance, and often seek strategic exits over financial ones.

| Ownership Type | Count | % of Scored |
|---|---|---|
| Unknown | 28 | 49% |
| Founder-owned | 11 | 19% |
| PE / VC-backed | 11 | 19% |
| Acquired / Subsidiary | 5 | 9% |
| Publicly listed | 2 | 4% |

### Ownership by Country

| Country | Acquired / Subsidiary | Founder-owned | PE / VC-backed | Publicly listed | Unknown |
|---|---|---|---|---|---|
| AT | 0 | 0 | 0 | 0 | 1 |
| BE | 0 | 3 | 1 | 0 | 3 |
| CH | 0 | 1 | 0 | 0 | 0 |
| DE | 0 | 0 | 2 | 0 | 14 |
| FR | 0 | 0 | 0 | 0 | 1 |
| Hotel distribution analytics and business intelligence | 0 | 1 | 0 | 0 | 0 |
| NL | 1 | 2 | 5 | 1 | 3 |
| UK | 2 | 4 | 3 | 1 | 6 |
| US | 2 | 0 | 0 | 0 | 0 |

### Ownership Distribution Chart

```mermaid
pie title "Ownership Structure — Scored Companies"
    "Unknown" : 28
    "Founder-owned" : 11
    "PE / VC-backed" : 11
    "Acquired / Subsidiary" : 5
    "Publicly listed" : 2
```

---

## Revenue & Scale Analysis

Revenue estimates for all scored companies. SolStein targets companies in the €2M–€30M ARR sweet spot — large enough to be mature, small enough to be acquirable.

| Rank | Company | Country | Category | Revenue Est. | Employees | Revenue Fit Score | Composite |
|---|---|---|---|---|---|---|---|
| 1 | Orderbird (ex-Garmondo) / SumUp Context | DE | POS System | €500M | 3000 | 1 | 2.20 |
| 2 | Aareon | DE | PropTech (NOT HORECA) | €200M | 2000 | 1 | 1.90 |
| 3 | Reservix GmbH | DE | Ticketing/Events | €30M | 480 | 3 | 2 |
| 4 | GuestU | NL | Guest Engagement | €24M | 4 | 1 | 2 |
| 5 | Booking Experts | NL | Vacation Rental/PMS | €10M | 150 | 4 | 4.59 |
| 6 | HotelPARTNER | CH | Revenue Management | €10M | 41 | 2 | 2.40 |
| 7 | eviivo | UK | Hotel PMS | €9M | — | 3 | 2.50 |
| 8 | Slerp | UK | Online Ordering | €4M | 35 | 3 | 2.50 |
| 9 | Resengo | NL | Reservations | €4M | — | 3 | 2.90 |
| 10 | Foodcase | NL | Inventory | €1M | 14 | 2 | 2 |
| 11 | Tenzo | UK | Analytics | €1M | 38 | 3 | 2.50 |
| 12 | GASTROpoint | DE | POS System | €1M | 10 | 1 | 1.20 |
| 13 | Wavem | BE | Restaurant Software | €0M | 5 | 1 | 2 |
| 14 | Beambox | UK | Guest WiFi | €0M | 5 | 1 | 2 |

> **43 scored companies** have no numeric revenue estimate: TableFever, unTill, Apicbase, Kitchen CUT, Mews Systems...


### Revenue Estimates Chart

```mermaid
xychart-beta
    title "Revenue Estimates — Scored Companies (EUR M)"
    x-axis [Orderbird, Aareon, ReservixGmbH, GuestU, BookingExperts, HotelPARTNER, eviivo, Slerp, Resengo, Foodcase, Tenzo, GASTROpoint, Wavem, Beambox]
    y-axis "EUR M" 0 --> 520
    bar [500, 200, 30, 23, 10, 10, 9, 4, 4, 1, 1, 1, 0, 0]
```

---

## Geographic Pipeline

SolStein's acquisition focus is NL-first (home market), BE (adjacent, similar culture), DE (large market, strong HORECA sector), and UK (English-language, international clients). Other geographies are tracked but deprioritised.

### Netherlands (NL) — 21 companies

**Prime Targets (1)**: Booking Experts

**Watch (2)**: unTill, Mews Systems

**Low Score (6)**: HiJiffy, OrderYOYO, Lightspeed Hospitality, Valk Solutions, Foodcase, GuestU

**Off-Market (3)**: Horeko, Formitable, Resengo

**Pending (9)**: Cures Werkt, Horeca Solutions, Horecavita, Juniper, Kashower, MaaS (Meals as a Service), Misterbook, Planax, Qompanion

### Belgium (BE) — 12 companies

**Prime Targets (1)**: TableFever

**Watch (2)**: Apicbase, Deliverect

**Low Score (1)**: Wavem

**Off-Market (7)**: Tablebooker, BePOS, Cubilis, Bionext, GastroHero, iPunt, OrderGrid

**Pending (1)**: Abcouse

### Germany (DE) — 18 companies

**Low Score (12)**: Reservix GmbH, GASTROpoint, kassensysteme.de, Kassensysteme TSE, Apfelroute, BrewUp, Fabella, myRES, PAUL (IndustryArena), Schnell ein Tisch, Sonnen PC, Systor

**Off-Market (4)**: orderbird AG (Garmondo), Orderbird (ex-Garmondo) / SumUp Context, Gastrofix GmbH, Aareon

**Pending (2)**: Gastroglück, Siveco

### United Kingdom (UK) — 16 companies

**Watch (1)**: Kitchen CUT

**Low Score (6)**: Lighthouse (formerly OTA Insight), SiteMinder, Slerp, Tenzo, TiPJAR, Beambox

**Off-Market (9)**: eviivo, Guestline, Access Hospitality (Access Group), Epos Now, Kafoodle, RotaGeek, Fourth, Zonal, Omnifi

### AT (AT) — 1 companies

**Low Score (1)**: FoodNotify

### CH (CH) — 1 companies

**Low Score (1)**: HotelPARTNER

### FR (FR) — 1 companies

**Off-Market (1)**: Zenchef

### Hotel distribution analytics and business intelligence (Hotel distribution analytics and business intelligence) — 1 companies

**Low Score (1)**: Triometric

### US (US) — 2 companies

**Off-Market (2)**: SevenRooms, Revel Systems

### Companies by Country

| Country | Total | Prime | Watch | Low Score | Off-Market | Pending |
|---|---|---|---|---|---|---|
| NL | 21 | 1 | 2 | 6 | 3 | 9 |
| BE | 12 | 1 | 2 | 1 | 7 | 1 |
| DE | 18 | 0 | 0 | 12 | 4 | 2 |
| UK | 16 | 0 | 1 | 6 | 9 | 0 |
| AT | 1 | 0 | 0 | 1 | 0 | 0 |
| CH | 1 | 0 | 0 | 1 | 0 | 0 |
| FR | 1 | 0 | 0 | 0 | 1 | 0 |
| Hotel distribution analytics and business intelligence | 1 | 0 | 0 | 1 | 0 | 0 |
| US | 2 | 0 | 0 | 0 | 2 | 0 |

### Country Distribution Chart

```mermaid
xychart-beta
    title "Companies by Country"
    x-axis [NL, BE, DE, UK, AT, CH, FR, Hotel distribution analytics and business intelligence, US]
    y-axis "Count" 0 --> 30
    bar [21, 12, 18, 16, 1, 1, 1, 1, 2]
```

---

## Scorecard Dimension Leaderboard

For each of the 8 M&A scoring dimensions, the top 5 and bottom 3 scored companies are shown. Use these rankings to identify companies with specific strengths that complement SolStein's gaps.

### Ownership attractiveness

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | TableFever | BE | 5 | 4.30 | Tier 1 |
| 2 | Booking Experts | NL | 4 | 4.59 | Tier 1 |
| 3 | Kitchen CUT | UK | 4 | 3.20 | Watch |
| 4 | Beambox | UK | 4 | 2 | Low Score |
| 5 | unTill | NL | 3 | 3.90 | Watch |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 44 | Cubilis | BE | 1 | 1.80 | Off-Market |
| 45 | Aareon | DE | 1 | 1.90 | Off-Market |
| 46 | Omnifi | UK | 1 | 2 | Off-Market |

### Revenue scale fit

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | Booking Experts | NL | 4 | 4.59 | Tier 1 |
| 2 | Kitchen CUT | UK | 4 | 3.20 | Watch |
| 3 | Horeko | NL | 4 | 4.40 | Off-Market |
| 4 | Cubilis | BE | 4 | 1.80 | Off-Market |
| 5 | TableFever | BE | 3 | 4.30 | Tier 1 |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 54 | Aareon | DE | 1 | 1.90 | Off-Market |
| 55 | Omnifi | UK | 1 | 2 | Off-Market |
| 56 | Zonal | UK | 1 | 2.10 | Off-Market |

### Geographic fit

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | Booking Experts | NL | 5 | 4.59 | Tier 1 |
| 2 | TableFever | BE | 5 | 4.30 | Tier 1 |
| 3 | unTill | NL | 5 | 3.90 | Watch |
| 4 | Horeko | NL | 5 | 4.40 | Off-Market |
| 5 | Formitable | NL | 5 | 3.40 | Off-Market |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 55 | Aareon | DE | 1 | 1.90 | Off-Market |
| 56 | Omnifi | UK | 1 | 2 | Off-Market |
| 57 | Zonal | UK | 1 | 2.10 | Off-Market |

### Tech stack modernity

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | Booking Experts | NL | 5 | 4.59 | Tier 1 |
| 2 | Apicbase | BE | 5 | 3.50 | Watch |
| 3 | Kitchen CUT | UK | 5 | 3.20 | Watch |
| 4 | Mews Systems | NL | 5 | 3.06 | Watch |
| 5 | Deliverect | BE | 5 | 3 | Watch |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 45 | Kassensysteme TSE | DE | 1 | 1.10 | Low Score |
| 46 | kassensysteme.de | DE | 1 | 1.20 | Low Score |
| 47 | Foodcase | NL | 1 | 2 | Low Score |

### Customer lock-in

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | Booking Experts | NL | 5 | 4.59 | Tier 1 |
| 2 | Kitchen CUT | UK | 5 | 3.20 | Watch |
| 3 | Mews Systems | NL | 5 | 3.06 | Watch |
| 4 | Deliverect | BE | 5 | 3 | Watch |
| 5 | Lighthouse (formerly OTA Insight) | UK | 5 | 2.60 | Low Score |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 46 | Schnell ein Tisch | DE | 1 | 1 | Low Score |
| 47 | Kassensysteme TSE | DE | 2 | 1.10 | Low Score |
| 48 | Foodcase | NL | 2 | 2 | Low Score |

### Vertical depth

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | Booking Experts | NL | 5 | 4.59 | Tier 1 |
| 2 | unTill | NL | 5 | 3.90 | Watch |
| 3 | Apicbase | BE | 5 | 3.50 | Watch |
| 4 | Kitchen CUT | UK | 5 | 3.20 | Watch |
| 5 | Mews Systems | NL | 5 | 3.06 | Watch |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 50 | Aareon | DE | 1 | 1.90 | Off-Market |
| 51 | Reservix GmbH | DE | 1 | 2 | Low Score |
| 52 | Foodcase | NL | 1 | 2 | Low Score |

### Integration potential

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | Booking Experts | NL | 5 | 4.59 | Tier 1 |
| 2 | unTill | NL | 5 | 3.90 | Watch |
| 3 | Apicbase | BE | 5 | 3.50 | Watch |
| 4 | Kitchen CUT | UK | 5 | 3.20 | Watch |
| 5 | Mews Systems | NL | 5 | 3.06 | Watch |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 44 | Kassensysteme TSE | DE | 1 | 1.10 | Low Score |
| 45 | Foodcase | NL | 1 | 2 | Low Score |
| 46 | BePOS | BE | 2 | 2.10 | Off-Market |

### Growth trajectory

**Top 5**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 1 | Mews Systems | NL | 5 | 3.06 | Watch |
| 2 | HiJiffy | NL | 5 | 2.94 | Low Score |
| 3 | Lighthouse (formerly OTA Insight) | UK | 5 | 2.60 | Low Score |
| 4 | TiPJAR | UK | 5 | 2.50 | Low Score |
| 5 | OrderYOYO | NL | 5 | 2.40 | Low Score |

**Bottom 3**

| Rank | Company | Country | Score | Composite | Status |
|---|---|---|---|---|---|
| 44 | Schnell ein Tisch | DE | 1 | 1 | Low Score |
| 45 | Kassensysteme TSE | DE | 1 | 1.10 | Low Score |
| 46 | Zonal | UK | 2 | 2.10 | Off-Market |

### Average Score per Dimension

```mermaid
xychart-beta
    title "Average Score per Dimension (scored companies)"
    x-axis [Ownership, Revenue, GeoFit, TechStack, LockIn, Vertical, Integration, Growth]
    y-axis "Avg Score /5.0" 0 --> 5
    bar [1.76, 1.84, 1.98, 4.11, 3.98, 3.54, 3.74, 3.5]
```

---

## Off-Market Registry

26 companies are classified as **Off-Market** — recently acquired, merged, or otherwise not available for acquisition by SolStein. They are tracked for competitive intelligence and market mapping.

| # | Company | Country | Category | Reason / Status | Composite (if scored) |
|---|---|---|---|---|---|
| 1 | Horeko | NL | Kitchen/F&B | Acquired / Not available | 4.40 |
| 2 | Formitable | NL | Reservations | Acquired / Not available | 3.40 |
| 3 | Tablebooker | BE | Reservations | Acquired / Not available | 3.40 |
| 4 | Zenchef | FR | Restaurant Management | PSG Equity (majority since Sep 2022) | 3.20 |
| 5 | Resengo | NL | Reservations | Subsidiary of Zenchef group (PSG Equity backed); Resengo ... | 2.90 |
| 6 | eviivo | UK | Hotel PMS | eviivo is not a SolStein target — it is UK-focused with i... | 2.50 |
| 7 | SevenRooms | US | Reservations/CRM | SevenRooms is not an acquisition target for SolStein — ac... | 2.50 |
| 8 | Guestline | UK | Hotel PMS | Guestline is not an acquisition target for SolStein — it ... | 2.40 |
| 9 | orderbird AG (Garmondo) | DE | POS System | Acquired / Not available | 2.40 |
| 10 | Access Hospitality (Access Group) | UK | PMS/Restaurant | Access Hospitality is the benchmark competitor in UK HORE... | 2.30 |
| 11 | Epos Now | UK | POS/Restaurant | Epos Now is not an acquisition target for SolStein. It is... | 2.30 |
| 12 | Kafoodle | UK | Menu/Allergens | Kafoodle is not a SolStein target — it has been acquired ... | 2.20 |
| 13 | Orderbird (ex-Garmondo) / SumUp Context | DE | POS System | PE-backed: Advent International, Bain Capital, Goldman Sa... | 2.20 |
| 14 | RotaGeek | UK | Workforce | RotaGeek is not a SolStein target — acquired by ELMO Grou... | 2.20 |
| 15 | BePOS | BE | Restaurant POS | PE-backed (Arcadea Group — permanent-hold SaaS investor) | 2.10 |
| 16 | Fourth | UK | Workforce/F&B | Fourth is not an acquisition target for SolStein. It is a... | 2.10 |
| 17 | Gastrofix GmbH | DE | POS/Restaurant | Acquired / Not available | 2.10 |
| 18 | Revel Systems | US | POS System | Revel Systems is not an acquisition target for SolStein u... | 2.10 |
| 19 | Zonal | UK | Restaurant POS | Zonal is not an acquisition target for SolStein under any... | 2.10 |
| 20 | Omnifi | UK | Guest WiFi | Omnifi (UK) is not an acquisition target for SolStein. It... | 2 |
| 21 | Aareon | DE | PropTech (NOT HORECA) | PE-backed (Advent International) | 1.90 |
| 22 | Cubilis | BE | Hotel PMS/Channel | Acquired / Not available | 1.80 |
| 23 | Bionext | BE | Horeca Software | Rating: INCOMPLETE — Company identity unverifiable

No HO... | N/A |
| 24 | GastroHero | BE | Restaurant POS | Rating: INCOMPLETE — Company existence must be verified b... | N/A |
| 25 | iPunt | BE | Restaurant POS | Rating: INCOMPLETE / POSSIBLE DEFUNCT — Cannot assess wit... | N/A |
| 26 | OrderGrid | BE | B2B Ordering | Rating: INCOMPLETE — Company identity unverifiable

The B... | N/A |

---

## Pending Research

12 companies are **pending research** — identified in the market map but not yet scored. Run `research-horeca-company` for each to generate their scorecard.

| # | Company | Country | Category | Folder |
|---|---|---|---|---|
| 1 | Abcouse | BE | Restaurant Software | `abcouse` |
| 2 | Cures Werkt | NL | Workforce | `cures-werkt` |
| 3 | Gastroglück | DE |  | `gastroglueck` |
| 4 | Horeca Solutions | NL | Restaurant POS | `horeca-solutions` |
| 5 | Horecavita | NL | Restaurant POS | `horecavita` |
| 6 | Juniper | NL | Hotel PMS | `juniper` |
| 7 | Kashower | NL | POS/Horeca | `kashower` |
| 8 | MaaS (Meals as a Service) | NL | Online Ordering (B2B) | `maas-meals-as-a-service` |
| 9 | Misterbook | NL | Hotel PMS | `misterbook` |
| 10 | Planax | NL | Workforce | `planax` |
| 11 | Qompanion | NL | Restaurant POS | `qompanion` |
| 12 | Siveco | DE | Hotel PMS | `siveco` |

---

## Data Coverage & Confidence

Research coverage and confidence ratings for all scored companies. `has_deep_analysis` indicates a full deep-analysis markdown was produced; companies without it rely on desk research only.

| Company | Country | Status | Has Deep Analysis | Confidence Band | Research Date | Composite |
|---|---|---|---|---|---|---|
| Booking Experts | NL | Tier 1 | Yes | Medium-High | 2026-04-30 | 4.59 |
| Horeko | NL | Off-Market | Yes | Medium | 2026-04-30 | 4.40 |
| TableFever | BE | Tier 1 | Yes | — | 2026-04-30 | 4.30 |
| unTill | NL | Watch | Yes | — | 2026-04-30 | 3.90 |
| Apicbase | BE | Watch | Yes | Medium | 2026-04-30 | 3.50 |
| Formitable | NL | Off-Market | Yes | Narrow | 2026-04-30 | 3.40 |
| Tablebooker | BE | Off-Market | Yes | Low | 2026-04-30 | 3.40 |
| Kitchen CUT | UK | Watch | Yes | Low-Medium | 2026-04-30 | 3.20 |
| Zenchef | FR | Off-Market | Yes | — | 2026-04-30 | 3.20 |
| Mews Systems | NL | Watch | Yes | Medium-High | 2026-04-30 | 3.06 |
| Deliverect | BE | Watch | Yes | — | 2026-04-30 | 3 |
| HiJiffy | NL | Low Score | Yes | — | 2026-04-30 | 2.94 |
| Resengo | NL | Off-Market | Yes | Wide (revenue, exact valuation, and most financials undisclosed) | 2026-04-30 | 2.90 |
| Lighthouse (formerly OTA Insight) | UK | Low Score | Yes | Medium | 2026-04-30 | 2.60 |
| SiteMinder | UK | Low Score | Yes | High | 2026-04-30 | 2.50 |
| Slerp | UK | Low Score | Yes | Low | 2026-04-30 | 2.50 |
| Tenzo | UK | Low Score | Yes | Low | 2026-04-30 | 2.50 |
| TiPJAR | UK | Low Score | Yes | Low-Medium | 2026-04-30 | 2.50 |
| eviivo | UK | Off-Market | Yes | Very Low | 2026-04-30 | 2.50 |
| SevenRooms | US | Off-Market | Yes | Medium | 2026-04-30 | 2.50 |
| HotelPARTNER | CH | Low Score | Yes | Medium | 2026-04-30 | 2.40 |
| OrderYOYO | NL | Low Score | Yes | Narrow (FY2024 financial statements publicly available; PE deal terms partially disclosed) | 2026-04-30 | 2.40 |
| Guestline | UK | Off-Market | Yes | Medium | 2026-04-30 | 2.40 |
| orderbird AG (Garmondo) | DE | Off-Market | Yes | Medium | 2026-04-30 | 2.40 |
| FoodNotify | AT | Low Score | Yes | Low | 2026-04-30 | 2.30 |
| Lightspeed Hospitality | NL | Low Score | Yes | Narrow (publicly disclosed financials; strong data quality) | 2026-04-30 | 2.30 |
| Access Hospitality (Access Group) | UK | Off-Market | Yes | High | 2026-04-30 | 2.30 |
| Epos Now | UK | Off-Market | Yes | Medium | 2026-04-30 | 2.30 |
| Kafoodle | UK | Off-Market | Yes | Low | 2026-04-30 | 2.20 |
| Orderbird (ex-Garmondo) / SumUp Context | DE | Off-Market | Yes | Medium | 2026-04-30 | 2.20 |
| RotaGeek | UK | Off-Market | Yes | Low | 2026-04-30 | 2.20 |
| Triometric | Hotel distribution analytics and business intelligence | Low Score | Yes | Very Low | 2026-04-30 | 2.10 |
| Valk Solutions | NL | Low Score | Yes | Medium-High (most data points confirmed; own revenue unknown but doesn't change verdict). | 2026-04-30 | 2.10 |
| BePOS | BE | Off-Market | Yes | Narrow-to-medium (40% Confirmed, 35% Estimated, 25% Unknown) | 2026-04-30 | 2.10 |
| Fourth | UK | Off-Market | Yes | Low-Medium | 2026-04-30 | 2.10 |
| Gastrofix GmbH | DE | Off-Market | Yes | Low-Medium | 2026-04-30 | 2.10 |
| Revel Systems | US | Off-Market | Yes | Medium | 2026-04-30 | 2.10 |
| Zonal | UK | Off-Market | Yes | Medium | 2026-04-30 | 2.10 |
| Beambox | UK | Low Score | Yes | Low | 2026-04-30 | 2 |
| Foodcase | NL | Low Score | Yes | Narrow (structural disqualifiers are confirmed | 2026-04-30 | 2 |
| GuestU | NL | Low Score | Yes | Narrow (structural disqualifiers are confirmed, not estimated) | 2026-04-30 | 2 |
| Reservix GmbH | DE | Low Score | Yes | Low | 2026-04-30 | 2 |
| Wavem | BE | Low Score | Yes | Very Low | 2026-04-30 | 2 |
| Omnifi | UK | Off-Market | Yes | Low | 2026-04-30 | 2 |
| Aareon | DE | Off-Market | Yes | High | 2026-04-30 | 1.90 |
| Cubilis | BE | Off-Market | Yes | Narrow on ownership/geography/vertical (Confirmed); Wide on financials/tech stack (Estimated/Unknown) | 2026-04-30 | 1.80 |
| GASTROpoint | DE | Low Score | Yes | Very Low | 2026-04-30 | 1.20 |
| kassensysteme.de | DE | Low Score | Yes | Very Low | 2026-04-30 | 1.20 |
| Kassensysteme TSE | DE | Low Score | Yes | Very Low | 2026-04-30 | 1.10 |
| Apfelroute | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |
| BrewUp | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |
| Fabella | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |
| myRES | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |
| PAUL (IndustryArena) | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |
| Schnell ein Tisch | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |
| Sonnen PC | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |
| Systor | DE | Low Score | Yes | Very Low | 2026-04-30 | 1 |

**Coverage Summary**: 57 scored companies | 57 with deep analysis (100%) | 3 high-confidence scorecards


---

## SolStein M&A Thesis Alignment

### Research Findings vs. Acquisition Criteria

SolStein's HORECA IT research covered **73 companies** in the European market. Of these, **57 have been scored** across 8 M&A dimensions, yielding **2 Prime Targets** and **5 Watch List** candidates.

The average composite score across scored companies is **2.29 / 5.0**. **26 companies** are currently off-market (recently acquired or merged), which underlines active M&A consolidation in the HORECA software space. **12 companies** remain pending research.

### Key Insights

- **Top acquisition candidate**: **Booking Experts** (composite 4.59, NL) — 1. Priority: Establish back-channel introduction to Ali Ilboga — ideally via a shared recreation sector contact, industry event (Booking Experts hosts "Embrace" conference), or via the ParcVu relationship
2. Framing: Lead with partnership / platform consolidation narrative (similar to ParcVu model), NOT an acquisition approach
3. Information request: Obtain last 3 years of filed accounts via KvK (publicly available for B.V.) to verify revenue and profitability before any formal approach
4. Timing: Monitor for any signals of growth plateau, founder fatigue, or succession planning — these would dramatically improve acquisition probability
5. Alternative entry: Consider approaching as a customer or App Store partner first to build trust and understand the platform from the inside

---

*Sources consulted: bookingexperts.com/about-us, bookingexperts.com/pricing, bookingexperts.com/our-story, bookingexperts.com/privacy-policy, jobs.bookingexperts.com, developers.bookingexperts.com, tracxn.com/booking-experts, crunchbase.com/organization/booking-experts, growjo.com/company/Booking_Experts_B.V., prospeo.io/c/booking-experts, zoominfo.com/c/booking-experts-bv, rocketreach.co/booking-experts-bv-management, mollie.com/integrations/bookingexperts, bookingexperts.com/blogs/booking-experts-and-parcvu, parcvu.com/blog/parcvus-new-partnership-with-booking-experts, northdata.de (KvK 55796850), creditsafe.com/booking-experts-bv-nl03186915*
- **11 of 57 scored companies** are founder-owned, the most accessible ownership structure for strategic acquisitions.
- **12 PE-backed companies** exist in the scored universe — higher entry price but potentially faster decision timelines.
- **Core geography alignment**: NL: 1 prime | BE: 1 prime
- **Consolidation signal**: 26 companies already acquired — window of opportunity may be closing for remaining independent targets.

### Recommended Next Steps

1. **Initiate outreach** for all Prime Targets — prioritise founder-owned, NL/BE companies
2. **Commission deep analysis** for Watch List companies missing it
3. **Monitor trigger events** for Watch List (ownership change, funding, founder announcement)
4. **Track off-market acquirers** — strategic acquirers reveal consolidation intent
5. **Complete pending research** — 12 companies still require scoring


---

## Methodology

- **Scoring**: All M&A Scorecard scores use the rubric defined in `research-horeca-company.prompt.md`
- **Classification**: Prime Target (4.0–5.0), Watch List (3.0–3.9), Low Score (1.0–2.9), Off-Market (acquired/unavailable)
- **Composite Score**: Weighted average of 8 dimensions — Ownership attractiveness, Revenue scale fit, Geographic fit, Tech stack modernity, Customer lock-in, Vertical depth, Integration potential, Growth trajectory
- **Currency**: All EUR equivalents use approximate rates at time of research
- **Rankings**: Tied composite scores broken by Ownership attractiveness score, then Revenue scale fit
- **Generated by**: `.cursor/scripts/analysis/market/generate_horeca_dashboard.py`
