# Wavem

**Category**: Restaurant Software
**Country**: BE
**City**: Brussels
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Wavem @HORECA_IT/wavem/
@research-horeca-company Wavem @HORECA_IT/wavem/
```
