# Wavem — Corporate History

**Research Date**: 2026-04-30
**Researcher**: AI due-diligence agent
**Sources**: KBO Public Search, wavem.be (timeout/unavailable), web search, netsolitsolution.com reference, Belgian company databases

---

## Research Finding: Very Limited Public Presence, Possible Small Operator

Research found one indirect reference to Wavem.be as a company offering restaurant management software in Belgium:

- A third-party IT services listing (netsolitsolution.com) briefly describes "Wavem.be as a company offering smart solutions for restaurant management, including quick billing and inventory tracking"
- The wavem.be domain appears to exist (no 404 returned) but the website timed out during research
- No KBO record found via web search
- No Crunchbase, LinkedIn company, or Tracxn profile found
- No product reviews on G2, Capterra, or Trustpilot
- "Wave.be" (KBO BE 0874.275.252) is a different Belgian company (technology, located at Rue du Frontispice 10, 1000 Brussels) — not the same company

**Assessment**: Wavem appears to be a very small Belgian operator or micro-company with a live (but slow/unavailable at time of research) website. The company likely exists but has minimal digital footprint consistent with micro-SME status (<5 FTE).

---

## Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | Unknown (likely different from brand "Wavem") | KBO — no direct match | Unknown |
| KBO enterprise number | Unknown | Not found | Unknown |
| Domain wavem.be | Appears registered; website timed out during research | URL test | Estimated |
| HQ address | Brussels, Belgium | Research brief | Unknown |
| Founding year | Unknown | Not found | Unknown |
| Founders | Unknown | Not found | Unknown |
| Product | Restaurant management including quick billing, inventory | netsolitsolution.com reference | Estimated |
| Revenue | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Investment | Unknown | Not found | Unknown |
| Wave.be (different company) | KBO 0874.275.252, Brussels, technology company | Sentometrics | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A[Wavem<br/>Brussels, Belgium<br/>wavem.be — website timed out] --> B[Unknown founders/management]
    B --> C[Likely micro-SME with minimal digital presence]
    D[Wave.be — KBO 0874.275.252<br/>Different company, Brussels, BE] --> E[Separate entity — not the target]
```

---

## Corporate Timeline

```mermaid
timeline
    title Wavem — Timeline (data insufficient)
    Unknown : Company reportedly offering restaurant management software in Brussels
    2026-04-30 : Research — website timeout; one indirect reference found; KBO match not confirmed
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Data availability** | Very low — only one indirect reference found |
| **Domain status** | wavem.be appears active but inaccessible during research window |
| **Size estimate** | Likely micro-SME; unlikely to meet €1M ARR threshold |
| **Recommended action** | Direct outreach to Brussels HORECA community; retry wavem.be website at a later date; KBO phonetic search for Brussels restaurant software companies |
