# Wavem — Deep Analysis

**Research Date**: 2026-04-30
**Category**: Restaurant Software (Management & Reservations)
**Country**: BE | **City**: Brussels
**Research Quality**: Very Low — one indirect reference; website inaccessible; no company registry data

---

> **⚠ DATA AVAILABILITY WARNING**: Very limited public data found for Wavem. One indirect third-party reference describes it as offering restaurant management software including quick billing and inventory. The wavem.be domain appears registered but was inaccessible during research. No KBO record, LinkedIn profile, or product reviews found. All assessments are speculative.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | KBO — no direct match | Unknown |
| KBO number | Unknown | Not found | Unknown |
| Website | wavem.be — registered, inaccessible at research time | URL test | Estimated |
| HQ | Brussels, Belgium | Research brief | Unknown |
| Founded | Unknown | Not found | Unknown |
| CEO | Unknown | Not found | Unknown |
| Ownership | Unknown (likely founder-owned micro-SME) | Inferred from digital footprint | Estimated |
| Employees | Unknown (likely <5 based on digital footprint) | Inferred | Estimated |
| Revenue | Unknown (likely <€500K based on footprint) | Inferred | Estimated |
| Funding | Unknown (likely bootstrapped/self-funded) | Inferred | Estimated |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary markets | Belgium (Brussels) — assumed | Research brief | Unknown |
| Product description | Restaurant management: quick billing, inventory tracking | netsolitsolution.com | Estimated |
| Additional product features | Listed as "reservation platform" in research brief | Research brief | Unknown |
| Market size | Unknown | Not found | Unknown |
| Customer count | Unknown | Not found | Unknown |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Product | Restaurant management system | Research brief, indirect reference | Estimated |
| Features | Quick billing, inventory tracking (per indirect reference) | netsolitsolution.com | Estimated |
| Deployment | Unknown (cloud vs on-premise) | Not found | Unknown |
| Tech stack | Unknown | Not found | Unknown |
| API | Unknown | Not found | Unknown |
| Bancontact | Unknown | Not found | Unknown |
| Fiscal receipt (BE/GKS) | Unknown | Not found | Unknown |
| Deliveroo/Uber Eats | Unknown | Not found | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned? | Likely yes (micro-SME profile) | Inferred | Estimated |
| Institutional investors | Likely none | Inferred from minimal digital presence | Estimated |
| PE overhang | Likely none | Inferred | Estimated |
| Succession signals | Unknown | Not found | Unknown |

---

## 5. Financial Growth & Trajectory

| Year | Revenue | Growth | Employees | Notes |
|---|---|---|---|---|
| All years | Unknown | Unknown | Unknown | No public financial data |

*Estimated ARR*: Likely below €500K based on digital footprint of a micro-SME. Does not meet SolStein's €1M minimum threshold.

---

## 6. HORECA Vertical Depth

| Compliance/Integration | Status | Source | Confidence |
|---|---|---|---|
| GDPR | Unknown | Not found | Unknown |
| Food safety / HACCP | Unknown | Not found | Unknown |
| Bancontact | Unknown | Not found | Unknown |
| Fiscal receipt (BE) | Unknown | Not found | Unknown |
| Delivery integrations | Unknown | Not found | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Business model | Unknown | Not found | Unknown |
| Pricing | Unknown | Not found | Unknown |
| Estimated ARR | Below €500K (estimated) | Inferred from micro-SME profile | Estimated |
| Revenue scale fit | Below SolStein's €1M minimum | Inferred | Estimated |
| Acquisition value range | Cannot estimate | N/A | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 3 | Likely founder-owned (micro-SME profile); but unconfirmed | Inferred |
| Revenue scale fit | High | 1 | Likely below €1M ARR threshold; too small for SolStein target range | Inferred |
| Geographic fit | High | 3 | Brussels-based aligns with BE geography; but too small | Research brief |
| Tech stack modernity | Medium | N/A | Cannot assess | Not found |
| Customer lock-in | Medium | N/A | Cannot assess | Not found |
| Vertical depth | Medium | 2 | Basic billing and inventory; likely limited depth for enterprise use | Indirect ref. |
| Integration potential | Low | N/A | Cannot assess | Not found |
| Growth trajectory | Low | N/A | Cannot assess | Not found |

**Composite Score (partial)**: ~2.0 / 5.0 (estimated based on available indicators)

**Confidence Band**: Very Low — Only 3 of 8 dimensions partially scoreable; 5 are N/A

---

### Overall M&A Assessment

**Rating: LOW PRIORITY — Likely too small for SolStein thesis**

Based on the extremely limited digital footprint and indirect product description (basic billing + inventory), Wavem appears to be a micro-SME. The estimated ARR is below SolStein's €1M minimum threshold. Even if founder-owned, the scale is unlikely to generate sufficient standalone value as an acquisition target.

Wavem may be worth monitoring as a very early-stage operator, but should not be prioritized for M&A investigation until basic company data is confirmed.

---

### Recommended Next Step

1. Retry wavem.be at a later date when the website may be accessible
2. Search LinkedIn for employees listing Wavem as employer
3. KBO search for Brussels-based restaurant software companies with similar phonetics
4. If revenue confirmed below €500K: downgrade to "Too Small" and remove from primary target list
