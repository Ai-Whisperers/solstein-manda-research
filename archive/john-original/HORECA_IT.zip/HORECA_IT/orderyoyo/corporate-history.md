# OrderYOYO — Corporate History

**Category**: Online Ordering (Direct / Commission-free)
**Country**: DK (HQ); NL presence via Amsterdam office + Foodticket acquisition
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | OrderYOYO A/S | cision.com (Danish company) | Confirmed |
| NL Entity / Address | Basisweg 30, 1043 AP Amsterdam, NL | orderyoyo.com/about-us-new | Confirmed |
| KvK Number (NL entity) | Unknown — post-Foodticket acq., NL presence via Foodticket BV | openkvk.nl search pending | Unknown |
| Registered City (HQ) | Copenhagen, Denmark — Vesterbrogade 149, 1620 | orderyoyo.com/about-us-new | Confirmed |
| Founded | 2014 | orderyoyo.com/about-us-new | Confirmed |
| Founders | Thomas Paulsen and Thor Angelo | orderyoyo.com/about-us-new | Confirmed |
| Current Ownership | Pollen Street Capital (London-based PE), acquired April 2025 | pollenstreetgroup.com, cision.com | Confirmed |
| PE/Investor Ownership | Yes — Pollen Street Capital | pollenstreetgroup.com | Confirmed |
| Employees (FTE) | 300+ (per Pollen Street announcement, March 2025) | pollenstreetgroup.com/pollen-street-agrees-investment-in-orderyoyo | Confirmed |
| Revenue FY2024 | DKK 316M (~€42M) net revenue; ARR DKK 362M (~€48M) | orderyoyo.com Annual Financial Statement 2024 | Confirmed |
| EBITDA FY2024 | DKK 55.7M normalized EBITDA (17.6% margin) | orderyoyo.com Annual Financial Statement 2024 | Confirmed |
| M&A History (acquirer) | Happz (2021, DE), app smart merger (2022, UK/IE), Kingfood (2023, UK/IE), Gustoco (2023, DE), App4 (2024, UK), Foodticket (Oct 2025, NL — 16,000 restaurants) | orderyoyo.com/about-us-new | Confirmed |
| M&A History (acquired) | Acquired by Pollen Street Capital, deal announced March 4, 2025; closed April 4, 2025 | news.cision.com, pollenstreetgroup.com | Confirmed |
| Investment Rounds | IPO on Nasdaq First North (Copenhagen), 2021; delisted April 2025 post-PE acquisition | orderyoyo.com/about-us-new, quartr.com | Confirmed |
| Name Changes | None | — | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A[Pollen Street Capital\nLondon, UK — PE Fund] --> B[OrderYOYO A/S\nCopenhagen, Denmark\nHolding entity]
    B --> C[OrderYOYO NL\nAmsterdam office\nBasisweg 30]
    B --> D[Foodticket B.V.\nNetherlands — acquired Oct 2025\n~16,000 restaurant customers]
    B --> E[App4 Ltd\nUK — acquired 2024]
    B --> F[Other EU subsidiaries\nUK, IE, DE, AT]
```

---

## Timeline

```mermaid
timeline
    title OrderYOYO Key Events
    2014 : Founded by Thomas Paulsen and Thor Angelo, Copenhagen, Denmark
    2015 : First restaurant signed — Egedal Pizzaria, Denmark
    2016 : Entered UK and Irish markets
    2021 : IPO on Nasdaq First North; Acquired Happz (Germany)
    2022 : Merged with app smart — combined 9,000+ UK/IE/DK/DE restaurants
    2023 : Acquired Kingfood (UK/IE) and Gustoco (DE)
    2024 : Acquired App4 (UK kiosk); ARR DKK 362M; YOYOPay payments launched Jan 2025
    2025 : Acquired by Pollen Street Capital (PE) April; Acquired Foodticket NL Oct (16,000 restaurants)
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | No | PE-owned since April 2025 (Pollen Street Capital) |
| PE-free | No | Pollen Street Capital is the majority owner |
| Revenue in thesis range (€1M–€15M ARR) | No | ARR ~€48M (DKK 362M) — substantially above thesis ceiling |
| Geographic fit (NL/BE) | Partial | NL presence via Amsterdam office + Foodticket (Oct 2025); HQ is Denmark |
| HORECA specialization | Yes | Direct online ordering for takeaway/QSR restaurants |
| Succession signal | No | PE-backed with active buy-and-build strategy |
| Overall feasibility | Very Low | PE-owned, revenue above thesis range; active M&A platform itself |
