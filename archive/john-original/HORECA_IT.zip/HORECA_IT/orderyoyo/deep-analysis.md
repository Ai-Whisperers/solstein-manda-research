# OrderYOYO — Deep Analysis

**Category**: Online Ordering (Direct / Commission-free)
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | OrderYOYO A/S (Danish company) | cision.com announcement | Confirmed |
| HQ address | Vesterbrogade 149, 1620 Copenhagen, Denmark | orderyoyo.com/about-us-new | Confirmed |
| NL office address | Basisweg 30, 1043 AP Amsterdam, NL (post-Foodticket acquisition) | orderyoyo.com/about-us-new | Confirmed |
| Founded | 2014 | orderyoyo.com/about-us-new | Confirmed |
| CEO / MD | Thomas Paulsen (co-founder; CEO at time of PE acquisition) | orderyoyo.com, pollenstreetgroup.com | Confirmed |
| Ownership structure | 100% owned by Pollen Street Capital (London PE), since April 2025 | pollenstreetgroup.com, cision.com | Confirmed |
| Employees (FTE) | 300+ (March 2025 per Pollen Street); ~68 (Dec 2023 excl. acquired entities) | pollenstreetgroup.com, tracxn.com | Confirmed |
| Revenue FY2024 | DKK 316M net revenue (~€42M at ~0.134 DKK/EUR); ARR DKK 362M (~€48M) | orderyoyo.com Annual Financial Statement 2024 | Confirmed |
| Profitability | Normalized EBITDA DKK 55.7M (17.6% margin) FY2024 | orderyoyo.com Annual Financial Statement 2024 | Confirmed |
| Website | orderyoyo.com | — | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | Denmark, UK, Ireland, Germany, Austria, Netherlands (via Foodticket Oct 2025) | orderyoyo.com/about-us-new | Confirmed |
| Customer count | 16,000+ restaurants (Netherlands via Foodticket); 9,000+ UK/IE/DK/DE pre-Foodticket | orderyoyo.com, pollenstreetgroup.com/orderyoyo-acquires-foodticket | Confirmed |
| Target verticals | Independent takeaway restaurants, pizza/kebab/burger QSR, Asian cuisine takeaways | orderyoyo.com | Confirmed |
| Market share estimate | Claimed European leader in direct online ordering for independent takeaways | pollenstreetgroup.com | Estimated |
| Key competitors | Flipdish, Slerp, Bopple, Just Eat / Thuisbezorgd (aggregators, indirect), Deliverect | — | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | White-label branded website + app; in-store POS; self-service kiosks (via App4); payment processing (YOYOPay); marketing tools | orderyoyo.com, orderyoyo.com/about-us-new | Confirmed |
| Tech stack | SaaS; MySQL database; Google Analytics; WP Rocket (caching); Zendesk (support) | leadiq.com, prospeo.io | Estimated |
| Deployment model | Cloud SaaS; white-label per restaurant | orderyoyo.com | Confirmed |
| API availability | Not publicly documented as open API | — | Unknown |
| Key integrations | POS integrations; payment gateways; marketing tools | orderyoyo.com | Estimated |
| Mobile app | Yes — branded restaurant-specific consumer apps (iOS/Android) per partner | orderyoyo.com | Confirmed |
| Payment solution | YOYOPay (proprietary, launched Jan 2025); iDEAL (NL via Foodticket) | orderyoyo.com/about-us-new, clairfield.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | No — PE-owned since April 2025 | pollenstreetgroup.com | Confirmed |
| Investor type | Private equity (Pollen Street Capital, London) | pollenstreetgroup.com | Confirmed |
| PE ownership | Yes — Pollen Street Capital completed acquisition April 4, 2025 at DKK 9.50/share | news.cision.com, view.news.eu.nasdaq.com | Confirmed |
| Succession signals | None — PE is pursuing active buy-and-build (Foodticket acquired Oct 2025) | pollenstreetgroup.com/orderyoyo-acquires-foodticket | Confirmed |
| Last funding date | Pre-IPO: various; IPO 2021 (Nasdaq First North); PE acquisition April 2025 | orderyoyo.com/about-us-new | Confirmed |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | FY2023: DKK 253M → FY2024: DKK 316M (+25% YoY); ARR grew 22% Dec-23 to Dec-24 | orderyoyo.com Annual Financial Statement 2024 | Confirmed |
| EBITDA trend | FY2021: 0.5% margin → FY2024: 17.6% margin — strong operational leverage | pollenstreetgroup.com | Confirmed |
| Employee growth | FY2022: 41 FTE → FY2023: 68 FTE → Mar 2025: 300+ (including acquired entities) | tracxn.com, pollenstreetgroup.com | Confirmed |
| New markets | Netherlands entered Oct 2025 via Foodticket (~16,000 restaurants) | pollenstreetgroup.com/orderyoyo-acquires-foodticket | Confirmed |
| Recent product launches | YOYOPay (Jan 2025); self-service kiosk via App4 (2024) | orderyoyo.com/about-us-new | Confirmed |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Independent takeaway, QSR chains, Asian cuisine, pizza/kebab | orderyoyo.com | Confirmed |
| GDPR/AVG compliance | Operates in EU; GDPR compliance expected for EU markets | — | Estimated |
| Allergen management | Not documented as a core feature | orderyoyo.com | Unknown |
| Fiscal compliance NL | Via Foodticket integration; Foodticket had established NL presence | clairfield.com | Estimated |
| iDEAL/Bancontact/Tikkie support | iDEAL supported via Foodticket (NL-native); Bancontact/Tikkie unknown | clairfield.com, pollenstreetgroup.com/orderyoyo-acquires-foodticket | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | SaaS subscription per restaurant (white-label site/app); payment processing fees (YOYOPay); no commission on orders — key differentiator vs. aggregators | orderyoyo.com, pollenstreetgroup.com | Confirmed |
| Estimated ARR | DKK 362M (~€48M) as of December 2024 | orderyoyo.com Annual Financial Statement 2024 | Confirmed |
| Estimated acquisition value (PE deal) | Not disclosed; acquisition at DKK 9.50/share implied ~DKK 550–700M market cap (~€75–95M) at time of offer | cision.com announcement | Estimated |
| Revenue per employee | ~€140K/FTE (€42M ÷ 300 FTE) | calculated | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | PE-owned by Pollen Street Capital since April 2025; no founder succession dynamic | pollenstreetgroup.com |
| Revenue scale fit | High | 1 | ARR ~€48M — more than 3× above thesis ceiling of €15M | orderyoyo.com Annual Report 2024 |
| Geographic fit | High | 2 | NL presence via Foodticket (Oct 2025) and Amsterdam office; primary markets are DK/UK/DE | orderyoyo.com |
| Tech stack modernity | Medium | 4 | Cloud SaaS, white-label apps, embedded payments (YOYOPay), kiosks — modern stack | orderyoyo.com |
| Customer lock-in | Medium | 4 | Commission-free model creates strong loyalty; branded app creates consumer stickiness | pollenstreetgroup.com |
| Vertical depth | Medium | 3 | Focused on takeaway/QSR — less relevance for full-service HORECA (sit-down restaurants) | orderyoyo.com |
| Integration potential | Low | 3 | No published open API; integration with POS/PMS ecosystem uncertain | orderyoyo.com |
| Growth trajectory | Low | 5 | 25% YoY revenue growth; EBITDA margin expansion from 0.5% to 17.6% in 3 years | orderyoyo.com Annual Report |

**Composite Score**: 2.4 / 5.0

**Confidence Band**: Narrow (FY2024 financial statements publicly available; PE deal terms partially disclosed)

**Overall M&A Assessment**: OrderYOYO is an operationally impressive SaaS business with exceptional growth and margin improvement, but it is wholly outside SolStein's M&A thesis on every key filter: PE-owned, ARR ~€48M (3× above thesis ceiling), HQ in Denmark, and now an active acquirer itself under Pollen Street Capital's ownership. Its entry into the Netherlands via Foodticket (Oct 2025) adds NL relevance, but changes nothing about its PE ownership or scale.

**Recommended Next Step**: No acquisition pursuit. Monitor Foodticket B.V. independently as a potential separate target should it be carved out, or watch for PE exit signals from Pollen Street Capital in 3–5 years.
