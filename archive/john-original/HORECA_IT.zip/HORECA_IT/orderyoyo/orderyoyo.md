# OrderYoyo

**Category**: Online Ordering
**Country**: NL
**City**: Amsterdam
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history OrderYoyo @HORECA_IT/orderyoyo/
@research-horeca-company OrderYoyo @HORECA_IT/orderyoyo/
```
