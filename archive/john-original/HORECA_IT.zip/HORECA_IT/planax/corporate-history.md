# Planax — Corporate History

**Category**: Workforce / Employee Scheduling
**Country**: NL
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Unknown | openkvk.nl — zero results for "planax" | Unknown |
| KvK Number | Unknown | openkvk.nl search returned no results for "planax" | Unknown |
| Registered City | Groningen (claimed) | Task brief; not verified in KvK | Unknown |
| Founding Year | Unknown | No public record found | Unknown |
| Founders | Unknown | No public record found | Unknown |
| Current Ownership | Unknown | No public record found | Unknown |
| PE/Investor Ownership | Unknown | No public record found | Unknown |
| Employees (FTE) | Unknown | No LinkedIn company page found | Unknown |
| Estimated Revenue | Unknown | No financial data found | Unknown |
| M&A History | Unknown | No public record found | Unknown |
| Investment Rounds | Unknown | No public record found | Unknown |
| Name Changes | Unknown | No public record found | Unknown |

---

## Research Notes

**Domain status**: The domain `planax.nl` appears to exist (connection timeout rather than HTTP 404), but the website was inaccessible during research on 2026-04-30. No cached version was retrievable.

**KvK search**: A search on [openkvk.nl](https://openkvk.nl/search?q=planax) for the term "planax" returned **zero results** — no Dutch company with this name is registered in the Handelsregister as of research date.

**Disambiguation**: "Planax" refers to multiple unrelated entities:
- **Planax AB** (Sweden) — EPM/BI consulting firm, Stockholm ([planax.se](https://www.planax.se/), LinkedIn confirmed)
- **Planax** (Germany) — thermal binding machine manufacturer, acquired by Planatol in 2009
- Neither is the Dutch HORECA scheduling company referenced in this research brief.

**LinkedIn**: No Dutch company LinkedIn page for "Planax" in the HORECA scheduling sector was found.

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown — Founder / Owner] --> B[Planax NL — Operating Entity]
    B --> C[Workforce Scheduling SaaS — HORECA]
```

*Structure is entirely inferred from task brief; no primary sources available.*

---

## Timeline

```mermaid
timeline
    title Planax — Key Events (Reconstructed)
    Unknown : Founded — year not established
    2026-04-30 : Research conducted — no public data found
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | No ownership data found |
| PE-free | Unknown | No investor data found |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No financial data found |
| Geographic fit (NL/BE) | Likely Yes | Claimed Groningen, NL location; unverified |
| Succession signal | Unknown | No public signal found |
| Overall feasibility | Unknown | Insufficient data to assess |

---

## Research Confidence Summary

Research across openkvk.nl, kvk.nl, LinkedIn, Crunchbase, Google, Dutch tech media, and direct website access produced **no verifiable data** about Planax as a Dutch HORECA workforce scheduling company. The company appears to have minimal or no public digital footprint. The domain `planax.nl` may be operational but was unreachable during this research window. A **direct outreach** or **paid KvK extract** would be required to confirm basic corporate facts.
