# Planax

**Category**: Workforce
**Country**: NL
**City**: Groningen
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Planax @HORECA_IT/planax/
@research-horeca-company Planax @HORECA_IT/planax/
```
