# Planax — Deep Analysis

**Category**: Workforce / Employee Scheduling
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | openkvk.nl — zero results | Unknown |
| HQ address | Groningen, NL (claimed) | Task brief only | Unknown |
| Founded | Unknown | No public record | Unknown |
| CEO / MD | Unknown | No public record | Unknown |
| Ownership structure | Unknown | No public record | Unknown |
| Employees (FTE) | Unknown | No LinkedIn page found | Unknown |
| Revenue (latest estimate) | Unknown | No financial data found | Unknown |
| Profitability | Unknown | No financial data found | Unknown |
| Website | planax.nl (unverified, inaccessible) | Domain timeout on 2026-04-30 | Unknown |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | NL (claimed) | Task brief | Unknown |
| Customer count | Unknown | No public data | Unknown |
| Target verticals | Hospitality / HORECA (claimed) | Task brief | Unknown |
| Market share estimate | Unknown | No public data | Unknown |
| Key competitors | Nostradamus, Planday, PlanPanther, MyRooster, TopRooster | Dutch HORECA scheduling market research | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Employee scheduling software for hospitality (claimed) | Task brief | Unknown |
| Tech stack | Unknown | No public data | Unknown |
| Deployment model | Unknown — likely SaaS or web-based | Sector inference | Unknown |
| API availability | Unknown | No public data | Unknown |
| Key integrations | Unknown | No public data | Unknown |
| Mobile app | Unknown | No public data | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No public data | Unknown |
| Investor type | Unknown | No public data | Unknown |
| PE ownership | Unknown | No public data | Unknown |
| Succession signals | Unknown | No public data | Unknown |
| Last funding date | Unknown | No public data | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No public data | Unknown |
| Employee growth | Unknown | No LinkedIn history | Unknown |
| New markets | Unknown | No public data | Unknown |
| Recent product launches | Unknown | No public data | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Unknown | No public data | Unknown |
| GDPR/AVG compliance | Unknown | No public data | Unknown |
| Allergen management | Unknown | Not applicable to scheduling software | N/A |
| Fiscal compliance NL | Unknown | No public data | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown | No public data | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown | No public data | Unknown |
| Estimated ARR | Unknown | No public data | Unknown |
| Estimated acquisition value | Unknown | No public data | Unknown |
| Revenue per employee | Unknown | No public data | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot score — no ownership data | — |
| Revenue scale fit | High | N/A | Cannot score — no revenue data | — |
| Geographic fit | High | N/A | NL claimed but unverified | Task brief |
| Tech stack modernity | Medium | N/A | Cannot score — no product data | — |
| Customer lock-in | Medium | N/A | Cannot score — no customer data | — |
| Vertical depth | Medium | N/A | Cannot score — no product detail | — |
| Integration potential | Low | N/A | Cannot score — no tech data | — |
| Growth trajectory | Low | N/A | Cannot score — no growth data | — |

**Composite Score**: N/A — Insufficient data
**Confidence Band**: Wide (high uncertainty)
**Overall M&A Assessment**: No verifiable public data exists for Planax as a Dutch HORECA scheduling company. The company does not appear in the KvK Handelsregister under this name. The domain planax.nl appears to exist but was inaccessible during research. Given zero confirmable data points, no M&A attractiveness score can be assigned with integrity.
**Recommended Next Step**: Attempt direct outreach via planax.nl contact form or LinkedIn; alternatively, order a paid KvK extract searching Groningen-registered software companies in SBI code 6201/6202; consider that the company may operate under a different legal entity name.

---

## 9. Competitive Landscape — Dutch HORECA Workforce Scheduling

The Dutch HORECA scheduling market is active, with several known competitors:

| Competitor | HQ | Positioning | Est. Customers |
|---|---|---|---|
| Nostradamus | Netherlands | AI-driven scheduling, 3,000+ HORECA clients | 3,000+ (claimed) |
| Planday (Xero) | Denmark | International, acquired by Xero | Large |
| PlanPanther | Netherlands | Hospitality-specific, AI, tip management | Unknown |
| MyRooster | Netherlands | Multi-location, payroll integration | Unknown |
| TopRooster (DDA Automation) | Limmen, NL | KvK 42012307 | Unknown |

*Sources: company websites and nostradamus.nl (accessed 2026-04-30)*

---

## 10. Research Methodology & Limitations

**Searches conducted**:
- openkvk.nl — "planax", "planax groningen" — zero KvK results
- Google — multiple query variants in Dutch and English
- LinkedIn — no Dutch Planax company page found
- Direct website — planax.nl timed out (not 404; domain may be active)
- planax.com — Swedish EPM company (unrelated)
- Crunchbase, PitchBook — only Planax AB (Swedish) and Planax GmbH (German) found

**Limitation**: This company has extremely limited public digital presence. Data cannot be confirmed without direct company contact or a paid registry extract.
