# Resengo — Deep Analysis

**Category**: Reservations / Table Management
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity (NL) | RESENGO NEDERLAND B.V. | transfirm.nl (KvK registry) | Confirmed |
| Legal entity (BE) | Resengo (Belgium entity; exact BV/NV name unknown) | pitchbook.com | Estimated |
| HQ address | Berchem, Belgium (Antwerp region) | pitchbook.com | Confirmed |
| NL address | Amsterdam (exact street address not located in research) | transfirm.nl (KvK 28061483) | Confirmed |
| Founded | 2003 | pitchbook.com, resengo.com (acquisition blog: "two decades ago") | Confirmed |
| CEO / MD (pre-acquisition) | Dirk Gypen (CEO; likely founder) | pro.resengo.com/en/blog/zenchef-formitable-acquires-resengo | Confirmed |
| Current CEO | Xavier Zeitoun (CEO of combined Zenchef group) | pro.resengo.com blog | Confirmed |
| Ownership structure | Subsidiary of Zenchef group (PSG Equity backed); Resengo brand retired 2024–2025 | pro.resengo.com, psgequity.com | Confirmed |
| Employees (FTE, pre-acquisition) | ~45 | pitchbook.com | Estimated |
| Revenue (latest estimate) | Not publicly disclosed; likely €2M–€6M ARR pre-acquisition (inferred from ~3,500 restaurant clients) | — | Unknown |
| Profitability | Unknown | — | Unknown |
| Website | resengo.com (redirects to Zenchef as of 2025) | pro.resengo.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | Belgium and Netherlands (core); operations in 13 countries at acquisition | crescolaw.com, pro.resengo.com | Confirmed |
| Customer count | 3,500+ restaurants at time of acquisition (Sep 2023) | pro.resengo.com | Confirmed |
| Target verticals | Restaurants, beauty & wellness, private saunas, hotels, service-based businesses | resengo.com | Confirmed |
| Market share estimate | Leader in online restaurant reservations in Belgium; significant NL presence | siliconcanals.com | Estimated |
| Key competitors (pre-acq.) | Formitable (NL — now merged), TheFork (TripAdvisor), OpenTable (US), Tablebooker (BE) | — | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Online reservation system; table management; guest relationship management; gift vouchers; terrace planning | resengo.com, lightspeedhq.com/integrations/resengo | Confirmed |
| Tech stack | Web-based SaaS; "Resengo Tables" widget for restaurant websites; unknown back-end stack | lightspeedhq.com/integrations/resengo | Estimated |
| Deployment model | Cloud SaaS; white-label booking widget embeddable on restaurant websites | resengo.com | Confirmed |
| API availability | Integration with Lightspeed POS documented; broader API unknown | lightspeedhq.com/integrations/resengo | Estimated |
| Key integrations | Lightspeed Restaurant POS (NL/BE); platform now part of Zenchef ecosystem | lightspeedhq.com/integrations/resengo | Confirmed |
| Mobile app | Consumer-facing booking app (resengo.com/EN) | resengo.com | Confirmed |
| Payments | Not a primary revenue feature; reservation-focused | resengo.com | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | No (since Sep 12, 2023 — acquired by Zenchef \| Formitable) | pro.resengo.com | Confirmed |
| Investor type | Growth equity (PSG Equity via Zenchef parent) | psgequity.com | Confirmed |
| PE ownership | Yes — PSG Equity (growth equity) invested €50M+ in Zenchef in Sep 2022 | psgequity.com/news/zenchef-announces-investment | Confirmed |
| Succession signals | Dirk Gypen (CEO) endorsed acquisition; likely exited post-transaction | pro.resengo.com blog | Estimated |
| Last funding date | Sep 2022: PSG Equity invested €50M+ in Zenchef (parent); Resengo itself had no known external investors | psgequity.com | Confirmed |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Not disclosed; 2003–2023 organic growth to 3,500 restaurant customers | — | Unknown |
| Employee growth | ~45 pre-acquisition; absorbed into Zenchef's 200+ employee base | pitchbook.com, pro.resengo.com | Estimated |
| New markets | 13 countries at time of acquisition; brand now retired into Zenchef | crescolaw.com | Confirmed |
| Recent product launches | N/A — brand retired; customers migrated to Zenchef platform (2024–2025) | pro.resengo.com/en | Confirmed |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Full-service restaurants (fine dining to casual), beauty/wellness, hotels | resengo.com | Confirmed |
| GDPR/AVG compliance | Belgium + Netherlands based; GDPR/AVG compliance required and assumed | — | Estimated |
| Allergen management | Not documented as core product feature | resengo.com | Unknown |
| Fiscal compliance NL | Reservation system; not directly linked to fiscal/POS compliance | — | Estimated |
| iDEAL/Bancontact/Tikkie support | Bancontact (BE) likely; iDEAL (NL) possible for pre-payment deposits; not confirmed | resengo.com | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | SaaS subscription per restaurant seat/table capacity; consumer-facing booking platform | resengo.com | Estimated |
| Estimated ARR | Not disclosed; inferred €2M–€6M based on ~3,500 clients at ~€600–€1,700/year average | — | Unknown |
| Estimated acquisition value | Not disclosed; PSG Equity deal terms for Zenchef + Resengo not public | crescolaw.com | Unknown |
| Revenue per employee | Unknown (revenue not disclosed) | — | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Acquired by PSG Equity-backed Zenchef in Sep 2023; fully absorbed; no longer independent | pro.resengo.com |
| Revenue scale fit | High | 3 | Likely €2M–€6M ARR pre-acquisition — potentially within thesis range, but now unavailable | pitchbook.com (inferred) |
| Geographic fit | High | 5 | Belgium + Netherlands core markets; perfect HORECA geographic fit | pro.resengo.com, crescolaw.com |
| Tech stack modernity | Medium | 3 | Cloud SaaS reservation widget; exact stack unknown; now migrated to Zenchef platform | lightspeedhq.com/integrations |
| Customer lock-in | Medium | 4 | Reservation platforms create strong operational dependency; 3,500 restaurant relationships | pro.resengo.com |
| Vertical depth | Medium | 4 | Pure-play HORECA reservations; Belgium's leading restaurant reservation platform | siliconcanals.com |
| Integration potential | Low | 3 | Lightspeed integration existed; broader ecosystem integration potential moderate | lightspeedhq.com/integrations/resengo |
| Growth trajectory | Low | 2 | 20-year organic-only business; modest scale at exit; brand retired post-acquisition | — |

**Composite Score**: 2.9 / 5.0

**Confidence Band**: Wide (revenue, exact valuation, and most financials undisclosed)

**Overall M&A Assessment**: Resengo was the highest-quality M&A target of the three companies evaluated — it was founder-CEO-led (Dirk Gypen), NL/BE focused, HORECA-specialized, and likely within SolStein's revenue thesis. Unfortunately, it was acquired by Zenchef | Formitable (PSG Equity) on September 12, 2023 and has since been fully rebranded and operationally merged into the Zenchef platform. It is no longer available as an independent entity. This acquisition demonstrates strong M&A demand for exactly the profile SolStein targets in the NL/BE reservation segment.

**Recommended Next Step**: No acquisition pursuit (target no longer exists as independent entity). Use Resengo's pre-acquisition profile as a benchmark for identifying similar BE/NL reservation platforms. Investigate Tablebooker (BE) and MyRes (NL) as potentially comparable independent targets in the same reservation niche.
