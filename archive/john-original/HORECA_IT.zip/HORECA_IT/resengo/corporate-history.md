# Resengo — Corporate History

**Category**: Reservations / Table Management
**Country**: BE (HQ); NL subsidiary (RESENGO NEDERLAND B.V.)
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name (NL) | RESENGO NEDERLAND B.V. | transfirm.nl (KvK data) | Confirmed |
| KvK Number (NL) | 28061483 | transfirm.nl | Confirmed |
| Registered City (NL) | Amsterdam | transfirm.nl | Confirmed |
| HQ Country | Belgium (Berchem/Antwerp area) | pitchbook.com, crescolaw.com | Confirmed |
| Founded | 2003 | pitchbook.com, resengo.com ("two decades ago" per 2023 acquisition blog) | Confirmed |
| Founders | Unknown (Dirk Gypen identified as longtime CEO, likely founder) | pro.resengo.com blog | Estimated |
| Current Ownership | Zenchef (formerly Zenchef \| Formitable group) — PSG Equity backed | pro.resengo.com, psgequity.com | Confirmed |
| PE/Investor Ownership | Yes — PSG Equity (growth equity), majority investor in Zenchef group | psgequity.com/news/zenchef-announces-investment | Confirmed |
| Pre-acquisition Employees | ~45 | pitchbook.com | Estimated |
| Pre-acquisition Customers | 3,500+ restaurants (Belgium + Netherlands) | pro.resengo.com blog | Confirmed |
| Estimated Revenue (pre-acq.) | Not publicly disclosed; likely €2M–€6M ARR | — | Unknown |
| M&A History | Acquired by Zenchef \| Formitable group on September 12, 2023 | pro.resengo.com, siliconcanals.com | Confirmed |
| Investment Rounds | None identified pre-acquisition (likely bootstrapped) | pitchbook.com | Estimated |
| Name Changes | Resengo → rebranded as Zenchef (2024–2025) | pro.resengo.com/en (redirects to "Resengo is now Zenchef") | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A[PSG Equity\nGrowth Equity — Boston/London] -->|Majority investor ~€50M+| B[Zenchef Group\nParis, France\nFormed Jan 2023 merger of Zenchef + Formitable]
    B --> C[RESENGO NEDERLAND B.V.\nKvK 28061483\nAmsterdam, NL\nAcquired Sep 2023]
    B --> D[Resengo Belgium entity\nBerchem, Belgium]
    B --> E[Formitable B.V.\nAmsterdam, NL\nPre-merger Zenchef|Formitable]
    B --> F[Zenchef SAS\nParis, France]
```

---

## Timeline

```mermaid
timeline
    title Resengo Key Events
    2003 : Founded in Belgium — online restaurant reservations platform
    2003-2022 : Organic growth across Belgium and Netherlands; 13 countries; ~3,500 restaurants
    Jan 2023 : Zenchef (France) and Formitable (NL) merge to form Zenchef | Formitable group
    Sep 2022 : PSG Equity invests €50M+ in Zenchef to fund European expansion
    Sep 2023 : Resengo acquired by Zenchef | Formitable group (announced September 12, 2023)
    2024 : Resengo brand begins transition to Zenchef platform
    2025-2026 : Full rebrand complete — "Resengo is now Zenchef"
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | No | Was likely founder/CEO-led (Dirk Gypen) but acquired in 2023 |
| PE-free | No | PSG Equity controls the parent Zenchef group |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | Pre-acquisition revenue not disclosed; post-acquisition folded into Zenchef group |
| Geographic fit (NL/BE) | Yes | Strong NL/BE focus — core markets before acquisition |
| HORECA specialization | Yes | Pure-play restaurant reservations and table management |
| Succession signal | N/A | No longer an independent entity; fully absorbed into Zenchef |
| Overall feasibility | Very Low | Acquired, rebranded, and operationally merged into Zenchef; not available as standalone target |
