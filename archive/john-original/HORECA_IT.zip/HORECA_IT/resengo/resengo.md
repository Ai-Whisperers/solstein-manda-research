# Resengo

**Category**: Reservations
**Country**: NL
**City**: Amsterdam
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Resengo @HORECA_IT/resengo/
@research-horeca-company Resengo @HORECA_IT/resengo/
```
