# eviivo

**Category**: Hotel PMS
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history eviivo @HORECA_IT/eviivo/
@research-horeca-company eviivo @HORECA_IT/eviivo/
```
