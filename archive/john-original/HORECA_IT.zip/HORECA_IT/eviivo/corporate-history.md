# eviivo — Corporate History

**Category**: Hotel PMS (Boutique / Independent Accommodation)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; Investcorp-backed, acquired/merged Dec 2022)

---

## Summary Assessment

eviivo is a **London-based cloud PMS** for boutique hotels, B&Bs, vacation rentals, and independent accommodation providers. Founded ~2003–2011 (conflicting dates), it was **acquired/merged on 1 December 2022** and is now backed by **Investcorp Technology Partners**. With 30,000+ properties globally and CEO Michele Fitzpatrick, eviivo serves the independent accommodation segment. Revenue estimates vary widely. Not a SolStein target (UK-focused; PE/institutional-backed). Useful as a **boutique hotel PMS benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | eviivo | eviivo.com | Confirmed |
| HQ | Fora Clerkenwell, 9 Dallington Street, London, UK | PitchBook | Confirmed |
| Founded | 2003 (PitchBook) — some sources cite 2011 | PitchBook | Estimated |
| CEO | Michele Fitzpatrick | owler.com | Estimated |
| Ownership | Investcorp Technology Partners (deal date Dec 1, 2022) | PitchBook | Confirmed |
| Acquisition/merger date | 1 December 2022 | PitchBook | Confirmed |
| Parent/investor | Investcorp Technology Partners | PitchBook | Confirmed |
| Total funding (various sources) | $4.4M (CBInsights), $36.5M (PitchBook), $48.9M (Owler) | Multiple — conflicting | Estimated |
| Properties served | 30,000+ globally | eviivo.com | Confirmed |
| Product | eviivo Suite™: PMS + channel manager + website manager + payment automation | eviivo.com | Confirmed |
| AI features | eviivo Concierge (AI) | eviivo.com | Confirmed |
| Mobile app | eviivo Mobile | eviivo.com | Confirmed |
| Key OTA integrations | Airbnb, Booking.com, Expedia, Vrbo | eviivo.com | Confirmed |
| Target customers | Boutique hotels, B&Bs, vacation rentals, unique properties | eviivo.com | Confirmed |

---

## Founding & History

eviivo was founded in **London** with a focus on the **independent accommodation sector** — the boutique hotels, B&Bs, guesthouses, and vacation rental properties that were underserved by enterprise hotel PMS vendors.

The company provides an **all-in-one suite** (eviivo Suite™) combining property management, OTA channel management, website builder, and payment automation — giving independent operators tools previously only accessible to chains.

**December 1, 2022**: eviivo was acquired by / merged with an entity backed by **Investcorp Technology Partners** (Bahrain-based global alternative investment management firm). The exact structure of the deal is not disclosed, but PitchBook records this as an acquisition/merger event.

**Michele Fitzpatrick** serves as CEO. As of 2026, eviivo serves 30,000+ properties worldwide, with active product development including an AI concierge product.

The conflicting founding dates (2003 vs 2011) likely reflect different starting points: the company concept/initial development vs the commercial SaaS product launch.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Investcorp Technology Partners<br/>(Manama, Bahrain — Global PE/Alternative Investment)"]
    B["eviivo<br/>(London, UK)"]
    C["30,000+ independent accommodation properties<br/>(boutique hotels, B&Bs, vacation rentals)"]

    A -->|"Acquired/merged Dec 1, 2022"| B
    B --> C
```

---

## Timeline of Critical Events

```mermaid
timeline
    title eviivo — Key Milestones
    2003 (or 2011) : Founded in London; boutique hotel and B&B PMS + channel management
    2022 : Acquired/merged; Investcorp Technology Partners backing (Dec 1, 2022)
    2026 : 30,000+ properties globally; Michele Fitzpatrick CEO; eviivo Concierge AI launched; eviivo Mobile active
```

---

## M&A Feasibility Assessment

### Is eviivo an Acquisition Target for SolStein?

**Answer: No. Institutional-backed (Investcorp); UK-focused; 30,000+ properties globally.**

| Factor | Assessment |
|---|---|
| **Scale** | 30,000+ properties globally — far above SolStein's target customer range |
| **Ownership** | Investcorp Technology Partners (PE/alternative investment) — not founder-owned |
| **Geography** | UK/global focus; no NL/BE-specific strategy |
| **Succession** | Professional CEO (Fitzpatrick); no founder succession angle |
| **Exit pathway** | Institutional PE holds; exit timeline unknown but not a founder sale |

### Role for SolStein

1. **Boutique hotel PMS benchmark**: eviivo defines the independent hotel/B&B PMS segment (channel management + direct booking + payments in one suite).
2. **Scale reference**: 30,000+ properties globally at SaaS pricing = large customer base but low ACV (average contract value) per property — suggesting ~£100–500/property/year pricing.
3. **NL/BE opportunity**: A NL/BE boutique hotel PMS company at founder-owned, €1–5M ARR level serving independent hotels is a SolStein target.

---

*Sources: PitchBook (eviivo 2026 profile), eviivo.com, CBInsights, owler.com.*
