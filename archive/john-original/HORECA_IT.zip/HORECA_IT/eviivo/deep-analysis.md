# eviivo — Deep Analysis

**Category**: Hotel PMS (Boutique / Independent Accommodation)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; Investcorp Technology Partners backed since Dec 2022)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | eviivo Ltd (inferred) | PitchBook | Estimated |
| HQ | 9 Dallington Street (Fora Clerkenwell), London, UK | PitchBook | Confirmed |
| Founded | 2003 (PitchBook) — some sources say 2011 | PitchBook | Estimated |
| CEO | Michele Fitzpatrick | owler.com | Estimated |
| Ownership | Investcorp Technology Partners (since Dec 1, 2022) | PitchBook | Confirmed |
| Properties served | 30,000+ | eviivo.com | Confirmed |
| Revenue | Conflicting estimates: $4.4M (CBInsights) to $12B (LeadIQ — outlier); likely £5M–£15M | Multiple sources | Estimated |
| Total funding | $36.5M (PitchBook) — conflicting with other sources | PitchBook | Estimated |
| Business model | SaaS all-in-one suite (PMS + channel + website + payments) | eviivo.com | Confirmed |
| Product | eviivo Suite™ + eviivo Concierge (AI) + eviivo Mobile | eviivo.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Primary | eviivo.com | Confirmed |
| Global presence | 30,000+ properties globally | eviivo.com | Confirmed |
| EU/NL/BE presence | Possible (global OTA integrations); not specifically stated | eviivo.com | Estimated |
| Target segment | Boutique hotels, B&Bs, guesthouses, vacation rentals, unique stays | eviivo.com | Confirmed |
| ACV estimate | ~£100–500/property/year (implied from 30K properties vs estimated revenue) | Derived | Estimated |
| Market position | Strong in UK independent accommodation segment | eviivo.com, hoteltechreport.com | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | eviivo Suite™ (all-in-one PMS) | eviivo.com | Confirmed |
| Channel management | OTA connectivity: Airbnb, Booking.com, Expedia, Vrbo | eviivo.com | Confirmed |
| Website builder | Direct booking website included | eviivo.com | Confirmed |
| Payment automation | Integrated payment processing | eviivo.com | Confirmed |
| AI features | eviivo Concierge (AI-powered guest communication) | eviivo.com | Confirmed |
| Mobile app | eviivo Mobile | eviivo.com | Confirmed |
| Owner management | Remote access for property owners | CBInsights (Mar 2026 update) | Confirmed |
| Deployment | Cloud SaaS | eviivo.com | Confirmed |
| Tech stack | Cloud-native; modern web stack | eviivo.com | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Current owner | Investcorp Technology Partners | PitchBook | Confirmed |
| Acquisition date | December 1, 2022 | PitchBook | Confirmed |
| Prior investors | Unknown pre-2022 | — | Unknown |
| CEO | Michele Fitzpatrick | owler.com | Estimated |
| Founder status | Unknown post-acquisition | — | Unknown |
| Divestiture likelihood | Unknown — Investcorp typical hold 3–5 years; potential exit ~2025–2027 | PE lifecycle | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Properties | 30,000+ | eviivo.com | Confirmed |
| Revenue (CBInsights) | ~$4.4M | CBInsights | Estimated |
| Revenue (PitchBook funding) | $36.5M total raised suggests ~£5–15M ARR | Derived | Estimated |
| Revenue (Owler funding) | $48.9M total raised | Owler | Estimated |
| Revenue (LeadIQ) | $12B annual — clear outlier; ignore | LeadIQ | Unknown |
| Best estimate | £5M–£15M ARR | Synthesis of above | Estimated |
| Growth | Active product development (AI, mobile) suggests investment phase | eviivo.com | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK accommodation compliance | UK GDPR, UK booking regulations | eviivo.com | Confirmed |
| UK payment methods | UK payment processing (direct debit, card) | eviivo.com | Confirmed |
| Airbnb/OTA integration | Full integration with major OTAs | eviivo.com | Confirmed |
| Independent sector | Deep understanding of boutique/independent operator needs | eviivo.com | Confirmed |
| Property type support | Hotels, B&Bs, vacation rentals, glamping, unique stays | eviivo.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | Per-property SaaS subscription | eviivo.com | Confirmed |
| ARR estimate | £5M–£15M (derived from 30K properties × £150–500/year) | Derived | Estimated |
| Acquisition valuation | Not disclosed | PitchBook | Unknown |
| SolStein fit | No — UK-focused; institutional PE-backed; 30,000+ properties global scale | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 2 | Investcorp Technology Partners PE-backed; no founder-owned angle; possible exit ~2025–2027 | PitchBook |
| Revenue scale fit | High | 3 | Estimated £5M–£15M ARR — within range, but PE-owned and global | Derived |
| Geographic fit | High | 1 | UK primary; 30,000+ globally but no NL/BE strategy | eviivo.com |
| Tech stack modernity | Medium | 5 | Cloud-native; AI (Concierge); mobile; OTA integrations | eviivo.com |
| Customer lock-in | Medium | 4 | All-in-one PMS creates high switching costs (property data, OTA connections) | eviivo.com |
| Vertical depth | Medium | 4 | Deep independent accommodation expertise; multi-property type | eviivo.com |
| Integration potential | Low | 5 | Airbnb/Booking/Expedia/Vrbo + payment APIs | eviivo.com |
| Growth trajectory | Low | 3 | Active AI/mobile development; PE investment phase | eviivo.com |

### Composite Score

**Weighted Composite: 2.5 / 5.0**

*(Geographic fit = 1 [high weight]; ownership attractiveness = 2 [PE-backed])*

**Confidence Band**: Very Low — revenue estimates span $4M to $12B (outlier); ownership confirmed but details limited.

### Overall M&A Assessment

eviivo is **not a SolStein target** — it is UK-focused with institutional PE backing and global scale (30,000+ properties). Its value is as a **boutique hotel PMS benchmark**: shows what all-in-one independent accommodation software looks like (PMS + OTA + payments + AI). NL/BE boutique hotel PMS companies at €1–5M ARR, founder-owned, are the SolStein equivalents to pursue.

### Recommended Next Step

No pursuit. Use as boutique hotel PMS benchmark. Evaluate NL/BE independent hotel software companies (Misterbook, Juniper, Booking Experts) against this profile.

---

*Sources: PitchBook (eviivo 2026), eviivo.com, CBInsights, owler.com.*
