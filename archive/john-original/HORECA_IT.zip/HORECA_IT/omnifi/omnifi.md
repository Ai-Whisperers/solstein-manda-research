# Omnifi

**Category**: Guest WiFi
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Omnifi @HORECA_IT/omnifi/
@research-horeca-company Omnifi @HORECA_IT/omnifi/
```
