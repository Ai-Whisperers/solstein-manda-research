# Omnifi — Corporate History

**Category**: Guest Order & Pay (Mobile Ordering / Digital F&B)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; acquired by Access Group 2021)

---

## Summary Assessment

Omnifi is a **London-based hospitality Order & Pay platform** that was **acquired by The Access Group in 2021** and is now integrated into **Access Hospitality** as its mobile ordering and digital payment product. The original Omnifi brand is maintained as a sub-brand within Access Hospitality's product portfolio. Not a standalone acquisition target; relevant as a product category example within the Access Group ecosystem.

**Note on research context**: The user listed Omnifi as "Guest WiFi, London, UK — Guest WiFi and marketing for hotels." Research reveals that Omnifi (UK) is in fact a **digital Order & Pay** platform for hospitality, not a dedicated WiFi marketing company. The Access Group describes it as an "Order and Pay app." A separate US company called Omnifi (formerly Plumeria Networks) exists in the WiFi/networking space but is unrelated.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Omnifi | theaccessgroup.com/our-brands/omnifi | Confirmed |
| Parent company | The Access Group (Access Hospitality division) | theaccessgroup.com | Confirmed |
| Acquisition by Access Group | 2021 | theaccessgroup.com | Confirmed |
| Original product category | Mobile Order & Pay for hospitality | theaccessgroup.com | Confirmed |
| HQ | London, UK | theaccessgroup.com | Estimated |
| Current status | Sub-brand/product within Access Hospitality | theaccessgroup.com | Confirmed |
| Founders | Not publicly identified | — | Unknown |
| Pre-acquisition funding | Not disclosed | — | Unknown |
| Companies House registration | Not confirmed in research | — | Unknown |
| UK sectors | Hospitality (hotels, restaurants, pubs) | theaccessgroup.com | Confirmed |
| Integration | Part of Access Hospitality suite (with Guestline, ResDiary, etc.) | theaccessgroup.com | Confirmed |

---

## History

Omnifi was a UK hospitality technology company providing a **mobile Order & Pay platform** enabling hotel and restaurant guests to browse menus, order food and drinks, and pay — all from their mobile device, without needing to download a dedicated app (typically via QR code or web app).

The platform addressed the post-COVID shift toward contactless dining and mobile payment in UK hospitality. In **2021**, The Access Group acquired Omnifi as part of its strategy to build a comprehensive Access Hospitality suite, adding mobile ordering and payments alongside its POS, property management, and reservations products.

Today, Omnifi is listed as one of The Access Group's brands under Access Hospitality, integrated with Guestline (PMS), Access Collins (reservations), and other Access products.

---

## Corporate Structure (Post-Acquisition)

```mermaid
graph TD
    A["The Access Group<br/>(Hg + TA Associates PE-backed)"]
    B["Access Hospitality Division"]
    C["Omnifi<br/>(Order & Pay platform — sub-brand)"]
    D["Guestline (PMS)"]
    E["ResDiary (Table Management)"]
    F["Access Collins (Reservations)"]

    A --> B
    B --> C
    B --> D
    B --> E
    B --> F
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Omnifi — Key Milestones
    2017-2020 : Founded in London; mobile Order & Pay platform for UK hospitality (approx founding period)
    2021 : Acquired by The Access Group; integrated into Access Hospitality division
    2023 : Guestline acquired by Access (Omnifi + Guestline integration begins)
    2026 : Omnifi listed as active Access Hospitality brand — Order & Pay sub-product
```

---

## M&A Feasibility Assessment

### Is Omnifi an Acquisition Target for SolStein?

**Answer: No. Already fully integrated into Access Group; not a standalone entity.**

| Factor | Assessment |
|---|---|
| **Ownership** | Wholly owned by Access Group (Hg + TA Associates PE) |
| **Geography** | UK only |
| **Scale** | Sub-brand within £1.15B group — not separable |
| **Succession** | N/A — corporate product |
| **Exit pathway** | Would require Access Group divestiture — not applicable |

### Role for SolStein

1. **Product benchmark**: Mobile Order & Pay for hospitality — demonstrates the product category (QR-code ordering, table service, contactless payments) that is becoming table-stakes in UK and EU hospitality.
2. **Category signal**: NL/BE mobile ordering companies at founder-owned scale represent a potential SolStein opportunity.

---

*Sources: theaccessgroup.com/our-brands/omnifi, Access Group annual reports, theaccessgroup.com/blog.*
