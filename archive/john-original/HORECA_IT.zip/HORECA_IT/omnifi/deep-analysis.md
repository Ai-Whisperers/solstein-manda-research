# Omnifi — Deep Analysis

**Category**: Guest Order & Pay (Mobile Ordering / Digital F&B)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; acquired by Access Group 2021, fully integrated)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Omnifi | theaccessgroup.com/our-brands/omnifi | Confirmed |
| Parent company | The Access Group | theaccessgroup.com | Confirmed |
| HQ | London, UK (original); Loughborough (Access Group parent) | theaccessgroup.com | Estimated |
| Acquisition year | 2021 | theaccessgroup.com | Confirmed |
| Founders | Not publicly identified | — | Unknown |
| Current ownership | 100% The Access Group (Hg + TA Associates PE-backed) | theaccessgroup.com | Confirmed |
| Employees (standalone) | Not applicable (fully integrated) | — | Unknown |
| Revenue (standalone) | Not applicable (group revenue) | — | Unknown |
| Business model | Mobile Order & Pay SaaS for hospitality | theaccessgroup.com | Confirmed |
| Product | Web-based QR code Order & Pay app (no download required) | theaccessgroup.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Integrated into Access Hospitality's 20,000+ customer base | theaccessgroup.com | Estimated |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | Not a stated market | theaccessgroup.com | Estimated |
| HORECA verticals | Hotels, restaurants, pubs, leisure | theaccessgroup.com | Confirmed |
| Market position | One of many Order & Pay sub-products; not a standalone market leader | theaccessgroup.com | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | QR-code based mobile Order & Pay | theaccessgroup.com | Confirmed |
| No app download | Web-based; no native app required | theaccessgroup.com | Confirmed |
| Payment processing | Integrated contactless payment | theaccessgroup.com | Confirmed |
| Integration | Connected to Access Hospitality PMS, POS, reservations | theaccessgroup.com | Confirmed |
| Deployment | Cloud SaaS | theaccessgroup.com | Confirmed |
| Post-COVID relevance | Contactless ordering growth driver 2020–2023 | Industry context | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Current owner | The Access Group (PE-backed) | theaccessgroup.com | Confirmed |
| Standalone status | Not standalone; fully integrated product | theaccessgroup.com | Confirmed |
| Divestiture likelihood | Very low | Inferred | Estimated |
| Founder status | Unknown / irrelevant post-acquisition | — | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Integrated into Access Hospitality group — not separable | — | Unknown |
| Growth | Tied to Access Hospitality's overall growth (£64.7M→£118.8M FY23→FY24) | Access Annual Report | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK payment compliance | Contactless, PCI DSS compliant | theaccessgroup.com | Confirmed |
| VAT handling | UK VAT-compliant order/payment processing | theaccessgroup.com | Confirmed |
| Menu management | Digital menu with item customisation | theaccessgroup.com | Confirmed |
| Multi-venue | Multi-location support within Access Hospitality | theaccessgroup.com | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS + payment processing take-rate | theaccessgroup.com | Confirmed |
| Standalone ARR | Unknown / not applicable | — | Unknown |
| Acquisition price | Not disclosed | theaccessgroup.com | Unknown |
| SolStein fit | No — integrated into large PE group; UK only | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Owned by The Access Group (PE-backed); not separable | theaccessgroup.com |
| Revenue scale fit | High | 1 | Not a standalone entity; grouped into £118.8M division | Access Annual Report |
| Geographic fit | High | 1 | UK only | theaccessgroup.com |
| Tech stack modernity | Medium | 4 | Modern web-based Order & Pay; cloud-native | theaccessgroup.com |
| Customer lock-in | Medium | 3 | Moderate — QR ordering is increasingly commoditised | Industry context |
| Vertical depth | Medium | 3 | Order & Pay only; not full-stack | theaccessgroup.com |
| Integration potential | Low | 5 | Integrated with full Access Hospitality suite | theaccessgroup.com |
| Growth trajectory | Low | 3 | Tied to Access Hospitality growth; no standalone view | Access Annual Report |

### Composite Score

**Weighted Composite: 2.0 / 5.0**

**Confidence Band**: Low — product confirmed; standalone financials and history largely unknown.

### Overall M&A Assessment

Omnifi (UK) is **not an acquisition target** for SolStein. It is a sub-brand within The Access Group's hospitality suite. Its value is as a **product category reference** for mobile Order & Pay in hospitality. NL/BE standalone Order & Pay companies at founder-owned scale would be more relevant SolStein candidates.

**Important note**: The user's original description identified Omnifi as "Guest WiFi and marketing for hotels." Research confirms this is incorrect — Omnifi (UK, Access Group) is an Order & Pay platform. There is a separate US company (Omnifi, formerly Plumeria Networks, California) that provides WiFi/networking services — this is a different entity with no UK hospitality WiFi marketing connection.

### Recommended Next Step

No pursuit. Clarify internal records: Omnifi (UK) = Order & Pay (Access Group). Monitor NL/BE mobile ordering companies as potential SolStein targets.

---

*Sources: theaccessgroup.com/our-brands/omnifi, Access Group Annual Reports FY2024/FY2025.*
