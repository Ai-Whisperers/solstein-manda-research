# unTill — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Scope**: M&A due-diligence corporate history for unTill (NL/BE HORECA POS)

---

## 1. Legal Entity Data

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary legal entity (software developer) | unTill Software Development Group B.V. | [creditsafe.com](https://www.creditsafe.com/business-index/en-gb/company/untill-software-development-group-bv-nl04001431) | Confirmed |
| KvK number (developer entity) | 63559706 | [adhocdata.nl](https://www.adhocdata.nl/bedrijven/ADH00000EZECICE/Wemeldinge/unTill-Software-Development-Group-BV) | Confirmed |
| Incorporation date (NL entity) | 22 June 2015 | [creditsafe.com](https://www.creditsafe.com/business-index/en-gb/company/untill-software-development-group-bv-nl04001431) | Confirmed |
| Registered address | Korte Eeweg 11, 4424 NA Wemeldinge, Zeeland, NL | [untill.com/about-us](https://untill.com/about-us/) | Confirmed |
| Legal form | Besloten Vennootschap (B.V.) | [adhocdata.nl](https://www.adhocdata.nl/bedrijven/ADH00000EZECICE/Wemeldinge/unTill-Software-Development-Group-BV) | Confirmed |
| Dutch subsidiary for Air product | unTill Air B.V. | [kompass.com](https://lu.kompass.com/c/untill-air-b-v/nld1958725/) | Confirmed |
| Dutch reseller entity (Noord-Holland) | Adnamics B.V. (trade name: "unTill Nederland") | [untill.nl/disclaimer](https://untill.nl/disclaimer/) | Confirmed |
| KvK number (Adnamics B.V.) | 52894606 | [untill.nl/disclaimer](https://untill.nl/disclaimer/) | Confirmed |
| Adnamics holding entity | Adnamics Holding B.V. | [northdata.com](https://www.northdata.com/Adnamics%20Holding%20B%C2%B7V%C2%B7,%20Heemskerk/KVK%2090548957) | Confirmed |
| KvK number (Adnamics Holding) | 90548957 | [northdata.com](https://www.northdata.com/Adnamics%20Holding%20B%C2%B7V%C2%B7,%20Heemskerk/KVK%2090548957) | Confirmed |
| Adnamics address | De Trompet 1730, 1967 DB Heemskerk, NL | [northdata.com](https://www.northdata.com/Adnamics%20Holding%20B%C2%B7V%C2%B7,%20Heemskerk/KVK%2090548957) | Confirmed |
| Dutch reseller entity (Zeeland) | UPTA Horeca Automatisering | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| UPTA address | Korte Eeweg 11, 4424 NA Wemeldinge (same as developer) | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| Dutch reseller entity (Noord-Brabant) | Janssens Kassasystemen | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| Janssens address | Industrieweg 12R, 5753 PC Deurne, NL | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| Trade name / brand | unTill (stylised: unTill®) | [untill.com](https://untill.com/) | Confirmed |
| Belgian resellers count | 12 active resellers across Belgium | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |

---

## 2. Founding History & Origins

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Geographic origin of software | Belgium ("van origine Belgische softwareoplossing") | [untill.nl/over-untill](https://untill.nl/over-untill/) | Confirmed |
| Brand age claimed | "meer dan 30 jaar" (more than 30 years) — implies founded ~1993–1995 | [untill.nl/over-untill](https://untill.nl/over-untill/) | Estimated |
| Alternative brand age claim | "over 25 years" (used in English-language materials) | [untill.com/about-us](https://untill.com/about-us/) | Estimated |
| Best-estimate founding window | ~1993–2000, Belgian entity, precise year unknown | Triangulated from age claims | Estimated |
| Original Belgian entity name | Unknown — no KBO record found in public search | KBO search, no result | Unknown |
| Original founders | Unknown — not publicly named | Public records search | Unknown |
| When brand migrated to NL | Unknown; Dutch holding entity incorporated 2015 suggests formalised post-2015 | [creditsafe.com](https://www.creditsafe.com/business-index/en-gb/company/untill-software-development-group-bv-nl04001431) | Estimated |
| UPTA Horeca Automatisering founding | André Kortlever as general director since 2004 — implies NL operations pre-2004 | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Estimated |
| Current CEO / MD of software entity | Not publicly named | Public records search | Unknown |
| Key person — UPTA (Zeeland) | André Kortlever, general director since 2004; former Getronics | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| Key person — Adnamics (Noord-Holland) | Martin Limburg, general director since 2015 (from 2023 in current title) | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| Key person — Janssens (Noord-Brabant) | Jeroen van den Heuvel, commercial director since 2023; with Janssens since 2013 | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |

---

## 3. Ownership Structure

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| PE/VC investment in developer entity | None found | Crunchbase, Prospeo, news search | Estimated |
| External funding rounds | None found ("no funding" per Prospeo) | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Ownership type (developer entity) | Likely private/founder-owned but exact shareholders unknown | KvK extract not obtained | Unknown |
| Adnamics Holding structure | Holding company for Adnamics reseller activities; private | [northdata.com](https://www.northdata.com/Adnamics%20Holding%20B%C2%B7V%C2%B7,%20Heemskerk/KVK%2090548957) | Confirmed |
| Group cohesion | Software developer + 3 independent resellers; not a single consolidated group | [untill.com/resellers](https://untill.com/resellers/) | Estimated |
| UPTA–developer relationship | UPTA shares address with developer entity; likely very close (possibly same principals) | [untill.com/resellers](https://untill.com/resellers/) | Estimated |

---

## 4. M&A Events

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Acquisitions made by unTill | None found | News search, Crunchbase | Unknown |
| unTill acquired by third party | No evidence found | News search | Unknown |
| Investment rounds | No rounds found | Crunchbase, Prospeo | Estimated |
| Name changes / rebrands | None documented; "unTill" brand consistent throughout | Web search | Estimated |
| Joint ventures or partnerships | Reseller network only; no equity JVs found | Web search | Estimated |

---

## 5. Critical Events Timeline

| Year | Event | Source | Confidence |
|---|---|---|---|
| ~1993–2000 | unTill software founded in Belgium (estimated) | [untill.nl/over-untill](https://untill.nl/over-untill/) | Estimated |
| ~2004 | André Kortlever joins UPTA Horeca Automatisering (Wemeldinge) as general director | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| ~2013 | Jeroen van den Heuvel joins Janssens Kassasystemen | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| 22 Jun 2015 | unTill Software Development Group B.V. incorporated in Netherlands | [creditsafe.com](https://www.creditsafe.com/business-index/en-gb/company/untill-software-development-group-bv-nl04001431) | Confirmed |
| ~2015 | Martin Limburg joins Adnamics (Heemskerk), subsequently becomes general director | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| 2020–2021 | COVID-19 impact on HORECA sector; likely revenue disruption (not publicly quantified) | General knowledge | Estimated |
| 2023 | Jeroen van den Heuvel becomes commercial director at Janssens; Martin Limburg becomes general director at Adnamics | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| 2024 | unTill Air launched: cloud-native, mobile POS subscription product (€19/month entry) | [untillair.nl/over-ons](https://untillair.nl/over-ons/) | Confirmed |
| 2024 | unTill Payments launched: integrated payment processing for Prime and Air | [untill.com](https://untill.com/) | Confirmed |
| Jan 2026 | Present at Horecava 2026 (RAI Amsterdam) | [untill.nl/nieuws](https://untill.nl/nieuws/) | Confirmed |

---

## 6. Corporate Structure Diagram

```mermaid
graph TD
    A["unTill Software Development Group B.V.<br/>KvK 63559706<br/>Korte Eeweg 11, Wemeldinge<br/>(Software developer & IP owner)"]
    B["unTill Air B.V.<br/>Korte Eeweg 11, Wemeldinge<br/>(Air product entity)"]

    subgraph NL_Resellers["Netherlands Resellers (Independent)"]
        C["UPTA Horeca Automatisering<br/>Wemeldinge, Zeeland<br/>Dir: André Kortlever (since 2004)"]
        D["Adnamics Holding B.V.<br/>KvK 90548957 → Adnamics B.V. KvK 52894606<br/>Trade name: unTill Nederland<br/>Heemskerk, Noord-Holland<br/>Dir: Martin Limburg (since 2015)"]
        E["Janssens Kassasystemen<br/>Deurne, Noord-Brabant<br/>Dir: Jeroen van den Heuvel (since 2013)"]
    end

    subgraph BE_Resellers["Belgium Resellers (12 independent)"]
        F["Microvolt · BNCX · VDS Solutions<br/>XPOS · Kassa-Systemen.be · Rakedi<br/>Rubbens & Co · Sekuriet · CuComp<br/>BC-Matic · AlfaPOS · Active Office"]
    end

    subgraph INT_Resellers["International Resellers (15+ countries)"]
        G["Germany · France · Denmark<br/>Luxembourg · Spain · Poland<br/>Lithuania · Morocco · Aruba · etc."]
    end

    A -->|"Licenses unTill Prime software"| C
    A -->|"Licenses unTill Prime software"| D
    A -->|"Licenses unTill Prime software"| E
    A -->|"Licenses unTill Prime software"| F
    A -->|"Licenses unTill Prime software"| G
    A --> B
```

---

## 7. Brand / Entity Timeline

```mermaid
timeline
    title unTill Corporate Timeline (estimated)
    section Origins
        ~1993–2000 : Software founded in Belgium
                   : Belgian HORECA POS software
        ~2000–2004 : Netherlands operations begin
                   : UPTA Horeca Automatisering active
    section Establishment
        2004       : André Kortlever joins UPTA (Wemeldinge)
                   : Formal NL reseller network develops
        2013       : Janssens Kassasystemen joins network
        2015       : unTill Software Development Group B.V. incorporated (NL)
                   : Martin Limburg joins Adnamics
    section Growth
        2020–2021  : COVID-19 HORECA disruption
        2023       : Leadership titles formalised at resellers
        2024       : unTill Air launched (cloud SaaS entry product)
                   : unTill Payments launched
        2026       : Present at Horecava 2026; 8,000+ customers worldwide
```

---

## 8. M&A Feasibility Assessment

### What ownership history tells us about deal feasibility

**Structure is fragmented, not monolithic.** unTill operates as a software developer (unTill Software Development Group B.V.) that licenses its platform to an independent reseller network. Any acquisition must target the developer entity, not the resellers. The resellers are autonomous businesses and would not be bundled in a software acquisition.

**No PE overhang detected.** No external investment or PE involvement has been found in any public source. This is consistent with a bootstrapped, founder-operated software company, and strongly positive for deal feasibility under the SolStein thesis.

**Ownership opacity is the principal risk.** The founder(s) and current shareholders of unTill Software Development Group B.V. are not publicly named. The Belgian origin of the software and the 2015 Dutch incorporation date suggest a restructuring event occurred, possibly involving a transfer of IP from a Belgian entity to the Dutch holding. This requires KvK extract / UBO register verification before any approach.

**Shared address with UPTA** (Korte Eeweg 11, Wemeldinge) suggests André Kortlever or UPTA principals may have a controlling or founding role in the software developer entity. This is the most likely entry point for an M&A approach.

**Age of company = succession pressure.** If the founder is ~60+ (as is common in a 30-year-old bootstrapped software company), succession planning is likely a live conversation. This is a positive signal for M&A receptiveness.

**Revenue is distributed across the group.** Acquiring only the software developer entity captures the IP and royalty/license stream, but not the NL reseller revenue (which sits in Adnamics, UPTA, and Janssens). A full-stack acquisition would require negotiating with all three Dutch resellers plus the developer entity.

| Feasibility Factor | Assessment | Signal |
|---|---|---|
| No PE overhang | No funding found | Positive |
| Founder identifiable | Unknown — requires KvK UBO extract | Neutral (risk) |
| Succession gap signal | 30-year company, founder likely 50–65 | Positive |
| Deal complexity | Fragmented: developer + 3 NL resellers + 12 BE resellers | Negative |
| Negotiation entry point | UPTA / André Kortlever (shared address with developer) | Actionable |
| IP clarity | Developer entity holds software IP; resellers hold customer relationships | Requires verification |
