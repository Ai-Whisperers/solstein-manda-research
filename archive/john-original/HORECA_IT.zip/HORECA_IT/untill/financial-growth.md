# Financial & Growth Deep-Dive — unTill

**Research Date**: 2026-04-30
**Data Availability**: Low — unTill Software Development Group B.V. (KvK 63559706) is a Dutch private micro/small BV with no publicly accessible financial filings. All revenue figures are triangulated estimates. Third-party intelligence (Prospeo, RocketReach, ZoomInfo) provides inconsistent and likely ecosystem-level (not developer-entity-level) revenue estimates. Financial-filing verification via a paid KvK jaarrekening extract is required before any valuation work.

---

> **Structural note — read first**: unTill operates as a fragmented group comprising (1) unTill Software Development Group B.V. (the IP-holding developer entity, KvK 63559706), (2) unTill Air B.V. (the cloud Air product entity, same Wemeldinge address), and (3) three independent NL resellers (UPTA, Adnamics/unTill Nederland, Janssens) plus 12 BE resellers. Third-party revenue estimates conflate developer + reseller revenues. The figures below attempt to isolate the developer entity where possible; ecosystem-level estimates are labelled accordingly. Any SolStein acquisition scenario for the developer entity alone would capture IP and license/royalty revenue, not reseller revenues.

---

### Revenue Timeline

| Year | Revenue (Developer Entity) | Revenue (Ecosystem — incl. resellers) | Currency | EUR Equivalent (dev.) | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026 (est.) | €4.5M–€7.0M | €20M–€25M | EUR | €4.5M–€7.0M | +10–15% | Triangulated (see notes) | Estimated |
| 2025 | €4.0M–€6.5M | €18M–€22M | EUR | €4.0M–€6.5M | +10–20% | Triangulated | Estimated |
| 2024 | €3.5M–€5.5M | €16M–€20M | EUR | €3.5M–€5.5M | +10–20% | Triangulated (Air launch year) | Estimated |
| 2023 | €3.0M–€4.5M | €14M–€18M | EUR | €3.0M–€4.5M | +5–10% | Triangulated | Estimated |
| 2022 | €2.5M–€4.0M | €13M–€17M | EUR | €2.5M–€4.0M | +0–5% | Triangulated (post-COVID recovery) | Estimated |
| 2021 | €2.5M–€4.0M | €12M–€16M | EUR | €2.5M–€4.0M | — | Triangulated (COVID disruption prior year) | Estimated |

**Revenue CAGR (3yr, 2021–2024, midpoint)**: ~12% (Estimated; wide uncertainty band)
**Revenue CAGR (5yr, 2019–2024)**: Unknown — pre-2021 data not estimable

#### Revenue Triangulation Methodology

| Estimate Layer | Basis | Value | Notes |
| --- | --- | --- | --- |
| Prospeo ecosystem estimate | Third-party intelligence | $20M (~€18.5M) | Almost certainly includes reseller revenues; not developer-entity revenue |
| UPTA reseller revenue (one of 3 NL resellers) | RocketReach estimate | ~$4M (~€3.7M) | UPTA only; one reseller of three NL + 12 BE |
| Developer license royalty proxy | 8,000 venues × estimated €30–€50/month royalty to developer | €2.9M–€4.8M/yr | Developer charges resellers a per-venue/per-month license fee |
| Air subscription (direct) | ~500–2,000 Air subscribers × €27/month avg (incl. 15% annual discount) | €0.2M–€0.6M/yr | Very early-stage; Air launched 2024 |
| Developer entity ARR (conservative) | License royalties from ~3,500 NL venues × €40/month | ~€1.7M | Floor estimate |
| Developer entity ARR (optimistic) | License royalties from 8,000 venues globally × €50/month + Air subs | ~€5.0M–€10M | Ceiling estimate |

**Central working estimate for developer entity**: €3M–€6M ARR (mid-range used for all scoring and valuation work)

> Note: unTill Air B.V. is a separate legal entity from unTill Software Development Group B.V. (confirmed in corporate records). Air subscription revenues may flow through unTill Air B.V. rather than the main developer entity. An acquisition of the developer entity may therefore not capture Air ARR without also acquiring unTill Air B.V.

**Revenue CAGR (3yr)**: ~12% estimated (midpoint of range; uncertainty is high)
**Revenue CAGR (5yr)**: Unknown — insufficient data pre-2021

#### Revenue Trend Chart

```mermaid
xychart-beta
    title "unTill Developer Entity — Estimated Revenue (EUR M, midpoint)"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "EUR Millions" 0 --> 8
    line [3.25, 3.25, 3.75, 4.5, 5.25, 5.75]
```

> Chart values are midpoints of estimated ranges. Wide uncertainty band applies. Do not use for valuation without KvK filing verification.

---

### Profitability

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| EBITDA (current) | Unknown — no public filing | KvK (paid extract required) | Unknown |
| EBITDA Margin | Likely 20–40% (bootstrapped software dev. IP company; low capex) | Industry proxy for NL HORECA SaaS | Estimated |
| Net Profit / Loss | Unknown — no public filing | KvK (paid extract required) | Unknown |
| Recurring Revenue % | Est. 80–90%+ (license royalties = recurring; Air = subscription) | Product model analysis | Estimated |
| SaaS / Subscription Revenue % | ~10–20% direct SaaS (Air, launched 2024); ~80–90% licence royalty stream | Product model + launch date | Estimated |
| Revenue per Employee (developer entity) | €150K–€400K/employee at 15 employees midpoint × €3M–€6M ARR | Calculated | Estimated |

> Profitability signal: A 30-year bootstrapped software company with no external funding and a small (11–20 person) developer team in rural Zeeland has very low overhead. Profit margins are likely attractive if the revenue base is confirmed. However, the Prospeo "revenue per employee" figure ($1.82M/employee) is ecosystem-wide and artificially high; it should not be used for the developer entity alone.

---

### Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Never | Bootstrapped | None | None | N/A | Crunchbase (no rounds), Prospeo ("no funding"), absence of press | Estimated |

**Total Raised**: Bootstrapped — no external funding identified in any public source
**Latest Valuation**: Not applicable — private/bootstrapped; no disclosed valuation
**Current Investors**: Founder-owned (founder identity not publicly confirmed; requires KvK UBO extract)
**Prospeo Revenue Multiple Estimate**: ~$64M (~€59M) — based on $20M ecosystem revenue × ~3× multiple; likely inflated given developer-entity revenue is a fraction of ecosystem revenue
**Realistic Valuation Range (developer entity only)**:
- Conservative: €6M–€18M (3–4× conservative ARR of €2M–€4.5M)
- Mid-range: €18M–€36M (4–6× mid-range ARR of €3M–€6M)
**War Chest Signals**: None identified; bootstrapped company; balance sheet information not publicly available

---

### Employee Timeline

| Year | Headcount (Developer Entity) | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- |
| 2026 (current) | 15–20 | ~0–5% | ZoomInfo (11–50 band), LinkedIn company page | Estimated |
| 2025 | 13–18 | ~0–5% | Inferred from stable band reports | Estimated |
| 2024 | 12–17 | ~0–5% | ZoomInfo, Prospeo (11–20 band) | Estimated |
| 2023 | 11–16 | ~0–5% | Prospeo baseline estimate | Estimated |
| 2022 | 11–15 | ~flat | COVID recovery; no hiring signals found | Estimated |
| 2021 | 10–15 | — | Inferred from stable headcount across reports | Estimated |

**UPTA reseller headcount (proxy)**: 11–16 employees (RocketReach), 15 (LinkedIn); stable; separate from developer entity
**Adnamics reseller headcount**: Not publicly disclosed; estimated 5–15
**Janssens reseller headcount**: Not publicly disclosed; estimated 5–15

**Employee CAGR (3yr, developer entity)**: ~0–5% (Estimated — headcount appears stable, not scaling)
**Current Open Positions**: None identified in public job boards (Indeed NL, LinkedIn Jobs) as of research date; no active hiring signals found for developer entity
**Hiring Hotspots**: Wemeldinge (Zeeland); no multi-location hiring
**Key Recent Hires (C-level/VP)**: None identified — founder/leadership team not publicly named

#### Employee Growth Chart

```mermaid
xychart-beta
    title "unTill Developer Entity — Estimated Headcount (midpoint)"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "Headcount" 0 --> 25
    line [12, 13, 13, 14, 15, 17]
```

> Headcount stability at developer entity level is consistent with a mature, capital-efficient bootstrapped IP company. Air and Payments products may have been built with a small team or via reseller-side resources.

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| ~1993–2000 | Software founded | Belgium | Belgian HORECA POS origin; Belgian reseller network (12 active today) | [untill.nl/over-untill](https://untill.nl/over-untill/) | Estimated |
| ~2000–2004 | NL operations begin | Netherlands | UPTA Horeca Automatisering active in Zeeland | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Estimated |
| 2015 | NL legal entity incorporated | Netherlands | unTill Software Development Group B.V. incorporated in Wemeldinge | [creditsafe.com](https://www.creditsafe.com/business-index/en-ie/company/untill-software-development-group-bv-nl04001431) | Confirmed |
| Ongoing | International reseller expansion | 15+ countries | Germany (MS POS), France, Denmark, Luxembourg, Spain, Poland, Lithuania, Morocco, Aruba, Caribbean | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| 2024 | unTill Air UK launch | United Kingdom | [untillair.co.uk](https://untillair.co.uk/) — separate Air brand presence in UK | [untillair.co.uk](https://untillair.co.uk/) | Confirmed |
| Mar 2025 | INTERNORGA 2025, Hamburg | Germany | Showcased unTill Air, Prime, Payments via German reseller MS POS (Hall A3, stand 615) | [ms-pos.net](https://ms-pos.net/en/rueckblick-internorga-2025/) | Confirmed |
| Jan 2026 | Horecava 2026, Amsterdam | Netherlands | Active presence at Netherlands' primary HORECA trade fair | [untill.nl/nieuws](https://untill.nl/nieuws/) | Confirmed |

**Primary Market**: Netherlands (self-described "marktleider" / market leader in NL HORECA POS; 3,500+ NL venues)
**Secondary Market**: Belgium (12 active resellers; origin market; Belgian fiscal compliance supported)
**International Revenue %**: Not disclosed; international resellers active in 15+ countries but volume unknown; likely <20% of developer entity revenue
**Expansion Trajectory**: unTill has pursued a passive international expansion via its reseller network (no direct offices, no equity investments abroad). The 2024 Air UK launch and the INTERNORGA 2025 presence via MS POS signal intent to activate the DACH and UK markets with the Air product. Expansion is reseller-led and asset-light; geographic reach is wide but depth outside NL/BE is limited.

---

### M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| None found | — | — | — | — | Crunchbase, press search, corporate records | Unknown |

**Acquisitions**: None identified in any public source (2020–2026)
**Divestitures**: None identified
**Funding rounds / strategic investments**: None found
**Been acquired by**: No evidence of acquisition; developer entity appears independently operated
**M&A Pattern**: Purely organic; no M&A activity detected in 5-year search window. unTill's growth has been entirely via reseller-network expansion and product line extension (Air, Payments). The company has shown no inbound or outbound M&A signals.

---

### SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | Hybrid: unTill Prime = on-premises POS + cloud WebManagement portal; unTill Air = fully cloud-native SaaS | [untill.com](https://untill.com/) | Confirmed |
| Cloud Revenue % (current) | ~10–20% direct SaaS (Air subscriptions); ~80–90% via legacy license royalty model (Prime) | Triangulated from product mix and Air launch date (2024) | Estimated |
| Recurring Revenue % | Est. 85–95% (license royalties are recurring; Air is subscription; hardware is reseller-side) | Product model analysis | Estimated |
| Payment Integrations | iDEAL (via Adyen, CCV), Bancontact (via Payconiq, Adyen), Adyen, CCV, Worldline, Ingenico, Stripe, CM.com, Zapper, PinDirect, YabandPay | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| unTill Payments (own gateway) | Integrated payments via Adyen platform; NL + BE; launched 2024; sub-day onboarding | [untill.com/untill-payments](https://untill.com/untill-payments) | Confirmed |
| Platform Stack | PHP (backend), Microsoft ASP.NET (web framework), Nginx (web server), Umbraco (CMS), Bootstrap (UI) | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Air Stack | iOS + Android native app; cloud back-office (air.untill.com); Adyen payment processing | [untillair.com](https://untillair.com/), [help.payments.untill.com](https://help.payments.untill.com/overview/) | Confirmed |
| API / Integration Model | Open REST API; 125+ verified integrations (Exact Online, Mews, SevenRooms, Deliverect, Apicbase, Horeko, Growzer, Dyflexis and many others) | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Migration Status | In progress — Air launched 2024 as the cloud-native successor/companion product; Prime base continues; transition pace dependent on reseller uptake of Air | [untillair.nl/over-ons](https://untillair.nl/over-ons/) | Confirmed |
| Air Pricing | Basic €21.85/mo · Standard €33.85/mo · Hospitality Extra €44.85/mo (excl. VAT); 15% annual discount | [untillair.com/pricing](https://untillair.com/pricing/) | Confirmed |
| Air Platform Availability | Netherlands, Belgium (untillair.be), United Kingdom (untillair.co.uk); Germany via MS POS | [untillair.nl](https://untillair.nl/), [untillair.be](https://untillair.be/), [untillair.co.uk](https://untillair.co.uk/) | Confirmed |
| API Ecosystem Partners | Deliverect → Thuisbezorgd/Just Eat/Uber Eats; Jamezz; MynOber; EasyOrder; Woby; Eatcard; SevenRooms; Zenchef; GoTable; Guestplan; Mews; Apaleo; Guestline; RoomRaccoon; Exact Online; Twinfield; Yuki; Xero; Dyflexis; L1nda; Shiftbase; Apicbase; Horeko; Growzer | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |

**SaaS Maturity Assessment**: The 2024 dual launch of unTill Air (cloud-native subscription POS) and unTill Payments (embedded payment processing via Adyen) represents a significant strategic inflection point. unTill is clearly executing a hybrid-to-cloud transition: maintaining the installed Prime base while building Air as a cloud-native product for smaller venues and new-to-POS customers. The 125+ integrations via open API demonstrate a platform mindset. However, Air is in its earliest growth phase (launched 2024) and the legacy Prime base still dominates revenue. A full SaaS transition would require 3–5 more years given the reseller-mediated sales motion.

---

### Growth Scorecard

| Dimension | Score (1-10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | 3 | No filed financials; estimated CAGR ~5–15% (post-COVID recovery + Air launch 2024); wide uncertainty; 30-year mature base unlikely to generate rapid growth; falls in "modest" 5–10% bracket at best |
| Funding Momentum | 2 | Fully bootstrapped; zero external funding across 30+ years of operations; no VC, PE, or government grant signal found; self-funded product launches (Air, Payments) |
| Employee Growth | 2 | Stable 11–20 headcount at developer entity; no active hiring signals; no CAGR growth detected; small-town Zeeland location limits talent scaling |
| Geographic Expansion | 5 | Active in 15+ countries via reseller network; NL and BE primary (3,500+ NL venues; 12 BE resellers); UK Air launch 2024; DACH via MS POS (INTERNORGA 2025); expansion is reseller-led and broad but shallow |
| M&A Activity | 1 | Zero acquisitions, investments, or M&A events detected across entire history; purely organic builder; no platform-acquisition signals |
| SaaS Maturity | 5 | Hybrid model: Prime (on-prem + cloud WebManagement) + Air (cloud-native, 2024) + Payments (Adyen, 2024); 125+ open API integrations; iDEAL + Bancontact supported; Air early-stage; Prime dominant; migration "in progress" |
| **COMPOSITE SCORE** | **3.0** | **Steady — mature, bootstrapped, capital-efficient HORECA POS with a meaningful SaaS step function underway but no growth acceleration yet measurable** |

**Classification Thresholds**:

- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

**unTill Classification**: **Steady (3.0)** — at the lower boundary of "Steady." The company is a capital-efficient, 30-year HORECA POS incumbent with high recurring revenue and a clear product roadmap (Air, Payments). It is not stagnating (the 2024 launches are directionally positive), but it is not yet on an accelerating growth trajectory. From SolStein's M&A perspective, this is an ideal profile: a stable, cash-generative business where an acquirer can accelerate the SaaS transition and geographic expansion rather than inheriting a turnaround problem.

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "unTill Growth Scorecard (1–10)"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [3, 2, 2, 5, 1, 5]
```

---

### Data Gaps & Priority Research Actions

| Gap | Impact | Recommended Action |
| --- | --- | --- |
| No KvK filed financials confirmed | High — all revenue figures are estimated; valuation is speculative | Order jaarrekening for KvK 63559706 via kvk.nl; order UPTA (KvK 18162517) and Adnamics (KvK 52894606) filings as proxies |
| Founder / UBO identity unknown | High — deal feasibility and approach strategy depend on confirming who controls developer entity | Order KvK UBO extract for KvK 63559706; approach André Kortlever (UPTA, shared address) as entry point |
| unTill Air B.V. entity separation | High — if Air revenue flows through a separate BV, acquisition of developer entity alone misses Air ARR | Confirm unTill Air B.V. KvK number and ownership; check if it is a subsidiary of developer entity or a parallel entity |
| Employee count (developer entity) | Medium — proxy range 11–20; exact figure would sharpen revenue-per-employee and cost estimates | LinkedIn company page cross-check; pay for ZoomInfo enhanced profile |
| Air adoption / customer count | Medium — determines trajectory of the cloud SaaS transition and future ARR growth | Request demo; reseller contact (Janssens/UPTA Air Services, Deurne); check app store download ratings/review count |
| Reseller revenue (UPTA, Adnamics, Janssens) | Medium — full-stack acquisition scenario requires understanding reseller profitability | Order KvK jaarrekeningen for each of the three NL resellers |
| COVID-era revenue impact (2019–2021) | Low for current valuation, higher for CAGR calculation | Estimated; sector-wide ~30–40% HORECA revenue drop in 2020; no company-specific data likely retrievable |

---

### M&A Implications for SolStein

**Acquisition scenario — developer entity only (recommended starting point)**:
- Captures: IP (unTill Prime + Air software), license royalty stream, open API ecosystem, brand
- Does not capture: Customer relationships (held by resellers), installation base service revenue, UPTA/Adnamics/Janssens workforce
- Valuation range: €6M–€36M depending on confirmed ARR (conservative 3–4× to optimistic 6× ARR)
- Risk: Resellers could defect post-acquisition if fee terms change; customer lock-in is via reseller relationship, not direct

**Acquisition scenario — developer + NL resellers (full-stack)**:
- Captures all of the above plus direct customer relationships with 3,500+ NL venues
- Requires separate negotiation with 3 independent companies + potentially Belgian resellers
- Complexity: High; sequential deals or consortium negotiation required
- Value creation: Highest — enables SolStein to consolidate the full NL unTill ecosystem

**Key near-term action**: Confirm André Kortlever's role at the developer entity via KvK extract. If Kortlever is a director/shareholder of unTill Software Development Group B.V. (as suggested by shared address), a confidential approach via the Horecava 2026 network or mutual HORECA contact is feasible now.
