# unTill — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Scope**: Full M&A deep-analysis for unTill (NL/BE HORECA POS)

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity (developer) | unTill Software Development Group B.V. | [creditsafe.com](https://www.creditsafe.com/business-index/en-gb/company/untill-software-development-group-bv-nl04001431) | Confirmed |
| KvK number | 63559706 | [creditsafe.com](https://www.creditsafe.com/business-index/en-gb/company/untill-software-development-group-bv-nl04001431) | Confirmed |
| Headquarters | Korte Eeweg 11, 4424 NA Wemeldinge, Zeeland, NL | [untill.com/about-us](https://untill.com/about-us/) | Confirmed |
| Brand founded | ~1993–2000 (Belgian origin; "30+ years" per NL site) | [untill.nl/over-untill](https://untill.nl/over-untill/) | Estimated |
| NL legal entity incorporated | 22 June 2015 | [creditsafe.com](https://www.creditsafe.com/business-index/en-gb/company/untill-software-development-group-bv-nl04001431) | Confirmed |
| CEO / Managing Director | Not publicly named | Public records search | Unknown |
| Key operational person (UPTA) | André Kortlever, general director UPTA Horeca Automatisering, since 2004 | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| Key person (Adnamics / NL) | Martin Limburg, general director Adnamics, since 2015 | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| Key person (Janssens / NL) | Jeroen van den Heuvel, commercial director Janssens, since 2013 | [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) | Confirmed |
| Ownership type | Private; no PE/VC investment found | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Employees (developer entity) | 11–20 (Prospeo estimate) | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Revenue (developer entity) | $20M (~€18.5M) estimated annual — likely inflated; includes reseller revenues | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Revenue (developer entity) — conservative | Likely €2M–€6M ARR in software license/royalty stream only | Triangulated estimate | Estimated |
| Profitability | Unknown — no public filing found | Public records | Unknown |
| Last funding event | None found | Crunchbase, Prospeo | Estimated |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary markets | Netherlands, Belgium | [untill.nl/over-untill](https://untill.nl/over-untill/), [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| International markets | 15+ countries (Germany, France, Denmark, Luxembourg, Spain, Poland, Lithuania, Morocco, Caribbean) | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| Total customer count (worldwide) | 6,500–8,000 (different pages cite different numbers) | [untill.com](https://untill.com/) | Estimated |
| Customer count Netherlands | 3,500+ (per untill.nl homepage) | [untill.nl](https://untill.nl/) | Estimated |
| NL reseller network | 3 authorised dealers: UPTA (Zeeland), Adnamics (Noord-Holland), Janssens (Noord-Brabant) | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| BE reseller network | 12 authorised dealers across Belgium | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| Notable customers | Loetje (36-location Dutch restaurant chain; 10-year partnership) | [untill.nl](https://untill.nl/), [untill.com](https://untill.com/) | Confirmed |
| Other named customers | Wander Island, De Heeren van Aemstel, Kasteel Maurick, Fellini (Leeuwarden) | [untill.nl/nieuws](https://untill.nl/nieuws/) | Confirmed |
| Verticals served | Restaurant, café/bar, hotel, cafeteria/take-away, recreation, catering, retail, food truck, events | [untill.com](https://untill.com/) | Confirmed |
| Self-described position | "marktleider" (market leader) in NL HORECA POS | [untill.nl](https://untill.nl/) | Estimated |
| G2 / Capterra reviews | No significant profile found on G2 or Capterra | G2/Capterra search | Unknown |
| Awards | None found in public sources | Web search | Unknown |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Product 1 | **unTill Prime** — flagship HORECA POS, fully customisable, on-premises + cloud hybrid | [untill.com](https://untill.com/) | Confirmed |
| Product 2 | **unTill Air** — cloud-native, subscription POS app; launched 2024; iOS & Android | [untillair.nl/over-ons](https://untillair.nl/over-ons/) | Confirmed |
| Product 3 | **unTill Payments** — integrated payment processing for Prime and Air | [untill.com](https://untill.com/) | Confirmed |
| Product 4 | **unTill WebManagement** — cloud management portal for Prime; reports, pricing, team management | [untill.com](https://untill.com/) | Confirmed |
| Deployment model | Hybrid: Prime is on-site POS with cloud WebManagement; Air is fully cloud-native | [untill.com](https://untill.com/) | Confirmed |
| Tech stack (backend) | PHP | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Tech stack (web server) | Nginx | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Tech stack (CMS) | Umbraco | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Tech stack (web framework) | Microsoft ASP.NET | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Tech stack (UI) | Bootstrap | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| API | Open API supporting 125+ integrations ("open API's") | [untill.nl/over-untill](https://untill.nl/over-untill/) | Confirmed |
| Integration count | 125+ verified integrations listed | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Payment integrations | Adyen, CCV, Worldline, Ingenico, Payconiq, Stripe, CM.com, PinDirect, Zapper, YabandPay | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Bancontact support | Yes — via Payconiq and Adyen integrations (relevant for Belgium) | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| iDEAL support | Yes — via Adyen, CCV, and similar Dutch payment gateways | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Estimated |
| Delivery integrations | Deliverect (→ Thuisbezorgd, Just Eat), Jamezz, MynOber, EasyOrder, Woby, Eatcard | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Reservation integrations | SevenRooms, Zenchef, Guestplan, GoTable | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Accounting integrations | Exact Online, Twinfield, Yuki, Xero, Asperion | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Hotel PMS integrations | Mews, Oracle, Apaleo, Guestline, RoomRaccoon, Amadeus, Clock PMS+, Elina, SmartHOTEL | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Workforce integrations | Dyflexis, L1nda, Shiftbase, Eitje, Fooks, Strobbo | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Kitchen/inventory integrations | Apicbase, Horeko, Growzer, Nostradamus, Orbisk | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Mobile app | Yes — unTill Air on iOS and Android | [untill.com](https://untill.com/) | Confirmed |
| Hardware compatibility | HP, FEC, NCR, Posbank; Sunmi L3 handheld | [untill.nl/over-untill](https://untill.nl/over-untill/), [untill.nl/nieuws](https://untill.nl/nieuws/) | Confirmed |
| Hardware deployment model | Resellers supply and configure hardware; customer does not need to source separately | [untill.nl/over-untill](https://untill.nl/over-untill/) | Confirmed |
| Release cadence | Active; Air launched 2024; Payments launched 2024; regular blog/news updates | [untillair.nl/over-ons](https://untillair.nl/over-ons/) | Confirmed |
| GKS (Belgian black box) compliance | Supported via Belgian resellers (Rakedi, etc.) | [rakedi.com](https://rakedi.com/en/services/rakedipos/) | Confirmed |
| Belgian fiscal receipt compliance | Supported via certified Belgian resellers | [rakedi.com](https://rakedi.com/en/services/rakedipos/) | Confirmed |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned (developer entity) | Likely yes — no PE found, bootstrapped signals — but not confirmed | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| PE/VC involvement | None found | Crunchbase, Prospeo, news search | Estimated |
| Founder still active | Unknown — no named founder found | Public records | Unknown |
| Succession signals | No succession plan visible; 30-year-old company with no PE exit signals | Web search | Estimated |
| Founder age | Unknown — not publicly identified | Public records | Unknown |
| UPTA–developer link | UPTA shares address with developer entity; André Kortlever may have principal stake | [untill.com/resellers](https://untill.com/resellers/) | Estimated |
| Group structure type | Software developer + independent reseller network (not a vertically integrated group) | Multiple sources | Confirmed |
| Resellers are independent | Yes — UPTA, Adnamics, Janssens are separate legal entities | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| Acquisition of developer entity only | Would capture IP and license stream; reseller relationships would require separate negotiation | Analysis | Estimated |
| PE exit horizon | N/A — no PE found | n/a | Estimated |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue (estimated, total ecosystem) | $20M (~€18.5M) — Prospeo estimate, likely includes reseller revenues | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Revenue (developer entity only) | Likely €2M–€6M ARR (software license/royalty stream) — conservative estimate | Triangulated | Estimated |
| Revenue per employee | $1.82M per employee (Prospeo estimate) — inflated if revenues include resellers | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Estimated valuation | $64M (~€59M) per Prospeo — based on revenue multiple | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Employee count (developer) | 11–20 | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| YoY revenue growth | Unknown — no public financials | Public records | Unknown |
| Customer growth | 3,500+ NL; growing international; Air launched 2024 to open entry-level market | [untill.nl](https://untill.nl/), [untillair.nl/over-ons](https://untillair.nl/over-ons/) | Estimated |
| Geographic expansion | Active in 15+ countries; international reseller network | [untill.com/resellers](https://untill.com/resellers/) | Confirmed |
| New product launches | unTill Air (2024), unTill Payments (2024) — significant product line expansion | [untillair.nl/over-ons](https://untillair.nl/over-ons/) | Confirmed |
| Churn signals | None found; Loetje 10-year partnership cited as key case study | [untill.com](https://untill.com/) | Estimated |
| COVID-19 impact | Likely revenue disruption 2020–2021 (HORECA sector wide); no specific data | General sector data | Estimated |
| Trade fair presence | Horecava (Amsterdam), Gastvrij Rotterdam — annual | [untillair.nl/over-ons](https://untillair.nl/over-ons/), [untill.nl/nieuws](https://untill.nl/nieuws/) | Confirmed |

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary vertical | Restaurant & bar (café, brasserie, strandpaviljoen, nachtclub) | [untill.nl](https://untill.nl/) | Confirmed |
| Secondary verticals | Hotel, cafeteria/take-away, recreation/leisure, catering, events | [untill.com](https://untill.com/) | Confirmed |
| Retail (non-HORECA) | Supported via unTill Air (retail, beauty, kiosk, market stall) | [untill.com](https://untill.com/) | Confirmed |
| GDPR / AVG compliance | Expected (Dutch software company); no explicit certification found | Implied by NL operations | Estimated |
| Allergen compliance | Not explicitly advertised; available via linked F&B management tools (Apicbase, Growzer) | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Estimated |
| Belgian fiscal receipt / black box | GKS (Geregistreerd Kassasysteem) supported via Belgian resellers | [rakedi.com](https://rakedi.com/en/services/rakedipos/) | Confirmed |
| Dutch cash register legislation | Compliant; no specific TSE requirement in NL as of 2026 | Web search | Estimated |
| Payment method breadth | Adyen, CCV, Worldline, Payconiq (Bancontact), iDEAL-capable providers | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Delivery platform connectivity | Deliverect integration → Thuisbezorgd, Just Eat, Uber Eats | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Reservation platform connectivity | SevenRooms, Zenchef, GoTable, Guestplan | [untill.com/untill-integrations](https://untill.com/untill-integrations/) | Confirmed |
| Multi-location support | Yes — WebManagement explicitly supports multiple locations | [untill.com](https://untill.com/) | Confirmed |
| Table management | Yes — table plan configurable via WebManagement | [untill.com](https://untill.com/) | Confirmed |
| Kitchen screen / KDS | Yes — integrated kitchen and bar screens | [untill.com](https://untill.com/) | Confirmed |
| Handheld ordering | Yes — wireless ordering and payment via handheld (Sunmi L3 certified) | [untill.nl/nieuws](https://untill.nl/nieuws/) | Confirmed |
| Staff onboarding time | "Operational within fifteen minutes" per website | [untill.com](https://untill.com/) | Estimated |
| System live time from contract | ~6 weeks from first contact | [untill.nl/over-untill](https://untill.nl/over-untill/) | Confirmed |

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | License fees / royalties from resellers + direct software subscriptions (Air) | Analysis | Estimated |
| unTill Air pricing — Basic | €21.85/month per screen (excl. VAT) | [untillair.com/pricing](https://untillair.com/pricing/) | Confirmed |
| unTill Air pricing — Standard | €33.85/month per screen (excl. VAT) | [untillair.com/pricing](https://untillair.com/pricing/) | Confirmed |
| unTill Air pricing — Hospitality Extra | €44.85/month per screen (excl. VAT) | [untillair.com/pricing](https://untillair.com/pricing/) | Confirmed |
| unTill Air annual billing discount | 15% discount for annual commitment | [untillair.com/pricing](https://untillair.com/pricing/) | Confirmed |
| unTill Prime pricing | Custom quote; estimated €69–€149/month per location | [bedrijfssoftwaregids.nl](https://bedrijfssoftwaregids.nl/categories/kassasystemen/) | Estimated |
| unTill Payments | Per-transaction fee model; no hidden fees per website | [untill.com](https://untill.com/) | Confirmed |
| Estimated ARR (developer entity — conservative) | €2M–€6M (license royalties on ~3,500 NL venues at ~€50–€100/month average fee to developer) | Triangulated estimate | Estimated |
| Estimated ARR (developer entity — optimistic) | Up to €10M if including Air subscriptions globally + international license flow | Triangulated estimate | Estimated |
| Estimated valuation — conservative | €6M–€18M (3–4× conservative ARR at SaaS comps for SME HORECA software) | Comparable transactions | Estimated |
| Estimated valuation — mid-range | €18M–€36M (3–6× mid-range ARR) | Comparable transactions | Estimated |
| Estimated valuation (Prospeo) | ~$64M (~€59M) — likely overestimated; based on conflated revenue | [prospeo.io](https://prospeo.io/c/untill-hq-revenue) | Estimated |
| Revenue multiple (comparable SaaS) | 3–8× ARR for profitable, bootstrapped HORECA SaaS at €2M–€15M ARR | Industry benchmarks | Estimated |
| Note on fragmentation | Reseller revenues not consolidated into developer entity — acquisition of developer entity alone is a partial capture | Analysis | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | 3 | No PE overhang found (positive), but founders unidentified and corporate structure fragmented across developer + 3 NL resellers + 12 BE resellers — deal structure complexity is significant | [prospeo.io](https://prospeo.io/c/untill-hq-revenue); [untill.com/resellers](https://untill.com/resellers/) |
| **Revenue scale fit** | High | 3 | Developer entity ARR estimated at €2M–€10M — likely within SolStein's €1M–€15M target range, but estimates are wide and unverified by financial filing | [prospeo.io](https://prospeo.io/c/untill-hq-revenue); triangulated pricing analysis |
| **Geographic fit** | High | 5 | Headquartered NL (Wemeldinge); 3 NL resellers; 12 BE resellers; self-described NL market leader; Benelux is the clear primary market | [untill.nl](https://untill.nl/); [untill.com/resellers](https://untill.com/resellers/) |
| **Tech stack modernity** | Medium | 3 | PHP/ASP.NET backend is legacy, but unTill Air (2024) is cloud-native; WebManagement is cloud-based; 125+ REST API integrations; migration path exists | [prospeo.io](https://prospeo.io/c/untill-hq-revenue); [untill.com](https://untill.com/) |
| **Customer lock-in** | Medium | 4 | 125+ deep integrations create high switching costs; 10-year partnership with Loetje cited; resellers provide 24/7 support creating local dependency; "within 6 weeks live" reduces churn friction | [untill.nl/over-untill](https://untill.nl/over-untill/); [untill.com](https://untill.com/) |
| **Vertical depth** | Medium | 5 | 30+ years of HORECA-only focus; Belgian origin; full vertical coverage (restaurant, hotel, bar, cafeteria, recreation, catering, events); staff self-described as "horecamensen" | [untill.nl/over-untill](https://untill.nl/over-untill/); [kassasystemen.nl](https://kassasystemen.nl/maak-kennis-met-de-mensen-van-untill/) |
| **Integration potential** | Low | 5 | 125+ existing integrations via open API; Exact Online, Mews, SevenRooms, Deliverect, Apicbase all confirmed; highly open architecture | [untill.com/untill-integrations](https://untill.com/untill-integrations/) |
| **Growth trajectory** | Low | 4 | unTill Air launched 2024 opens large entry-level market; Payments added 2024; international resellers in 15+ countries; Horecava 2026 presence; 8,000+ customers and growing | [untillair.nl/over-ons](https://untillair.nl/over-ons/); [untill.com](https://untill.com/) |

### Weighted Score Calculation

| Dimension | Weight | Score | Weighted |
|---|---|---|---|
| Ownership attractiveness | 3 | 3 | 9 |
| Revenue scale fit | 3 | 3 | 9 |
| Geographic fit | 3 | 5 | 15 |
| Tech stack modernity | 2 | 3 | 6 |
| Customer lock-in | 2 | 4 | 8 |
| Vertical depth | 2 | 5 | 10 |
| Integration potential | 1 | 5 | 5 |
| Growth trajectory | 1 | 4 | 4 |
| **Total** | **17** | | **66** |

**Composite Score**: 66 / 85 = **3.9 / 5.0**

---

### Confidence Band: **Wide**

Approximately 40% of data points are Confirmed (primary source). The remaining 60% are Estimated (secondary source) or Unknown. Key unknowns — founder identity, true developer ARR, profitability, ownership percentage — all materially affect deal feasibility and valuation. Financial filing verification is required before advancing.

---

### Overall M&A Assessment

unTill is a compelling HORECA POS software company with a 30+ year track record, strong Benelux market position, no PE overhang, and deep HORECA vertical expertise — all closely aligned with the SolStein M&A thesis. The 2024 launch of unTill Air and unTill Payments signals an active management team pursuing growth, which could indicate either an opportune pre-exit moment or a company not yet ready to sell. The principal risk is structural: unTill operates as a fragmented ecosystem of an IP-holding developer entity plus multiple independent resellers, not a single acquirable unit. An acquisition of the developer entity alone captures the IP and license revenue but not the customer-facing relationships embedded in the reseller network. Any deal requires separate negotiation with the three Dutch resellers (UPTA, Adnamics, Janssens) and possibly the 12 Belgian resellers.

---

### Recommended Next Step

**Approach UPTA / André Kortlever.** UPTA Horeca Automatisering shares its registered address with unTill Software Development Group B.V. at Korte Eeweg 11, Wemeldinge. André Kortlever has been general director since 2004 and is the most likely principal or co-principal of the developer entity. A confidential exploratory conversation via a warm introduction (e.g., through the Horecava trade fair network or a mutual HORECA sector contact) is the recommended first step. Simultaneously obtain the KvK UBO (Ultimate Beneficial Owner) extract for unTill Software Development Group B.V. (KvK 63559706) to confirm shareholders before any approach.
