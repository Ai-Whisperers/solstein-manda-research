# Untill

**Category**: POS/Restaurant
**Country**: NL
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history Untill @HORECA_IT/untill/
@research-horeca-company Untill @HORECA_IT/untill/
```
