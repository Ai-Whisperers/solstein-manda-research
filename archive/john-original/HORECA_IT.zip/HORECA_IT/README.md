# HORECA IT — M&A Target Landscape

## Purpose

Map and evaluate HORECA IT software companies in the Benelux market as potential acquisition,
combination, or restructuring targets for SolStein.

**Focus market**: Netherlands (primary), Belgium (primary), Germany and UK (reference/watch)
**Last Updated**: 2026-04-30

---

## SolStein M&A Thesis

SolStein targets founder-owned, bootstrapped or lightly funded HORECA IT companies that:

| Criterion | Target Profile |
|---|---|
| **Ownership** | Founder-owned or family-owned; no PE overhang or distressed PE |
| **Revenue scale** | €1M–€15M ARR; profitable or near-profitable |
| **Geography** | NL and/or BE primary market; Benelux customer base |
| **Vertical depth** | Niche specialization (POS, reservations, kitchen, workforce, PMS) |
| **Tech stack** | Cloud-native or actively migrating; modern web stack preferred |
| **Succession signal** | Founder approaching retirement, no obvious succession plan |
| **Customer lock-in** | Multi-year contracts, deep integrations, high switching costs |

---

## M&A Attractiveness Scorecard — Dimensions

Every `deep-analysis.md` closes with a scored attractiveness summary. Dimensions and weights:

| # | Dimension | Weight | What to Assess |
|---|---|---|---|
| 1 | **Ownership attractiveness** | High | Founder-owned? No PE? Succession gap? |
| 2 | **Revenue scale fit** | High | €1M–€15M ARR? Profitable? |
| 3 | **Geographic fit** | High | NL/BE primary market? Benelux customer base? |
| 4 | **Tech stack modernity** | Medium | Cloud-native? Active SaaS migration? Modern stack? |
| 5 | **Customer lock-in** | Medium | Long contracts? Deep integrations? Low churn signals? |
| 6 | **Vertical depth** | Medium | Clear niche? Defensible position? |
| 7 | **Integration potential** | Low | REST API? Open architecture? Modular? |
| 8 | **Growth trajectory** | Low | Headcount growth? New customers? Market expansion? |

**Scoring**: 1 (poor fit) → 5 (excellent fit). Composite = weighted average.
**Confidence band**: Fraction of data points that are Confirmed (vs Estimated/Unknown) narrows or widens the band.
**Every score must cite a specific source** — no score without a reference.

---

## Company Tier Classification

### Tier 1 — Primary NL/BE Acquisition Targets

High-fit companies in NL/BE with strong M&A attractiveness signals.

| Company | Category | Country | Composite Score | Research Status |
|---|---|---|---|---|
| TableFever | Reservations | BE | 4.3 / 5.0 | Done 2026-04-30 |

### Tier 2 — Secondary / Watch List

Potentially attractive but with blockers (PE-owned, too large, wrong geography, or insufficient data).

| Company | Category | Country | Blocker | Research Status |
|---|---|---|---|---|
| Zenchef | Restaurant Management / Reservations | FR (NL/BE ops) | PE-backed (PSG Equity); est. €25M–€43M ARR; 500+ employees; 20-country operator | Done 2026-04-30 |
| Tablebooker | Reservations | BE | Acquired by Zenchef (PSG Equity) Feb 2024; API deprecated; migrating to ZenchefOS; not independently acquirable | Done 2026-04-30 |

### Tier 3 — Reference / Landscape

Landscape players included for market context and valuation benchmarking. Not acquisition targets.

| Company | Category | Country | Blocker | Research Status |
|---|---|---|---|---|
| Deliverect | Order Aggregation / SaaS | BE (global) | Unicorn ($1.4B val); $332M VC-backed; ~€34–45M ARR — 100× too large | Done 2026-04-30 |
| Epos Now | POS/Restaurant | UK | Founder-owned at £113M ARR; exploring PE stake at $1.5B; far too large | Done 2026-04-30 |
| Zonal | Restaurant POS | UK | Acquired by Volaris/Constellation Software Feb 2026; 700+ employees | Done 2026-04-30 |
| Access Hospitality | PMS/Restaurant | UK | PE-backed (Hg + TA Associates); £118.8M hospitality revenue; active acquirer | Done 2026-04-30 |
| Fourth | Workforce/F&B | UK+US | PE-backed (Marlin Equity + Insight Partners); US/UK dual HQ | Done 2026-04-30 |
| Tenzo | Analytics | UK | VC-backed; UK/US focused; no NL/BE strategy | Done 2026-04-30 |
| Kafoodle | Menu/Allergens | UK | Acquired by 365 Retail Markets (USA) Apr 2023 | Done 2026-04-30 |
| Omnifi | Order & Pay | UK | Acquired by Access Group 2021; fully integrated (note: Order&Pay, not WiFi) | Done 2026-04-30 |
| Revel Systems | POS System | US/UK | Acquired by Shift4 Payments Mar 2024; US HQ; UK sales office only | Done 2026-04-30 |
| Slerp | Online Ordering | UK | VC-backed (Eight Roads Ventures); UK-only | Done 2026-04-30 |
| Beambox | Guest WiFi | UK | Bootstrapped; M&A offer Apr 2025; sub-£1M ARR; Bristol (not London) | Done 2026-04-30 |
| Triometric | Analytics | UK | B2B travel distribution analytics only; not direct HORECA ops | Done 2026-04-30 |
| KitchenCut | Kitchen/F&B Ops | UK | Bootstrapped; strong profile; UK (Oxfordshire) only | Done 2026-04-30 |
| Guestline | Hotel PMS | UK | Acquired by Access Group Jul 2023 (from Riverside PE); 2,900+ venues | Done 2026-04-30 |
| eviivo | Hotel PMS | UK | Investcorp Technology Partners backed (Dec 2022); 30,000+ properties | Done 2026-04-30 |
| RotaGeek | Workforce | UK | Acquired by ELMO Group (Breathe HR) Jun 2025 | Done 2026-04-30 |
| TiPJAR | Gratuities | UK | VC-backed; UK tipping law compliance product; no NL/BE equivalent | Done 2026-04-30 |
| Lighthouse | Revenue/Data | UK/Belgium | KKR-backed $494M raised; formerly OTA Insight; 70,000+ properties | Done 2026-04-30 |
| SiteMinder | Hotel Distribution | AU/UK | ASX-listed (SDR); A$224M FY2025 revenue; global scale | Done 2026-04-30 |
| SevenRooms | Reservations/CRM | US/UK | Acquired by DoorDash May 2025 for $1.2B; US HQ | Done 2026-04-30 |

> Tiers will be assigned after deep-analysis is complete for each company.

---

## Research Status

### Netherlands

| Company | Category | Slug | Corporate History | Deep Analysis | Financial Growth |
|---|---|---|---|---|---|
| Lightspeed Hospitality | POS/Restaurant | lightspeed-hospitality | Done 2026-04-30 | Done 2026-04-30 | — |
| OrderYoyo | Online Ordering | orderyoyo | Done 2026-04-30 | Done 2026-04-30 | — |
| Resengo | Reservations | resengo | Done 2026-04-30 | Done 2026-04-30 | — |
| MaaS (Meals as a Service) | Online Ordering | maas-meals-as-a-service | Done 2026-04-30 | Done 2026-04-30 | — |
| Horecavita | Restaurant POS | horecavita | Done 2026-04-30 | Done 2026-04-30 | — |
| Misterbook | Hotel PMS | misterbook | Done 2026-04-30 | Done 2026-04-30 | — |
| GuestU | Guest Engagement | guestu | Done 2026-04-30 | Done 2026-04-30 | — |
| Kashower | POS/Horeca | kashower | Done 2026-04-30 | Done 2026-04-30 | — |
| Foodcase | Inventory | foodcase | Done 2026-04-30 | Done 2026-04-30 | — |
| Planax | Workforce | planax | Done 2026-04-30 | Done 2026-04-30 | — |
| Cures Werkt | Workforce | cures-werkt | Done 2026-04-30 | Done 2026-04-30 | — |
| Juniper | Hotel PMS | juniper | Done 2026-04-30 | Done 2026-04-30 | — |
| Horeca Solutions | Restaurant POS | horeca-solutions | Done 2026-04-30 | Done 2026-04-30 | — |
| Qompanion | Restaurant POS | qompanion | Done 2026-04-30 | Done 2026-04-30 | — |
| Untill | POS/Restaurant | untill | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |
| Booking Experts | Vacation Rental/PMS | booking-experts | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |
| Horeko | Kitchen/F&B | horeko | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |
| Valk Solutions | Hotel PMS | valk-solutions | Done 2026-04-30 | Done 2026-04-30 | — |
| Mews Systems | Hotel PMS | mews-systems | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |
| Formitable | Reservations | formitable | Done 2026-04-30 | Done 2026-04-30 | N/A (off-market) |

### Belgium

| Company | Category | Slug | Corporate History | Deep Analysis | Financial Growth |
|---|---|---|---|---|---|
| Apicbase | Kitchen/F&B | apicbase | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |
| Abcouse | Restaurant Software | abcouse | Done 2026-04-30 | Done 2026-04-30 | — |
| GastroHero | Restaurant POS | gastrohero | Done 2026-04-30 | Done 2026-04-30 | — |
| iPunt | Restaurant POS | ipunt | Done 2026-04-30 | Done 2026-04-30 | — |
| Bionext | Horeca Software | bionext | Done 2026-04-30 | Done 2026-04-30 | — |
| OrderGrid | B2B Ordering | ordergrid | Done 2026-04-30 | Done 2026-04-30 | — |
| Wavem | Restaurant Software | wavem | Done 2026-04-30 | Done 2026-04-30 | — |
| Deliverect | Online Ordering | deliverect | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |
| Tablebooker | Reservations | tablebooker | Done 2026-04-30 | Done 2026-04-30 | N/A (acquired by Zenchef 2024) |
| Cubilis | Hotel PMS/Channel | cubilis | Done 2026-04-30 | Done 2026-04-30 | — |
| Zenchef | Restaurant Management | zenchef | Done 2026-04-30 | Done 2026-04-30 | — |
| HiJiffy | Guest Engagement | hijify | Done 2026-04-30 | Done 2026-04-30 | — |
| BePOS | Restaurant POS | bepos | Done 2026-04-30 | Done 2026-04-30 | — |
| TableFever | Reservations | tablefever | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |

### Germany (Reference)

| Company | Category | Slug | Corporate History | Deep Analysis | Financial Growth |
|---|---|---|---|---|---|
| Garmondo (orderbird) | Restaurant POS | orderbird | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Gastrofix | POS/Restaurant | gastrofix | Done 2026-04-30 | Done 2026-04-30 | N/A |
| kassensysteme.de | POS System | kassensysteme-de | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Sonnen PC | POS System | sonnen-pc | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Reservix | Ticketing/Events | reservix | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Siveco | Hotel PMS | siveco | Done 2026-04-30 | Done 2026-04-30 | N/A |
| HotelPARTNER | Hotel PMS | hotelpartner | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Aareon | Gastronomy | aareon | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Orderbird | POS System | orderbird-sumupp | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Systor | Hospitality IT | systor | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Fabella | Restaurant Software | fabella | Done 2026-04-30 | Done 2026-04-30 | N/A |
| GASTROpoint | POS System | gastropoint | Done 2026-04-30 | Done 2026-04-30 | N/A |
| myRES | Reservations | myres | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Apfelroute | Restaurant Software | apfelroute | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Schnell ein Tisch | Reservations | schnell-ein-tisch | Done 2026-04-30 | Done 2026-04-30 | N/A |
| PAUL (IndustryArena) | Restaurant | paul-industryarena | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Gastroglück | Restaurant Software | gastroglueck | Done 2026-04-30 | Done 2026-04-30 | N/A |
| FoodNotify | Feedback | foodnotify | Done 2026-04-30 | Done 2026-04-30 | N/A |
| BrewUp | Brewery Software | brewup | Done 2026-04-30 | Done 2026-04-30 | N/A |
| Kassensysteme TSE | POS System | kassensysteme-tse | Done 2026-04-30 | Done 2026-04-30 | N/A |

### United Kingdom (Reference)

| Company | Category | Slug | Corporate History | Deep Analysis | Financial Growth |
|---|---|---|---|---|---|
| Epos Now | POS/Restaurant | epos-now | Done 2026-04-30 | Done 2026-04-30 | — |
| Zonal | Restaurant POS | zonal | Done 2026-04-30 | Done 2026-04-30 | — |
| Access Hospitality | PMS/Restaurant | access-hospitality | Done 2026-04-30 | Done 2026-04-30 | — |
| Fourth | Workforce/F&B | fourth | Done 2026-04-30 | Done 2026-04-30 | — |
| Tenzo | Analytics | tenzo | Done 2026-04-30 | Done 2026-04-30 | — |
| Kafoodle | Menu/Allergens | kafoodle | Done 2026-04-30 | Done 2026-04-30 | — |
| Omnifi | Guest WiFi/Order&Pay | omnifi | Done 2026-04-30 | Done 2026-04-30 | — |
| Revel Systems | POS System | revel-systems | Done 2026-04-30 | Done 2026-04-30 | — |
| Slerp | Online Ordering | slerp | Done 2026-04-30 | Done 2026-04-30 | — |
| Beambox | Guest WiFi | beambox | Done 2026-04-30 | Done 2026-04-30 | — |
| Triometric | Analytics | triometric | Done 2026-04-30 | Done 2026-04-30 | — |
| KitchenCut | Kitchen | kitchencut | Done 2026-04-30 | Done 2026-04-30 | Done 2026-04-30 |
| Guestline | Hotel PMS | guestline | Done 2026-04-30 | Done 2026-04-30 | — |
| eviivo | Hotel PMS | eviivo | Done 2026-04-30 | Done 2026-04-30 | — |
| RotaGeek | Workforce | rotageek | Done 2026-04-30 | Done 2026-04-30 | — |
| TiPJAR | Gratuities | tipjar | Done 2026-04-30 | Done 2026-04-30 | — |
| Lighthouse | Revenue/Data | lighthouse | Done 2026-04-30 | Done 2026-04-30 | — |
| SiteMinder | Hotel PMS/Distribution | siteminder | Done 2026-04-30 | Done 2026-04-30 | — |
| SevenRooms | Reservations/CRM | sevenrooms | Done 2026-04-30 | Done 2026-04-30 | — |

---

## Research Prompts

Run these prompts against each company folder:

```
@research-horeca-company [Company Name] @HORECA_IT/[slug]/
@research-horeca-company-history [Company Name] @HORECA_IT/[slug]/
```

Both prompts live in `.cursor/prompts/analysis/market/`.

---

## Source Conventions

All research files use the following conventions consistently:

| Confidence Level | Criteria |
|---|---|
| **Confirmed** | Primary source: trade register (KBO/KvK), official filing, company website statement |
| **Estimated** | Credible secondary source: LinkedIn, Crunchbase, news article, analyst estimate |
| **Unknown** | No reliable source found — marked explicitly, never guessed |

Every scored dimension in the M&A Attractiveness Scorecard must link to at least one Confirmed or Estimated source. Unknown data points reduce the scorecard's confidence band.
