# Gastrofix GmbH — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Acquired by Lightspeed (Jan 2020) — NOT an available M&A target

---

## Executive Summary

Gastrofix GmbH was a Berlin-based cloud POS software company specializing in the hospitality industry. Founded in 2011/2012 by Reinhard Martens, Gastrofix grew to serve 8,000+ customer locations across Germany, Austria, and Norway before being acquired by Lightspeed POS Inc. (TSX: LSPD) in January 2020 for approximately US$61 million in cash plus 1,437,930 Lightspeed shares (total consideration up to ~US$125M including earn-outs). Post-acquisition, Gastrofix was rebranded as Lightspeed POS Germany GmbH, and its technology was integrated into the Lightspeed Restaurant G-Series platform.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | Gastrofix GmbH | Lightspeed press release; Taylor Wessing advisory note | Confirmed |
| Post-acquisition name | Lightspeed POS Germany GmbH | SEC annual information form 2021 | Confirmed |
| Legal form | GmbH (Gesellschaft mit beschränkter Haftung) | Public records | Confirmed |
| Registered address | Berlin, Germany (HQ); additional office in Hamburg | Clipperton deal note; Tracxn | Confirmed |
| Country | Germany | Multiple sources | Confirmed |
| Primary activity | Cloud-based hospitality POS software (iPad-based) | Lightspeed press release | Confirmed |
| Handelsregister number | Not retrieved | No public source found | Unknown |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | 2011 (Tracxn) / 2012 (Clipperton) | Tracxn; Clipperton | Estimated |
| Best estimate | 2011–2012 | Multiple sources | Estimated |
| Founder / CEO | Reinhard Martens | Lightspeed press release (Jan 2020) | Confirmed |
| Focus | iPad-based cloud POS for restaurants, bars, cafés, hotels | Lightspeed press release | Confirmed |
| Markets at acquisition | Germany, Austria, Norway | Lightspeed press release; Clipperton | Confirmed |
| Customers at acquisition | 8,000+ customer locations | Lightspeed press release; Clipperton | Confirmed |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pre-acquisition ownership | Founder-led; investor details not fully public | Clipperton (advises suggests VC backing) | Estimated |
| External funding | Not confirmed in public records; may have been bootstrapped or early VC | Tracxn | Unknown |
| Acquisition by Lightspeed | January 7, 2020 (announcement) | Lightspeed press release; PR Newswire | Confirmed |
| Acquirer | Lightspeed POS Inc. (TSX: LSPD) | Lightspeed press release | Confirmed |
| Acquisition base price | ~US$61 million cash | Lightspeed press release | Confirmed |
| Additional equity consideration | 1,437,930 Lightspeed subordinate voting shares | Lightspeed press release | Confirmed |
| Earn-out mechanism | Up to additional consideration tied to German market revenue targets through 2022 | Lightspeed press release; Clipperton | Confirmed |
| Total deal value (incl. earn-outs) | Up to ~US$125M (Clipperton estimate) | Clipperton deal note | Estimated |
| Legal advisor | Taylor Wessing (advised Lightspeed) | Taylor Wessing press release | Confirmed |
| Post-acquisition brand | Lightspeed POS Germany GmbH | SEC filing | Confirmed |
| Technology integration | Gastrofix tech → Lightspeed Restaurant G-Series | Lightspeed blog; Blent.io | Confirmed |

---

## M&A History Timeline

| Date | Event Type | Detail | Source | Confidence |
|---|---|---|---|---|
| 2011/2012 | Company founding | Gastrofix GmbH founded in Berlin by Reinhard Martens | Tracxn; Clipperton | Confirmed |
| 2011–2019 | Growth phase | Expanded to 8,000+ customer locations in DE, AT, NO | Lightspeed press release | Confirmed |
| Jan 7, 2020 | Acquisition announced | Lightspeed POS Inc. acquires Gastrofix; $61M cash + shares | Lightspeed press release | Confirmed |
| 2020 | Integration begins | Gastrofix → Lightspeed Restaurant G-Series | Blent.io | Confirmed |
| 2020+ | Rebrand | Gastrofix GmbH → Lightspeed POS Germany GmbH | SEC filing 2021 | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A["Lightspeed Commerce Inc.<br/>(TSX/NYSE: LSPD — Montreal, Canada)"]
    B["Lightspeed POS Germany GmbH<br/>(formerly Gastrofix GmbH, Berlin, DE)"]
    C["Lightspeed Restaurant G-Series<br/>(Product — integrated Gastrofix tech)"]

    A -->|"Acquired Jan 2020<br/>~$61M cash + shares"| B
    B --> C

    style B fill:#f9f,stroke:#333
    style C fill:#bbf,stroke:#333
```

---

## Corporate Timeline

```mermaid
timeline
    title Gastrofix GmbH — Corporate Timeline
    2011-2012 : Founded in Berlin by Reinhard Martens
               : Cloud-based iPad POS for hospitality
    2012-2019 : Growth phase
              : Expanded to 8,000+ locations in DE, AT, NO
              : HQ Berlin + Hamburg office
    2020 (Jan) : Acquired by Lightspeed POS Inc.
               : $61M cash + 1.44M Lightspeed shares
               : Total up to $125M with earn-outs
               : Taylor Wessing advises Lightspeed
    2020+ : Rebranded Lightspeed POS Germany GmbH
          : Technology → Lightspeed Restaurant G-Series
          : German KassenSichV compliance integration
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | NOT AVAILABLE — fully acquired by Lightspeed (TSX/NYSE: LSPD) January 2020 |
| **Ownership structure** | Canadian publicly listed company; no path for SolStein-style acquisition |
| **SolStein thesis fit** | Fails all primary criteria: not founder-owned, not independent, not NL/BE |
| **Strategic rationale for Lightspeed** | Gastrofix provided Lightspeed with immediate DACH market presence and KassenSichV compliance tech |
| **Role for SolStein** | Valuation benchmark: ~$61M base ($125M max) for 8,000 DACH locations; comparable for smaller DACH POS targets |

**Verdict**: Gastrofix is a **confirmed acquisition blocker**. Acquired by Lightspeed in January 2020. Benchmark value: US$61M base for 8,000 DACH locations ≈ ~$7,600/location (or likely 4–6x ARR at time of acquisition).

---

## Sources

| Source | URL | Type |
|---|---|---|
| Lightspeed press release — acquisition announcement | https://www.lightspeedhq.com/news/lightspeed-pos-inc-announces-the-acquisition-of-gastrofix/ | Primary (press release) |
| PR Newswire — acquisition announcement | https://www.prnewswire.com/news-releases/lightspeed-pos-inc-announces-the-acquisition-of-gastrofix-300982642.html | Primary (press release) |
| Clipperton deal note | https://www.clipperton.com/news-transaction/gastrofix-sold-to-lightspeed-pos-inc-tsxlspd | Secondary (deal advisory) |
| Taylor Wessing advisory announcement | https://www.taylorwessing.com/en/insights-and-events/news/media-centre/press-releases/2020/01/taylor-wessing-bert-lightspeed-beim-kauf-von-gastrofix | Secondary (legal advisory) |
| Lightspeed — Gastrofix is now Lightspeed | https://www.lightspeedhq.com/uk/pos/restaurant/gastrofix-is-now-lightspeed/ | Primary (company site) |
| Blent.io — G-Series integration | https://www.blent.io/data-sources/gastrofix-lightspeed-g-series | Secondary |
| Tracxn — Gastrofix profile | https://tracxn.com/d/companies/gastrofix | Secondary (company DB) |
