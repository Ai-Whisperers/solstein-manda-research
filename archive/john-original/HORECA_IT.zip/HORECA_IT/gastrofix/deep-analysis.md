# Gastrofix GmbH — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Valuation benchmark for DACH cloud POS; NOT an acquisition target

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Gastrofix GmbH (now Lightspeed POS Germany GmbH) | SEC filing 2021 | Confirmed |
| HQ | Berlin, Germany | Lightspeed press release | Confirmed |
| Founded | 2011–2012 | Tracxn; Clipperton | Estimated |
| CEO at acquisition | Reinhard Martens (founder) | Lightspeed press release | Confirmed |
| Current ownership | 100% Lightspeed Commerce Inc. (TSX/NYSE: LSPD) | Lightspeed press release | Confirmed |
| Employees | Unknown; not publicly reported | No source found | Unknown |
| Revenue at acquisition (2019) | Not publicly disclosed; Taylor Wessing notes "2019 revenue" without figure | Taylor Wessing note | Unknown |
| Estimated revenue multiple | ~4–6x ARR (estimated; $61M base for ~8,000 locations at modest ARPU) | Calculated | Estimated |
| Countries | Germany, Austria, Norway | Lightspeed press release | Confirmed |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Customer locations | 8,000+ at time of acquisition (Jan 2020) | Lightspeed press release | Confirmed |
| Markets | Germany (primary), Austria, Norway | Lightspeed press release | Confirmed |
| Segments | Restaurants, bars, cafés, hotels | Lightspeed press release | Confirmed |
| Market claim | "Leading cloud ePOS provider in German-speaking market" | Lightspeed blog | Confirmed |
| Competitive position | Competed directly with orderbird AG; complementary geography (orderbird = iPad-first; Gastrofix = iPad/Android) | CBInsights report | Estimated |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | iPad-based cloud POS for hospitality | Lightspeed press release | Confirmed |
| Platform type | Cloud-based SaaS; device-agnostic (iPad + Android) | Blent.io; Lightspeed blog | Estimated |
| Offline capability | Yes — offline-resilient operation | Blent.io | Confirmed |
| TSE compliance | Integrated as part of KassenSichV compliance (key 2020 German fiscal law requirement) | Lightspeed press release; Taylor Wessing | Confirmed |
| Post-acquisition integration | Merged into Lightspeed Restaurant G-Series platform | Blent.io; Lightspeed blog | Confirmed |
| European operational standards | GDPR, German fiscal law compliant | Lightspeed blog | Confirmed |
| Current product status | No longer branded as Gastrofix; fully absorbed into Lightspeed Restaurant | Lightspeed brand page | Confirmed |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Current owner | Lightspeed Commerce Inc. (TSX: LSPD, NYSE: LSPD) | Public records | Confirmed |
| PE overhang | None — Canadian publicly traded company | Public records | Confirmed |
| Founder status post-acquisition | Reinhard Martens — unknown post-acquisition status | Not reported | Unknown |
| Exit type | Strategic acquisition; sold to Canadian cloud commerce platform | Lightspeed press release | Confirmed |
| Carve-out probability | Near zero — absorbed into Lightspeed Restaurant G-Series product | Assessment | Estimated |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue at acquisition | Not publicly disclosed | Lightspeed SEC filing (no specific figure) | Unknown |
| Implied revenue multiple | ~4–6x ARR estimated (based on $61M base for 8,000 locations) | Calculated | Estimated |
| Growth trajectory (pre-acquisition) | Strong — grew to 8,000+ locations across 3 countries before being acquired | Lightspeed press release | Estimated |
| Post-acquisition reporting | No separate P&L disclosed; integrated into Lightspeed's European segment | Lightspeed investor reports | Confirmed |

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| German fiscal law compliance | KassenSichV / TSE compliant — key strategic reason for Lightspeed acquisition | Taylor Wessing note; Lightspeed press release | Confirmed |
| German payment methods | Girocard, EC-Cash, credit cards supported | Industry standard | Estimated |
| DACH market expertise | Deep — purpose-built for German hospitality; Norway expansion validated product | Lightspeed press release | Confirmed |
| DATEV integration | Likely but unconfirmed | Industry standard | Unknown |
| Hospitality specialization | Specific to restaurants, bars, cafés, hotels — not generic retail | Lightspeed press release | Confirmed |

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Acquisition price (base) | US$61 million cash | Lightspeed press release | Confirmed |
| Equity consideration | 1,437,930 Lightspeed shares (value depends on LSPD share price at close) | Lightspeed press release | Confirmed |
| Earn-out structure | Additional amounts tied to German market revenue targets through 2022 | Lightspeed press release | Confirmed |
| Total deal value | Up to ~US$125M (Clipperton estimate) | Clipperton | Estimated |
| Revenue model | Monthly SaaS subscription + hardware | Lightspeed/Gastrofix product model | Confirmed |
| Implied revenue multiple | ~4–6x ARR (estimated) | Calculated | Estimated |

---

## 8. M&A Attractiveness Scorecard

> **Note**: These scores assess fit with SolStein's NL/BE acquisition thesis. As Tier 3, this is for benchmarking context only.

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | 100% owned by publicly listed Lightspeed Commerce; no acquisition path | Lightspeed press release |
| Revenue scale fit | High | 2 | Estimated €10–15M ARR at acquisition — fit range, but now absorbed into LSPD | Calculated |
| Geographic fit | High | 1 | Germany, Austria, Norway — zero NL/BE | Lightspeed press release |
| Tech stack modernity | Medium | 4 | Cloud-native, offline-capable, iPad/Android; fully modern at time of acquisition | Blent.io |
| Customer lock-in | Medium | 4 | 8,000+ locations; fiscal compliance switching costs; hardware dependency | Lightspeed press release |
| Vertical depth | Medium | 4 | Deep DACH hospitality POS with KassenSichV compliance | Taylor Wessing note |
| Integration potential | Low | 3 | Now part of Lightspeed G-Series; API exposure uncertain from SolStein's perspective | Blent.io |
| Growth trajectory | Low | 3 | Growth pre-acquisition; now absorbed; standalone trajectory unknown | Assessment |

**Composite Score**: ~2.1 / 5.0 (penalized by ownership and geography)

**Confidence Band**: Low-Medium — deal financials confirmed but ARR not disclosed

**Overall M&A Assessment**: Gastrofix is definitively **NOT acquirable**. Fully absorbed into Lightspeed Restaurant G-Series. Its primary value to SolStein is as a **valuation benchmark**: US$61M base (up to $125M) for 8,000 DACH hospitality locations. Gastrofix's acquisition also validates the strategic value of KassenSichV compliance as an asset — any DACH POS company with deep German fiscal law integration commands a premium.

**Recommended Next Step**: Use Gastrofix deal (US$61–125M for 8,000 DACH locations) as the lower-to-mid range comparable for DACH POS companies. Cross-reference with orderbird (€130M for 17,000 locations) to triangulate per-location value: ~$7,600–$15,000/location for cloud DACH POS.

---

*Sources: Lightspeed press release, PR Newswire, Clipperton, Taylor Wessing, Blent.io, Tracxn, SEC annual information form 2021*
