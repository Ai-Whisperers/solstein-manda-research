# Gastrofix

**Category**: POS/Restaurant
**Country**: DE
**City**: Berlin
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Gastrofix @HORECA_IT/gastrofix/
@research-horeca-company Gastrofix @HORECA_IT/gastrofix/
```
