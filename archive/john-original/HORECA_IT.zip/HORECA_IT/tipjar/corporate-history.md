# TiPJAR — Corporate History

**Category**: Gratuities / Digital Tipping Platform
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; VC/growth-backed; active growth phase)

---

## Summary Assessment

TiPJAR is a **London-based digital tipping and tronc management platform** for the UK hospitality industry. With £11.3M total funding (most recently £4.5M in March 2026 led by YFM Equity Partners), it serves 5,000+ hospitality sites, processes £130M+ in tips annually for 75,000+ workers, and is positioned as the leading platform for the UK's Employment (Allocation of Tips) Act 2023 compliance. Highly UK-specific; not a SolStein NL/BE target. Useful as a **digital tipping and tronc benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | TiPJAR | wearetipjar.com | Confirmed |
| HQ | London, UK | wearetipjar.com | Confirmed |
| Founded | Not confirmed (pre-2021 per funding history) | — | Estimated |
| Founders | Not publicly identified in research | — | Unknown |
| Ownership | VC/growth-backed: YFM Equity Partners (lead, Mar 2026); Active Partners | wearetipjar.com, LinkedIn | Confirmed |
| Total funding | £11.3M | wearetipjar.com | Confirmed |
| Latest round | £4.5M (March 24, 2026; YFM Equity Partners lead) | wearetipjar.com, uktech.news | Confirmed |
| Prior round | £6.8M (approximate, based on £11.3M total minus £4.5M) | Derived | Estimated |
| Active Partners | Investor (prior round) | LinkedIn (Active Partners post) | Confirmed |
| Hospitality sites | 5,000+ | wearetipjar.com | Confirmed |
| Tips processed annually | £130M+ | wearetipjar.com | Confirmed |
| Hospitality workers served | 75,000+ | wearetipjar.com | Confirmed |
| Product | Digital tipping (cashless) + tronc management (Supertronc™) | wearetipjar.com | Confirmed |
| Key compliance product | Supertronc™ — Employment (Allocation of Tips) Act 2023 compliance | wearetipjar.com | Confirmed |
| UK regulatory driver | Employment (Allocation of Tips) Act 2023 (compliance from Oct 2024; new mandate Oct 2026) | uktech.news | Confirmed |
| HORECA sectors | Pubs, bars, restaurants, hotels, QSR | wearetipjar.com | Confirmed |

---

## Founding & History

TiPJAR was founded in London to address the fragmented and opaque management of tips in UK hospitality. Historically, tipping in UK hospitality was managed through cash, informal tronc schemes, or service charges collected by employers — with no guarantee that tips reached workers fairly.

**The regulatory tailwind**: The **Employment (Allocation of Tips) Act 2023** (effective from October 2024, with enhanced requirements from October 2026) mandates that all tips must be allocated fairly and transparently. This created a compliance obligation for every UK hospitality employer.

TiPJAR's **Supertronc™** product automates tronc calculations, ensures Act compliance, and provides payroll savings by treating tips as tronc (which has National Insurance efficiency advantages). The platform operates via a digital QR code tip mechanism, enabling customers to tip workers directly from their phones.

**March 2026 funding round**: £4.5M raised (YFM Equity Partners lead, Active Partners participates) to fund team expansion, product development, and UK market scaling. Total funding reaches £11.3M.

---

## Investor/Ownership Structure

```mermaid
graph TD
    A["YFM Equity Partners<br/>(Lead — Mar 2026 round)"]
    B["Active Partners<br/>(Prior round)"]
    C["TiPJAR<br/>(London, UK)"]
    D["5,000+ UK hospitality sites<br/>75,000+ workers<br/>£130M+ tips/year"]

    A -->|"Mar 2026 lead — £4.5M"| C
    B -->|"Prior round"| C
    C --> D
```

---

## Funding Timeline

| Round | Date | Amount | Lead Investor | Notes |
|---|---|---|---|---|
| Early funding | Pre-2024 | ~£6.8M (estimated) | Active Partners (at minimum) | Multiple rounds |
| Mar 2026 round | Mar 24, 2026 | £4.5M | YFM Equity Partners | Active Partners participates; Mountside Ventures advisory |
| **Total raised** | | **£11.3M** | | wearetipjar.com |

---

## Timeline of Critical Events

```mermaid
timeline
    title TiPJAR — Key Milestones
    Pre-2021 : Founded in London; digital tipping platform for UK hospitality
    2023 : Employment (Allocation of Tips) Act 2023 passed; Supertronc™ compliance product launched
    2024 : Act effective Oct 2024; TiPJAR becomes compliance solution; 5,000+ sites
    2026 : £4.5M raised Mar 2026 (YFM Equity Partners); £11.3M total; 75,000+ workers; £130M+ tips/year; Oct 2026 enhanced tipping regulation
```

---

## M&A Feasibility Assessment

### Is TiPJAR an Acquisition Target for SolStein?

**Answer: Not suitable — UK-specific regulatory product; VC/growth-backed; active growth phase.**

| Factor | Assessment |
|---|---|
| **Geography** | UK only — product is built around UK Employment (Allocation of Tips) Act |
| **Ownership** | YFM Equity Partners + Active Partners — institutional investors; not founder-only |
| **Scale** | £130M tips processed; 5,000+ sites; growing rapidly — above SolStein's target |
| **Regulatory** | UK-specific tipping law — not directly applicable to NL/BE |
| **Exit pathway** | VC/growth investors need exit; likely trade sale to payroll/HR platform |

### Role for SolStein

1. **Digital tipping benchmark**: TiPJAR defines digital tipping and tronc management — an emerging category in UK hospitality. NL/BE may develop similar digital tipping norms.
2. **Regulatory signals**: UK tipping legislation drives software adoption — monitor NL/BE regulatory changes that might create equivalent demand.
3. **Payment layer**: Shows how financial flows in hospitality (tips, service charges) create software opportunities.

---

*Sources: wearetipjar.com, uktech.news, uktechnews.info, startupmag.co.uk, retailtechinnovationhub.com, LinkedIn (Active Partners).*
