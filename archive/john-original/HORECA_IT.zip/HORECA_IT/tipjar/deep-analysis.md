# TiPJAR — Deep Analysis

**Category**: Gratuities / Digital Tipping & Tronc Management
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; growth-backed; regulatory-driven growth phase)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | TiPJAR Ltd (inferred) | wearetipjar.com | Estimated |
| HQ | London, UK | wearetipjar.com | Confirmed |
| Founded | Pre-2021 (exact date not confirmed) | Funding timeline | Estimated |
| Founders | Not publicly identified | — | Unknown |
| Ownership | YFM Equity Partners (lead, Mar 2026) + Active Partners | wearetipjar.com, LinkedIn | Confirmed |
| Total funding | £11.3M | wearetipjar.com | Confirmed |
| Latest round | £4.5M (Mar 24, 2026) | wearetipjar.com, uktech.news | Confirmed |
| Hospitality sites | 5,000+ | wearetipjar.com | Confirmed |
| Tips processed annually | £130M+ | wearetipjar.com | Confirmed |
| Workers served | 75,000+ | wearetipjar.com | Confirmed |
| Business model | SaaS platform (per-site or per-transaction) for digital tipping and tronc | wearetipjar.com | Confirmed |
| Product | Digital QR tip collection + Supertronc™ tronc management + payroll integration | wearetipjar.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Primary; dominant in UK digital tipping | wearetipjar.com | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | UK-specific product (UK tipping law) | wearetipjar.com | Confirmed |
| New markets (2026) | Scaling across UK; possible new market expansion | wearetipjar.com | Estimated |
| HORECA verticals | Pubs, bars, restaurants, hotels, QSR | wearetipjar.com | Confirmed |
| Regulatory position | Leading compliance platform for Employment (Allocation of Tips) Act 2023 | wearetipjar.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Digital tipping | QR code-based cashless tipping (customer to worker direct) | wearetipjar.com | Confirmed |
| Supertronc™ | Automated tronc calculation; Act 2023 compliance; NI efficiency | wearetipjar.com | Confirmed |
| Payroll integration | Integration with payroll systems for tip allocation | wearetipjar.com | Confirmed |
| Compliance reporting | Audit trail for Employment (Allocation of Tips) Act | wearetipjar.com | Confirmed |
| Deployment | Cloud SaaS; QR-code physical touchpoints | wearetipjar.com | Confirmed |
| Tech stack | Cloud-native; mobile-first (customer tips via phone browser) | wearetipjar.com | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| PE/VC backers | YFM Equity Partners (lead Mar 2026) + Active Partners | wearetipjar.com, LinkedIn | Confirmed |
| Founder status | Unknown | — | Unknown |
| Exit horizon | 3–5 years from Mar 2026 round; YFM holds hospitality/fintech portfolio | YFM profile | Estimated |
| Likely exit path | Trade sale to payroll provider, HR platform, or payments company | Market context | Estimated |
| Access Group connection | Access Hospitality published guide on TiPJAR integration for tronc compliance | theaccessgroup.com | Confirmed |

---

## 5. Financial Growth & Trajectory

| Period | Details | Source | Confidence |
|---|---|---|---|
| Pre-2026 | ~£6.8M raised in earlier rounds; 5,000+ sites achieved | Derived | Estimated |
| Mar 2026 | £4.5M raised; team expansion + product development | wearetipjar.com | Confirmed |
| Tipping volume | £130M+ annually through platform | wearetipjar.com | Confirmed |
| Revenue estimate | Platform fee on £130M tips = £650K–£2.6M at 0.5–2%; plus SaaS fees | Derived | Estimated |
| Growth trajectory | Strong; Oct 2026 tipping legislation creates further mandatory adoption | uktech.news | Confirmed |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK tipping law | Employment (Allocation of Tips) Act 2023 — core compliance product | wearetipjar.com | Confirmed |
| Tronc management | Automated tronc scheme management (NI-efficient tip allocation) | wearetipjar.com | Confirmed |
| National Insurance | NI savings via tronc structure | wearetipjar.com | Confirmed |
| UK financial regulation | FCA/payment regulations for money movement | Inferred | Estimated |
| Staff satisfaction | Cashless tipping improves worker satisfaction and recruitment | wearetipjar.com | Confirmed |
| NL/BE equivalent | NL/BE tip culture different; no similar mandate | Inferred | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription per site + optional transaction fees | wearetipjar.com | Estimated |
| ARR estimate | £1M–£3M (derived from 5,000 sites × £200–600/year SaaS) | Derived | Estimated |
| Post-money valuation | ~£15–30M (implied at £4.5M round at standard growth multiples) | VC norms | Estimated |
| Acquisition value | £15M–£40M (PE/strategic at 5–15x ARR) | Industry comparable | Estimated |
| SolStein fit | No — UK-specific regulation; VC-backed; no NL/BE transferability | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 2 | VC/growth-backed (YFM Equity Partners + Active Partners); not founder-only | wearetipjar.com |
| Revenue scale fit | High | 3 | Estimated £1–3M ARR — within range, but VC-backed and regulatory-dependent | Derived |
| Geographic fit | High | 1 | UK-only; product built around UK tipping legislation | wearetipjar.com |
| Tech stack modernity | Medium | 5 | Cloud-native; QR-based; payroll integrations; modern fintech | wearetipjar.com |
| Customer lock-in | Medium | 4 | Compliance obligation creates near-mandatory adoption; payroll integration | wearetipjar.com |
| Vertical depth | Medium | 3 | Deep UK hospitality tipping expertise; but single-function (tipping only) | wearetipjar.com |
| Integration potential | Low | 4 | Payroll, POS, PMS integrations | wearetipjar.com |
| Growth trajectory | Low | 5 | Strong; Oct 2026 tipping legislation mandate drives rapid UK adoption | uktech.news |

### Composite Score

**Weighted Composite: 2.5 / 5.0**

*(Geographic fit = 1 [high weight]; ownership = 2 [institutional]; decisive for SolStein)*

**Confidence Band**: Low-Medium — tipping volume confirmed; ARR and ownership detail estimated.

### Overall M&A Assessment

TiPJAR is **not a SolStein target** — it is a UK-specific regulatory compliance product for UK tipping law, which does not apply to NL/BE. Its value to SolStein is as a **digital payments-in-hospitality benchmark** and a signal that hospitality-specific fintech (tipping, tronc) companies are an emerging category. If NL/BE develops similar gratuity regulation, a NL/BE digital tipping company could emerge as a future target.

### Recommended Next Step

No pursuit. Monitor UK tipping law developments for any EU-level equivalent. Use as fintech-meets-hospitality benchmark.

---

*Sources: wearetipjar.com, uktech.news, uktechnews.info, startupmag.co.uk, retailtechinnovationhub.com, theaccessgroup.com.*
