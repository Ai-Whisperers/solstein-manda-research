# TiPJAR

**Category**: Gratuities
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history TiPJAR @HORECA_IT/tipjar/
@research-horeca-company TiPJAR @HORECA_IT/tipjar/
```
