# orderbird AG (Garmondo) — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Valuation benchmark and competitive reference; NOT an acquisition target

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | orderbird AG | Nexi press release 2022 | Confirmed |
| HQ | Berlin, Germany | orderbird.com | Confirmed |
| Founded | March 2011 | orderbird.com/about-us | Confirmed |
| CEO (at acquisition) | Mark Schoen | Nexi press release 2022 | Confirmed |
| Founder / CSO | Jakob Schreyer | Nexi press release 2022 | Confirmed |
| Current ownership | 100% Nexi Group S.p.A. (via Nets A/S) | Nexi press release May 2022 | Confirmed |
| Employees | ~200–300 (estimated) | Not publicly confirmed | Unknown |
| Revenue / ARR | ~€15–20M ARR at acquisition (implied by ~8x multiple on ~€130M deal) | Estimated from deal value | Estimated |
| Countries served | Germany, Austria, Switzerland, France | orderbird.com | Confirmed |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Customer count | 17,000+ hospitality businesses | orderbird.com | Confirmed |
| Primary market | Germany (DACH primary) | orderbird.com | Confirmed |
| Secondary markets | Austria, Switzerland, France | orderbird.com | Confirmed |
| Market claim | "No. 1 iPad POS system for hospitality in Germany" | orderbird.com | Estimated |
| Segments served | Restaurants, bars, cafés, food trucks, hotels | orderbird.com | Confirmed |
| DE market competitors | Gastrofix (acquired by Lightspeed), Gastronovi, SumUp POS | CBInsights report | Confirmed |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | orderbird PRO — cloud-based iPad POS | orderbird.com | Confirmed |
| Mobile product | orderbird MINI — all-in-one mobile POS (launched 2020) | orderbird.com/about-us | Confirmed |
| Platform type | Cloud-based SaaS; iPad-native | orderbird.com | Confirmed |
| TSE compliance | Yes — compliant with German KassenSichV (Kassensicherungsverordnung) fiscal receipt law | orderbird.com; German regulatory context | Confirmed |
| DATEV integration | Likely (common for German POS vendors; unconfirmed) | Industry standard | Unknown |
| Embedded payments | Yes — integrated payments via Nexi post-acquisition | Nexi press release | Confirmed |
| 2023 acquisition | Split Tech-Solutions GmbH acquired — likely extends payment/ordering capabilities | orderbird.com/about-us | Confirmed |
| Tech stack | Cloud-native; iOS-native; AWS infrastructure (PCG migration case study) | pcg.io/insights/orderbird-aws-migration | Confirmed |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Current owner | Nexi Group S.p.A. (NYSE: NEXI) — Italian PayTech | Nexi press release | Confirmed |
| Intermediate owner | Nets A/S — Nexi subsidiary; acquired 40% Sep 2021, 100% May 2022 | Multiple sources | Confirmed |
| PE overhang | None — Nexi is publicly listed (NYSE) | Nexi press release | Confirmed |
| Founder exit | Jakob Schreyer transitioned to CSO post-acquisition; other founders likely exited | Nexi press release; LinkedIn | Estimated |
| Strategic rationale for Nexi | Access to 17,000 DACH hospitality merchants + integrated payments cross-sell | Nexi press release; TechCrunch | Confirmed |
| Carve-out probability | Very low — core to Nexi's DACH SMB payments strategy | Assessment | Estimated |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| ARR growth (2019) | 30%+ YoY growth in ARR | EU-Startups Aug 2019 | Confirmed |
| Implied ARR at acquisition (2022) | ~€15–20M (estimated from ~8x multiple on €130M deal) | Calculated | Estimated |
| Revenue model | SaaS subscription (hardware + monthly software fee) | orderbird.com pricing | Confirmed |
| Post-acquisition trajectory | Integrated into Nexi's €1B+ German payment business; standalone metrics not reported | Nexi investor reports | Estimated |
| Profitability | Unknown pre-acquisition; likely EBITDA-positive by 2021 given Nets' investment thesis | Not disclosed | Unknown |

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| German fiscal law compliance | KassenSichV / TSE (Technische Sicherheitseinrichtung) compliant | orderbird.com | Confirmed |
| German payment methods | Supports EC card, Girocard, credit cards, cash | orderbird.com product | Confirmed |
| German-language support | Full German-language product and support | orderbird.com/de | Confirmed |
| DATEV integration | Not confirmed | Unknown | Unknown |
| Hospitality specialization | Deep — purpose-built for German gastronomy; not adapted from generic retail POS | orderbird.com | Confirmed |
| Offline resilience | Yes — works without internet connection | orderbird.com | Confirmed |

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Acquisition value | ~€130M total consideration (€100M cash-out + prior stake purchases) | TechCrunch; Nexi PDF | Confirmed |
| Implied revenue multiple | ~7–9x ARR (estimated, based on implied ARR €15–20M) | Calculated | Estimated |
| Revenue model | Monthly SaaS + hardware; embedded payment revenue (post-Nexi) | orderbird.com pricing | Confirmed |
| Pricing | €79–€129/month (POS software); hardware bundled or separate | orderbird.com pricing | Estimated |
| Benchmark value | High-quality DE HORECA POS at 7–9x ARR = key benchmark for SolStein NL/BE comparisons | Assessment | Estimated |

---

## 8. M&A Attractiveness Scorecard

> **Note**: These scores assess fit with SolStein's NL/BE acquisition thesis. As a Tier 3 reference company, this is for benchmarking context only.

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | 100% owned by publicly listed Nexi Group; no founder-owned angle whatsoever | Nexi press release 2022 |
| Revenue scale fit | High | 3 | Estimated €15–20M ARR — within SolStein's range, but now PE/corporate-owned and growing | Calculated from deal value |
| Geographic fit | High | 1 | Germany-only (DACH + France); zero NL/BE presence | orderbird.com |
| Tech stack modernity | Medium | 5 | Cloud-native, iPad-first, AWS infrastructure, TSE-compliant; best-in-class tech for DACH POS | pcg.io case study |
| Customer lock-in | Medium | 4 | 17,000+ customers; hardware dependency; TSE compliance switching cost; SaaS model | orderbird.com |
| Vertical depth | Medium | 5 | Deepest DACH hospitality POS specialist; purpose-built for German gastronomy | orderbird.com |
| Integration potential | Low | 4 | Open API likely (Nexi ecosystem); modern cloud architecture | Nexi partnership model |
| Growth trajectory | Low | 4 | Strong growth pre-acquisition (30%+ YoY); trajectory continues within Nexi | EU-Startups 2019 |

**Composite Score**: ~2.4 / 5.0 (heavily penalized by ownership and geography — both blocking factors)

**Confidence Band**: Medium — acquisition price confirmed; ARR estimated

**Overall M&A Assessment**: orderbird is definitively **NOT acquirable by SolStein**. It is fully owned by Nexi Group (NYSE-listed Italian PayTech). Its primary value to SolStein is as a **valuation benchmark**: the 2022 deal at ~7–9x ARR for a DACH cloud POS with 17,000 customers is the reference point for what best-in-class DACH HORECA POS companies command at exit. Any comparable NL/BE POS company with similar ARR, customer count, and cloud-native architecture would likely command a 4–7x multiple in the current market.

**Recommended Next Step**: Use orderbird's deal metrics (€130M for ~17,000 DACH customers) as the upper bound of the DACH POS comparable set. When valuing NL/BE POS targets, apply a 20–40% discount for smaller scale and geography concentration.

---

*Sources: orderbird.com, Nexi Group press releases, TechCrunch, ffnews.com, EU-Startups, pcg.io, CBInsights, orderbird.design*
