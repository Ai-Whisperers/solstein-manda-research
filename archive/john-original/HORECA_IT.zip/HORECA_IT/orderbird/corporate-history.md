# orderbird AG (Garmondo) — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Acquired — NOT an available M&A target

---

## Executive Summary

orderbird AG was Germany's first and leading iPad-based POS system for the hospitality industry, founded in Berlin in March 2011. The company grew to serve 17,000+ customers across Germany, Austria, Switzerland, and France. In September 2021, Nets A/S (a subsidiary of the Nexi Group) acquired a 40% stake, completing the full acquisition in May 2022 for approximately €130 million. orderbird continues to operate as a distinct business unit within the Nexi Group. **Note**: The user's landscape reference uses the name "Garmondo (orderbird)." Extensive research finds no publicly registered entity named "Garmondo" associated with orderbird; the legal entity is "orderbird AG." This name may refer to an internal holding or rebrand not disclosed in public records.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | orderbird AG | orderbird.com/en/about-us, Nexi press release | Confirmed |
| Trade name | orderbird | orderbird.com | Confirmed |
| Alternative name referenced | Garmondo | SolStein research brief; no public source confirming this name | Unknown |
| Legal form | Aktiengesellschaft (AG) | Nexi press release (2022) | Confirmed |
| Registered address | Berlin, Germany | orderbird.com | Confirmed |
| Country | Germany | Multiple sources | Confirmed |
| Primary activity | Cloud-based iPad POS system for hospitality | orderbird.com | Confirmed |
| Handelsregister number | Not retrieved in searches | No public source found | Unknown |
| VAT number | Not publicly disclosed | No public source found | Unknown |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | March 2011 | orderbird.com/en/about-us; Nexi press release | Confirmed |
| Founders | Bastian (unknown surname), Jakob Schreyer, Artur Hasselbach, Patrick (unknown surname) | orderbird.design/about-orderbird; LinkedIn (Artur Hasselbach post) | Estimated |
| Origin | Founders wanted to create a cash register as intuitive as Apple devices; launched Germany's first iPad POS | orderbird.com/en/about-us | Confirmed |
| Original HQ | Berlin, Germany | Multiple sources | Confirmed |
| First product | Germany's first iPad-based POS for restaurants and cafés | orderbird.com/about-us | Confirmed |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pre-2021 investors | METRO AG, ALSTIN Capital, Digital+ Partners, Concardis GmbH | CBInsights; Techcrunch 2022 | Confirmed |
| Nets A/S (Nexi subsidiary) — initial stake | September 2021 — acquired 40% stake | ffnews.com; Techcrunch 2022 | Confirmed |
| Nexi Group — full acquisition | May 12, 2022 | orderbird.com press release; Nexi press release; Techcrunch | Confirmed |
| Acquisition price | ~€130M–€140M aggregate cash consideration (~€100M cash-out including prior share purchases) | Techcrunch; Nexi PDF press release | Confirmed |
| Post-acquisition brand | orderbird (continues operating as distinct brand within Nexi Group) | orderbird.com press release | Confirmed |
| Post-acquisition leadership | CEO: Mark Schoen; Founder/CSO: Jakob Schreyer | Nexi press release 2022 | Confirmed |

---

## M&A History Timeline

| Date | Event Type | Detail | Source | Confidence |
|---|---|---|---|---|
| 2011 | Company founding | orderbird AG founded in Berlin; Germany's first iPad POS | orderbird.com | Confirmed |
| ~2013–2019 | Growth phase | Expanded to 17,000+ hospitality businesses; DACH + France | orderbird.com | Estimated |
| 2019 | Revenue milestone | 30%+ YoY ARR growth announced | EU-Startups 2019 | Confirmed |
| Sep 2021 | Nets A/S acquires 40% stake | Nets (Nexi Group subsidiary) takes minority position | ffnews.com | Confirmed |
| May 2022 | Nexi Group acquires full stake | Full acquisition; ~€130M total consideration | Nexi press release | Confirmed |
| 2023 | orderbird acquires Split Tech-Solutions GmbH | Bolt-on acquisition; 100% of shares | orderbird.com/about-us | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A["Nexi Group S.p.A.<br/>(Italian PayTech, NYSE: NEXI)"]
    B["Nets A/S<br/>(Nexi subsidiary)"]
    C["orderbird AG<br/>(Berlin, DE)"]
    D["Split Tech-Solutions GmbH<br/>(acquired 2023)"]

    A --> B
    B -->|"40% Sep 2021<br/>100% May 2022"| C
    C -->|"Acquired 2023"| D

    style C fill:#f9f,stroke:#333
    style D fill:#bbf,stroke:#333
```

---

## Corporate Timeline

```mermaid
timeline
    title orderbird AG — Corporate Timeline
    2011 : Founded in Berlin (March)
         : Germany's first iPad POS system
         : Founders: Bastian, Jakob Schreyer, Artur Hasselbach, Patrick
    2013-2019 : Growth phase DACH + France
              : 17,000+ hospitality clients
              : Investors: METRO AG, ALSTIN, Digital+ Partners, Concardis
    2019 : 30%+ ARR growth announced
    2021 : Nets A/S (Nexi) acquires 40% stake (September)
    2022 : Nexi Group acquires 100% for ~€130M (May 12)
         : CEO Mark Schoen; Founder Jakob Schreyer becomes CSO
    2023 : orderbird acquires Split Tech-Solutions GmbH
         : Expanded product via bolt-on M&A
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | NOT AVAILABLE — 100% owned by Nexi Group since May 2022 |
| **Ownership structure** | Italian PayTech conglomerate (NYSE-listed); no path to founder-owned exit |
| **SolStein thesis fit** | Fails multiple primary criteria: not founder-owned, not independent, not NL/BE geography |
| **Carve-out possibility** | Theoretically possible but extremely unlikely; Nexi has built orderbird into its DACH PayTech strategy |
| **Role for SolStein** | Use as valuation benchmark (€130M for ~€15M ARR = ~8x revenue multiple); competitive reference for DACH POS market |

**Verdict**: orderbird is a **confirmed acquisition blocker**. Acquired by Nexi Group in May 2022 for ~€130M. Serves as a key valuation benchmark for cloud-native restaurant POS companies in the DACH market. The 8x ARR multiple reflects premium for market leadership.

---

## Sources

| Source | URL | Type |
|---|---|---|
| orderbird about page | https://www.orderbird.com/en/about-us | Primary (company site) |
| orderbird — Nexi acquisition press release | https://www.orderbird.com/en/pm-2202-05-12-orderbird-is-now-fully-part-of-the-nexi-family | Primary (press release) |
| Nexi Group press release PDF | https://www.nexigroup.com/content/dam/corp/downloads/investors/financial-press-releases/2022/2022-05-12-pr-Orderbird.pdf | Primary (investor release) |
| TechCrunch — Nexi buys orderbird | https://techcrunch.com/2022/05/12/nexi-the-italian-payments-giant-buys-germanys-orderbird-for-140-150m-to-expand-its-smb-strategy/ | Secondary (news) |
| ffnews.com — Nets acquires full stake | https://ffnews.com/newsarticle/nets-acquires-full-stake-in-orderbird/ | Secondary (news) |
| orderbird.design — About orderbird | https://orderbird.design/about-orderbird | Secondary (company info) |
| LinkedIn — Artur Hasselbach post | https://www.linkedin.com/posts/artur-hasselbach | Secondary (social) |
| EU-Startups 2019 ARR growth announcement | https://www.eu-startups.com/2019/08/berlin-based-orderbird | Secondary (news) |
