# Garmondo (orderbird)

**Category**: Restaurant POS
**Country**: DE
**City**: Berlin
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Garmondo (orderbird) @HORECA_IT/orderbird/
@research-horeca-company Garmondo (orderbird) @HORECA_IT/orderbird/
```
