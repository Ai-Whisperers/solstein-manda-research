# FoodNotify — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE/AT)
**M&A Role**: Austrian F&B management reference; SolStein brief contains geographic and category errors

---

## Critical Research Notes

1. **Geography**: FoodNotify is headquartered in **Vienna, Austria** — not Hamburg, Germany as stated in the brief
2. **Category**: FoodNotify is a **F&B procurement and operations management platform** (back-of-house) — not "guest feedback and review management" as stated in the brief
3. **Relevance**: Austria falls outside SolStein's primary NL/BE thesis and Germany-reference scope

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Company name | FoodNotify | foodnotify.com | Confirmed |
| HQ | Vienna, Austria | LinkedIn | Confirmed |
| Founded | Unknown | No public source | Unknown |
| CEO / Founders | Unknown | No public source | Unknown |
| Ownership | Unknown — likely private | No source | Unknown |
| Employees | Unknown | No source | Unknown |
| Revenue | Unknown | No source | Unknown |
| Countries active | DACH (AT, DE, CH) | foodnotify.com | Estimated |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Segments | Restaurants, hotels, caterers, food service businesses | foodnotify.com | Confirmed |
| German market | Active — German clients confirmed (Rauschenberger caterer, INTERNORGA trade fair) | foodnotify.com | Confirmed |
| NL/BE presence | None identified | No source | Unknown |
| Market positioning | Back-of-house F&B management (procurement, recipes, inventory) | foodnotify.com | Confirmed |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | F&B management platform (procurement, recipes, inventory, catering, analytics) | foodnotify.com | Confirmed |
| Deployment | Cloud SaaS | foodnotify.com | Confirmed |
| Mobile app | iOS/Android (ordering, stocktaking) | foodnotify.com/en/foodnotify-app | Confirmed |
| POS integration | Yes — connects with POS and cost management tools | foodnotify.com | Confirmed |
| Modern stack | Cloud-native, mobile-first | foodnotify.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership | Unknown | No source | Unknown |
| PE involvement | None identified | No source | Unknown |
| Founder status | Unknown | No source | Unknown |

---

## 5–7. Financial, Vertical, Valuation

All Unknown — no public financial data available.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown | No source |
| Revenue scale fit | High | — | Unknown | No source |
| Geographic fit | High | 1 | Austria (Vienna) — outside NL/BE AND Germany reference scope | LinkedIn |
| Tech stack modernity | Medium | 4 | Cloud-native, mobile app, POS integration — modern stack | foodnotify.com |
| Customer lock-in | Medium | 3 | Recipe/inventory data creates moderate switching costs | Assessment |
| Vertical depth | Medium | 4 | Deep F&B management: procurement, costing, allergens, events, analytics | foodnotify.com |
| Integration potential | Low | 4 | Designed to integrate with POS; open architecture implied | foodnotify.com |
| Growth trajectory | Low | — | Unknown | No source |

**Composite Score**: ~2.3 / 5.0 (penalized by geography and unknown financials)

**Confidence Band**: Low — product confirmed; financials/ownership Unknown

**Overall M&A Assessment**: FoodNotify is an interesting F&B management platform with a modern cloud stack and genuine HORECA vertical depth. However, it fails SolStein's primary geographic criterion (Austria, not NL/BE). The research brief also misidentifies the product (procurement/ops vs. guest feedback) and the location (Vienna vs. Hamburg). If SolStein ever expands its thesis to include Austrian F&B tech, FoodNotify would warrant a closer look.

**Recommended Next Step**: Flag the research brief geographic and category errors. No immediate action for SolStein's NL/BE thesis. File for reference if Austria expansion is considered.

---

*Sources: foodnotify.com, LinkedIn, Capterra, G2, foodnotify.com/en/customers/rauschenberger*
