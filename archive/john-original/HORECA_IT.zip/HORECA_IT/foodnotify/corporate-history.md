# FoodNotify — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Active company — but headquartered in Vienna, Austria (NOT Hamburg, Germany); and focused on F&B procurement/inventory (NOT guest feedback as described in brief)

---

## Executive Summary

FoodNotify is a real, active F&B management platform that provides software for food procurement, recipe management, inventory control, and analytics for restaurants, hotels, caterers, and food service businesses. However, the SolStein research brief contains two inaccuracies: (1) it lists FoodNotify as "Hamburg, DE" when the company is actually headquartered in **Vienna, Austria**; and (2) it categorizes FoodNotify as a "guest feedback and review management" platform when in reality it is a **F&B procurement and operational management** platform (back-of-house, not guest-facing). The company is active in Germany (particularly around Hamburg events like INTERNORGA trade fair) but is an Austrian company. No financial data or ownership details are publicly available.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Company name | FoodNotify | foodnotify.com | Confirmed |
| Actual HQ | Vienna, Austria | LinkedIn company page | Confirmed |
| SolStein brief location | "Hamburg, DE" (incorrect — Vienna, AT) | SolStein research brief | Estimated |
| Country | Austria (NOT Germany) | LinkedIn; foodnotify.com | Confirmed |
| Primary activity | F&B management platform (procurement, recipes, inventory, analytics) | foodnotify.com | Confirmed |
| SolStein brief categorization | "Guest feedback and review management" (incorrect — it's procurement/operations) | SolStein research brief | Estimated |
| Website | foodnotify.com | foodnotify.com | Confirmed |
| German market | Active in Germany; participates in INTERNORGA Hamburg | foodnotify.com/en/customers/rauschenberger | Confirmed |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | Unknown | No public source | Unknown |
| Founders | Unknown | No public source | Unknown |
| Origin country | Austria (Vienna) | LinkedIn | Confirmed |
| Market focus | Restaurants, hotels, caterers, food service in DACH region | foodnotify.com | Confirmed |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership type | Unknown — appears privately held | No public source | Unknown |
| PE involvement | None identified | No source | Unknown |
| External funding | Unknown | No source | Unknown |

---

## Product Profile

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | F&B management: digital ordering, recipe costing, inventory, analytics | foodnotify.com | Confirmed |
| Modules | Procurement/ordering, recipe management (allergens, nutrition), inventory, catering event planning, analytics | foodnotify.com | Confirmed |
| Mobile app | FoodNotify app (iOS/Android) for ordering, stocktaking, goods acceptance | foodnotify.com/en/foodnotify-app | Confirmed |
| POS integration | Integrates with POS and cost management tools | foodnotify.com | Confirmed |
| Deployment | Cloud-based SaaS | foodnotify.com | Confirmed |
| Key customer | Rauschenberger Eventcatering (Frankfurt/Munich catering firm) | foodnotify.com/en/customers/rauschenberger | Confirmed |
| German customers | Multiple German hospitality chains and caterers | foodnotify.com/en/customers | Confirmed |

---

## Corporate Timeline

```mermaid
timeline
    title FoodNotify — Corporate Timeline
    Unknown : Founded in Vienna, Austria
            : F&B procurement management platform
    2020-2026 : Active in DACH market
              : Participating in INTERNORGA Hamburg
              : German restaurant/catering clients
    2026 : Active cloud SaaS platform
         : Vienna HQ; DACH customer base
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — privately held; ownership details not public |
| **Geography** | Austrian company (Vienna) — NOT German; brief incorrectly lists Hamburg |
| **SolStein thesis fit** | Poor — Austrian (not NL/BE), wrong brief categorization; back-of-house ops vs. SolStein's broader HORECA thesis |
| **Product fit** | F&B procurement/inventory — adjacent to HORECA but back-of-house focused; different from POS/PMS |
| **Note** | Austria is not a target market for SolStein's primary NL/BE thesis; could be watch list |

**Verdict**: FoodNotify is an Austrian F&B management company, not a German guest feedback company as described. It falls outside SolStein's geographic thesis (NL/BE primary; DE reference only). The product is interesting (cloud-native F&B management for hospitality) but the geography and SolStein thesis alignment are limited.

---

## Sources

| Source | URL | Type |
|---|---|---|
| FoodNotify website | https://www.foodnotify.com/en/ | Primary (company site) |
| FoodNotify LinkedIn | https://es.linkedin.com/company/foodnotify | Secondary (social) |
| Capterra — FoodNotify | https://www.capterra.com/p/10002971/FoodNotify/ | Secondary (review site) |
| G2 — FoodNotify reviews | https://www.g2.com/products/foodnotify/reviews | Secondary (review site) |
| FoodNotify customer — Rauschenberger | https://www.foodnotify.com/en/customers/rauschenberger | Primary (case study) |
