# Kassensysteme TSE

**Category**: POS System
**Country**: DE
**City**: Frankfurt
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Kassensysteme TSE @HORECA_IT/kassensysteme-tse/
@research-horeca-company Kassensysteme TSE @HORECA_IT/kassensysteme-tse/
```
