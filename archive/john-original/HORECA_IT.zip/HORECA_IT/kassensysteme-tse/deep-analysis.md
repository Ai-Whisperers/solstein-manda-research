# Kassensysteme TSE — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: German TSE POS market context; company identity not confirmed

---

## Research Limitations

"Kassensysteme TSE" as a specific Frankfurt-based company could not be confirmed. This entry may refer to a generic market category (TSE-compliant POS systems) rather than a specific company. Even if a company by this name exists, it would likely be a hardware reseller/integrator rather than a SaaS developer.

---

## TSE Compliance Market Context (for Valuation Reference)

| Aspect | Detail | Source | Confidence |
|---|---|---|---|
| German law | KassenSichV (Kassensicherungsverordnung) effective January 2020 | German regulatory | Confirmed |
| Requirement | All POS systems must include TSE (Technische Sicherheitseinrichtung) for fiscal receipts | German regulatory | Confirmed |
| Market impact | Forced upgrade cycle for all German hospitality POS operators | Industry | Confirmed |
| TSE solutions | Hardware dongles (Swissbit, EPSON), cloud TSE (fiskaly, Deutsche Fiskal) | Industry | Confirmed |
| SolStein relevance | Any NL/BE company entering DE market would need TSE compliance; German targets must have it | Assessment | Confirmed |

---

## 1–7. All Data Points

All Unknown — company identity not confirmed.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown | No source |
| Revenue scale fit | High | 1 | Likely hardware reseller — below SolStein's SaaS threshold | Estimated |
| Geographic fit | High | 1 | Germany (Frankfurt) only — no NL/BE | SolStein brief |
| Tech stack modernity | Medium | 1 | Likely hardware reseller, not SaaS developer | Estimated |
| Customer lock-in | Medium | 2 | TSE compliance creates some switching costs but hardware-centric | Assessment |
| Vertical depth | Medium | 2 | German fiscal compliance specialty — very narrow | Assessment |
| Integration potential | Low | 1 | Hardware integrator; limited SaaS integration potential | Assessment |
| Growth trajectory | Low | 1 | TSE compliance market is post-mandate (2020); growth phase over | Assessment |

**Composite Score**: ~1.1 / 5.0

**Confidence Band**: Very Low

**Overall M&A Assessment**: Kassensysteme TSE is **not a SolStein target**. Even if the entity is confirmed, it would be a hardware/compliance reseller operating in a post-mandate compliance market — not a scalable SaaS business. Germany-only with zero NL/BE presence.

**Recommended Next Step**: No action. Use TSE compliance context as regulatory knowledge for evaluating other DACH POS targets.

---

*Sources: SolStein research brief; German KassenSichV regulatory background*
