# Kassensysteme TSE — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — generic term; very limited public data

---

## Executive Summary

"Kassensysteme TSE" (German: "Cash register systems TSE") is listed in the SolStein research brief as a Frankfurt-based provider of TSE-certified cash registers for hospitality. "TSE" refers to Technische Sicherheitseinrichtung — a mandatory German fiscal security device required by the Kassensicherungsverordnung (KassenSichV, effective 2020). Rather than referring to a specific company named "Kassensysteme TSE," this entry likely refers to the general market of TSE-compliant POS systems, or potentially a specific Frankfurt-based POS reseller operating under a descriptive trade name. No specific company named "Kassensysteme TSE GmbH" in Frankfurt could be confirmed.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | Kassensysteme TSE | SolStein research brief | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Frankfurt, Hesse, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany | SolStein research brief | Estimated |
| Primary activity | TSE-certified cash registers for hospitality (reported) | SolStein research brief | Estimated |

---

## TSE Market Context

The KassenSichV (German Fiscal Cash Register Security Regulation) mandated that all POS systems in Germany be equipped with a TSE (Technische Sicherheitseinrichtung — Technical Security Device) effective January 2020. This created a large compliance-driven market:

| TSE Provider | Type | Notes |
|---|---|---|
| Bundesdruckerei (fiskaly) | TSE cloud solution | Major DE TSE provider |
| Deutsche Fiskal | TSE cloud solution | Telekom subsidiary |
| Swissbit | Hardware TSE dongle | Major hardware TSE |
| EPSON TSE | Hardware TSE printer | POS hardware integration |

A company calling itself "Kassensysteme TSE" would likely be a **reseller/integrator** of third-party TSE-compliant POS hardware and software — not a TSE developer.

---

## Research Methodology & Limitations

Searches conducted:
- Handelsregister searches for "Kassensysteme TSE" in Frankfurt
- Web searches for Frankfurt TSE-certified POS companies

The search for "kassensysteme TSE" returns many results for TSE compliance information and various POS resellers but no specific company named "Kassensysteme TSE GmbH" in Frankfurt.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — company existence not confirmed |
| **SolStein thesis fit** | Very poor — Germany-only; TSE reseller (not SaaS developer); compliance-driven market likely to consolidate |
| **Research confidence** | Very low |

**Verdict**: If this is a TSE-compliant POS reseller in Frankfurt, it would be a hardware/integration business — not a SaaS company and not suitable for SolStein's M&A thesis.

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| German Kassensicherungsverordnung context | German regulatory background | Reference |
| Web search results (inconclusive) | Multiple searches; no specific company found | Negative result |
