# Financial & Growth Deep-Dive — Mews Systems

**Research Date**: 2026-04-30
**Data Availability**: High — VC-funded unicorn with confirmed figures from lead investor Kinnevik (listed), press releases, and third-party databases (Getlatka, Clay.com, Crunchbase). KvK B.V. filings not accessed (large company likely files abbreviated Dutch accounts). Primary caveat: 2020–2022 revenue estimates carry medium confidence due to COVID disruption and private company reporting gaps.

---

### Revenue Timeline

| Year | Revenue | Currency | EUR Equivalent | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| 2026 (est.) | ~€520M | EUR | €520M | ~33% | Extrapolated from 2025 trajectory at 35–40% growth | Estimated |
| 2025 (FY est.) | ~€390M | EUR | €390M | ~95% | Aug 2025 run-rate €330M confirmed; FY extrapolated | Estimated |
| 2025 (run-rate Aug) | €330M | EUR | €330M | ~65% run-rate | Kinnevik Year-End Release 2025; investor page | Confirmed |
| 2024 | ~€200M | EUR | €200M | ~43% | Kinnevik investor page + Getlatka Dec 2024 | Confirmed |
| 2023 | ~€140M | EUR | €140M | ~56% | Estimated — interpolated from 2024 confirmed + Kinnevik "50% CAGR since 2022" reference | Estimated |
| 2022 | ~€90M | EUR | €90M | ~500%+ | Estimated — implied by $860M Series C valuation at ~10x ARR multiple; wide uncertainty band (€70–€130M) | Estimated |
| 2021 | ~€14M | USD/EUR | ~€14M | ~(47%) vs 2019 | Getlatka ($16.5M × 0.85 EUR/USD avg); COVID-19 hotel closure impact; likely subscription ARR only | Estimated |
| 2020 | ~€10–12M | EUR | ~€11M | ~(55%) | Estimated proxy — COVID-19 near-total hospitality shutdown; industry-wide SaaS churn elevated | Estimated (proxy) |
| 2019 | ~$26.6M | USD | ~€23.8M | n/a | Getlatka; includes Winner Hotel Software acquisition (Dec 2019); pre-COVID baseline | Estimated |

> **Revenue Data Note**: A significant gap exists between Getlatka's $16.5M figure for 2021 (likely subscription/SaaS ARR only, ex-payment processing and service revenue) and the €90M estimate implied by Kinnevik's Dec 2022 Series C at $860M valuation. This discrepancy is common with embedded-payments-heavy SaaS companies; Mews Payments generates transaction revenue on $19.7B TPV (2025) that may not be captured in subscription ARR figures. The 2022 estimate carries an uncertainty range of ±€40M. The 116% revenue increase cited in a Jan 2023 Mews press release about new Amsterdam/Barcelona offices likely describes 2022 vs. 2021 SaaS growth, not total platform revenue.

**Revenue CAGR (3yr, 2022–2024, EUR)**: ~49%
**Revenue CAGR (5yr, 2019–2024, EUR)**: ~53% (COVID base effect inflates; use with caution)

#### Revenue Trend Chart

```mermaid
xychart-beta
    title "Mews Systems Revenue Trend (EUR M)"
    x-axis [2019, 2020, 2021, 2022, 2023, 2024, "2025e"]
    y-axis "EUR Millions" 0 --> 420
    line [24, 11, 14, 90, 140, 200, 390]
```

---

### Profitability

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| EBITDA (current) | Not disclosed | KvK / public filings not available | Unknown |
| EBITDA Margin | Not disclosed; likely negative (growth investment mode) | Series D context — investing $300M in AI and expansion | Estimated |
| Net Profit / Loss | Likely operating at loss; reinvesting all revenue | VC growth stage; aggressive acquisition cadence | Estimated |
| Recurring Revenue % | ~85–95% (SaaS subscriptions + payments) | Cloud-native model; per-room SaaS + payment take-rate | Estimated |
| SaaS / Subscription Revenue % | ~60–70% subscription; ~25–30% payment processing | $19.7B TPV at ~0.3% margin ≈ $59M payment rev; balance = SaaS | Estimated |
| Revenue per Employee (EUR) | ~€133K (€200M ÷ ~1,500 employees) | Calculated from 2024 revenue + mid-2024 headcount | Estimated |

---

### Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Jan 2026 | Series D | $300M (≈€276M) | EQT Growth | $2.5B (post) | mews.com press release Jan 22, 2026; Wilson Sonsini advisory announcement | Confirmed |
| Mar 2025 | Growth Round | $75M (≈€69M) | Tiger Global Management | Not disclosed | Vestbee; Clay.com dossier | Confirmed |
| Sep 2024 | Debt Financing | $100M (≈€92M) | Vista Credit Partners | n/a | Clay.com dossier | Confirmed |
| Mar 2024 | Series D (Tranche 1) | $110M (≈€101M) | Kinnevik | $1.2B | Clay.com; Kinnevik investor materials | Confirmed |
| Dec 2022 | Debt Financing | Undisclosed | Columbia Lake Partners | n/a | Clay.com dossier | Confirmed |
| Dec 2022 | Series C | $185M (≈€172M) | Kinnevik + Goldman Sachs AM | ~$860M | mews.com about-us timeline; Kinnevik Q4 2022 release (SEK 436M for ~5% stake) | Confirmed |
| Aug 2019 | Series B | $33M (≈€30M) | Battery Ventures | Not disclosed | Clay.com; Crunchbase | Confirmed |
| Jun 2018 | Series A | $7.1M (≈€6.0M) | Notion Capital | Not disclosed | Clay.com; Crunchbase | Confirmed |
| Nov 2016 | Seed | $1.6M (≈€1.4M) | Undisclosed | Not disclosed | Clay.com; Crunchbase | Confirmed |

**Total Raised**: ~$812M equity + debt (~€747M) — Clay.com cites ~$710M, likely equity-only; full sum including debt rounds = ~$812M
**Latest Valuation**: $2.5 billion / ~€2.3B (January 22, 2026 — Series D at EQT Growth lead)
**Current Investors**: EQT Growth (lead Series D), Kinnevik (major, since 2022), Tiger Global, Battery Ventures, Goldman Sachs AM, Atomico, HarbourVest Partners, Notion Capital, henQ, Revaia, Orbit Capital, Salesforce Ventures, Thayer Ventures, Derive Ventures (~16–20 investors total)
**War Chest Signals**: $300M Series D (Jan 2026) designated for AI investment and geographic expansion; CEO stated "up to four acquisitions per year" as target; internal M&A team of ~10 people; $100M Vista debt facility (Sep 2024) adds additional acquisition capacity

---

### Employee Timeline

| Year | Headcount | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- |
| 2026 (Apr, current) | ~1,520 | +16% | LinkedIn company page | Confirmed |
| 2025 (mid) | 1,300+ | ~(8%) from 2024 peak | mews.com/ventures page | Confirmed |
| 2024 | ~1,418 | +77% vs 2023 | Getlatka Dec 2024 | Estimated |
| 2023 | 800+ | ~60% | mews.com press release (Amsterdam/Barcelona office opening) | Confirmed |
| 2022 | ~500–600 | ~40–60% | Estimated; Series C growth period; multiple acquisitions | Estimated |
| 2021 | ~300–400 | ~50% | Estimated; post-Winner integration + Hotel Perfect acquisition | Estimated |
| 2019 | ~150–200 | n/a | Estimated; post-Series B startup stage | Estimated |

> **Headcount Note**: 2025 mid-year count of "1,300+" appears lower than 2024 peak of ~1,418. This may reflect integration-related restructuring after 14 acquisitions, or data lag in the Ventures page metric. LinkedIn's current 1,520 (Apr 2026) suggests net growth resumed post-Series D.

**Employee CAGR (3yr, 2023–2026)**: ~24% ((1520/800)^(1/3) – 1)
**Current Open Positions**: Not enumerated in this research; Mews careers page active with roles across engineering, sales, and CS
**Hiring Hotspots**: Amsterdam (HQ), Prague (founding city, engineering hub), Barcelona (opened 2023), San Francisco (North America), Nashville (Nomi origin)

#### Employee Growth Chart

```mermaid
xychart-beta
    title "Mews Systems Employee Growth"
    x-axis [2019, 2021, 2022, 2023, 2024, 2026]
    y-axis "Headcount" 0 --> 1600
    line [175, 350, 550, 800, 1418, 1520]
```

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2016 | New office | UK (London) | First international office; first funding round | mews.com/about-us | Confirmed |
| 2019 | Acquisition + US entry | Belgium + USA | Winner Hotel Software (BE, 300+ hotels); opened US office | mews.com blog; PR Newswire | Confirmed |
| 2021 | Acquisition | UK | Hotel Perfect (UK cloud PMS) acquired Aug 2021 | PhocusWire | Confirmed |
| 2022 | Acquisitions | Europe-wide | Cenium (luxury/resort segment) + Bizzon (Czech republic F&B) | PhocusWire; Mews Ventures | Confirmed |
| 2023 | North America push | Canada + USA | Hotello (Canada, Apr 2023) + Nomi (Nashville, AI unit) | PR Newswire; Hotel Dive | Confirmed |
| 2023 | New offices | NL + Spain | Expanded Amsterdam HQ; new Barcelona office (60% Spain headcount growth) | mews.com press release | Confirmed |
| 2024 | North America consolidation | USA | Frontdesk Anywhere (San Francisco) acquired — 3rd North American acquisition in 12 months | PR Newswire Jan 2024 | Confirmed |
| 2024 | Germany/DACH | DACH | HS/3 Hotelsoftware acquired May 2024 (German-language market) | Tracxn; Mews Ventures | Confirmed |
| 2025 | APAC + UK | Asia-Pacific + UK | Clarity Hospitality Software Solutions acquired Jan 2025 (APAC/UK footprint) | Yahoo Finance; Mews blog | Confirmed |
| 2026 | AI-led global | Global | $300M Series D targeted at AI investment and global expansion | mews.com press Jan 2026 | Confirmed |

**Primary Market**: Global — Amsterdam NL HQ but 85 countries with significant North American growth push since 2023
**International Revenue %**: Not disclosed; estimated >90% non-NL based on property distribution (15,000 properties across 85 countries; NL is a small fraction)
**Expansion Trajectory**: Mews has systematically entered every major hospitality market via a combination of organic growth and targeted acquisitions, typically acquiring regional PMS vendors to migrate their customer bases. North America became the 2023–2024 priority, adding three dedicated acquisitions. APAC and DACH entered via 2024–2025 acquisitions. The $300M Series D will fund further AI-driven geographic push.

---

### M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Oct 2025 | DataChat (USA) | Undisclosed | Generative AI analytics platform; conversational BI for hotels | Accelerate "agentic hospitality" — natural language hotel data interaction; 14th acquisition | mews.com press; Skift | Confirmed |
| Sep 2025 | Flexkeeping (Slovenia/global) | Undisclosed | Hotel housekeeping and operations automation platform | Native housekeeping suite in PMS; reduces ops silos; 13th acquisition | mews.com press; Axios | Confirmed |
| Jan 2025 | Clarity Hospitality Software Solutions (UK/APAC) | Undisclosed | APAC + UK regional PMS customer base | APAC market entry; UK reinforcement; 12th acquisition | Yahoo Finance; mews.com blog | Confirmed |
| Nov 2024 | Quotelo | Undisclosed | Group booking and event quoting software | Event/group revenue management capability added | Tracxn | Confirmed |
| Nov 2024 | Atomize (Sweden) | Undisclosed | AI-driven Revenue Management System | Native RMS added to Hospitality OS; eliminates third-party RMS dependency | Kinnevik; PhocusWire | Confirmed |
| May 2024 | HS/3 Hotelsoftware (Germany) | Undisclosed | DACH regional PMS customer base | DACH market entry and customer migration | Tracxn | Confirmed |
| Jan 2024 | Frontdesk Anywhere (USA) | Undisclosed | San Francisco cloud PMS; North American hotel customer base | North American scale-up; 3rd North American acquisition in 12 months | PR Newswire; PhocusWire | Confirmed |
| Apr 2023 | Hotello (Canada) | Undisclosed | Canadian cloud PMS customer base | North America expansion; independent hotel segment | PR Newswire; Hotel Dive | Confirmed |
| 2023 | Nomi (USA — Nashville) | Undisclosed | AI/hospitality tech startup | AI capability acquisition; talent acquisition (Nashville hospitality AI team) | ION Analytics | Confirmed |
| 2022 | Cenium (Norway) | Undisclosed | Luxury/resort PMS for complex property types | Resort and luxury segment coverage | PhocusWire | Confirmed |
| 2022 | Bizzon (Czech Republic) | Undisclosed | Restaurant POS for hotel F&B | POS capability in home market; Czech/European hotel F&B | PhocusWire; Mews Ventures | Confirmed |
| Aug 2021 | Hotel Perfect (UK) | Undisclosed | UK independent hotel PMS customer base | UK market expansion via customer base migration | PhocusWire | Confirmed |
| 2020 | base7booking (from Trivago, Netherlands) | Undisclosed | European cloud PMS; Trivago-built product | Acquire cloud-native European PMS customers; remove competitor | mews.com/ventures; Hotel Dive | Confirmed |
| Dec 2019 | Planet Winner (Belgium) | Undisclosed | Belgium's largest on-premise PMS (~300 European hotels) | Benelux market leadership; first acquisition; migrate Winner base to cloud | PR Newswire Dec 2019; mews.com blog | Confirmed |

**Divestitures**: None identified — Mews has been a net acquirer in all years since 2019
**M&A Pattern**: Mews runs a systematic "acquire-and-migrate" playbook: buy regional/segment-specific hotel PMS vendors (often with on-premise or legacy cloud products), migrate their customer bases onto the Mews platform, and sunset the acquired product. Secondary pattern: "acquire-and-integrate" for capability gaps (Atomize for RMS, Flexkeeping for housekeeping, DataChat for AI analytics). Internal M&A team of ~10 professionals (ION Analytics confirmed). CEO Matt Welle publicly stated target of up to 4 acquisitions per year.

---

### SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | Cloud-native SaaS — 100%; no on-premise version | mews.com product pages; founding architecture (2012) | Confirmed |
| Cloud Revenue % | 100% cloud | Cloud-native since founding; no hybrid mode | Confirmed |
| Recurring Revenue % | ~85–95% estimated (subscription + payments + marketplace) | SaaS per-room model + embedded payments take-rate + marketplace rev share | Estimated |
| Payment Integrations | Mews Payments (embedded, proprietary); Stripe; iDEAL; Bancontact; 1,000+ marketplace payment connectors | mews.com/marketplace; mews.com product pages | Confirmed |
| Platform Stack | React/TypeScript frontend; .NET/C# backend (inferred from job postings); Azure cloud; REST API; multi-tenant | LinkedIn job postings tech keywords; mews.com developer docs | Estimated |
| API / Integration Model | Open REST API; Mews Marketplace with 1,000+ certified integrations; developer portal with full documentation | mews.com/marketplace; mews.com developer docs | Confirmed |
| Migration Status | Fully cloud — no migration required. Acquired companies' customers are migrated to Mews cloud. | mews.com blog (acquisition announcements consistently describe customer migration) | Confirmed |
| AI / Next-Gen | Agentic hospitality roadmap: DataChat generative AI analytics; automated workflows; Mews BI "DataChat" conversational interface | mews.com press Jan 2026; mews.com/blog/2025-hospitality-highlights | Confirmed |

---

### Growth Scorecard

| Dimension | Score (1-10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | **9** | Revenue CAGR ~49% (2022–2024 confirmed); Aug 2025 run-rate €330M (+65% from 2024 €200M); explosive trajectory sustained across multiple years; COVID trough distorts longer-term view |
| Funding Momentum | **10** | $375M raised in last 3 years (Mar 2025: $75M + Jan 2026: $300M); $2.5B valuation (Jan 2026); $100M debt (Sep 2024); total ~$812M raised; 16–20 institutional investors including EQT Growth, Tiger Global, Kinnevik |
| Employee Growth | **8** | CAGR ~24% (2023–2026): 800+ → 1,520; just below 25% hypergrowth threshold; hiring across NL, CZ, ES, US simultaneously; some integration-period headcount normalization in 2025 |
| Geographic Expansion | **10** | 85 countries served (2025); deliberate market-entry acquisitions in Belgium (2019), UK (2021), Czech Republic/Nordic (2022), North America ×3 (2023–2024), DACH (2024), APAC (2025); intercontinental since 2023 |
| M&A Activity | **10** | 14 acquisitions 2019–2025; 10 acquisitions in last 3 years (2023–2025 alone); clear dual pattern: market-entry consolidation + capability-building; CEO targets 4/year; dedicated M&A team of ~10 |
| SaaS Maturity | **10** | Cloud-native from 2012 founding; 100% cloud, no on-premise; embedded payments on $19.7B TPV (2025); open REST API with 1,000+ certified integrations; AI (agentic hospitality) roadmap; #1 Hotel Tech Report PMS three consecutive years |
| **COMPOSITE SCORE** | **9.5** | **Rocket — hypergrowth unicorn at $2.5B valuation; defines hotel PMS category standard** |

**Classification Thresholds**:
- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor ← **Mews: 9.5**
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "Mews Systems Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [9, 10, 8, 10, 10, 10]
```

---

### Why Is the M&A Attractiveness Score Only 3.06/5.0?

The Growth Scorecard above (9.5/10 — Rocket) measures Mews's performance as a business. The **M&A Attractiveness Score of 3.06/5.0** measures fit for SolStein's acquisition thesis. These are intentionally different measures.

The three High-weight SolStein M&A criteria are disqualifying for Mews:

| SolStein Criterion | Mews Reality | Score |
| --- | --- | --- |
| Ownership attractiveness (founder-owned, no PE) | 16–20 institutional investors; IPO-track; EQT Growth as lead | 1/5 |
| Revenue scale fit (€1M–€15M ARR) | €200M ARR in 2024; €330M run-rate Aug 2025 — 22–330× above ceiling | 1/5 |
| Geographic fit (NL/BE niche) | Amsterdam HQ but 85 countries; NL/BE is <5% of customer base | 2/5 |

The remaining dimensions (tech stack, lock-in, vertical depth) all score 5/5 — reflecting Mews's genuine excellence. This pulls the composite to 3.06 despite the three disqualifying High-weight scores.

**Adjusted acquisition-feasibility score (High-weight dimensions only): 1.3/5.0**

Mews is a **reference / valuation benchmark company** for SolStein, not a target.

---

### Strategic Value to SolStein

1. **Valuation anchor**: Hotel PMS commands 7–8× revenue at Mews's growth rate; NL/BE niche targets would trade at 3–5× revenue in private M&A
2. **Technology standard**: Defines what hotels expect — cloud-native, open API, embedded payments, AI
3. **Competitive displacement map**: Hotels NOT on Mews (under 50 rooms, price-sensitive, NL/BE-first) are the natural market for SolStein acquisitions (Misterbook, Valk Solutions, Juniper)
4. **Acquisition supply signals**: Mews already acquired Winner Hotel Software (BE, 2019) and base7booking (NL, from Trivago, 2020), reducing the available independent NL/BE hotel PMS pool
5. **IPO intelligence**: Mews's IPO will publicly validate cloud hotel PMS revenue multiples — useful for SolStein deal pricing

---

*Sources: mews.com (press releases Jan 2026, Sep 2025, Oct 2025, about-us, ventures, blog), Kinnevik Year-End Release 2025, Kinnevik Q4 2022 Release, Kinnevik investor page (mews.com transformation), Getlatka (Dec 2024), Clay.com dossier, Crunchbase/Tracxn (funding rounds, acquisition count), PR Newswire (Winner Dec 2019, Frontdesk Jan 2024, Flexkeeping Sep 2025, DataChat Oct 2025), PhocusWire (Frontdesk, Flexkeeping), Hotel Dive (Hotello, Frontdesk), Yahoo Finance (Clarity Jan 2025), Axios (Flexkeeping Sep 2025, "13th acquisition"), Skift (DataChat Oct 2025, "14th acquisition"), ION Analytics/Mergermarket (CEO interview; 4 acquisitions/year target; IPO signal), Wilson Sonsini advisory announcement (Series D Jan 2026), Vestbee (Jan 2026 Series D), mews.com/about-us timeline.*
