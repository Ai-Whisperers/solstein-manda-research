# Mews Systems

**Category**: Hotel PMS
**Country**: NL
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history Mews Systems @HORECA_IT/mews-systems/
@research-horeca-company Mews Systems @HORECA_IT/mews-systems/
```
