# Mews Systems — Deep Analysis

**Category**: Hotel PMS (Property Management System) / Hospitality OS
**Country**: NL (HQ Amsterdam; Czech-founded)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — not a direct SolStein acquisition target

---

## 1. Company Fundamentals

| Metric | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Mews Systems B.V. | Crunchbase | Confirmed |
| HQ | Amsterdam, Netherlands | mews.com | Confirmed |
| Founded | 2012 (Prague CZ) | mews.com/about-us | Confirmed |
| Employees | ~1,300–1,400 | mews.com/ventures, Getlatka | Estimated |
| CEO | Matthijs (Matt) Welle (Dutch, joined 2013) | mews.com press | Confirmed |
| Founder | Richard Valtr (Czech, founder 2012) | mews.com, Sifted | Confirmed |
| Revenue FY2024 | ~$200M | Getlatka | Estimated |
| Run-rate revenue Aug 2025 | EUR 330M | Kinnevik investor page | Confirmed |
| SaaS gross profit growth 2025 | +55% YoY | mews.com press Jan 2026 | Confirmed |
| Valuation (Jan 2026) | $2.5 billion | mews.com press Jan 2026 | Confirmed |
| Total funding raised | ~$810M (equity + debt) | Clay.com, Tracxn | Estimated |
| Ownership | Multi-investor VC/growth equity | mews.com press Jan 2026 | Confirmed |
| IPO readiness | CEO stated "realistic option" (2024) | ION Analytics/Mergermarket | Estimated |

Mews is among the **top 3 hotel PMS vendors globally by customer count** and the **#1 ranked PMS by Hotel Tech Report** for three consecutive years (2024, 2025, 2026). It has transitioned from a single-market PMS startup to a full **Hospitality Operating System** — encompassing PMS, POS, RMS, Housekeeping, Payments, and Kiosk.

---

## 2. HORECA Market Position

### Global Scale

| Metric | Value (2025/Q4) | Source | Confidence |
|---|---|---|---|
| Properties on platform | 15,000 | mews.com press Jan 2026 | Confirmed |
| Monthly active hoteliers | 132,000+ | mews.com press Jan 2026 | Confirmed |
| Countries | 85 | mews.com press Jan 2026 | Confirmed |
| Reservations checked in (2025) | 42.3 million | mews.com press Jan 2026 | Confirmed |
| Self-service kiosk check-ins | 3.2 million (2025) | mews.com press Jan 2026 | Confirmed |
| Platform Transaction Volume | $19.7 billion (2025) | mews.com press Jan 2026 | Confirmed |
| Revenue generated for hoteliers via Mews Spaces | $537 million (2025) | mews.com press Jan 2026 | Confirmed |

### NL/BE Market Presence

Mews has a **historically strong Benelux foothold**, partly through its 2019 acquisition of **Winner Hotel Software** (Belgium), which served 300+ European hotels. Notable NL/BE customers include:

- **Bilderberg Hotels** (12 NL/DE properties) — mid-rollout
- **WestCord Hotels** (NL)
- **Amrâth Hôtels** (NL)
- **GuestHouse Hotels** (Kaatsheuvel, NL)
- **Yalo** (Ghent, BE)

Mews competes in the NL/BE market against Valk Solutions, Misterbook, and legacy on-premise vendors. Given its global scale and pricing (per-room SaaS), it primarily targets **hotels with 50+ rooms** — leaving smaller independent hotels and B&Bs underserved and as a market opportunity for niche NL/BE players.

---

## 3. Product & Technology

### Platform Overview

Mews has evolved from a pure PMS to a **full-stack Hospitality Operating System**:

| Module | Description | Status |
|---|---|---|
| **Mews PMS** | Core cloud-native PMS | GA; #1 HTR 3 years |
| **Mews POS** | Hotel point-of-sale | GA; #1 HTR 2026 |
| **Mews Payments** | Embedded fintech / payment processing | GA; $19.7B TPV in 2025 |
| **Mews RMS** | Revenue Management System (via Atomize acquisition) | Integrated 2024/25 |
| **Mews Kiosk** | Self-service check-in/out hardware + software | GA; 3.2M uses in 2025 |
| **Mews Spaces** | Multi-space (non-room) booking and revenue | GA; $537M revenue for hotels in 2025 |
| **Mews Housekeeping** | Task automation + team collaboration (via Flexkeeping acq.) | Integrated 2025 |
| **Mews BI / DataChat** | Generative AI analytics (via DataChat acquisition) | In integration 2025/26 |
| **Mews Marketplace** | Open API ecosystem; 1,000+ integrations | GA |

### Tech Stack Highlights

| Attribute | Detail | Source | Confidence |
|---|---|---|---|
| Architecture | Cloud-native, multi-tenant SaaS | mews.com product pages | Confirmed |
| API | Open REST API; developer-friendly | mews.com/marketplace | Confirmed |
| Integrations | 1,000+ third-party apps via marketplace | mews.com | Confirmed |
| AI strategy | Agentic hospitality — DataChat acquisition, automated workflows | mews.com press Jan 2026 | Confirmed |
| Mobile | Guest-facing mobile journeys + staff apps | mews.com | Confirmed |
| Payments | Embedded payment processing (fintech layer) | mews.com | Confirmed |

Mews defines the **technical benchmark** for what a modern hotel PMS looks like: cloud-native, open API, embedded payments, AI-augmented operations.

---

## 4. M&A Ownership & Succession

### Current Cap Table (Approximate, Post-Jan 2026)

| Investor | Entry Round | Notes |
|---|---|---|
| EQT Growth | Series D Jan 2026 | Lead; Swedish PE/growth equity giant |
| Atomico | Series D Jan 2026 | New; Skype-founders' VC |
| HarbourVest Partners | Series D Jan 2026 | New; global PE fund-of-funds |
| Kinnevik | Series C / D T1 / D | Major shareholder; Swedish listed investment company |
| Battery Ventures | Series B / C / D | Long-term VC |
| Tiger Global | Growth Round / D | Crossover VC/hedge fund |
| Notion Capital | Series A / B / C | Early SaaS VC |
| henQ | Seed / A / B / C | Dutch early-stage VC |
| Goldman Sachs AM | Series C / Growth | Co-investor |

### Founder Status

- **Richard Valtr**: Active as Founder (not CEO); cited in Jan 2026 press release; likely has meaningful equity stake but not control
- **Matt Welle**: Active CEO; operationally in charge

### Succession & Exit Outlook

| Signal | Assessment |
|---|---|
| Founder retirement gap | None — both founders active and growth-oriented |
| Distressed PE | None — all investors are long-term growth backers |
| IPO signal | CEO explicitly mentioned IPO as "realistic option" in 2024; $2.5B valuation makes this a logical path |
| Secondary exit likelihood | Low for SolStein; EQT Growth as lead makes a trade sale or IPO the likely outcome |

**Conclusion**: Mews has zero acquisition attractiveness from SolStein's ownership-fit angle. The ownership structure is deeply institutionalized, the company is on an IPO trajectory, and the valuation is 100–250x outside SolStein's range.

---

## 5. Financial Growth & Trajectory

| Year | Revenue / ARR | Growth Signal | Source | Confidence |
|---|---|---|---|---|
| 2019 | Low (pre-scale) | — | Getlatka | Estimated |
| 2021 | ~$30–50M (est.) | Early traction | Getlatka (trend) | Estimated |
| 2024 (FY) | ~$200M | Strong scale | Getlatka (Dec 2024) | Estimated |
| Aug 2025 (run-rate) | EUR 330M | +~65% YoY | Kinnevik investor page | Confirmed |
| 2025 SaaS GP growth | +55% | Accelerating | mews.com press Jan 2026 | Confirmed |

### Growth Drivers

1. **Acquisitions**: 14 acquisitions migrate legacy customer bases onto Mews cloud
2. **North America expansion**: Frontdesk Anywhere + Nomi establish US footprint
3. **Payments attach rate**: Embedded payments (Mews Payments) drive transaction revenue on $19.7B TPV
4. **Agentic AI**: DataChat + Flexkeeping create new automation-driven upsell
5. **Mews Spaces**: Non-room inventory monetization ($537M for hotels in 2025)

The company is clearly in **hypergrowth**: from ~$200M to EUR 330M run-rate in under a year implies >60% revenue growth. The $300M Series D (Jan 2026) will accelerate AI investment and geographic expansion.

---

## 6. HORECA Vertical Depth

Mews is **exclusively focused on hospitality** — hotels, hostels, apart-hotels, resorts, and hybrid spaces. It does not serve restaurant-only or food service verticals (though it has a POS module for F&B within hotels).

| Aspect | Detail | Source | Confidence |
|---|---|---|---|
| Primary vertical | Hotels (50+ rooms; independent + groups + chains) | mews.com | Confirmed |
| Secondary vertical | Hostels, apart-hotels, hybrid spaces, resorts | mews.com | Confirmed |
| F&B | Hotel F&B only (via Mews POS); not standalone restaurant | mews.com | Confirmed |
| Non-HORECA | None | mews.com | Confirmed |
| Niche depth | Full hotel OS — not a point solution | mews.com product | Confirmed |
| Competitor set | Oracle Opera, Cloudbeds, Apaleo, Protel, SiteMinder, Guestline | Contrary Research | Estimated |

Mews has achieved **extraordinary vertical depth** within the hotel segment: it has replaced a five-part tech stack (PMS + POS + RMS + payments + housekeeping) with a single platform, creating extremely high switching costs.

---

## 7. Valuation & Business Model

### Business Model

- **SaaS per-room per-month**: Core PMS pricing model (exact figures not public; typical enterprise SaaS pricing for PMS is €3–€10/room/month)
- **Payment processing revenue**: Percentage of transaction volume ($19.7B TPV at typical 0.2–0.5% margin = $40–100M revenue)
- **Marketplace**: Revenue share from 1,000+ integrations
- **Mews Spaces**: Non-room booking commission/SaaS
- **Hardware**: Kiosk (3.2M uses in 2025)

### Valuation Analysis

| Metric | Value | Source | Confidence |
|---|---|---|---|
| Valuation (Jan 2026) | $2.5 billion | mews.com press | Confirmed |
| Run-rate revenue (Aug 2025) | EUR 330M | Kinnevik | Confirmed |
| Revenue multiple | ~7.6x run-rate revenue | Calculated | Estimated |
| Prior valuation (Mar 2024) | $1.2 billion | Skift reference | Confirmed |
| Valuation growth (24 months) | 2.1x | Calculated | Estimated |

At **7–8x revenue**, Mews trades at a premium consistent with high-growth (>50% YoY) cloud SaaS with embedded payments revenue. This multiple provides a useful **upper-bound benchmark** for hotel PMS valuations. Smaller, slower-growing NL/BE hotel PMS companies would likely trade at **3–5x revenue** in a private M&A context.

---

## 8. M&A Attractiveness Scorecard

> **Note**: Scores reflect SolStein's acquisition criteria, not Mews's general quality. Low scores do NOT mean Mews is a poor business — they mean it is a poor *fit* for SolStein's thesis.

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | **1** | Multi-VC/PE cap table (EQT Growth, Kinnevik, Battery, Tiger, Atomico, HarbourVest); IPO-track company; zero founder-succession gap | mews.com press Jan 2026 |
| **Revenue scale fit** | High | **1** | EUR 330M ARR run-rate vs. SolStein target of €1M–€15M ARR; 22–330x above ceiling | Kinnevik, Getlatka |
| **Geographic fit** | High | **2** | Amsterdam HQ is NL; but customer base is 85 countries — not NL/BE-niche. NL/BE is a small slice of a global footprint | mews.com press Jan 2026 |
| **Tech stack modernity** | Medium | **5** | Cloud-native, open API, AI-augmented, embedded payments — defines the category standard | mews.com product pages |
| **Customer lock-in** | Medium | **5** | Full-stack OS lock-in: PMS + POS + Payments + RMS + Housekeeping; switching costs are very high | mews.com, Contrary Research |
| **Vertical depth** | Medium | **5** | Exclusively hotel-focused; deepest technology stack in the vertical globally | mews.com |
| **Integration potential** | Low | **5** | 1,000+ marketplace integrations; open REST API; developer-friendly | mews.com/marketplace |
| **Growth trajectory** | Low | **5** | EUR 330M run-rate; +55% SaaS GP; 14 acquisitions; AI roadmap; IPO-ready | mews.com, Kinnevik |

### Composite Score Calculation

| Dimension | Weight Factor | Weighted Score |
|---|---|---|
| Ownership attractiveness | 3 | 3 × 1 = 3 |
| Revenue scale fit | 3 | 3 × 1 = 3 |
| Geographic fit | 3 | 3 × 2 = 6 |
| Tech stack modernity | 2 | 2 × 5 = 10 |
| Customer lock-in | 2 | 2 × 5 = 10 |
| Vertical depth | 2 | 2 × 5 = 10 |
| Integration potential | 1 | 1 × 5 = 5 |
| Growth trajectory | 1 | 1 × 5 = 5 |
| **Total** | **17** | **52** |

**Composite Score: 52 / 85 = 3.06 / 5.0**

> The score is misleading in isolation. The **three High-weight dimensions** (ownership, revenue, geography) all score 1–2, which would make this a **0.9–1.3/5.0** if only acquisition-feasibility criteria are applied. The high scores in lower-weight dimensions (tech, lock-in, vertical depth) reflect Mews's genuine excellence as a business — not its suitability as an acquisition target for SolStein.

**Adjusted acquisition-feasibility score (High-weight only): 1.3 / 5.0**

---

### Confidence Band

| Confirmed data points | ~22 of ~35 total data points |
|---|---|
| Estimated data points | ~11 |
| Unknown data points | ~2 |
| **Confidence band** | **Medium-High** — core financial and ownership data confirmed from primary sources (mews.com press releases, Kinnevik investor page) |

---

### Overall Assessment

**Mews Systems is NOT an acquisition target for SolStein.**

It is a **$2.5B unicorn on an IPO track**, owned by global institutional investors, generating EUR 330M ARR, and employing ~1,300 people. Every dimension of SolStein's thesis (founder-owned, €1–15M ARR, NL/BE niche, succession gap) is the inverse of Mews's profile.

**Strategic value to SolStein is as a reference company**:

1. **Valuation benchmark**: Hotel PMS commands 7–8x revenue at Mews's growth rate; NL/BE niche targets should be valued at 3–5x revenue in private deals
2. **Technology standard**: Mews defines what hotels expect from a modern PMS — cloud-native, open API, embedded payments, AI
3. **Competitive displacement map**: NL/BE hotels NOT on Mews (and not intending to move to Mews) are the target market for a SolStein-acquired NL/BE hotel PMS
4. **Acquisition supply**: Mews already acquired Winner Hotel Software (BE, 2019) — remaining independent NL/BE hotel PMS players (Misterbook, Valk Solutions, Juniper) are the actual target pool
5. **Market intelligence**: Mews's IPO announcement will validate cloud hotel PMS valuations publicly, which will inform SolStein's own deal pricing

---

### Recommended Next Step

**No acquisition action.** Use Mews as:
- A pricing/valuation anchor when modeling NL/BE hotel PMS deals
- A competitive reference point when due-diligencing Misterbook, Valk Solutions, or Juniper
- A customer signal: hotels in NL/BE that cannot afford Mews (typical hotel with 20–50 rooms) are the natural customer base of SolStein's target companies

---

*Sources: mews.com (press releases, product pages, about-us, careers, ventures), Kinnevik investor page, Getlatka, Clay.com dossier, Tracxn, Hotel Dive, Skift, Sifted, Contrary Research, ION Analytics/Mergermarket, Vestbee, Hotel Tech Report citations, HotelTechnologyNews (Winner acquisition), HFTP (Bilderberg case study).*
