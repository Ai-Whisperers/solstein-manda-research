# Mews Systems — Corporate History

**Category**: Hotel PMS (Property Management System)
**Country**: NL (legally HQ'd Amsterdam; founded Prague CZ)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape (not a direct acquisition target)

---

## Summary Assessment

Mews is a **unicorn-scale, VC/growth-equity-backed** hotel technology company valued at **$2.5 billion** (Jan 2026). With ~1,300 employees, €330M run-rate revenue, and 15,000 hotel customers across 85 countries, it is orders of magnitude outside SolStein's acquisition criteria. It serves as a critical **market benchmark** and **valuation reference** for the hotel PMS vertical.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Mews Systems B.V. | Crunchbase / company filings | Confirmed |
| HQ | Amsterdam, Netherlands | mews.com / multiple press | Confirmed |
| Founded (product/company) | 2012 | mews.com/about-us, Sifted, Contrary Research | Confirmed |
| Founded in | Prague, Czech Republic (later HQ moved to Amsterdam) | Sifted, TheRecursive, Contrary Research | Confirmed |
| Founder(s) | Richard Valtr (Czech; concept + founder); Matthijs (Matt) Welle (Dutch; joined 2013, now CEO) | mews.com/about-us, press | Confirmed |
| KvK number | Not publicly located in searches | KvK.nl search (not retrieved) | Unknown |
| Employees (2024/25) | ~1,300–1,400 | mews.com/ventures, Getlatka, LinkedIn | Estimated |
| Customers (Q4 2025) | 15,000 properties | mews.com press release Jan 2026 | Confirmed |
| Countries | 85 | mews.com press release Jan 2026 | Confirmed |
| Monthly active hoteliers | 132,000+ | mews.com press release Jan 2026 | Confirmed |
| Platform Transaction Volume 2025 | $19.7 billion | mews.com press release Jan 2026 | Confirmed |
| Revenue (FY 2024) | ~$200M | Getlatka (cited Dec 2024) | Estimated |
| Run-rate revenue (Aug 2025) | EUR 330M | Kinnevik investor page | Confirmed |
| SaaS gross profit growth 2025 | 55% YoY | mews.com press release Jan 2026, Kinnevik | Confirmed |
| Total funding raised | ~$710M–$770M | Clay.com dossier, Tracxn | Estimated |
| Valuation (Jan 2026) | $2.5 billion | mews.com press release Jan 2026 | Confirmed |
| Valuation (Mar 2024) | $1.2 billion (unicorn) | Skift (Jan 2026 article reference) | Confirmed |
| Current ownership | VC/growth equity — EQT Growth (lead), Atomico, HarbourVest, Kinnevik, Battery Ventures, Tiger Global | mews.com press Jan 2026 | Confirmed |
| IPO status | Discussed as "realistic option" per CEO (2024) | ION Analytics / Mergermarket | Estimated |
| Seed round | Nov 2016: $1.6M (incl. henQ) | Clay.com dossier | Estimated |
| Series A | Jun 2018: $7.1M (Notion Capital lead) | Clay.com dossier | Estimated |
| Series B | Aug 2019: $33M (Battery Ventures lead) | Clay.com dossier | Estimated |
| Series C | Dec 2022: $185M (Kinnevik + Goldman Sachs AM lead) | Clay.com dossier | Estimated |
| Debt financing | Dec 2022: Columbia Lake Partners (amount undisclosed) | Clay.com dossier | Estimated |
| Series D tranche 1 | Mar 2024: $110M (Kinnevik lead) → unicorn status | Clay.com dossier, Tracxn | Estimated |
| Debt financing 2 | Sep 2024: $100M (Vista Credit Partners) | Clay.com dossier, Tracxn | Estimated |
| Growth round | Mar 2025: $75M (Tiger Global lead; Kinnevik, Goldman Sachs, Battery Ventures) | Hotel Dive, Clay.com | Confirmed |
| Series D (latest) | Jan 2026: $300M (EQT Growth lead; Atomico, HarbourVest, Kinnevik, Battery, Tiger Global) | mews.com press Jan 2026 | Confirmed |
| Total acquisitions completed | 14 (as of Jan 2026) | mews.com press Jan 2026, Tracxn | Confirmed |
| Named #1 PMS globally | 2024, 2025, 2026 (Hotel Tech Report) | mews.com press Jan 2026 | Confirmed |

---

## Founding & Early History

Richard Valtr, a Czech entrepreneur and former hotelier, founded Mews in **2012 in Prague** after experiencing firsthand the limitations of legacy hotel software. While building a hotel in Prague, he recognized that the industry ran on fundamentally outdated, on-premise systems — and set out to build a cloud-native alternative that would eliminate the physical reception desk as a bottleneck.

**Matthijs (Matt) Welle**, a Dutch national, joined as co-founder/CEO in **2013**, bringing operational and commercial leadership. Welle subsequently drove the Amsterdam HQ decision, which made Mews legally a Dutch company (Mews Systems B.V.) while retaining Czech engineering roots.

The product went live at a hotel in Prague and began spreading across Central Europe before the company pivoted to an international-first, Amsterdam-headquartered structure.

---

## Funding Rounds — Complete Timeline

| Round | Date | Amount | Lead Investor(s) | Other Investors | Notes |
|---|---|---|---|---|---|
| Seed | Nov 2016 | ~$1.6M | Undisclosed | henQ | Pre-product funding |
| Series A | Jun 2018 | $7.1M | Notion Capital | henQ, Thayer Ventures | First institutional VC |
| Series B | Aug 2019 | $33M | Battery Ventures | Notion Capital, henQ, Thayer Ventures | Funded international expansion |
| Series C | Dec 2022 | $185M | Kinnevik, Goldman Sachs AM | Battery Ventures, Notion Capital, henQ, Thayer Ventures | Also included Columbia Lake Partners debt |
| Debt financing | Dec 2022 | Undisclosed | Columbia Lake Partners | — | Concurrent with Series C |
| Series D (T1) | Mar 2024 | $110M | Kinnevik | Existing investors | Unicorn milestone ($1.2B valuation) |
| Debt financing | Sep 2024 | $100M | Vista Credit Partners | — | Conventional debt |
| Growth round | Mar 2025 | $75M | Tiger Global | Kinnevik, Goldman Sachs, Battery Ventures | Pre-Series D extension |
| Series D | Jan 2026 | $300M | EQT Growth | Atomico, HarbourVest Partners, Kinnevik, Battery Ventures, Tiger Global | $2.5B valuation |

**Cumulative equity + debt raised**: ~$810M

---

## M&A History — Acquisitions BY Mews (14 total)

| # | Company | Country | Date | Domain | Notes |
|---|---|---|---|---|---|
| 1 | Planet Winner (Winner Hotel Software) | BE | 2019 | Hotel PMS | Belgian PMS serving 300+ EU hotels; key Benelux foothold |
| 2 | Base7Booking | CH/DE | 2020 | Hotel PMS | Swiss-based cloud PMS |
| 3 | Hotel Perfect | IE | 2021 | Hotel PMS | Irish hotel management software |
| 4 | Bizzon | CZ | 2022 | Restaurant POS | Czech hospitality POS |
| 5 | Cenium | NO | 2022 | Hospitality ERP | Norwegian hospitality management |
| 6 | Hotello | CA (Montreal) | Apr 2023 | Hotel PMS | Cloud hotel management; North America expansion |
| 7 | Nomi | US (Nashville) | Sep 2023 | Guest Experience / AI | AI-driven personalization; US market |
| 8 | Frontdesk Anywhere | US (San Francisco) | Jan 2024 | Hotel PMS | Cloud PMS; North America |
| 9 | HS/3 Hotelsoftware | DE | May 2024 | Hotel PMS | German market; legacy customer base migration |
| 10 | Quotelo | Unknown | Nov 2024 | Unknown | — |
| 11 | Atomize | SE | Nov 2024 | Revenue Management System (RMS) | Swedish RMS; integrated into Mews platform |
| 12 | DataChat | US | Oct 2025 | Generative AI analytics | AI/BI platform; agentic hospitality roadmap |
| 13 | Flexkeeping | SI | Sep 2025 | Housekeeping ops | Automated housekeeping + team collab |
| 14 | (Undisclosed 14th) | — | ~Jan 2026 | — | Referenced in Jan 2026 press release |

> **Key observation**: Mews acquired **Winner Hotel Software (Belgium, 2019)** — a PMS serving 300+ EU hotels — giving Mews its initial Benelux foothold. Several NL/BE hotels currently on Mews likely originated through this acquisition.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Mews Systems B.V.<br/>(Amsterdam, NL — legal HQ)"]
    B["EQT Growth (lead, Jan 2026)"]
    C["Atomico"]
    D["HarbourVest Partners"]
    E["Kinnevik"]
    F["Battery Ventures"]
    G["Tiger Global"]
    H["Notion Capital (early)"]
    I["henQ (seed)"]
    J["Goldman Sachs AM"]

    B -->|"Series D lead"| A
    C -->|"Series D new"| A
    D -->|"Series D new"| A
    E -->|"Series C/D"| A
    F -->|"Series B/C/D"| A
    G -->|"Growth/Series D"| A
    H -->|"Series A/B/C"| A
    I -->|"Seed/A/B/C"| A
    J -->|"Series C/Growth"| A

    A --> K["Mews Ventures (acquisition vehicle)"]
    K --> L["14 acquired companies<br/>(2019–2026)"]
    K --> M["Winner Hotel Software BE (2019)"]
    K --> N["Bizzon CZ (2022)"]
    K --> O["Atomize SE (2024)"]
    K --> P["Flexkeeping SI (2025)"]
    K --> Q["DataChat US (2025)"]
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Mews Systems — Key Milestones
    2012 : Founded by Richard Valtr in Prague CZ
    2013 : Matt Welle joins as CEO; Amsterdam HQ established
    2016 : Seed round ~$1.6M (henQ)
    2018 : Series A $7.1M (Notion Capital); product-market fit confirmed
    2019 : Series B $33M (Battery Ventures); acquired Winner Hotel Software (BE)
    2020 : Acquired Base7Booking (CH)
    2021 : Acquired Hotel Perfect (IE)
    2022 : Series C $185M (Kinnevik + GS AM); acquired Bizzon + Cenium
    2023 : Acquired Hotello (CA) + Nomi (US); North America push
    2024 : Series D T1 $110M → Unicorn at $1.2B; Frontdesk Anywhere acquired; Atomize + Quotelo acquired; HS/3 acquired
    2025 : $75M growth round (Tiger Global); Flexkeeping + DataChat acquired; EUR 330M run-rate; 15,000 customers
    2026 : Series D $300M (EQT Growth) → $2.5B valuation; 14th acquisition complete; #1 PMS globally (Hotel Tech Report 3rd year)
```

---

## M&A Feasibility Assessment

### Is Mews an Acquisition Target for SolStein?

**Answer: No. Definitively not a direct target.**

| Factor | Assessment |
|---|---|
| **Scale** | $2.5B valuation / EUR 330M ARR — ~22–330x above SolStein's target range |
| **Ownership** | Multi-stakeholder VC/PE (EQT Growth, Kinnevik, Battery, Tiger, Atomico, HarbourVest) — no founder-owned angle |
| **Succession gap** | None — active CEO (Matt Welle), active founder (Richard Valtr), growth trajectory upward |
| **Geography** | Global (85 countries), not NL/BE niche |
| **Exit path** | IPO floated as likely outcome; not a private buyout candidate for SolStein |

### Role for SolStein

Mews is the **dominant global reference point** for cloud-native hotel PMS. It should be used:

1. **Valuation benchmarking**: Mews trades at ~7–8x revenue. NL/BE hotel PMS niche players may command 3–5x.
2. **Tech standard**: Mews defines what "modern" hotel PMS looks like — open API, marketplace, embedded payments, cloud-native.
3. **Competitive displacement signal**: Hotels on legacy systems (vs. Mews) represent the acquisition opportunity — NL/BE companies serving hotels that cannot afford or don't need Mews-scale solutions.
4. **Acquisition supply**: Mews's own M&A activity (14 acquisitions) has consolidated some NL/BE targets (Winner Software). Remaining independent players in NL/BE are the opportunity.

---

*Sources: mews.com press releases, Kinnevik investor page, Clay.com funding dossier, Tracxn, Hotel Dive, Crunchbase, Sifted, TheRecursive, Contrary Research, ION Analytics/Mergermarket, Hotel Tech Report citations.*
