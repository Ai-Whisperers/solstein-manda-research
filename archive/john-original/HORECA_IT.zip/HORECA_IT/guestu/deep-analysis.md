# GuestU — Deep Analysis

**Category**: Guest Engagement
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

> **CRITICAL FLAG**: GuestU is **not an independent acquisition target**. It was acquired by Nonius (Portugal) circa 2018–2020 and now operates solely as a product line ("Nonius Mobile") within NONIUSSOFT S.A. Additionally, no Dutch (NL) entity exists — the company is Portuguese. The brief's "Amsterdam, NL" attribution is factually incorrect. All analysis below reflects the original GuestU entity and its current status within Nonius.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | NONIUSSOFT - SOFTWARE E CONSULTORIA PARA TELECOMUNICAÇÕES, S.A. (current parent) | play.google.com; apps.apple.com | Confirmed |
| HQ address | Moreira da Maia, Porto, Portugal (Nonius); original GuestU: Lisbon, Portugal | getlatka.com; tracxn.com | Confirmed |
| Founded | 2014 (GuestU startup); Nonius founded 2005 | tracxn.com; getlatka.com | Confirmed |
| CEO / MD | António Silva (Nonius CEO); Manuel Lima (GuestU Director post-acquisition) | getlatka.com; essential-business.pt | Estimated |
| Ownership structure | Wholly owned by Nonius (NONIUSSOFT S.A.); Nonius is privately held, no PE, no disclosed investors | getlatka.com ($0 funding); noniussolutions.com | Confirmed |
| Employees (FTE) | 4 (GuestU brand as of Jul 2024); Nonius group: 225 | tracxn.com; getlatka.com | Estimated |
| Revenue (latest estimate) | GuestU standalone: Unknown. Nonius group: $25.8M (2024) | getlatka.com | Estimated |
| Profitability | Unknown — Nonius group profitable (no external funding needed per getlatka) | getlatka.com | Unknown |
| Website | guestu.com (redirects to mobile.noniussolutions.com) | live URL check | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | Portugal (primary), global reach through Nonius's 17 offices | essential-business.pt; noniussolutions.com | Confirmed |
| Customer count | 250+ hotels using GuestU Phone or Super App (as of 2020 article) | essential-business.pt (2020) | Estimated |
| Target verticals | Hotels (full-service, boutique, resort); serviced apartments | hoteltechreport.com; noniussolutions.com | Confirmed |
| Market share estimate | #36 of 244 active competitors in hotel guest apps (Tracxn ranking) | tracxn.com | Estimated |
| Key competitors | Duve (Series B, $85M raised), Virdee, Iris Software, Criton (now also Nonius) | tracxn.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | GuestU Phone (branded smartphone for hotel rooms), GuestU App (white-label mobile app), Online Check-in, Digital Dining, Guest Web App | mobile.noniussolutions.com (guestu.com redirect); hoteltechreport.com | Confirmed |
| Tech stack | iOS + Android native apps; web app; AI-driven facial recognition for check-in; QR ordering | mobile.noniussolutions.com | Confirmed |
| Deployment model | Cloud/SaaS; mobile-first | mobile.noniussolutions.com | Confirmed |
| API availability | Integrates with PMS, CRS, CRM; loyalty programme connectors (per 2020 article) | essential-business.pt | Estimated |
| Key integrations | PMS systems, Nonius RMS, payment processors, IP printers | mobile.noniussolutions.com; hoteltechreport.com | Estimated |
| Mobile app | Yes — iOS and Android native apps; web app variant also available | mobile.noniussolutions.com; play.google.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | No — acquired by Nonius | essential-business.pt; noniussolutions.com | Confirmed |
| Investor type | Pre-acquisition: seed VCs (Portugal Ventures, Techstars, LeadX Capital). Post-acquisition: Nonius is the sole owner | tracxn.com | Confirmed |
| PE ownership | No PE involvement found at any stage | getlatka.com; tracxn.com | Confirmed |
| Succession signals | N/A — not an independent entity. Original founder Euclides Major listed as "Former Co-Founder" | tracxn.com | Confirmed |
| Last funding date | May 21, 2015 (Seed round, $1.1M) | tracxn.com | Confirmed |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Nonius group grew: $9M (2021) → $15M (2023) → $25.8M (2024) — 72% YoY growth in 2024 | getlatka.com | Estimated |
| Employee growth | Nonius group: grew to 225; GuestU brand team contracted to ~4 post-integration | tracxn.com; getlatka.com | Estimated |
| New markets | Nonius operating globally with 17 offices; UK expansion via Criton acquisition (2022) | noniussolutions.com | Confirmed |
| Recent product launches | In-App Messaging & Notifications (Feb 2025); Check-in Kiosk; Loyalty Program module | noniussolutions.com/2025/02/13 | Confirmed |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Hotels (primarily); serviced apartments; some resort properties | hoteltechreport.com; mobile.noniussolutions.com | Confirmed |
| GDPR/AVG compliance | Unknown — no explicit GDPR statement found for GuestU/Nonius Mobile | N/A | Unknown |
| Allergen management | N/A — not applicable to guest engagement platform | N/A | N/A |
| Fiscal compliance NL | N/A — Portuguese company, no NL operations confirmed | N/A | N/A |
| iDEAL/Bancontact/Tikkie support | Unknown — no Dutch payment integration documentation found | N/A | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Subscription/SaaS per-property pricing; quote-based (not publicly disclosed) | hoteltechreport.com | Estimated |
| Estimated ARR | GuestU standalone: Unknown. Nonius group: ~$25.8M total revenue (2024) | getlatka.com | Estimated |
| Estimated acquisition value | Not applicable — GuestU is not a separable entity within Nonius | N/A | N/A |
| Revenue per employee | Nonius group: ~$114K/employee ($25.8M ÷ 225) | getlatka.com calculation | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Already acquired by Nonius; founders exited; not available as standalone target | tracxn.com; essential-business.pt |
| Revenue scale fit | High | 1 | Not separable; Nonius group far exceeds thesis ceiling ($25.8M group revenue) | getlatka.com |
| Geographic fit | High | 1 | Portuguese company; no Dutch entity; Amsterdam attribution in brief was incorrect | tracxn.com; hoteltechreport.com |
| Tech stack modernity | Medium | 4 | Modern cloud-native SaaS; iOS/Android native; AI check-in; strong integrations | mobile.noniussolutions.com |
| Customer lock-in | Medium | 3 | 250+ hotel clients; white-label creates switching friction; but low review volume suggests limited NL/BE penetration | essential-business.pt; hoteltechreport.com |
| Vertical depth | Medium | 3 | Strong hotel guest engagement; 250+ clients; limited restaurant/café coverage | mobile.noniussolutions.com |
| Integration potential | Low | 3 | Good API/PMS integrations; could complement PMS or POS assets | mobile.noniussolutions.com |
| Growth trajectory | Low | 4 | Nonius group growing fast (72% YoY); expanding globally | getlatka.com |

**Composite Score**: 2.0 / 5.0  
**Confidence Band**: Narrow (structural disqualifiers are confirmed, not estimated)  
**Overall M&A Assessment**: GuestU fails the SolStein acquisition thesis on three critical dimensions simultaneously: it is not an independent company (acquired by Nonius ~2018–2020), it is geographically misaligned (Portuguese, not Dutch/Belgian), and its revenue is not separable from the Nonius group. The technology is modern and the product category is valid, but GuestU as a standalone target does not exist. Acquiring Nonius as a whole would be out of scope (>$25M revenue, Portuguese HQ, 225 employees).  
**Recommended Next Step**: Remove GuestU from the active target list. If SolStein seeks NL-based hotel guest engagement targets, evaluate Userguest (Amsterdam, founded 2018, AI-driven direct booking) as an alternative. Re-verify the original brief's source for the "Amsterdam, NL" attribution.
