# GuestU

**Category**: Guest Engagement
**Country**: NL
**City**: Amsterdam
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history GuestU @HORECA_IT/guestu/
@research-horeca-company GuestU @HORECA_IT/guestu/
```
