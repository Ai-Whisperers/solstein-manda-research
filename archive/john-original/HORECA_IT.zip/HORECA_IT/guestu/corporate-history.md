# GuestU — Corporate History

**Category**: Guest Engagement
**Country**: PT (not NL — see note below)
**Research Date**: 2026-04-30

> **RESEARCH NOTE**: The target brief described GuestU as "Amsterdam, NL." Research confirms GuestU is a Portuguese company headquartered in Lisbon, Portugal, with no Dutch legal entity found. The domain guestu.com now resolves to Nonius Mobile (mobile.noniussolutions.com), a product line of NONIUSSOFT S.A. (Portugal). GuestU was **acquired by Nonius** prior to 2022 and is no longer an independent company. This significantly affects M&A feasibility.

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | NONIUSSOFT - SOFTWARE E CONSULTORIA PARA TELECOMUNICAÇÕES, S.A. (parent); GuestU was an independent startup prior to acquisition | play.google.com (developer listing); essential-business.pt | Confirmed |
| KvK Number | N/A — no Dutch entity found | openkvk.nl search (no results); KVK search (no results) | Confirmed |
| Registered City | Lisbon, Portugal (original); Moreira da Maia, Portugal (Nonius HQ) | tracxn.com; hoteltechreport.com; getlatka.com | Confirmed |
| Founding Year | 2014 (GuestU original startup) | tracxn.com; hoteltechreport.com; essential-business.pt | Confirmed |
| Founders | Euclides Major (CEO), Joao Paiva Mendes (Co-Founder) | tracxn.com; essential-business.pt | Confirmed |
| Current Ownership | Owned by Nonius (NONIUSSOFT S.A.) — not independent | essential-business.pt; noniussolutions.com; pymnts.com | Confirmed |
| PE/Investor Ownership | No PE. Pre-acquisition investors: Portugal Ventures, LeadX Capital, Techstars, and 2 undisclosed others | tracxn.com; startups.co.uk | Confirmed |
| Employees (FTE) | ~4 (GuestU brand as of July 2024); Nonius group: 225 total | tracxn.com (4 as of Jul 2024); getlatka.com (225 Nonius group) | Estimated |
| Estimated Revenue | GuestU standalone: Unknown. Nonius group 2024: ~$25.8M USD | getlatka.com | Estimated |
| M&A History | Acquired by Nonius (Portugal) — date undisclosed, believed 2018–2020. Nonius then acquired Criton (UK) in March 2022, merging it with GuestU | essential-business.pt; noniussolutions.com/2022/03/16 | Confirmed |
| Investment Rounds | 1 round: Seed, May 21, 2015, $1.1M (Portugal Ventures, LeadX Capital, Techstars + 2 others) | tracxn.com; startups.co.uk | Confirmed |
| Name Changes | Brand absorbed into Nonius Mobile; guestu.com redirects to mobile.noniussolutions.com | guestu.com (live redirect) | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A[NONIUSSOFT S.A. - Moreira da Maia, Portugal] --> B[Nonius Mobile Product Line]
    B --> C[GuestU Brand - absorbed ca. 2018-2020]
    B --> D[Criton - acquired March 2022, UK]
    C --> E[GuestU Phone / GuestU App / White-label Mobile]
```

---

## Timeline

```mermaid
timeline
    title GuestU Key Events
    2013 : Concept originated from Lisbon Big Apps competition (Vodafone/Lisbon City Council) — €20K prize
    2014 : GuestU formally founded in Lisbon by Euclides Major and Joao Paiva Mendes
    2015 : Seed round — $1.1M from Portugal Ventures, LeadX Capital, Techstars
    2018 : Multiple growth funding rounds from Portugal Ventures and private investors (per essential-business.pt)
    2018-2020 : Acquired by Nonius (NONIUSSOFT S.A.) — exact year undisclosed
    2022 : Nonius acquires Criton (UK) and merges with GuestU to form expanded Nonius Mobile offering
    2024 : Nonius group revenue reaches $25.8M; GuestU brand retains ~4 team members
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | No | Acquired by Nonius; founders exited or in advisory roles |
| PE-free | Yes | No private equity involvement found; Nonius itself is bootstrapped ($0 funding per getlatka.com) |
| Revenue in thesis range (€1M–€15M ARR) | No | GuestU alone: revenue unknown/sub-scale. Nonius group: ~$25.8M — above thesis ceiling and not separable |
| Geographic fit (NL/BE) | No | Portuguese company; no Dutch legal entity; Amsterdam attribution in brief was incorrect |
| Succession signal | N/A | Already acquired; not an independent target |
| Overall feasibility | **Low** | GuestU is not an independent acquisition target — it is a product brand within Nonius (Portugal). Geographic mismatch with SolStein thesis. |
