# Slerp

**Category**: Online Ordering
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Slerp @HORECA_IT/slerp/
@research-horeca-company Slerp @HORECA_IT/slerp/
```
