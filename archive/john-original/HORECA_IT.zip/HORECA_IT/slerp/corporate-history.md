# Slerp — Corporate History

**Category**: Online Ordering / Direct D2C Platform (Restaurants)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; VC-backed, Series A stage)

---

## Summary Assessment

Slerp is a **London-based e-commerce platform for hospitality** enabling restaurants and multi-brand operators to run direct online ordering, delivery, click-and-collect, and catering management without relying on third-party aggregators (Deliveroo, Uber Eats). Founded ~2020, it raised ~£7M (seed + Series A May 2021) from Eight Roads Ventures and Jigsaw VC. Revenue ~$4.4M (2025 estimate). UK-focused; not a SolStein target but a useful **direct online ordering benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Slerp | slerp.com | Confirmed |
| Legal entity | SLERP LIMITED | Companies House (filing history confirmed) | Confirmed |
| Companies House No. | 10222686 | gov.uk Companies House | Confirmed |
| HQ | London, UK | slerp.com, PitchBook | Confirmed |
| Founded | ~2016–2020 (PitchBook: 2016; uktechnews.info: 2020 activity; conflicting) | PitchBook / tracxn | Estimated |
| Founders | Not publicly identified in research | — | Unknown |
| Employees | ~30–40 | PitchBook (30), Getlatka (~40) | Estimated |
| Revenue (2025) | ~$4.4M | Getlatka | Estimated |
| Seed round | May 2021: £2M | uktechnews.info | Confirmed |
| Series A round | May 2021: £5M (led by Eight Roads Ventures) | uktechnews.info | Confirmed |
| Total funding | ~£7M (~$10M) | uktechnews.info | Confirmed |
| Investors (seed) | Jigsaw VC + angels including Rumi Verjee (Domino's UK founder) | uktechnews.info | Confirmed |
| Investors (Series A) | Eight Roads Ventures (lead), Jigsaw VC, TrueSight Ventures, Aldea Ventures | uktechnews.info | Confirmed |
| Product | Branded direct ordering (web + app), click-and-collect, delivery, catering, loyalty, CRM | slerp.com | Confirmed |
| Integrations | Deliveroo Express, Uber Direct, POS systems | slerp.com | Confirmed |
| Target customer | Restaurants, bakeries, QSR, multi-brand groups | slerp.com | Confirmed |
| Capterra recognition | 2025 "Best Ease of Use" in Online Ordering category | slerp.com | Confirmed |
| UK focus | Primary market: UK | slerp.com | Confirmed |

---

## Founding & History

Slerp was founded in **London** to address a clear pain point: hospitality operators were overly dependent on third-party aggregators (Deliveroo, Uber Eats, Just Eat) that charged 25–30% commission on every order, while owning the customer relationship.

Slerp's model: provide restaurants with a **white-label direct ordering platform** so they can own the customer, own the data, and reduce commission dependency. The platform integrates with delivery providers (Deliveroo Express, Uber Direct) as logistics partners — while keeping the ordering and customer relationship direct.

**May 2021**: Raised £2M seed + £5M Series A simultaneously, closing the rounds in quick succession. The Series A was led by **Eight Roads Ventures** (Fidelity-backed VC) and included Jigsaw VC, TrueSight Ventures, and Aldea Ventures. Notable angel: **Rumi Verjee**, founder of Domino's Pizza UK — validating the restaurant delivery angle.

By 2025, Slerp had ~40 employees and ~$4.4M estimated revenue, with Capterra recognition for ease of use.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Eight Roads Ventures (Series A lead — Fidelity-backed)"]
    B["Jigsaw VC"]
    C["TrueSight Ventures"]
    D["Aldea Ventures"]
    E["Rumi Verjee (Domino's UK — angel)"]
    F["SLERP LIMITED<br/>(London, UK)"]

    A -->|"Series A lead"| F
    B -->|"Seed + Series A"| F
    C -->|"Series A"| F
    D -->|"Series A"| F
    E -->|"Angel"| F
```

---

## Funding Timeline

| Round | Date | Amount | Lead Investor | Notes |
|---|---|---|---|---|
| Seed | May 2021 | £2M | Jigsaw VC | Angels including Rumi Verjee |
| Series A | May 2021 | £5M | Eight Roads Ventures | TrueSight Ventures, Aldea Ventures |
| **Total raised** | | **~£7M** | | uktechnews.info |

---

## Timeline of Critical Events

```mermaid
timeline
    title Slerp — Key Milestones
    2016-2020 : Founded in London; direct ordering platform for hospitality
    2021 : £2M seed + £5M Series A closed (Eight Roads Ventures lead, May 2021)
    2025 : ~$4.4M revenue; ~40 employees; Capterra "Best Ease of Use" recognition
    2026 : Active; UK direct online ordering market; expansion potential
```

---

## M&A Feasibility Assessment

### Is Slerp an Acquisition Target for SolStein?

**Answer: Not suitable — UK-only; VC-backed; US exit likely needed.**

| Factor | Assessment |
|---|---|
| **Scale** | ~$4.4M revenue — at lower bound of SolStein's range, but UK-focused |
| **Ownership** | VC-backed (Eight Roads, Jigsaw) — investors need exit; SolStein not typical VC portfolio exit buyer |
| **Geography** | UK primary; no NL/BE strategy |
| **Succession** | VC-backed company; founder likely present but VC board controls exit |
| **Exit pathway** | Likely strategic acquisition by aggregator platform or payments company |

### Role for SolStein

1. **Direct ordering benchmark**: Slerp demonstrates the D2C channel stack for restaurants — relevant for any NL/BE direct ordering platform.
2. **Commission reduction thesis**: £5M Series A validates investor belief that restaurants want to own their direct channel vs. aggregator dependence.
3. **NL/BE opportunity**: If a NL/BE equivalent of Slerp exists (founder-owned, €1–5M ARR, direct restaurant ordering), it fits SolStein's criteria better.

---

*Sources: uktechnews.info (May 2021 funding), slerp.com, Companies House 10222686, PitchBook, Getlatka.*
