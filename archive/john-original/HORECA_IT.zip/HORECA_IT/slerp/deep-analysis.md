# Slerp — Deep Analysis

**Category**: Online Ordering / Direct D2C Platform (Restaurants)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; VC-backed Series A stage)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | SLERP LIMITED | Companies House 10222686 | Confirmed |
| HQ | London, UK | slerp.com | Confirmed |
| Founded | ~2016–2020 (founding date unclear; Series A May 2021) | PitchBook, uktechnews.info | Estimated |
| Founders | Not publicly identified | — | Unknown |
| Ownership | VC-backed (Eight Roads Ventures, Jigsaw VC) | uktechnews.info | Confirmed |
| Employees | ~30–40 | PitchBook / Getlatka | Estimated |
| Revenue | ~$4.4M (2025 Getlatka estimate) | Getlatka | Estimated |
| Total funding | ~£7M (~$10M) | uktechnews.info | Confirmed |
| Business model | SaaS platform fee + transaction commission on direct orders | slerp.com | Estimated |
| Product | Branded direct ordering web/app + click-and-collect + catering + loyalty | slerp.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Primary; UK restaurant operators | slerp.com | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU expansion (2021) | Series A announcement mentioned EU expansion intent | uktechnews.info | Confirmed |
| EU actual presence | Not evident in 2026 | slerp.com | Estimated |
| Target customer | Independent restaurants, bakeries, QSR, multi-brand groups | slerp.com | Confirmed |
| Value proposition | Eliminate 25–30% aggregator commission; own customer data | slerp.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | White-label direct online ordering platform | slerp.com | Confirmed |
| Order channels | Branded website, mobile web app, click-and-collect, catering | slerp.com | Confirmed |
| Delivery integrations | Deliveroo Express, Uber Direct (logistics only; Slerp retains customer) | slerp.com | Confirmed |
| Loyalty | Built-in loyalty programme | slerp.com | Confirmed |
| CRM | Customer data ownership and direct marketing | slerp.com | Confirmed |
| Deployment | Cloud SaaS | slerp.com | Confirmed |
| Multi-brand | Multi-brand/ghost kitchen support | slerp.com | Confirmed |
| Tech stack | Web-first; API integrations with delivery and POS | slerp.com | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| PE/VC backing | Eight Roads Ventures (lead) + Jigsaw VC + TrueSight + Aldea | uktechnews.info | Confirmed |
| Investor type | Institutional VC (not PE); exit-oriented | Eight Roads Ventures profile | Confirmed |
| Founder status | Unknown — likely active (early-stage company) | — | Unknown |
| Exit horizon | 3–5 years from Series A (2021) = 2024–2026 window | Standard VC lifecycle | Estimated |
| M&A candidacy | Yes — at $4.4M ARR, could be acquired by aggregator, payments co., or strategic | Market context | Estimated |

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Employees | Source | Confidence |
|---|---|---|---|---|
| 2025 | ~$4.4M | ~40 | Getlatka | Estimated |
| Growth rate | Unknown | — | — | Unknown |

Revenue of ~$4.4M with ~40 employees suggests $110K revenue per employee — reasonable for a SaaS platform. Growth rate unknown. Eight Roads Ventures (Fidelity-backed) invests in high-growth businesses; trajectory is expected to be positive.

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Restaurant delivery | Core vertical | slerp.com | Confirmed |
| Click-and-collect | Supported | slerp.com | Confirmed |
| Catering/events | Catering management module | slerp.com | Confirmed |
| UK payment compliance | UK payment processing (PCI DSS) | slerp.com | Estimated |
| VAT compliance | UK VAT on food orders | slerp.com | Estimated |
| Ghost kitchen / dark kitchen | Multi-brand support for virtual brands | slerp.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | Monthly SaaS fee + % of online orders (estimated) | slerp.com | Estimated |
| ARR estimate | ~$4.4M | Getlatka | Estimated |
| Post-money valuation (Series A) | ~$25–50M (estimated at standard Series A multiples) | VC norms | Estimated |
| Acquisition price estimate | £15–30M (at 3–7x ARR) | Industry comparable | Estimated |
| SolStein fit | No — VC-backed; UK-only; wrong ownership type | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 2 | VC-backed; Eight Roads Ventures institutional lead; not founder-owned | uktechnews.info |
| Revenue scale fit | High | 3 | ~$4.4M ARR — within SolStein's range BUT VC-backed ownership is a blocker | Getlatka |
| Geographic fit | High | 1 | UK primary; EU expansion not materialised | slerp.com |
| Tech stack modernity | Medium | 5 | Cloud-native; white-label; API integrations | slerp.com |
| Customer lock-in | Medium | 3 | Platform dependency moderate; restaurants can switch ordering platforms | slerp.com |
| Vertical depth | Medium | 3 | Direct online ordering only; not full-stack HORECA | slerp.com |
| Integration potential | Low | 4 | Deliveroo, Uber Direct, POS integrations | slerp.com |
| Growth trajectory | Low | 4 | VC-backed growth; Capterra recognition; active product development | slerp.com |

### Composite Score

**Weighted Composite: 2.5 / 5.0**

*(Geographic fit = 1 [high weight]; ownership not ideal for SolStein)*

**Confidence Band**: Low — revenue from Getlatka (estimated); founder and financial details unknown.

### Overall M&A Assessment

Slerp is **not a SolStein target** — it is UK-focused with VC institutional backing, and SolStein's thesis requires founder-owned companies in NL/BE. Slerp's value is as a **direct ordering product benchmark** and a signal that the category is well-validated (Eight Roads/Fidelity backing). NL/BE equivalent founder-owned direct ordering platforms would fit SolStein's criteria.

### Recommended Next Step

No pursuit. Monitor as technology and market benchmark. Identify NL/BE restaurant direct-ordering or delivery management companies at €1–10M ARR, founder-owned, as SolStein targets.

---

*Sources: uktechnews.info (May 2021), slerp.com, Companies House (10222686), PitchBook, Getlatka.*
