# Qompanion — Corporate History

**Category**: Restaurant POS / Cloud Hospitality Software (unverified)
**Country**: NL (unconfirmed)
**Research Date**: 2026-04-30

> **Research Note**: Extensive search across Northdata, KvK, LinkedIn, Crunchbase, Tracxn, OpenKVK, and direct domain access found no verifiable Dutch business registration, product listing, or company profile for a "Qompanion" POS software company in Amsterdam or the Netherlands. The domain qompanion.nl is registered (WHOIS confirmed) but returns HTTP 503 (Service Unavailable). The only "Qompanion" entity in global tech databases is a deadpooled Malaysian insurance comparison startup (Tracxn). All data points below are marked accordingly.

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Unknown — no KvK match found | KvK search, Northdata, OpenKVK | Unknown |
| KvK Number | Unknown | Multiple Dutch registry searches | Unknown |
| Registered City | Unknown (Amsterdam claimed by M&A brief) | No primary source found | Unknown |
| Founding Year | Unknown | No source found | Unknown |
| Founders | Unknown | No source found | Unknown |
| Current Ownership | Unknown | No source found | Unknown |
| PE/Investor Ownership | None detected | Tracxn, Crunchbase | Unknown |
| Employees (FTE) | Unknown | LinkedIn search returned no profile | Unknown |
| Estimated Revenue | Unknown | No source found | Unknown |
| M&A History | None found | — | Unknown |
| Investment Rounds | None found | Tracxn, Crunchbase | Unknown |
| Name Changes | Unknown | — | Unknown |
| Domain qompanion.nl | Registered; HTTP 503 as of 2026-04-30 | who.is/whois/qompanion.nl | Confirmed |
| Domain qompanion.com | Timeout / not accessible as of 2026-04-30 | Direct fetch attempt | Unknown |
| LinkedIn company page | Not found (404) | linkedin.com/company/qompanion | Unknown |

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown Founders / Owners] --> B["Qompanion — Legal Entity Unknown"]
    B --> C["Cloud POS / Hospitality Software — Product Details Unknown"]
    D["qompanion.nl domain — Registered, HTTP 503"] --> B
```

---

## Timeline

```mermaid
timeline
    title Qompanion Key Events
    Unknown : Company reportedly founded (year unknown)
    Unknown : Domain qompanion.nl registered
    2026-04-30 : Domain active (registered) but website returning HTTP 503; no public company profile found
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | No ownership data available |
| PE-free | Unknown | No investor data found |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No revenue data available |
| Geographic fit (NL/BE) | Unknown | Amsterdam claimed; no KvK or address confirmed |
| Succession signal | Unknown | No leadership data found |
| Software / POS identity confirmed | No | No product details, customer reviews, or integrations found |
| Overall feasibility | **Cannot Assess** | Insufficient public information to evaluate |

---

## Analyst Commentary

After conducting more than 10 web searches across Dutch and English sources, checking Northdata, LinkedIn (404 result), Crunchbase, Tracxn, OpenKVK, Ensun, and both direct domain accesses (503/timeout), **no verifiable public profile for a Dutch hospitality POS company named "Qompanion" could be found**. The registered domain qompanion.nl exists but is currently inaccessible. No KvK registration, LinkedIn profile, product listing, press mention, or customer review was found. SolStein should verify the correct company name, legal entity name, or website URL before any outreach or due diligence activity.
