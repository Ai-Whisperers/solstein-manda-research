# Qompanion

**Category**: Restaurant POS
**Country**: NL
**City**: Amsterdam
**Research Status**: Completed (2026-04-30) — Very Limited Data Found

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Completed — Unknown (no KvK or public profile found) |
| `deep-analysis.md` | Completed — Unknown (domain registered; site inaccessible) |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Qompanion @HORECA_IT/qompanion/
@research-horeca-company Qompanion @HORECA_IT/qompanion/
```
