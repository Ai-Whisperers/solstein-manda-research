# Qompanion — Deep Analysis

**Category**: Restaurant POS / Cloud Hospitality Software (unverified)
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

> **Important Caveat**: After 10+ targeted web searches in Dutch and English, direct domain access attempts, and checks of Northdata, LinkedIn, Crunchbase, Tracxn, Ensun, OpenKVK, and Who.is, no verifiable public company profile exists for a Dutch hospitality POS company named "Qompanion." The domain qompanion.nl is registered but inaccessible (HTTP 503). No KvK registration, LinkedIn company page, product listing, integration registry entry, or press mention was found. This analysis documents all research findings; all substantive fields are Unknown.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown — no KvK entry found | KvK, Northdata, OpenKVK searches | Unknown |
| HQ address | Unknown (Amsterdam claimed in M&A brief) | No primary source found | Unknown |
| Founded | Unknown | No source found | Unknown |
| CEO / MD | Unknown | LinkedIn 404; no profile found | Unknown |
| Ownership structure | Unknown | No source found | Unknown |
| Employees (FTE) | Unknown | LinkedIn company page: 404 | Unknown |
| Revenue (latest estimate) | Unknown | No financial source found | Unknown |
| Profitability | Unknown | No source | Unknown |
| Website | qompanion.nl (registered; HTTP 503 as of 2026-04-30) | who.is/whois/qompanion.nl | Confirmed — domain exists |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | Unknown | No footprint found | Unknown |
| Customer count | Unknown | No source found | Unknown |
| Target verticals | Unknown | No product found | Unknown |
| Market share estimate | Unknown | No source | Unknown |
| Key competitors | Unknown | No market context found | Unknown |

**Market Context**: The Dutch cloud HORECA POS market includes Sjef (Amsterdam, cloud-native, founded ~2015), unTill Air (cloud tier of market leader unTill), Tebi (Amsterdam, all-in-one hospitality platform, VC-backed), and Lightspeed Restaurant (global, strong NL presence). No source placed "Qompanion" in this competitive set.

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Unknown — no product pages or screenshots found | Multiple searches | Unknown |
| Tech stack | Unknown | No source | Unknown |
| Deployment model | Unknown (cloud claimed in M&A brief) | No confirmation found | Unknown |
| API availability | Unknown | No source | Unknown |
| Key integrations | Unknown | No integration directory listing found | Unknown |
| Mobile app | Unknown | No App Store / Play Store listing found | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No source found | Unknown |
| Investor type | None detected | Crunchbase, Tracxn searches | Estimated |
| PE ownership | None detected | No source | Estimated |
| Succession signals | Unknown | No leadership data found | Unknown |
| Last funding date | None found | Crunchbase, Tracxn | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No financial data found | Unknown |
| Employee growth | Unknown | No LinkedIn profile accessible | Unknown |
| New markets | Unknown | No expansion news found | Unknown |
| Recent product launches | Unknown | No product news found | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Unknown | No product found | Unknown |
| GDPR/AVG compliance | Unknown | No privacy policy accessible | Unknown |
| Allergen management | Unknown | No source | Unknown |
| Fiscal compliance NL | Unknown | No source | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown | No source | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown | No product or pricing page accessible | Unknown |
| Estimated ARR | Unknown | No revenue data | Unknown |
| Estimated acquisition value | Not calculable | Insufficient data | Unknown |
| Revenue per employee | Unknown | No data | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | No ownership data found | — |
| Revenue scale fit | High | N/A | No revenue data | — |
| Geographic fit | High | N/A | Domain registered in NL; no address confirmed | who.is |
| Tech stack modernity | Medium | N/A | No product found | — |
| Customer lock-in | Medium | N/A | No customer data found | — |
| Vertical depth | Medium | N/A | No HORECA software product confirmed | — |
| Integration potential | Low | N/A | No product or API found | — |
| Growth trajectory | Low | N/A | No growth signals | — |

**Composite Score**: N/A (insufficient data to score)
**Confidence Band**: Wide — almost all data missing
**Overall M&A Assessment**: No verifiable public presence exists for a Dutch HORECA POS company named "Qompanion." The domain qompanion.nl is registered but returning HTTP 503, suggesting the company may be very early-stage, in stealth, rebranding, or operating primarily through direct sales with no public marketing footprint. Alternatively, the company name may differ from its legal entity name, or the information provided may contain an error. The target cannot be evaluated against the SolStein M&A thesis without additional verification.
**Recommended Next Step**: Obtain direct contact information or KvK number from the deal source who identified this target. Attempt a Dutch-language LinkedIn People search for founders/employees who list "Qompanion" as their employer, which may reveal the correct legal entity name. If the website becomes accessible, initiate a fresh research pass. Do not proceed to outreach without identity confirmation.
