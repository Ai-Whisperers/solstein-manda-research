# Schnell ein Tisch — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Unconfirmed entity; insufficient data

---

## Research Limitations

"Schnell ein Tisch" as a Stuttgart last-minute restaurant booking company could not be confirmed. The phrase is a common German search term, not a confirmed brand. All data Unknown.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown | No source |
| Revenue scale fit | High | 1 | Assumed micro-scale or non-existent | Estimated |
| Geographic fit | High | 1 | Germany only | SolStein brief |
| Tech stack modernity | Medium | — | Unknown | No source |
| Customer lock-in | Medium | 1 | Last-minute booking is low-switching-cost market | Assessment |
| Vertical depth | Medium | 2 | Niche last-minute reservation focus | Assessment |
| Integration potential | Low | — | Unknown | No source |
| Growth trajectory | Low | 1 | Competing against TheFork, Quandoo, OpenTable; difficult standalone market position | Assessment |

**Composite Score**: ~1.0 / 5.0

**Confidence Band**: Very Low

**Overall M&A Assessment**: Cannot assess. Entity not confirmed. No action recommended.

---

*Sources: SolStein research brief only*
