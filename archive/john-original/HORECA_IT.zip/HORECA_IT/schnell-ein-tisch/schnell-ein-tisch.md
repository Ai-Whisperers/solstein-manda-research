# Schnell ein Tisch

**Category**: Reservations
**Country**: DE
**City**: Stuttgart
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Schnell ein Tisch @HORECA_IT/schnell-ein-tisch/
@research-horeca-company Schnell ein Tisch @HORECA_IT/schnell-ein-tisch/
```
