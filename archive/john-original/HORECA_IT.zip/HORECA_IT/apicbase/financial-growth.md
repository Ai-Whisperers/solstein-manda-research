# Financial & Growth Deep-Dive — Apicbase

**Research Date**: 2026-04-30
**Data Availability**: Medium — VC-funded Belgian NV; KBO gross margin confirmed via companyweb.be; turnover not separately filed; ARR from GetLatka (CEO self-reported); funding from PitchBook/press releases; no audited full P&L in public domain.

---

### Revenue Timeline

> **Note on sources**: Apicbase NV files abbreviated annual accounts and does not separately disclose turnover. The KBO figures below represent **gross margin** (turnover minus COGS/external services), confirmed via companyweb.be. GetLatka ARR is self-reported by the CEO in an interview and treated as ARR/revenue proxy. Tracxn reports €5.31M for 2024, likely an overestimate or different definition. The two confirmed-proxy series are presented side by side. EUR equivalents for USD figures use ECB annual average rates (2021: 0.846; 2022: 0.951; 2023: 0.921; 2024: 0.924).

| Year | KBO Gross Margin (EUR) | YoY | GetLatka ARR (USD) | EUR Equiv. | YoY | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 2026 (est.) | ~€2.9M est. | ~+15% | ~$4.0–4.5M est. | ~€3.7–4.2M | ~+15% | Extrapolation | Estimated |
| 2025 (est.) | ~€2.8M est. | ~+10% | ~$3.7M est. | ~€3.4M | ~+15% | Extrapolation | Estimated |
| 2024 | €2,518,942 | +47% | $3.2M | €2.96M | +19% | companyweb.be (KBO); GetLatka | Confirmed (margin) / Estimated (ARR) |
| 2023 | €1,714,211 | +96% | $2.7M | €2.49M | +35% | companyweb.be (KBO); GetLatka | Confirmed (margin) / Estimated (ARR) |
| 2022 | €874,432 | +14% | ~$2.0–2.3M est. | ~€1.9–2.2M | ~+10% | companyweb.be (KBO); interpolated | Confirmed (margin) / Estimated (ARR) |
| 2021 | €769,160 | — | $2.0M | €1.69M | — | companyweb.be (KBO); GetLatka | Confirmed (margin) / Estimated (ARR) |

**Revenue CAGR (3yr, KBO gross margin 2021–2024)**: ~48% — driven by acceleration in 2022–2023; note gross margin, not turnover
**Revenue CAGR (3yr, GetLatka ARR 2021–2024)**: ~17% — more conservative; likely understates Belgian entity contribution
**Revenue CAGR (5yr)**: Insufficient confirmed data prior to 2021

> **Reconciliation note**: The KBO gross margin grew 48% CAGR (2021–2024) while GetLatka ARR implies ~17% CAGR. This divergence likely reflects: (a) geographic revenue in UK/international not captured in Belgian entity gross margin, or (b) COGS deductions reducing gross margin below total ARR. The actual revenue CAGR is most likely in the 20–35% range, placing Apicbase in the **strong grower** bracket.

#### Revenue Trend Chart

```mermaid
xychart-beta
    title "Apicbase KBO Gross Margin Trend (EUR M)"
    x-axis [2021, 2022, 2023, 2024]
    y-axis "EUR Millions" 0 --> 3
    line [0.77, 0.87, 1.71, 2.52]
```

---

### Profitability

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| EBITDA (2024) | Not filed separately | KBO abbreviated accounts | Unknown |
| Net Profit / Loss (2024) | -€280,542 | companyweb.be (KBO annual accounts) | Confirmed |
| Net Profit / Loss (2023) | -€882,806 | companyweb.be (KBO annual accounts) | Confirmed |
| Net Profit / Loss (2022) | -€1,942,137 | companyweb.be (KBO annual accounts) | Confirmed |
| Net Profit / Loss (2021) | -€1,127,088 | companyweb.be (KBO annual accounts) | Confirmed |
| Equity (2024) | €1,605,974 | companyweb.be (KBO) | Confirmed |
| Equity (2023) | €1,886,516 | companyweb.be (KBO) | Confirmed |
| Equity (2022) | €2,769,322 | companyweb.be (KBO) | Confirmed |
| Equity (2021) | €1,761,550 | companyweb.be (KBO) | Confirmed |
| Recurring Revenue % | ~100% | SaaS subscription model confirmed; no perpetual licences | Estimated |
| SaaS / Subscription Revenue % | ~100% | Cloud-native; per-module per-location subscription | Confirmed (model) |
| Revenue per Employee (2024) | ~€57K (KBO gross margin / 22.7 FTE) or ~€57K (GetLatka ARR / 52) | Calculated | Estimated |

**Profitability Trend**: Losses narrowing significantly — from -€1.94M (2022) to -€281K (2024). If the trend continues, 2025 break-even is plausible, particularly given the April 2025 funding injection. The company is in a **controlled burn** trajectory: investing in growth while losses shrink.

---

### Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Apr 3, 2025 | Later Stage VC | $4.21M (~€3.9M) | Undisclosed | Not disclosed | PitchBook | Estimated |
| May 19, 2021 | Series A | €4.0M (~$4.89M) | Volta Ventures | Not disclosed | tech.eu; Silicon Canals; Newion press release | Confirmed |
| Jun 2019 | Growth Capital / Pre-Series A | €1.5M (~$1.7M) | Newion Investments | Not disclosed | Newion press release; Silicon Canals; Center of Startups | Confirmed |
| 2017 | Pre-Seed / Angel | €700K (~$786K) | BAN Flanders (Business Angels Network Vlaanderen) | Not disclosed | Apicbase press release; Tracxn | Confirmed |

**Total Raised**: ~€10.1M (~$11.5M per PitchBook); discrepancy with Tracxn ($7.56M) and GetLatka ($4.5M) is due to those sources not including the April 2025 round
**Latest Valuation**: Not publicly disclosed; estimated €15–25M post-money for 2025 round based on comparable niche SaaS multiples (deep-analysis.md)
**Current Investors**: Volta Ventures (Benelux-focused early-stage VC), Newion Investments (Amsterdam-based B2B SaaS VC), Ark Angels Activator Fund (AAA), BAN Flanders angels
**War Chest Signals**: KBO equity €1.61M (2024); April 2025 round injects ~€3.9M fresh capital; likely €4–5M cash runway as of mid-2025. No PE dry powder — VC-backed, not PE-backed.

---

### Employee Timeline

> **Note on sources**: KBO FTE is the Belgian entity headcount from filed annual accounts (medium-sized classification). LinkedIn/GetLatka global headcount includes remote and international staff. From 2022 onward, the divergence between KBO FTE (~23–32) and global headcount (~38–52) suggests Apicbase employs significant international or contractor workforce outside the Belgian entity.

| Year | Global Headcount (LinkedIn/GetLatka) | KBO FTE | YoY (Global) | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2026 (current) | ~49 | ~22.7 (2024 filing) | -6% vs 2024 | LinkedIn company page | Estimated |
| 2024 | ~52 | 22.7 | +8% | GetLatka (CEO interview); KBO | Estimated / Confirmed (KBO) |
| 2023 | ~48 | 23.6 | ~+27% (vs 2022 est.) | LinkedIn estimate; KBO | Estimated |
| 2022 | ~38 | 31.7 | ~+58% (vs 2021) | Estimate based on KBO growth + CEO 2021 doubling target | Estimated |
| 2021 | ~24 | 24.5 | — | Tracxn; KBO; GetLatka | Confirmed (KBO) |
| 2019 | ~10 | — | — | Tracxn | Estimated |

**Employee CAGR (3yr global, 2021–2024)**: ~29%
**Employee CAGR (3yr KBO FTE, 2021–2024)**: -3% (KBO FTE declining from 24.5 → 22.7; offset by international growth)
**Current Open Positions**: Not separately tracked; career page lists roles in product, engineering, customer success
**Hiring Hotspots**: Antwerp (Belgian HQ); remote-first for international roles; UK-based customer success roles noted

#### Employee Growth Chart

```mermaid
xychart-beta
    title "Apicbase Global Employee Growth"
    x-axis [2021, 2022, 2023, 2024, 2026]
    y-axis "Headcount" 0 --> 60
    line [24, 38, 48, 52, 49]
```

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| Pre-2018 | UK market entry | UK | Formal UK launch after £500K capital raise; exhibited at Commercial Kitchen Show, The Restaurant Show, Hotelympia | Apicbase press release (UK intro) | Confirmed |
| Pre-2018 | Enterprise customers internationally | ES, FR, USA | El Celler de Can Roca (Spain), La Mère Brazier (France), Thomas Keller Group (USA), Unilever Food Solutions UK | Apicbase UK press release | Confirmed |
| 2019 | Netherlands presence | NL | La Place (major NL chain) named as customer; Newion (Amsterdam VC) joins as investor signalling NL commercial push | Newion press release; Silicon Canals | Confirmed |
| 2021 | Office expansion announced | NL/UK/US | CEO announced plans to open offices in Amsterdam, London, New York by end of 2022 | Silicon Canals (2021 Series A article) | Confirmed (announced) |
| 2021 | CitizenM global rollout | NL/Global | CitizenM (NL-founded global hotel chain) rolled out Apicbase across 30+ properties in Europe, US, and Asia | Apicbase case study; customers page | Confirmed |
| 2022–2024 | Ongoing UK scale-up | UK | Heavenly Desserts (UK franchise) and The Ivy Collection as UK enterprise customers | Apicbase customers page | Confirmed |
| 2022–2024 | Denmark market | DK | Danish poké chain listed as customer | Apicbase customers page | Estimated |
| 2023–2024 | Netherlands enterprise | NL | Restaurant Company Europe (RCE, largest NL hospitality group, 75+ locations including Loetje) | Apicbase case studies | Confirmed |

**Primary Market**: Belgium (origin); UK and Netherlands now equal priority
**International Revenue %**: Not disclosed; estimated 30–50% based on customer geography diversity
**Expansion Trajectory**: Apicbase targets multi-unit enterprise operators regardless of geography; UK and NL are confirmed enterprise markets with named customers. US presence exists through global chains (CitizenM, Thomas Keller) but no US-dedicated sales team confirmed. The 2021 plan to open NYC/London/Amsterdam offices was likely partially executed via remote hiring rather than formal offices.

---

### M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| — | No acquisitions identified | — | — | — | Crunchbase, Dealroom, press search | Confirmed (absence) |

**Divestitures**: None identified
**M&A Pattern**: Purely organic growth. No acquisitions made or disclosed in any monitored source (Crunchbase, Dealroom, press archives). The company is a potential **acquisition target** rather than an acquirer at current scale. The April 2025 "Later Stage VC" round and ongoing VC backing signal continued focus on organic scaling rather than buy-and-build.

---

### SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | Cloud-native SaaS; no on-premise option | Company website; product docs | Confirmed |
| Cloud Revenue % | ~100% | Subscription-only model; no perpetual licence or on-prem product | Confirmed |
| Recurring Revenue % | ~100% | Per-module, per-location subscription; enterprise annual contracts | Confirmed (model) |
| Payment Integrations | Not a POS/payments provider; does not process Bancontact/iDEAL/Stripe directly | deep-analysis.md; KBO activity | Confirmed |
| Platform Stack | Cloud-based; REST API; described as "AI-native"; MCP interface (ChatGPT-style query layer) | Company website; product docs; press releases | Confirmed |
| API / Integration Model | Open REST API; partner ecosystem with POS, ERP, accounting, payroll, delivery platforms; HubRise integration listed | developers.apicbase.com; HubRise; company website | Confirmed |
| Migration Status | N/A — cloud-native from founding; no migration required | Company history; deep-analysis.md | Confirmed |
| AI Feature Maturity | AI-generated recipe concepts; dietary/allergen auto-generation; AI demand forecasting; carbon footprint tracking | Company website (2024–2026) | Confirmed |

---

### Growth Scorecard

| Dimension | Score (1–10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | 6 | GetLatka ARR CAGR ~17% (2021–2024); KBO gross margin CAGR ~48% over same period; true revenue CAGR estimated 20–35%; solid but decelerating from ~100% in 2021 |
| Funding Momentum | 5 | Total raised ~€10.1M from confirmed VC investors (Volta, Newion, AAA); April 2025 round of ~€3.9M in last 3yr falls just below EUR 5M threshold; strong VC backing but not a mega-round |
| Employee Growth | 7 | Global headcount CAGR ~29% (2021–2024); planned doubling post-Series A executed; slight pullback to 49 in 2026 prevents score 8 |
| Geographic Expansion | 7 | Customers in 15+ countries; confirmed enterprise deployments in BE, NL, UK, USA, ES, FR, DK; CitizenM rollout across Europe/US/Asia; active international push with planned US/UK offices |
| M&A Activity | 2 | No acquisitions identified in any source; purely organic strategy; not yet a platform acquirer |
| SaaS Maturity | 9 | Cloud-native from founding; 100% subscription; AI-native feature set (2021+); open REST API; MCP interface; full integration ecosystem with POS/ERP/accounting/payroll |
| **COMPOSITE SCORE** | **6.0** | **Riser — strong SaaS foundation with genuine international traction; VC-fuelled growth mode; M&A activity absent** |

**Classification Thresholds**:

- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating ← **Apicbase**
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "Apicbase Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [6, 5, 7, 7, 2, 9]
```

---

### SolStein Acquisition Context

**Financial Growth Classification**: Riser (6.0 composite)

The growth scorecard confirms the deep-analysis "Watch" rating. Apicbase is a technically excellent, internationally expanding, genuinely VC-backed SaaS company — but it is **not currently acquirable at SolStein's typical price range**. Key financial context:

- Losses narrowed from -€1.94M (2022) to -€281K (2024); break-even within 12–18 months if trend holds
- April 2025 round of ~€3.9M means fresh VC capital is deployed; exit not imminent
- Valuation estimated €15–25M (post-2025 round) — above SolStein's typical entry range
- Revenue trajectory healthy at 17–35% CAGR depending on source; not distressed
- Volta Ventures fund typically 7–10yr lifecycle; founded 2007, portfolio suggests fund maturity approaching ~2027–2029 window

**Recommended monitoring trigger**: Volta Ventures fund cycle announcement or Apicbase CEO messaging shift (from growth to profitability). A trade sale becomes realistic if the 2025 round is the last VC round and EBITDA-positive status is achieved by 2026.

---

*Sources*:
- companyweb.be (KBO 0550.392.648) — gross margin, profit/loss, equity, FTE 2021–2024; filed 19-08-2025
- getlatka.com/companies/apicbase — ARR $3.2M (2024), $2.7M (2023), $2.0M (2021); 52 employees; CEO interview-based
- pitchbook.com/profiles/company/222035-41 — total funding $11.5M; April 2025 Later Stage VC $4.21M
- tech.eu (May 2021) — Series A €4M; Volta Ventures lead; Newion, AAA Fund, Angels participation
- siliconcanals.com (May 2021) — office expansion plans Amsterdam/London/New York; 100% growth claim
- newion.com — €1.5M 2019 growth capital; €4M 2021 Series A confirmation
- get.apicbase.com/apicbase-introduction-uk/ — UK market entry; 15+ countries; 200+ companies; enterprise customers named
- get.apicbase.com/customers/ — "thousands of foodservice units"; named customer logos
- tracxn.com/apicbase — 24 employees (2021); 10 employees (2019); €5.31M revenue claim (2024, likely overestimate)
- be.linkedin.com/company/apicbase — 49 current employees
