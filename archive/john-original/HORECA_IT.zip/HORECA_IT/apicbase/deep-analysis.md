# Apicbase — Deep Analysis

**Research Date**: 2026-04-30
**Category**: Kitchen / F&B Management
**Country**: BE | **City**: Antwerp (KBO) / listed as Oudenaarde in target CSV
**Research Quality**: Medium-High (Confirmed KBO data + multiple secondary sources)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | APICBASE NV | KBO 0550.392.648 | Confirmed |
| HQ address | Samberstraat 3, 2060 Antwerpen | KBO | Confirmed |
| Founded | April 6, 2014 (incorporated); 2017 (rebranded & operationalised) | KBO + press | Confirmed |
| CEO | Carl Jacobs | KBO, press releases | Confirmed |
| CTO | Pieter Wellens | Press releases, Tracxn | Confirmed |
| Ownership | Founder-owned + institutional VC: Volta Ventures, Newion, AAA Fund | Tracxn, press | Confirmed |
| Employees | ~49–52 (2024–2026) | GetLatka, Tracxn | Estimated |
| Revenue 2024 | $3.2M (GetLatka) / €5.31M (Tracxn) | GetLatka, Tracxn | Estimated |
| Revenue 2023 | $2.7M | GetLatka | Estimated |
| Revenue 2021 | $2.0M | GetLatka | Estimated |
| YoY growth | ~20% (2024); ~100% in earlier years | GetLatka, press | Estimated |
| Profitability | Not confirmed; VC-backed, likely investing in growth | Unknown | Unknown |
| Total funding | ~$7.56M (Tracxn) / ~$4.5M (GetLatka); discrepancy likely due to VLAIO grants | Tracxn, GetLatka | Estimated |
| Share capital | €3,699,484.04 | KBO | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary markets | Belgium, UK, Netherlands, expanding globally | Press releases, Tracxn | Confirmed |
| Customer count | Not publicly disclosed | Unknown | Unknown |
| Target verticals | Multi-unit restaurant chains, ghost kitchens, central production units, large-scale catering, hotel F&B | Company website, press | Confirmed |
| Known customers | La Place (NL), Be Burger (BE), Sodexo, Not So Dark, CitizenM hotels, Tastyoo | Apicbase press release 2021 | Confirmed |
| Market positioning | Back-of-house (BoH) management platform; "single source of truth" for F&B data across multi-unit operations | Company website | Confirmed |
| Competitor ranking | 61st of 1,739 active competitors globally (Tracxn) | Tracxn | Estimated |
| Belgian horeca focus | Strong — product is Belgium-born and serves Belgian enterprise chains | Press releases | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Product name | Apicbase F&B Management Platform | Company website | Confirmed |
| Deployment | Cloud (SaaS), subscription-based | Tracxn, company website | Confirmed |
| Core modules | Recipe management, menu engineering, inventory, procurement, demand forecasting, HACCP/task management, production planning, traceability | Company website | Confirmed |
| AI features | AI-generated recipe concepts, dietary/allergen auto-generation, carbon footprint tracking, AI demand forecasting | Company website | Confirmed |
| Tech stack | Cloud-based; described as "AI-native"; integrates via REST API | Press release, company website | Estimated |
| API availability | Yes — MCP interface (ChatGPT-style data query layer) and integrations | Company website | Confirmed |
| POS integrations | Integrates with multiple POS systems (not named as POS itself) | HubRise integration page, company website | Confirmed |
| Accounting integrations | Yes — ERP/finance/payroll integrations | Company website | Confirmed |
| Delivery integrations | Yes — API connects to delivery platforms | Company website | Estimated |
| Bancontact | Not a POS provider; does not directly process payments | N/A | Confirmed |
| Fiscal receipt (BE) | Not applicable (back-of-house only, not at point of sale) | N/A | Confirmed |
| GKS/White Cash Register (BE) | Not applicable (does not handle front-of-house fiscal transactions) | N/A | Confirmed |
| Mobile capability | Yes — barcode/QR scanning for inventory | Company website | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned? | Partially — founders are still active executives, but institutional VC holds equity | KBO, Tracxn | Confirmed |
| Institutional investors | Volta Ventures (lead, Series A), Newion, Ark Angels Activator Fund (AAA), VLAIO (government grant) | Tracxn, press | Confirmed |
| Board composition | Carl Jacobs (CEO/founder), Pieter Wellens (CTO/founder), Koen De Waele (Volta Ventures), Jan Verbeke (Newion-linked), Marc Mommaerts, Franciscus Claassen | KBO | Confirmed |
| PE overhang | No PE; VC-backed (Volta Ventures is Benelux-focused early-stage VC) | Tracxn | Confirmed |
| Latest funding | ~April 2025 per PitchBook — active fundraising ongoing | PitchBook | Estimated |
| Succession signals | None identified; founding team intact and active | LinkedIn, press | Estimated |
| M&A/exit signals | No exit or acquisition announced; company on international growth path | Tracxn | Confirmed |

---

## 5. Financial Growth & Trajectory

| Year | Revenue (USD) | YoY Growth | Employees | Notes |
|---|---|---|---|---|
| 2014 | $0 (launch) | — | Unknown | KBO registration |
| 2021 | $2.0M | ~100% (press stated) | ~20–30 | Series A funding |
| 2023 | $2.7M | ~35% | ~45–50 | Steady growth |
| 2024 | $3.2M | ~20% | 52 | Latest confirmed data |
| 2026 | ~$4–5M est. | ~15–20% est. | 49 | Headcount slightly down |

*Note*: Tracxn cites €5.31M revenue (Dec 31, 2024) which differs from GetLatka's $3.2M — the discrepancy suggests either currency difference, different definitions (bookings vs. ARR), or estimation methodology differences.

---

## 6. HORECA Vertical Depth

| Compliance/Integration | Status | Source | Confidence |
|---|---|---|---|
| GDPR compliance | Expected for Belgian SaaS; not explicitly confirmed | Inferred | Estimated |
| Food safety / HACCP | Yes — dedicated HACCP task management module | Company website | Confirmed |
| Allergen management | Yes — automatic allergen tracking & nutritional values | Company website | Confirmed |
| Bancontact | Not applicable (not a POS system) | N/A | Confirmed |
| Fiscal receipt (BE / GKS) | Not applicable | N/A | Confirmed |
| Deliveroo / Uber Eats BE | Via API layer; specific BE integrations not confirmed | Company website (general) | Estimated |
| Multi-site management | Core product capability for 10+ location chains | Company website | Confirmed |
| Central production unit support | Yes — specific module for central kitchens | Company website | Confirmed |
| Carbon footprint tracking | Yes — per recipe and menu level | Company website | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Business model | SaaS subscription per module per location | Tracxn, company website | Confirmed |
| Pricing | Not publicly disclosed; enterprise pricing per site | Company website (no public pricing) | Estimated |
| Estimated ARR | $3.2M–€5.3M (2024) | GetLatka, Tracxn | Estimated |
| Valuation basis | Series A post-money ~€4–6M implied (2021); subsequent round 2025 may imply €15–25M valuation | Tracxn (obfuscated) | Estimated |
| Acquisition value range | €15M–€40M (10–12x ARR at VC-backed premium) | Estimated based on comparable SaaS multiples | Estimated |
| Revenue multiple benchmark | 8–12x for niche SaaS in food/hospitality | Market comparables | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 2 | VC-backed (Volta Ventures, Newion); institutional investors hold board seats; recent 2025 round makes near-term acquisition unlikely at SolStein's budget | KBO, Tracxn |
| Revenue scale fit | High | 3 | ~$3.2M ARR (2024) within €1M–€15M range, but growing and approaching ceiling; Tracxn estimate of €5.3M is closer to upper bound | GetLatka, Tracxn |
| Geographic fit | High | 4 | Belgian-founded and headquartered; serves BE/NL enterprise market; international ambitions may shift focus | KBO, press |
| Tech stack modernity | Medium | 5 | Cloud-native SaaS, AI-powered, REST API, modern modules — exemplary tech stack | Company website |
| Customer lock-in | Medium | 4 | Deep back-of-house integration, multi-module dependency, enterprise contracts; high switching cost | Company website, product design |
| Vertical depth | Medium | 5 | Best-in-class F&B back-of-house for multi-unit hospitality; HACCP, allergen, carbon footprint — deep domain expertise | Company website |
| Integration potential | Low | 5 | Open API, MCP interface, POS/ERP/accounting integrations already in place | Company website |
| Growth trajectory | Low | 3 | Growth has decelerated from ~100% to ~20% YoY; still positive but modest | GetLatka |

### Composite Score

**Weighted Composite: 3.5 / 5.0**

*Calculation*: High-weight (ownership 2, revenue 3, geo 4) × 3 + Medium-weight (tech 5, lock-in 4, vertical 5) × 2 + Low-weight (integration 5, growth 3) × 1 / weighted denominator ≈ 3.5

**Confidence Band**: Medium — KBO data confirmed; revenue and valuation are estimated from secondary sources (GetLatka, Tracxn); no audited accounts reviewed.

---

### Overall M&A Assessment

**Rating: WATCH — Not immediately acquirable, but strategically attractive**

Apicbase is the most technically sophisticated and best-funded of the 7 Belgian HORECA IT targets. Its back-of-house F&B platform is genuinely differentiated, cloud-native, and deeply embedded in enterprise customer workflows. However, the company does not fit SolStein's founder-owned criterion: Volta Ventures and Newion hold board seats and participated in a further funding round as recently as April 2025. This makes acquisition at SolStein's typical target price range very unlikely in the near term.

The company's revenue ($3.2M–€5.3M) is at the upper-middle of SolStein's target band. A potential acquisition window would open if Volta Ventures reaches its fund cycle endpoint (~2026–2028) and seeks a trade sale rather than a further growth round.

---

### Recommended Next Step

Monitor for VC exit signals. Track Volta Ventures fund lifecycle. Consider initiating a soft relationship with Carl Jacobs via industry events (e.g., HORECA Belgium, Food Tech Belgium) to build familiarity. Do not approach with acquisition proposal until VC exit dynamics shift.

---

*Sources*: kbopub.economie.fgov.be (KBO 0550.392.648) · tracxn.com/apicbase · getlatka.com/companies/apicbase · get.apicbase.com/hospitality-tech-scale-up-apicbase-raises-e4m/ · pitchbook.com/profiles/company/222035-41 · Silicon Canals (June 2019) · EU Startups (May 2021)
