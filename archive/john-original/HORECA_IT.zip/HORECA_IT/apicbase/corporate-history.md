# Apicbase — Corporate History

**Research Date**: 2026-04-30
**Researcher**: AI due-diligence agent
**Sources**: KBO Public Search, Tracxn, PitchBook, GetLatka, Apicbase press releases, EU Startups, Silicon Canals

---

## Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | APICBASE NV | KBO 0550.392.648 | Confirmed |
| Trade name (historical) | APIC | KBO (trade name since 2014) | Confirmed |
| Trade name (current) | APICBASE | KBO (name since April 20, 2017) | Confirmed |
| KBO enterprise number | 0550.392.648 | kbopub.economie.fgov.be | Confirmed |
| Legal form | Public limited company (NV) | KBO | Confirmed |
| KBO status | Active | KBO | Confirmed |
| Legal situation start | April 6, 2014 | KBO | Confirmed |
| Registered address | Samberstraat 3, 2060 Antwerpen | KBO | Confirmed |
| VAT subject since | April 1, 2014 | KBO | Confirmed |
| Employer NSSO since | June 1, 2017 | KBO | Confirmed |
| NACE activity (2025) | 62.900 — Other IT and computer service activities | KBO | Confirmed |
| Founding year | 2014 (KBO incorporation) / 2017 (rebranded/operational) | KBO + press release | Confirmed |
| Founders | Carl Jacobs (CEO), Pieter Wellens (CTO), Kim Rothuys, Julien Burlat | Tracxn, press releases | Confirmed |
| Current CEO | Carl Jacobs | KBO (managing director since 2021), press releases | Confirmed |
| Current CTO | Pieter Wellens | Apicbase press release, LinkedIn | Confirmed |
| Current CMO | Joris Brabants | Apicbase press release (2021) | Estimated |
| Director Koen De Waele | Since May 6, 2021 (also Venture Partner at Volta Ventures) | KBO | Confirmed |
| Directors (other) | Jan Verbeke (0466.337.891), Franciscus Claassen (0699.462.149), Marc Mommaerts (0843.353.929) | KBO | Confirmed |
| Share capital | €3,699,484.04 EUR | KBO | Confirmed |
| Financial year end | December 31 | KBO | Confirmed |
| Annual assembly | May | KBO | Confirmed |
| Establishment units | 2 | KBO | Confirmed |
| Seed funding (Jun 2017) | Undisclosed; investors include Ark Angels Activator Fund, BAN Flanders | Tracxn, press release | Estimated |
| Series A (Jun 2019) | ~€1.5M from Collibra-backer (Newion) | Silicon Canals June 2019 | Estimated |
| Series A (May 2021) | €4M led by Volta Ventures; also Newion, AAA Fund, angels | Apicbase press release | Confirmed |
| Total funding | ~$7.56M (Tracxn) / ~$4.5M (GetLatka) | Tracxn, GetLatka | Estimated |
| Latest funding round | April 3, 2025 (~$4.21M) | PitchBook | Estimated |
| Revenue 2021 | $2.0M | GetLatka | Estimated |
| Revenue 2023 | $2.7M | GetLatka | Estimated |
| Revenue 2024 | $3.2M (GetLatka) / €5.31M (Tracxn) | GetLatka, Tracxn | Estimated |
| YoY growth 2024 | ~20% (GetLatka) / ~100% in prior years | GetLatka, press release | Estimated |
| Employees (2024) | 52 | GetLatka | Estimated |
| Employees (Mar 2026) | 49 | Tracxn | Estimated |
| HQ city in CSV | Oudenaarde | horeca_software_companies.csv | Unknown (KBO says Antwerp) |
| Name changes | APIC (2014) → APIBASE (2017) | KBO | Confirmed |
| M&A history | None (no acquisitions as of April 2026) | Tracxn | Confirmed |
| Investor ownership | Volta Ventures, Newion, AAA Fund, Collibra-linked angels | Press releases, Tracxn | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A[APICBASE NV<br/>KBO 0550.392.648<br/>Antwerp, BE<br/>Founded April 2014] --> B[Carl Jacobs<br/>CEO & Co-founder]
    A --> C[Pieter Wellens<br/>CTO & Co-founder]
    A --> D[Kim Rothuys<br/>Co-founder]
    A --> E[Julien Burlat<br/>Co-founder]
    A --> F[Koen De Waele<br/>Director — Volta Ventures rep]
    A --> G[Jan Verbeke<br/>Director — Newion rep]
    A --> H[Marc Mommaerts<br/>Director]
    A --> I[Franciscus Claassen<br/>Director]

    J[Volta Ventures<br/>Lead Series A investor<br/>2021] --> A
    K[Newion<br/>Investor 2019+] --> A
    L[Ark Angels AAA Fund<br/>Seed investor 2017] --> A
```

---

## Corporate Timeline

```mermaid
timeline
    title Apicbase Corporate Timeline
    2014 : April 6 — APIC incorporated (KBO 0550.392.648) as BV
    2017 : June — Seed funding (Ark Angels Activator Fund, BAN Flanders)
         : April — Rebranded/renamed to APICBASE; converted to NV
    2019 : June 20 — ~€1.5M round (Newion/Collibra-backer; Silicon Canals)
    2021 : May 19 — €4M Series A led by Volta Ventures (+ Newion, AAA Fund)
         : Carl Jacobs announces plan to open NY, London, Amsterdam offices
    2024 : Revenue reaches $3.2M with 52-person team
    2025 : April 3 — Further funding round (~$4.21M per PitchBook)
    2026 : 49 employees (Tracxn, March 2026)
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Ownership attractiveness** | NEGATIVE — Apicbase has institutional investors (Volta Ventures, Newion, AAA Fund). Founders do not own 100%. Any acquisition requires investor buy-in at VC-backed valuation multiples. |
| **PE/VC overhang** | YES — Volta Ventures and Newion are current shareholders with board seats (Koen De Waele as director). Last known round was ~2025, so investors likely have a 5–7 year horizon. |
| **Revenue scale fit** | BORDERLINE — Revenue of ~$3.2M–€5.3M ARR (2024) is within the €1M–€15M range, but growth trajectory suggests it may exit the target range by 2026–2027. |
| **Geographic fit** | BORDERLINE — HQ in Antwerp (BE) fits geography, but the company has stated ambitions to open offices in NY, London, and Amsterdam, suggesting international scale ambitions that exceed SolStein's thesis. |
| **M&A readiness** | LOW — Institutional investors actively involved, recent 2025 funding round, international expansion plans. Founders not signaling succession. |
| **Recommended action** | Watch list — revisit after VC exit cycle. Potentially acquirable post-Series B exit if next investor looks for trade sale. |
