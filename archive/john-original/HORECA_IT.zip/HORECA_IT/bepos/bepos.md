# BePOS

**Category**: Restaurant POS
**Country**: BE
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history BePOS @HORECA_IT/bepos/
@research-horeca-company BePOS @HORECA_IT/bepos/
```
