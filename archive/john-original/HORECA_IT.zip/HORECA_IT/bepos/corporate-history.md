# BePOS — Corporate History

> **Clarification**: "BePOS" is not a standalone legal entity. It is a product brand and POS module within **Becosoft** (KBO: BE 0448.096.349), a Belgian provider of POS and ERP solutions headquartered in Temse, Belgium. All corporate history below refers to Becosoft as the legal entity behind BePOS.

---

## KBO / Company Registration

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Becosoft SRL (formerly NV) | companyweb.be | Confirmed |
| KBO enterprise number | BE 0448.096.349 | companyweb.be | Confirmed |
| Legal form | SRL (Société à Responsabilité Limitée / BV) | companyweb.be | Confirmed |
| Registered address | Luxemburgstraat 1, 9140 Temse, Belgium | companyweb.be / becosoft.com | Confirmed |
| Principal activity (NACE) | Computer programming activities | companyweb.be | Confirmed |
| Registration date | 21-08-1992 | companyweb.be | Confirmed |
| VAT registered | Yes | companyweb.be | Confirmed |
| Status | Active | companyweb.be | Confirmed |

**Note**: The task brief describes BePOS as "headquartered in Brussels." This is inaccurate — Becosoft is headquartered in Temse (Province of East Flanders, ~25 km from Antwerp). No separate legal entity named "BePOS" exists in the Belgian KBO registry.

---

## Founding & Founders

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Company name at founding | Becosoft | KBO / State Gazette | Confirmed |
| Founded | 21 August 1992 | companyweb.be (KBO) | Confirmed |
| Founder | Kristof De Coninck | BusinessWire 2023-10-26 | Confirmed |
| Co-founder / sibling | Davy De Coninck | BusinessWire 2023-10-26 | Confirmed |
| Founder description | BusinessWire cites Kristof as sole original founder; Davy joined as MD | BusinessWire 2023-10-26 | Confirmed |
| Founder roles at acquisition | Kristof De Coninck — CEO & MD; Davy De Coninck — COO & MD | BusinessWire 2023-10-26 | Confirmed |
| Legal form change | Changed from NV to SRL (2022) | KBO Gazette 30-06-2022 | Confirmed |
| Bootstrapped | Yes — "bootstrapped founders" per press release | BusinessWire 2023-10-26 | Confirmed |

---

## Name Changes & Legal Form History

| Date | Event | Source | Confidence |
|---|---|---|---|
| 21-08-1992 | Company founded as Becosoft | KBO | Confirmed |
| 30-06-2022 | Legal form change + Articles updated + management changes | State Gazette | Confirmed |
| 13-10-2023 | Becosoft Holdings Belgium SRL incorporated (BE 1001.184.609) — Arcadea vehicle | companyweb.be | Confirmed |
| 26-10-2023 | Majority acquisition by Arcadea Group announced | BusinessWire | Confirmed |
| 02-01-2026 | Goal publication + Articles update (Holdings level) | State Gazette | Confirmed |

---

## Ownership & M&A History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pre-2023 ownership | Founder-owned, bootstrapped (Kristof & Davy De Coninck) | BusinessWire 2023-10-26 | Confirmed |
| M&A event | Majority acquisition by Arcadea Group | BusinessWire / PE Hub / Crunchbase | Confirmed |
| M&A date | 26 October 2023 (announced) | BusinessWire | Confirmed |
| Acquirer | Arcadea Group (Toronto, Canada + Orlando, FL offices) | BusinessWire | Confirmed |
| Acquirer type | Long-hold, growth-oriented SaaS investor ("permanent-hold" model) | BusinessWire / arcadeagroup.com | Confirmed |
| Arcadea deal structure | Majority stake; founders retain "significant equity interest" and continue in roles | BusinessWire | Confirmed |
| Current majority owner | Arcadea Group | BusinessWire / Crunchbase / ZoomInfo | Confirmed |
| Arcadea MD on deal | Daniel Eisen + Paul Yancich | BusinessWire | Confirmed |
| Legal counsel | Strelia (assisted Arcadea) | apex-partners.com / strelia.com | Confirmed |
| Pre-deal investor rounds | None (bootstrapped) | BusinessWire | Confirmed |
| Post-deal acquisitions by Becosoft | None identified | — | Unknown |

### Holdco Structure (Post-2023)

| Entity | KBO | Established | Role | Source | Confidence |
|---|---|---|---|---|---|
| Becosoft SRL | BE 0448.096.349 | 21-08-1992 | Operating company | KBO | Confirmed |
| Becosoft Holdings Belgium SRL | BE 1001.184.609 | 13-10-2023 | Holding vehicle (Arcadea) | companyweb.be | Confirmed |

---

## Investment Events

| Date | Event | Amount | Investor | Source | Confidence |
|---|---|---|---|---|---|
| October 2023 | Majority acquisition | Undisclosed | Arcadea Group (Canada) | BusinessWire 2023-10-26 | Confirmed |
| Pre-2023 | No external funding | — | — | BusinessWire (bootstrapped) | Confirmed |

---

## BePOS Product Brand

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Product name | BePOS | support.becosoft.com | Confirmed |
| Product category | HORECA POS (restaurant/hospitality) | support.becosoft.com; becosoft.com | Confirmed |
| Parent company | Becosoft BV | support.becosoft.com footer | Confirmed |
| Separate legal incorporation | None identified in KBO | KBO search | Confirmed |
| Domain bepos.be | Not owned by Becosoft — resolves to Fixolite (construction company) | bepos.be | Confirmed |

---

## Mermaid Corporate Structure

```mermaid
graph TD
    A["Arcadea Group<br/>(Toronto, Canada — majority)"]
    B["Kristof De Coninck<br/>(CEO, significant minority)"]
    C["Davy De Coninck<br/>(COO, significant minority)"]
    D["Becosoft Holdings Belgium SRL<br/>BE 1001.184.609<br/>Est. 13-10-2023"]
    E["Becosoft SRL<br/>BE 0448.096.349<br/>Est. 21-08-1992<br/>Temse, Belgium<br/>~38 FTE"]
    F["BePOS<br/>(Product Brand — HORECA POS)"]
    G["Retail/Wholesale ERP<br/>(Primary product line)"]

    A --> D
    B --> D
    C --> D
    D --> E
    E --> F
    E --> G
```

---

## Corporate Timeline

```mermaid
timeline
    title Becosoft / BePOS Corporate Timeline
    1992 : Becosoft founded in Temse by Kristof De Coninck
         : Computer programming / POS for retail
    2001 : Commonly cited LinkedIn/PitchBook founding year
         : (likely year of significant growth or relaunch)
    2022 : Legal form change NV → SRL
         : Management updates
    2023-10 : Arcadea Group acquires majority stake
            : Becosoft Holdings Belgium SRL incorporated
            : BePOS brand active in HORECA support portal
    2024 : 38.4 FTE, gross margin €2.4M
         : Arcadea accelerates product expansion
    2026-01 : Holdings articles updated in State Gazette
```

---

## M&A Feasibility Assessment

### Summary Verdict: **NOT FEASIBLE** — PE Overhang (Arcadea Group, majority stake since Oct 2023)

| Dimension | Assessment |
|---|---|
| **PE overhang** | **BLOCKING.** Arcadea Group holds majority. SolStein thesis requires no PE overhang. Arcadea is a permanent-hold firm — exits are long-horizon and on Arcadea's terms. |
| **Founder availability** | Founders (De Coninck brothers) remain in roles with minority equity. They are not free to sell without Arcadea's agreement. |
| **Scale** | Gross margin ~€2.4M (2024), declining trend. Revenue unknown but modest for a 38-person firm. May be at low end of SolStein's €1M–€15M ARR target but uncertainty is high. |
| **Geography** | Temse (East Flanders), not Brussels as originally noted. Benelux market alignment is present. |
| **HORECA fit** | HORECA (BePOS) is a secondary vertical; primary business is retail/wholesale ERP. Pure-play HORECA fit is weak. |
| **Recommended action** | **PASS** — remove from active pipeline. Monitor for Arcadea exit (unlikely <5 years). |

---

## Data Confidence Summary

| Category | Confirmed | Estimated | Unknown |
|---|---|---|---|
| KBO registration | ✓ | | |
| Founding date | ✓ | | |
| Founders | ✓ | | |
| Ownership (current) | ✓ | | |
| Revenue/ARR | | | ✓ |
| HORECA-specific revenue share | | | ✓ |
| Exact Arcadea deal value | | | ✓ |
| Founders' equity % retained | | ✓ | |
| Succession signals | ✓ (locked in by Arcadea) | | |

---

*Research date: 2026-04-30. Sources: KBO Belgium, companyweb.be, BusinessWire, PE Hub Europe, Crunchbase, pitchbook.com, support.becosoft.com.*
