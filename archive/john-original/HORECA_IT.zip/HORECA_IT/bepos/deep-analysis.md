# BePOS — Deep Analysis

> **Entity clarification**: "BePOS" is a product brand of **Becosoft SRL** (KBO: BE 0448.096.349), not a standalone legal entity. This analysis covers Becosoft as the legal entity, with specific focus on the BePOS HORECA product line.

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Becosoft SRL | KBO | Confirmed |
| KBO number | BE 0448.096.349 | KBO | Confirmed |
| Founded | 21 August 1992 | KBO (companyweb.be) | Confirmed |
| Headquarters | Luxemburgstraat 1, 9140 Temse, Belgium | KBO / becosoft.com | Confirmed |
| Common "founding year" cited | 2001 (LinkedIn, PitchBook) | LinkedIn / PitchBook | Estimated |
| Employees (2024 FTE) | 38.4 FTE | KBO / annual accounts | Confirmed |
| Employees (2023 FTE) | 33.8 FTE | KBO / annual accounts | Confirmed |
| Employees (2022 FTE) | 34.4 FTE | KBO / annual accounts | Confirmed |
| Gross margin 2024 | €2,437,806 | companyweb.be / NBB | Confirmed |
| Gross margin 2023 | €2,603,791 | companyweb.be / NBB | Confirmed |
| Gross margin 2022 | €2,611,556 | companyweb.be / NBB | Confirmed |
| Profit/Loss 2024 | -€674,873 | companyweb.be / NBB | Confirmed |
| Profit/Loss 2023 | +€34,213 | companyweb.be / NBB | Confirmed |
| Revenue (turnover) | Not published | KBO (not required for SRL below threshold) | Unknown |
| Revenue estimate | ~€5M–€15M (inferred from gross margin, headcount, RocketReach $15M) | RocketReach; analyst inference | Estimated |
| Website | becosoft.com | Primary source | Confirmed |
| BePOS support | support.becosoft.com | Primary source | Confirmed |
| Majority owner | Arcadea Group (Canada) — majority since Oct 2023 | BusinessWire 2023-10-26 | Confirmed |
| Founders (retained minority) | Kristof De Coninck (CEO) + Davy De Coninck (COO) | BusinessWire 2023-10-26 | Confirmed |
| Ownership type | PE-backed (Arcadea Group — permanent-hold SaaS investor) | BusinessWire | Confirmed |

### Key Structural Note

Becosoft is a **multi-vertical POS and ERP company**. Its primary focus is **retail and wholesale** (fashion retailers, fashion wholesalers, garden centers), with HORECA hospitality being a **secondary vertical** via the BePOS product line. This significantly affects HORECA depth scores.

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| HORECA product name | BePOS | support.becosoft.com | Confirmed |
| HORECA position | Secondary vertical (primary = retail/wholesale) | BusinessWire; becosoft.com | Confirmed |
| Belgian HORECA customers (count) | Unknown | — | Unknown |
| Market share in Belgian restaurant POS | Unknown; not a primary HORECA vendor | — | Unknown |
| Geographic reach | Benelux (primary); pan-European for large retail operators | BusinessWire | Confirmed |
| Competitors in Belgian HORECA POS | Lightspeed, Kaspr, WPOS, CloudPOS, Caspeco, Restomax/Tills | market research | Estimated |
| HORECA product maturity | Support portal active (2024–2026), hardware requirements documented | support.becosoft.com | Confirmed |
| Belgian HORECA market position | Niche / unknown share — not dominant | — | Estimated |
| Key HORECA differentiator claimed | "Innovative POS for the hospitality sector," omnichannel, cloud-first, AI-driven | becosoft.com | Confirmed |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Product brand | BePOS (HORECA POS) | support.becosoft.com | Confirmed |
| Product architecture | Cloud-first (stated on website) | becosoft.com/en | Confirmed |
| Omnichannel capability | Yes — inventory + sales sync across physical and digital channels | becosoft.com | Confirmed |
| AI-driven features | Claimed (process optimization, automation) | becosoft.com | Estimated |
| CRM integration | Yes — loyalty programs, customer data | becosoft.com | Confirmed |
| Inventory management | Yes — complex inventory, multi-location | becosoft.com / BusinessWire | Confirmed |
| Order entry & invoicing | Yes | PitchBook | Confirmed |
| Mobile/tablet support | Yes (Google Play app referenced in BePOS context) | play.google.com; Apple App Store | Estimated |
| Hardware requirements | Documented (BePOS hardware requirements article) | support.becosoft.com | Confirmed |
| 24/7 support | Yes | becosoft.com | Confirmed |
| Belgian fiscal compliance (GKS/SCE) | Belgium requires GKS for HORECA >€25K on-premise revenue; Becosoft serves HORECA — GKS compliance expected but not explicitly confirmed in public sources | fiskaly.com; fiscal-requirements.com | Estimated |
| GKS 2.0 readiness | GKS 2.0 mandatory from Jan 2026 (new) / Jul 2026 (existing); Becosoft's compliance status unconfirmed publicly | fiskaly.com | Unknown |
| Bancontact payment integration | Not publicly confirmed; expected for Belgian HORECA | — | Unknown |
| Fiscal receipt (TVA receipt) | Expected for HORECA compliance; not explicitly documented publicly | — | Unknown |
| Tech stack | Not publicly disclosed | — | Unknown |
| API / integrations | Not publicly documented | — | Unknown |
| Primary product beyond HORECA | Retail/Wholesale ERP + POS for fashion, garden centers, complex supply chains | BusinessWire; becosoft.com | Confirmed |

### Belgian Fiscal Context (GKS)
Belgium mandates a **Geregistreerd Kassasysteem (GKS / SCE)** for all HORECA establishments with on-premise sales exceeding €25,000/year. The system requires:
- A **certified POS** (software certified by FPS Finance)
- A **Fiscal Data Module (FDM)** — the "Black Box"
- A **Virtual Smart Card (VSC)**

**GKS 2.0** (real-time reporting to FPS Finance cloud) is mandated from January 2026 for new establishments and July 2026 for existing ones. Whether BePOS holds current GKS 2.0 certification is **unknown** from public sources — this is a due-diligence priority.

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Current ownership structure | Arcadea Group (majority) + De Coninck brothers (significant minority) | BusinessWire | Confirmed |
| Pre-deal ownership | 100% founder-owned (bootstrapped) | BusinessWire | Confirmed |
| PE involvement | YES — Arcadea Group, majority stake since October 2023 | BusinessWire | Confirmed |
| PE firm type | Permanent-hold SaaS investor (not traditional PE with 5-year exit horizon) | BusinessWire / arcadeagroup.com | Confirmed |
| Founder succession signal | Low — founders continue in CEO/COO roles, locked in with Arcadea | BusinessWire | Confirmed |
| Arcadea exit horizon | Long-hold ("no traditional PE or growth equity firm can match" — per Arcadea) | arcadeagroup.com | Confirmed |
| Founders' age / retirement signal | Unknown | — | Unknown |
| M&A feasibility | BLOCKED by PE overhang (Arcadea majority) | — | Confirmed |
| Holdco established | Becosoft Holdings Belgium SRL (BE 1001.184.609) — 13-10-2023 | companyweb.be | Confirmed |
| Holdings equity 2024 | €6,811,010 | companyweb.be | Confirmed |
| Holdings equity 2023 | €7,116,700 (pre-2023 comparison) | companyweb.be | Confirmed |
| Holdings loss 2024 | -€305,690 | companyweb.be | Confirmed |

### Succession Analysis

Before the October 2023 Arcadea deal, Becosoft was a **textbook SolStein target**: bootstrapped, founder-led, 30+ years of stable operation, Benelux market, niche POS software. The De Coninck brothers explicitly cited "no PE" preference before Arcadea — they were approached many times but chose Arcadea's "partnership model" and "long-term vision."

**Post-deal**: The company is now PE-backed. Arcadea is a "permanent-hold" firm — it does not have the same 5–7 year exit pressure as traditional PE. An Arcadea exit (and thus availability for acquisition by SolStein) is not expected within a 5–10 year horizon under normal circumstances.

---

## 5. Financial Growth & Trajectory

| Metric | 2021 | 2022 | 2023 | 2024 | Trend |
|---|---|---|---|---|---|
| Gross Margin | €2,208,809 | €2,611,556 | €2,603,791 | €2,437,806 | Peak 2022; declining |
| Profit/Loss | +€68,157 | +€31,988 | +€34,213 | -€674,873 | Turning negative |
| Equity | €740,565 | €772,553 | €806,766 | €131,893 | Sharp drop 2024 |
| FTE | 31.9 | 34.4 | 33.8 | 38.4 | Slow growth |

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue (turnover) | Not published | KBO | Unknown |
| Revenue estimate | €5M–€15M (third-party sources vary: ZoomInfo <$5M, RocketReach ~$15M) | ZoomInfo / RocketReach | Estimated |
| 2024 financial position | Loss year (-€674K); equity fell 84% YoY | NBB / companyweb | Confirmed |
| Growth trajectory | Gross margin flat/declining since 2022; 2024 significant loss | KBO / NBB | Confirmed |
| HORECA ARR share | Unknown — primary business is retail/wholesale | — | Unknown |
| SaaS ARR (total) | Unknown | — | Unknown |
| Estimated total ARR | €3M–€8M (based on gross margin ~€2.4M and typical SaaS multiples for mixed software/services firm) | Analyst inference | Estimated |

### Financial Concern
The 2024 accounts show a **significant deterioration**: profit flipped to -€674K and equity dropped 84% to €131K (operating entity). This may reflect acquisition costs, Arcadea integration investment, or structural issues. The Holdings entity (Arcadea vehicle) holds €6.8M equity — suggesting operating losses are being absorbed at the holding level.

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| HORECA vertical depth | Shallow — BePOS is one product line among several | becosoft.com; BusinessWire | Confirmed |
| Primary verticals | Fashion retail, fashion wholesale, garden centers, complex supply chains | BusinessWire | Confirmed |
| HORECA product name | BePOS | support.becosoft.com | Confirmed |
| Belgian fiscal law compliance (GKS) | Expected (serves HORECA in Belgium); certification status unconfirmed | fiskaly.com (context) | Estimated |
| GKS 2.0 (2026 mandate) | Compliance status unknown | — | Unknown |
| GDPR compliance | Expected (Belgian company, processes customer data) | GDPR regulation | Estimated |
| Restaurant-specific features | Table management, floor plan, kitchen printing: not confirmed publicly | — | Unknown |
| Cafe/bar features | Mentioned in general terms; specifics unknown | — | Unknown |
| Bancontact support | Not confirmed publicly; expected for Belgian HORECA | — | Unknown |
| Online ordering integration | Omnichannel claimed; delivery platform integrations unconfirmed | becosoft.com | Estimated |
| Reservations integration | Not mentioned | — | Unknown |
| Kitchen display system (KDS) | Not confirmed | — | Unknown |
| Belgian HORECA specialization | Low — company is primarily retail/wholesale; HORECA is secondary | BusinessWire; becosoft.com | Confirmed |

### Vertical Assessment
BePOS is a **POS tool** offered to hospitality clients, but Becosoft's core DNA is retail/wholesale ERP (fashion, garden centers). HORECA-specific depth — Belgian fiscal compliance, table management, kitchen workflows, tipping, split bills — is not publicly documented. The company does not market itself as a specialist HORECA provider.

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Business model | Mixed: SaaS software + hardware + professional services | becosoft.com | Confirmed |
| Pricing model for BePOS | Not publicly disclosed | — | Unknown |
| Per-venue SaaS pricing | Unknown | — | Unknown |
| Estimated HORECA venues | Unknown | — | Unknown |
| Estimated HORECA ARR | Unknown | — | Unknown |
| Total company ARR estimate | €3M–€8M (based on gross margin €2.4M) | Analyst inference | Estimated |
| Arcadea deal valuation | Not disclosed | — | Unknown |
| Comparable SaaS multiples | Belgian mid-market vertical SaaS: 3–6x ARR | market benchmarks | Estimated |
| Estimated enterprise value (total Becosoft) | €10M–€48M (wide band, high uncertainty) | Analyst inference | Estimated |
| HORECA-only value (BePOS) | Very difficult to ring-fence; HORECA is not a reportable segment | — | Unknown |
| Acquisition feasibility | Not feasible (PE-owned; Arcadea permanent-hold) | — | Confirmed |

### Acquisition Value Context
A standalone BePOS product carve-out from Becosoft would be highly complex:
- BePOS is not a separate legal entity
- Shared infrastructure with retail/wholesale ERP
- Arcadea would need to agree to divest a product line — unlikely given permanent-hold model
- HORECA-specific customer base and revenue are not publicly segmented

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | **1** | Arcadea Group holds majority stake since Oct 2023. Permanent-hold model — no near-term exit. Founders locked in. Directly contradicts SolStein's "no PE overhang" criterion. | BusinessWire 2023-10-26 |
| **Revenue scale fit** | High | **2** | Gross margin ~€2.4M (2024). Estimated total ARR €3M–€8M — may be within SolStein range, but HORECA share is uncertain and small. 2024 was a loss year. Confidence is low. | companyweb.be / NBB |
| **Geographic fit** | High | **3** | Headquartered in Temse, Belgium (Benelux). Pan-European reach. Benelux customer base confirmed. Not Brussels as originally noted, but geography is relevant. | KBO; BusinessWire |
| **Tech stack modernity** | Medium | **3** | Cloud-first claimed. AI-driven automation claimed. Omnichannel SaaS architecture. However, GKS 2.0 readiness unconfirmed; tech stack details not public. | becosoft.com |
| **Customer lock-in** | Medium | **3** | Complex ERP/POS implementations typically have high switching costs. 30+ year company suggests long customer relationships. Specifics for HORECA lock-in unknown. | Analyst inference |
| **Vertical depth** | Medium | **2** | HORECA is a secondary vertical. Primary business is retail/wholesale. Belgian HORECA-specific depth (GKS, table management, kitchen ops) not documented publicly. Weak HORECA specialization. | BusinessWire; becosoft.com |
| **Integration potential** | Low | **2** | No public API or integration documentation for BePOS. Omnichannel approach suggests some integration capability. Unknown compatibility with third-party HORECA tools. | — |
| **Growth trajectory** | Low | **2** | Gross margin flat/declining since 2022 peak. 2024 was a significant loss year (-€674K). Equity collapsed 84% at operating entity level. Headcount grew modestly (+4.6 FTE 2023→2024). | companyweb.be / NBB |

### Composite Score

| | |
|---|---|
| **Weighted composite** | **2.1 / 5.0** |
| **Confidence band** | **Narrow-to-medium** (40% Confirmed, 35% Estimated, 25% Unknown) |

**Score methodology**: High-weight dimensions (3 factors, score 1+2+3 = 6, max 15) contribute ~60% of composite; medium-weight (3 factors) ~30%; low-weight (2 factors) ~10%. Weighted result ≈ 2.1.

---

### Overall Assessment

**BePOS / Becosoft is NOT a viable M&A target for SolStein at this time.**

The single most important disqualifier is the **Arcadea Group majority acquisition (October 2023)**. SolStein's thesis explicitly requires "no PE overhang" — Becosoft is now PE-backed by a self-described permanent-hold investor. There is no realistic path to acquisition within a 3–5 year horizon.

Secondary concerns:
- BePOS is **not a standalone HORECA company** — it is a product within a retail/wholesale-focused ERP vendor
- HORECA vertical depth is shallow; Belgian fiscal compliance (GKS 2.0) is unconfirmed
- The 2024 financial accounts show **deteriorating performance** (loss, equity drop) — likely related to Arcadea integration costs
- Headquarters is in Temse, not Brussels (minor data quality concern in the original target list)

The De Coninck brothers were a textbook SolStein target **before** October 2023 — bootstrapped, founder-led, 30+ years in Belgian POS software. The window closed with the Arcadea deal.

---

### Recommended Next Step

**PASS — move to Tier 2 (Watch List) with blocker: PE-owned (Arcadea Group).**

1. Close active M&A evaluation; no outreach warranted
2. Set a calendar reminder to reassess in 2028–2029 (Arcadea's typical hold horizon is 5–10+ years)
3. If Arcadea announces exit, re-activate research immediately
4. Consider BePOS as a competitive intelligence reference for Belgian HORECA POS landscape

---

## Sources Used

| Source | URL | Type |
|---|---|---|
| KBO / companyweb.be | https://www.companyweb.be/en/0448096349/becosoft | Primary — Trade Register |
| Becosoft Holdings KBO | https://www.companyweb.be/en/1001184609/becosoft-holdings-belgium | Primary — Trade Register |
| BusinessWire (Arcadea deal) | https://www.businesswire.com/news/home/20231026675444/en/Becosoft-Announces-Majority-Partnership-with-Arcadea-Group | Confirmed — Press Release |
| PE Hub Europe | https://www.pehubeurope.com/arcadea-group-invests-in-becosoft/ | Confirmed — News |
| Becosoft website | https://www.becosoft.com | Primary — Company website |
| BePOS support portal | https://support.becosoft.com/hc/en-us/categories/16754165302802-BePOS | Primary — Company |
| PitchBook | https://pitchbook.com/profiles/company/539194-51 | Secondary |
| Crunchbase | https://www.crunchbase.com/organization/becosoft | Secondary |
| GKS Belgium (Fiskaly) | https://www.fiskaly.com/blog/gks-2-0-fdm-requirements-belgium | Reference — Regulatory |
| bepos.be | https://bepos.be | Primary (confirms no BePOS entity at this domain) |

---

*Research date: 2026-04-30. All scores reflect information available as of this date.*
