# TableFever

**Category**: Reservations
**Country**: BE
**City**: Ghent (Sint-Denijs-Westrem)
**Research Status**: Done 2026-04-30

**Discovery Source**: Tablebooker deep-analysis (2026-04-30) — identified as the only remaining independent Belgian restaurant reservation platform after Tablebooker and Resengo were absorbed by Zenchef (PSG Equity).

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Done 2026-04-30 |
| `deep-analysis.md` | Done 2026-04-30 |
| `financial-growth.md` | N/A — financial data embedded in deep-analysis.md |
