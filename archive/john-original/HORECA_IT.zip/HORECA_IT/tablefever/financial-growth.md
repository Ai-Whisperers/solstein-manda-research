# Financial & Growth Deep-Dive — TableFever

**Research Date**: 2026-04-30
**Data Availability**: Medium — Belgian KBO/NBB filings yield gross margin and profit data for 2022–2025 (confirmed); turnover published for 2022 only; pricing confirmed from T&C; headcount confirmed via KBO FTE filings; ARR requires triangulation from multiple proxies.

---

### Revenue Timeline

TableFever files abbreviated annual accounts ("kleine onderneming / petite entreprise") with the National Bank of Belgium (NBB / Balanscentrale). Under Belgian accounting law for micro-/small entities, turnover is only disclosed when it cannot be derived from other published figures. **Turnover was published for 2022 only.** For 2023–2025 the gross margin (bruto marge) is the highest-confidence financial indicator available and is used as a revenue proxy throughout this document.

> **Gross margin proxy rationale**: In 2022, published turnover (€851,454) and published gross margin (€675,820) yield a gross margin ratio of 79.4%. This is consistent with a pure-play cloud SaaS model where the only COGS is hosting/infrastructure. The 79.4% ratio is applied to estimate turnover for 2023–2025 where the raw turnover is suppressed.

| Year | Gross Margin (proxy) | Turnover (published / est.) | YoY Growth (GM basis) | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2026 (est.) | ~€1.81M | ~€2.28M est. | +28% | Extrapolation (28% CAGR sustained) | Estimated |
| 2025 | €1,412,085 | ~€1.78M est. | +30% | KBO / NBB filing via companyweb.be (filed 04-11-2025) | Confirmed (GM); Estimated (turnover) |
| 2024 | €1,086,937 | ~€1.37M est. | +19% | KBO / NBB filing via companyweb.be | Confirmed (GM); Estimated (turnover) |
| 2023 | €915,253 | ~€1.15M est. | +35% | KBO / NBB filing via companyweb.be | Confirmed (GM); Estimated (turnover) |
| 2022 | €675,820 | **€851,454** (published) | +28% vs 2021 est. | KBO / NBB filing via companyweb.be | **Confirmed** |
| 2021 | ~€528K est. | ~€665K est. | — | Back-extrapolation from 2022 at 28% CAGR; COVID recovery period | Estimated |

**Revenue CAGR (3yr, 2022–2025)**: **27.9%** (gross margin basis; confirmed data)
**Revenue CAGR (3yr, 2022–2025)**: ~27.9% (turnover basis; estimated for 2023–2025)

> **2021 caveat**: TableFever was active during COVID-19. Belgium imposed repeated hospitality closures in 2020 and 2021. The DPD Fresh partnership (March 2021) shows active product development during this period. The 2021 estimate of ~€528K may overstate actual performance if growth accelerated sharply post-lockdown in 2022. No pre-2022 NBB filing data is publicly accessible from companyweb.be.

#### Revenue Trend Chart

```mermaid
xychart-beta
    title "TableFever Gross Margin / Revenue Proxy (EUR M)"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "EUR Millions" 0 --> 2.0
    line [0.53, 0.68, 0.92, 1.09, 1.41, 1.81]
```

---

### Profitability

| Data Point | 2022 | 2023 | 2024 | 2025 | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Gross Margin | €675,820 | €915,253 | €1,086,937 | €1,412,085 | KBO / companyweb.be | Confirmed |
| Net Profit | €298,039 | €388,699 | €545,759 | €731,240 | KBO / companyweb.be | Confirmed |
| Equity (book) | €624,460 | €613,159 | €778,917 | €1,010,158 | KBO / companyweb.be | Confirmed |
| Net Margin (turnover basis) | 35.0% | ~33.8% est. | ~39.8% est. | ~41.1% est. | Calculated | Confirmed (2022); Estimated (2023–2025) |
| Gross Margin % | 79.4% | ~79.4% est. | ~79.4% est. | ~79.4% est. | Calculated from 2022 ratio | Confirmed (2022); Estimated (2023–2025) |
| EBITDA (est.) | ~€320K | ~€410K | ~€570K | ~€760K | Net profit + estimated minimal depreciation (micro team, low capex) | Estimated |
| Recurring Revenue % | ~100% | ~100% | ~100% | ~100% | Subscription-only model confirmed in T&C; no per-booking commission | Confirmed |
| SaaS Revenue % | ~100% | ~100% | ~100% | ~100% | Pure-play SaaS reservation + website/marketing services; no hardware | Confirmed |
| Revenue per Employee | ~€387K | ~€360K | ~€415K | ~€387K | Gross margin / FTE (KBO basis) | Estimated |

**ARR Estimation (2025)**:

Two triangulation methods applied:

| Method | Calculation | Result |
| --- | --- | --- |
| **Gross margin proxy** | 2025 GM €1.41M ÷ 79.4% GM ratio | ~**€1.78M ARR** |
| **Customer count × ARPU** | ~1,500 avg restaurants (growth toward 2,000 during year) × €78/month blended × 12 | ~**€1.41M ARR** |
| **Full-year 2,000 at blended €75/month** | 2,000 × €75 × 12 | **€1.80M ARR** |

> **Blended ARPU rationale**: Published T&C rate is €99/month excl. VAT per restaurant (Reservation Module). A Facebook discussion references €30/month for older customers, suggesting legacy pricing. Blended estimate of €65–78/month is consistent with a mix of legacy and current-rate subscribers, yielding an ARR in the range of **€1.4M–€1.8M (2025)**. The 48-month fixed contract term means all current subscribers are locked in.

**Key profitability observation**: TableFever generated a 41% net margin in 2025 on a 4.6 FTE cost base. This is an extraordinarily profitable micro-cap SaaS. The company is accumulating cash via retained earnings (equity: €624K in 2022 → €1.01M in 2025, a 62% increase in book equity).

---

### Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| 2014–present | Bootstrap / self-financed | €0 external | Founder (Stef Van der Schueren) | N/A | companyweb.be; Crunchbase; Belgian M&A press; absence of any funding announcement | Confirmed |

**Total Raised**: **€0 — Bootstrapped since founding (August 2014)**
**Latest Valuation**: Not applicable — private, founder-owned, no VC/PE transaction
**Current Investors**: Founder-owned (estimated 100% by Stef Van der Schueren)
**War Chest Signals**: Book equity of €1,010,158 (2025 filing), growing via retained earnings. No disclosed debt or credit facilities. Small team means low burn rate. The company generates €731K net profit annually on €1.41M gross margin — it is self-funding any growth investment.

**Government Grants / Subsidies**: No VLAIO.be or EU-funded grants identified in public records. No Horizon Europe or Belgian regional subsidy announcements found.

---

### Employee Timeline

> **FTE vs LinkedIn note**: KBO annual accounts report average FTE (full-time equivalents) for the financial year. The LinkedIn employee count of ~7 reflects a snapshot in 2026 and likely includes part-time staff counted as fractional FTE in the KBO filings, plus possible freelancers.

| Year | Headcount (KBO FTE) | LinkedIn / Est. | YoY Growth (FTE) | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2026 (current) | ~5–6 est. | **~7** | +52% (LinkedIn vs 2025 KBO) | LinkedIn company page (April 2026) | Estimated |
| 2025 | **4.6 FTE** | — | +39% | KBO / NBB filing (filed 04-11-2025) | Confirmed |
| 2024 | **3.3 FTE** | — | +3% | KBO / NBB filing | Confirmed |
| 2023 | **3.2 FTE** | — | +45% | KBO / NBB filing | Confirmed |
| 2022 | **2.2 FTE** | — | — | KBO / NBB filing | Confirmed |
| 2021 | ~1.7 est. | — | — | Back-extrapolation; COVID recovery context | Estimated |

**Employee CAGR (3yr, 2022–2025)**: **27.9%** (FTE basis, KBO confirmed)
**Current Open Positions**: No active job listings identified on tablefever.com/en/jobs or LinkedIn Jobs at time of research (April 2026). Historically recruited for: social media management, administrative support, sales (2022–2023).
**Hiring Hotspots**: Sint-Denijs-Westrem (Ghent area) — single location, no geographic distribution of hiring.

**Hiring pattern observation**: The FTE jump from 3.3 (2024) to 4.6 (2025, +39%) coincides with the period when Zenchef had completed its Belgian consolidation (Resengo Sep 2023 + Tablebooker Feb 2024) and TableFever was absorbing displaced restaurant clients. The 2024 flat year (3.2→3.3 FTE) may reflect a hiring lag relative to revenue growth, with the founder managing customer onboarding before hiring.

#### Employee Growth Chart

```mermaid
xychart-beta
    title "TableFever Headcount (FTE)"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "Headcount (FTE)" 0 --> 8
    line [1.7, 2.2, 3.2, 3.3, 4.6, 7]
```

---

### Pricing Model — Detail

> Source: TableFever B2B Agreement Template (tablefever.com/en/algemene-voorwaarden); confirmed via direct T&C read. This is the contractual pricing structure, not a published public pricing page.

| Module | Price | Billing | Contract Term | Notes |
| --- | --- | --- | --- | --- |
| Reservation Module | **€99/month excl. VAT** | Monthly, direct debit | **48 months fixed** | Core module; setup fee applies (amount defined at signing) |
| Google Module | **€120/year excl. VAT** | Annual | Part of main contract | Enables "Reserve with Google" bookings |
| Website Module | **€195/month excl. VAT** | Monthly installments | 48 months | Fixed build price upfront + monthly; restaurant owns the site |
| Gift Voucher Module | % per redeemed voucher | Per transaction | Part of main contract | Rate defined per restaurant; platform sells on restaurant's behalf |
| Mail Campaigns | Custom | Monthly | Part of main contract | Branded newsletters/campaign emails to guest list |
| Ticket Module | % of ticket value | Per transaction | Part of main contract | Advance payment / no-show protection deposits |

**Key commercial insight**: The 48-month fixed contract with automatic 48-month renewal (on 3 months' notice before end of term) creates extraordinary revenue visibility. Early termination triggers full remaining-contract penalty. A restaurant signed in 2023 is contractually committed through 2027. This structure explains TableFever's consistent profitability despite a tiny team — churn is structurally minimized by contract architecture, not product quality alone.

**Estimated blended ARPU**: €65–78/month (factoring legacy customers on older, lower rates; the €30/month Facebook reference likely reflects early pricing from 2015–2019 era).

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2014 | Founded; Belgium launch | BE | Launched as Belgian restaurant reservation SaaS in Zottegem, Flemish Brabant | KBO founding date | Confirmed |
| 2021 (Mar) | DPD Fresh partnership | BE | Enabled refrigerated takeaway delivery for Belgian top restaurants via TableFever platform | dpd.com/be/nl/news | Confirmed |
| 2022 | Declined Zenchef acquisition approach | BE | Stef Van der Schueren declined acquisition offer from Zenchef (then pre-merger with Formitable) | vierbordjes.be interview | Confirmed |
| 2023–2024 | Post-consolidation displacement growth | BE | Resengo (Sep 2023) and Tablebooker (Feb 2024) absorbed by Zenchef; TableFever gains displaced Belgian restaurants | manda.be; vierbordjes.be | Confirmed |
| 2025 | 2,000 restaurant milestone | BE (+) | Het Nieuwsblad article: "2.000 restaurants in binnen- en buitenland" — primary market Belgium; minor possible cross-border presence | Nieuwsblad, 15 May 2025 | Confirmed (BE); Estimated (abroad) |

**Primary Market**: Belgium (Flemish focus; operational HQ Sint-Denijs-Westrem / Ghent area)
**International Revenue %**: Not disclosed. The Nieuwsblad phrase "binnen- en buitenland" ("in Belgium and abroad") suggests minimal cross-border presence — most likely Belgian restaurateurs with locations in adjacent countries or cross-border restaurants serving Belgian customers. No international office, partner, or press release indicating active expansion found.
**NL Market Coverage**: None identified — no Dutch-language marketing, no NL press, no Dutch company registration found
**Expansion Trajectory**: Deliberately Belgium-only. Post-consolidation, the market opportunity is the estimated 40% of Belgian restaurants still without any online reservation system, plus migration from Zenchef's now-6,000-restaurant Belgian base. Van der Schueren explicitly frames TableFever's positioning around Belgian-specific service quality, which Zenchef's international scale cannot match.

---

### M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Mar 2021 | **DPD Fresh partnership** | N/A (commercial deal) | Refrigerated takeaway delivery logistics for Belgian restaurants via TableFever platform | COVID response: added delivery capability to reservation platform; differentiated from pure-reservation competitors | dpd.com/be press release | Confirmed |
| 2022 | **Declined Zenchef acquisition approach** | Undisclosed | N/A (seller-side event) | Stef Van der Schueren rejected Zenchef's acquisition offer; preference for independence confirmed | vierbordjes.be; Stef Van der Schueren direct quote | Confirmed |
| 2025 | **Received acquisition offer (undisclosed party)** | "Mooi overnamebod" (nice offer) | N/A (seller-side event) | Founder publicly acknowledged the offer but no announcement of acceptance or rejection | Nieuwsblad, 15 May 2025 (headline; article paywalled) | Confirmed (offer received); Unknown (outcome) |

**Divestitures**: None identified.
**M&A Pattern**: TableFever is a **sell-side target**, not a buyer. It has received at least two acquisition approaches (2022 from Zenchef; 2025 from undisclosed party). No acquisitions have been made by TableFever. Commercial partnerships (DPD Fresh) serve as a product-extension substitute for M&A.

**Zenchef displacement opportunity (market-level M&A event)**: The Sep 2023 acquisition of Resengo and Feb 2024 acquisition of Tablebooker by Zenchef/PSG Equity is the single most important M&A event for TableFever's growth trajectory. These two acquisitions placed approximately 6,000 Belgian restaurants involuntarily into a PE-backed, internationally integrated platform. The timing of TableFever's customer growth from ~1,000 (2023) to ~2,000 (May 2025) — a 100% increase in approximately 18–24 months — directly coincides with this consolidation. TableFever is the primary beneficiary of Zenchef's Belgian consolidation.

---

### SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | **Cloud-native SaaS** | tablefever.com; product description; no on-premise offering found | Confirmed |
| Cloud Revenue % | ~100% — no on-premise product identified | tablefever.com product suite | Confirmed |
| Recurring Revenue % | ~100% — subscription model, no per-booking commission | T&C: €99/month module; no commission clause | Confirmed |
| Contract Term | **48 months fixed** with automatic renewal (3-month notice) | tablefever.com/en/algemene-voorwaarden | Confirmed |
| Payment Integrations | **Bancontact**: likely (Belgian market standard; gift voucher/ticket payments online) — not explicitly confirmed | Product logic; Belgian market norm | Estimated |
| iDEAL | Not applicable (NL payment method; TableFever is BE-only) | Market scope | Confirmed |
| Stripe | Not confirmed; platform accepts online payments for vouchers/tickets | tablefever.com | Unknown |
| Platform Stack | Web-based SaaS (back-end not disclosed publicly); iOS + Android management apps confirmed; historic mobile apps (2016) built in Objective-C/Java by MLSDev Ukraine | Zenchef comparison table; aciety.com | Confirmed (web+mobile); Unknown (back-end) |
| API / Integration Model | **No public API** — explicitly absent from feature list; Zenchef comparison confirms "POS & Custom APIs integrations: –" | Zenchef comparison; tablefever.com | Confirmed |
| Integrations (confirmed) | Google Reserve, Gault&Millau, Teamleader, DPD Fresh, Bluebarn | tablefever.com; vierbordjes.be | Confirmed |
| Migration Status | N/A — cloud-native from founding (2014); no on-premise legacy to migrate | Product history | Confirmed |
| Free Trial | 30-day no-commitment trial | tablefever.com/en | Confirmed |
| Billing Method | Direct debit domiciliation (Belgisch bankdomiciliëring) | T&C Art. 5 | Confirmed |

**SaaS maturity commentary**: TableFever is cloud-native and fully subscription-based with effectively 100% recurring revenue. The 48-month contract term is exceptional — most SaaS businesses operate on 12-month contracts at best. This structure means that at any given moment, the entire installed base is under multi-year contract, providing extraordinary revenue predictability. The absence of a public API is the primary SaaS maturity gap — it limits integration potential with third-party platforms (POS, PMS, review aggregators) and restricts the platform's eventual value in a broader SolStein software stack.

---

### Growth Scorecard

| Dimension | Score (1–10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | **7** | 27.9% CAGR (2022–2025) on gross margin basis; consistent growth across all three years (35%, 19%, 30%); qualifies for 7–8 band (20–30% CAGR) |
| Funding Momentum | **4** | Bootstrapped (€0 raised); score reflects rubric's "bootstrap with evident profitability" criterion — 41% net margin in 2025 is exceptional for a micro-cap SaaS |
| Employee Growth | **7** | 27.9% FTE CAGR (2022–2025, KBO basis); technically meets 9–10 criterion (>25% CAGR) but single-geography hiring (all Sint-Denijs-Westrem) and tiny absolute base cap the score |
| Geographic Expansion | **2** | Belgium-only confirmed market; possible minor cross-border presence per Nieuwsblad headline "buitenland" — unverified; no expansion office, partner, or market entry announced |
| M&A Activity | **1** | No acquisitions made; purely organic growth; commercial partnerships (DPD Fresh) serve as product extension substitute; TableFever is a sell-side target, not a buyer |
| SaaS Maturity | **8** | Cloud-native from founding (2014); ~100% recurring revenue; 48-month contracts (exceptional stickiness); Google Reserve live; no public API (one deduction from 9–10 band) |
| **COMPOSITE SCORE** | **4.83** | **Steady** (threshold: 3.0–4.9) — profitable, growing, defensively positioned; just below Riser threshold |

**Classification Thresholds**:

- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

> **Classification note**: TableFever's composite score of 4.83 places it firmly in "Steady" — but only 0.17 points below the Riser threshold. The two dimensions dragging the score down are Geographic Expansion (structural, Belgium-only strategy) and M&A Activity (buyer-side score only; as a sell-side target, TableFever scores very high). If SolStein acquires TableFever and injects geographic expansion (NL market, where Resengo had presence) and product investment (API layer), the underlying growth profile (28% CAGR, 100% recurring, 48-month contracts) would quickly re-classify this as a Riser.

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "TableFever Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [7, 4, 7, 2, 1, 8]
```

---

### Key Financial Ratios Summary (2025)

| Metric | Value | Notes |
| --- | --- | --- |
| Gross Margin | €1,412,085 | Confirmed (KBO/NBB filing) |
| Estimated ARR | **€1.4M–€1.8M** | Gross margin proxy + customer count triangulation |
| Net Profit | €731,240 | Confirmed |
| Net Margin | ~41% | Estimated (based on 2022 confirmed ratio + growth) |
| Book Equity | €1,010,158 | Confirmed |
| Employees | 4.6 FTE (KBO); ~7 LinkedIn | Confirmed / Estimated |
| Revenue per FTE | ~€387K gross margin/FTE | Estimated |
| Customer Count | ~2,000 restaurants | Confirmed (Nieuwsblad, May 2025) |
| Blended ARPU | ~€65–78/month | Estimated |
| Contract Duration | 48 months (4 years) | Confirmed |
| Revenue CAGR (3yr) | 27.9% | Confirmed |
| Indicative EV (ARR basis) | **€4.2M–€9.0M** | 3×–5× €1.4M–€1.8M ARR |
| Indicative EV (EBITDA basis) | **€4.6M–€7.6M** | 6×–10× ~€760K EBITDA |
| **Blended EV Estimate** | **€4M–€8M** | Consistent with deep-analysis valuation |

---

### Data Confidence Summary

| Confidence Level | Data Points in This Analysis |
| --- | --- |
| **Confirmed** | KBO/NBB filings (gross margin, net profit, equity, FTE: 2022–2025); published turnover (2022 only); pricing from T&C (€99/month, 48-month term, Google Module €120/year, Website Module €195/month); customer count ~2,000 (Nieuwsblad May 2025); Zenchef approach declined (2022); 2025 acquisition offer received; Google Reserve live; no public API; integrations list |
| **Estimated** | 2021 gross margin (~€528K); 2023–2025 turnover (derived from 2022 GM ratio); blended ARPU (€65–78/month); ARR (€1.4M–€1.8M); EBITDA (~€760K); net margin trajectory; 2026 projections; Bancontact support; minor "buitenland" presence |
| **Unknown** | Full cap table (exact % ownership); pre-2022 financial data; 2025 acquisition offer outcome; acquirer identity (2025); detailed tech stack (back-end language/framework); exact Bancontact/Stripe configuration; GDPR DPA status |

**Overall confidence**: **Medium-High**. Core financial data (2022–2025 KBO filings) is confirmed. ARR and profitability calculations are supported by multiple triangulation methods. The key unknowns (cap table, 2025 offer outcome) are deal-process items that would be resolved in a standard due diligence process.

---

### Sources Referenced

| Source | URL | Type | Used For |
| --- | --- | --- | --- |
| companyweb.be | companyweb.be/en/0559892314/table-fever | KBO/NBB filing aggregator | Gross margin, profit, equity, FTE (2022–2025) |
| KBO / NBB Balanscentrale | via companyweb.be | Official Belgian trade register | Turnover 2022; all financial filing data |
| tablefever.com/en/algemene-voorwaarden | tablefever.com/en/algemene-voorwaarden | Company T&C / B2B contract | Pricing: €99/month, 48-month term, module structure |
| Het Nieuwsblad | nieuwsblad.be (May 15, 2025) | Belgian press | 2,000 restaurant milestone; acquisition offer received; founder profile |
| vierbordjes.be (id=585) | vierbordjes.be/?p=foodnews_detail&id=585 | Belgian food industry press | Zenchef 2022 approach declined; market consolidation context |
| manda.be | manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker | M&A press | Tablebooker acquisition; TableFever last independent |
| LinkedIn | be.linkedin.com/company/tablefever | Professional network | Current headcount ~7; founder profile |
| DPD Belgium press | dpd.com/be/nl/news | Corporate press release | DPD Fresh partnership (March 2021) |
| Zenchef comparison | zenchef.com/comparison/zenchef-vs-tablefever | Competitor comparison page | Feature gaps; pricing model (no commission); API absence |
| Facebook / HORECA UNIE | facebook.com/groups/HORECAUNIE | Community discussion | Legacy pricing reference (~€30/month) |
