# TableFever — Deep M&A Analysis

**Research date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Coverage**: All 8 M&A dimensions per SolStein framework

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | TableFever BV (SRL) | KBO / companyweb.be | Confirmed |
| Enterprise number | BE 0559.892.314 | KBO | Confirmed |
| Founded | 19 August 2014 | KBO via companyweb.be | Confirmed |
| Founder & CEO | Stef van der Schueren | LinkedIn, F6S, vierbordjes.be interview | Confirmed |
| Founder age | ~43 (as of 2025) | Nieuwsblad article headline | Estimated |
| HQ (operational) | Kortrijksesteenweg 1033, 9051 Sint-Denijs-Westrem (Ghent area) | tablefever.com/en | Confirmed |
| HQ (registered) | Pauwelstraat(Moe) 106A, 9500 Geraardsbergen | companyweb.be (Jan 2025) | Confirmed |
| Ownership | Founder-owned; no external investors identified | companyweb.be, Crunchbase, news search | Estimated |
| Employees (FTE) | 4.6 FTE (2025 filing) | companyweb.be | Confirmed |
| LinkedIn headcount | ~7 employees | LinkedIn company page | Estimated |
| Second business | Stef van der Schueren also owns PITTIG.be | LinkedIn, Facebook | Confirmed |
| Self-described positioning | "Full-service advertising and marketing agency for restaurants" | vierbordjes.be, direct founder quote | Confirmed |
| Website | tablefever.com / tablefever.be | tablefever.com | Confirmed |

TableFever is a micro-cap, founder-run SaaS company embedded in the Belgian restaurant market. The founder describes the business as having evolved beyond reservations into a full marketing and digital services platform for restaurants. The operational team is extremely lean (4–7 people), which creates both a scaling constraint and a clean deal structure for a potential acquirer.

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary market | Belgium (exclusive focus) | tablefever.com, all sources | Confirmed |
| Customer count | ~2,000 restaurants (2025) | Nieuwsblad article headline (May 2025) | Confirmed |
| Prior customer count | ~1,000 restaurants (~2023) | hln.be article reference | Estimated |
| Customer growth rate | ~100% in ~2 years (1,000 → 2,000) | Nieuwsblad vs HLN articles | Estimated |
| Independent competitors (Belgium) | Zero — TableFever is the last independent | manda.be M&A article; vierbordjes.be | Confirmed |
| Main competitor | Zenchef (PSG Equity, 25,000+ restaurants in 20 countries) | zenchef.com | Confirmed |
| International competitor | The Fork (TripAdvisor) | vierbordjes.be, industry article | Confirmed |
| Gault&Millau integration | TableFever (and peers) integrated with gaultmillau.be | vierbordjes.be | Confirmed |
| Belgian market size (est.) | €10M total addressable, ~€20M potential | Resengo CEO Dirk Gypen, vierbordjes.be | Estimated |
| Untapped restaurant market | ~40% of Belgian restaurants still have no online reservation system | Resengo CEO Gypen, vierbordjes.be | Estimated |

### Market structure post-consolidation

The Belgian restaurant reservation SaaS segment underwent complete consolidation in 18 months (Sep 2023–Feb 2024). Zenchef acquired both Resengo (the pioneer, founded 2003) and Tablebooker (the second-mover, founded 2012). TableFever, founded in 2014 as the third entrant, is the sole surviving independent.

This creates a structurally advantaged position: Belgian restaurateurs who wish to avoid the Zenchef/PSG Equity platform have exactly one alternative. If SolStein acquires TableFever and invests in its growth (sales, product, integrations), it inherits the only PE-free Belgian competitor to a well-funded European giant.

The ~40% of Belgian restaurants that still lack online reservation tools represents the most significant growth runway.

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | Cloud-based restaurant reservation SaaS | tablefever.com/en | Confirmed |
| Reservation widget | Embeddable booking widget for restaurant websites | tablefever.com/en/reservations | Confirmed |
| Floor plan management | Visual seating plan tool, real-time updates | tablefever.com/en/solutions; Zenchef comparison | Confirmed |
| Room bookings | Multi-room/space booking | tablefever.com/en/solutions | Confirmed |
| Gift voucher system | Online sale, custom design, redeemable for reservations | tablefever.com/en/solutions | Confirmed |
| CRM / Contact management | Guest preferences, no-show reduction, segmentation | tablefever.com/en/solutions | Confirmed |
| Waitlist management | Last-minute availability capture | tablefever.com/en/solutions | Confirmed |
| Deposits / credit card guarantee | Credit card guarantee only (no full prepayment) | Zenchef comparison table | Confirmed |
| Reservation reminder | Yes | Zenchef comparison table | Confirmed |
| Marketing: email templates | Yes — send campaigns in brand style | tablefever.com/en/solutions | Confirmed |
| Social media management | Yes — content creation and scheduling | tablefever.com/en/solutions | Confirmed |
| Website development | Full website design, CMS, seasonal personalisation | tablefever.com/en/solutions | Confirmed |
| Reserve with Google | Yes — bookings via Google Search and Maps | tablefever.com/en/reservations; Zenchef comparison | Confirmed |
| Reserve via Instagram/Facebook | No | Zenchef comparison table | Confirmed |
| Call assist (phone logging) | No | Zenchef comparison table | Confirmed |
| Reservation analytics | No (Zenchef has; TableFever does not) | Zenchef comparison table | Confirmed |
| Multi-venue operations | No | Zenchef comparison table | Confirmed |
| Pay-at-table (QR) | No | Zenchef comparison table | Confirmed |
| POS integration / custom APIs | No public API; not listed in integrations | Zenchef comparison table | Confirmed |
| Mobile app (management) | iOS and Android app confirmed (centralised reservation management) | Zenchef comparison table | Confirmed |
| Mobile app (consumer-side) | Historic Android APK (2016, MLSDev) — current consumer app status unknown | APKPure, aciety.com/portfolio/tablefever | Estimated |
| Integrations listed | Google Reserve, Teamleader, DPD Fresh, Gault&Millau, Bluebarn | tablefever.com; vierbordjes.be | Confirmed |
| Tech stack (historic mobile) | Objective-C (iOS), Java (Android) — early apps by MLSDev Ukraine | aciety.com/portfolio/tablefever | Confirmed |
| Tech stack (current) | Web-based SaaS; back-end stack not publicly disclosed | tablefever.com | Unknown |
| Pricing model | Monthly or annual subscription; no commission per booking | Zenchef comparison; tablefever.com | Confirmed |
| Free trial | 30 days, no commitment | tablefever.com/en | Confirmed |
| Pricing published | No — custom quote required | tablefever.com | Confirmed |

### Product gap assessment vs Zenchef

TableFever lacks several features Zenchef offers: reservation analytics, multi-venue, Facebook/Instagram booking, call assist, QR pay-at-table, post-visit review automation, and a formal POS API. These gaps are consistent with a 4–7 person team. They are bridgeable with investment post-acquisition and represent a defined product roadmap, not a structural limitation.

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership | 100% founder-owned (estimated) | companyweb.be; no co-founder or shareholder filings identified | Estimated |
| External capital | None identified — bootstrapped since 2014 | All public sources | Unknown |
| PE/VC investors | None | Crunchbase, Belgian M&A press | Confirmed |
| 2022 Zenchef approach | Confirmed — founder DECLINED | vierbordjes.be direct quote from Stef Van der Schueren | Confirmed |
| Reason for 2022 decline | Not stated publicly — independence motive inferred | vierbordjes.be (context of interview) | Estimated |
| 2025 acquisition offer | Reported — "al een mooi overnamebod naast me neergelegd" | Nieuwsblad article headline (2025) | Confirmed |
| 2025 offer outcome | Not disclosed | Article body not accessible; no press announcement | Unknown |
| Founder succession signals | Lean team; second business (PITTIG.be); age ~43; publicly discussing offers | Multiple sources | Estimated |
| Formal succession plan | Not identified | No public disclosure | Unknown |
| Deal motivation for founder | Financial reward, independence, legacy, team continuity — all unknown | No disclosed statements | Unknown |

### Succession analysis

Stef van der Schueren is the sole publicly identified owner and operator. The company's 4–7 FTE team means he is operationally central. At ~43 (2025), he is not at typical retirement age, but is evidently receiving and discussing acquisition offers in the press. The shift from the 2022 explicit rejection of Zenchef to the 2025 public acknowledgment of "a nice acquisition offer" suggests increasing openness.

A non-PE acquirer with a founder-friendly pitch (operational continuity, Belgium-first, no aggressive integration) is well-positioned relative to financial buyers. Zenchef (PE-backed, integration-heavy) is the least attractive acquirer archetype from TableFever's documented posture.

---

## 5. Financial Growth & Trajectory

All financial data from National Bank of Belgium / companyweb.be (Belgian annual accounts).

| Metric | 2022 | 2023 | 2024 | 2025 | YoY Growth (2024→2025) |
|---|---|---|---|---|---|
| Gross margin | €675,820 | €915,253 | €1,086,937 | €1,412,085 | +30% |
| Profit / Loss | €298,039 | €388,699 | €545,759 | €731,240 | +34% |
| Equity | €624,460 | €613,159 | €778,917 | €1,010,158 | +30% |
| Turnover | €851,454 | not published | not published | not published | — |
| Employees (FTE) | 2.2 | 3.2 | 3.3 | 4.6 | +39% |

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Published turnover | Only 2022: €851,454 | companyweb.be | Confirmed |
| Gross margin (2025) | €1,412,085 — used as ARR proxy | companyweb.be | Confirmed |
| Profit margin (2025) | €731,240 / ~€1.4M ≈ 52% net profit margin | companyweb.be calculation | Estimated |
| ARR estimate | €1.2M–€1.5M (2025) — based on gross margin proxy and 2,000 restaurants × ~€60–70/month avg | companyweb.be + customer count | Estimated |
| Revenue CAGR (2022–2025) | ~28% CAGR (gross margin basis) | companyweb.be calculation | Estimated |
| Post-consolidation tailwind | Resengo and Tablebooker customer migrations to TableFever likely contributed to the 1,000→2,000 customer jump | Inferred from market timing | Estimated |
| Profitability | Strongly profitable — equity growing via retained earnings | companyweb.be | Confirmed |
| Leverage / debt | Not disclosed | companyweb.be (no balance sheet detail) | Unknown |

### ARR estimation logic

Belgian restaurant reservation SaaS pricing is typically in the range of €49–€149/month per restaurant (Zenchef no-commission subscription; Resengo historic pricing). TableFever promotes value pricing and service-led positioning. Assuming a blended average of ~€60–70/month per restaurant:

- 2,000 restaurants × €65/month × 12 = **~€1.56M ARR**

This is directionally consistent with the 2025 gross margin of €1.41M. The slight gap likely reflects some restaurants on lower tiers, trial accounts, or the website/marketing services revenue portion being recognized differently.

**ARR estimate: €1.3M–€1.6M (2025)**

This puts TableFever at the low end of the SolStein €1M–€15M ARR target range — but growing at 28–30% per year with strong profitability and meaningful market expansion potential in the still-40%-untapped Belgian restaurant market.

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Vertical focus | Pure-play restaurant reservation and digital marketing — Belgium | tablefever.com | Confirmed |
| Geographic scope | Belgium only — no expansion to NL, FR, or other markets identified | tablefever.com; all sources | Confirmed |
| Language | Dutch (Flemish) primary; French-language capability unconfirmed | tablefever.com/en (English also available) | Estimated |
| Payment methods | Online payments via platform (gift vouchers, deposits); Bancontact integration not explicitly confirmed | tablefever.com/en/solutions | Unknown |
| GDPR compliance | Belgian-registered entity — subject to GDPR; no explicit certification or DPA mentioned | companyweb.be; legal entity | Confirmed |
| Gault&Millau integration | Integrated (listed in site integrations) | tablefever.com | Confirmed |
| Reserve with Google | Live | tablefever.com/en/reservations | Confirmed |
| Restaurant verticals served | Fine dining, bistro, brasserie, hotel restaurants — general catering | tablefever.com/en/restaurants | Confirmed |
| No-show protection | Credit card guarantee only (no full pre-payment) | Zenchef comparison | Confirmed |
| Belgian market penetration | ~2,000 of ~17,000+ Belgian restaurants with table service | Nieuwsblad; IBISWorld Belgium est. | Estimated |
| Switching costs | Embedded widget on restaurant website, reservation history in system, review pipeline, marketing templates — meaningful | Analysis of product suite | Estimated |

### Vertical defensibility

TableFever's product suite extends well beyond the reservation widget. A restaurant using TableFever for reservations, gift vouchers, CRM, email campaigns, social media, and website hosting faces significant migration cost and disruption risk. This multi-product entanglement creates real switching costs and above-average retention, even without long-term contractual lock-in.

The Belgian-only focus is both a vertical depth strength (deep local knowledge, Flemish-language service, Belgian payment context) and a scale ceiling. A SolStein acquisition could unlock expansion to the Netherlands, where Resengo had substantial presence before its Zenchef acquisition — a natural adjacency.

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Business model | Monthly / annual subscription SaaS, no per-booking commission | tablefever.com; Zenchef comparison | Confirmed |
| Revenue streams | Software subscription, website development services, social media management | tablefever.com/en/solutions | Confirmed |
| ARR estimate (2025) | €1.3M–€1.6M | Gross margin proxy + customer count | Estimated |
| Net profit (2025) | €731,240 | companyweb.be | Confirmed |
| EBITDA estimate | ~€750K–€900K (approximated; small team, low capex) | companyweb.be (profit + est. depreciation) | Estimated |
| Revenue multiple (SaaS, small BE) | 3×–5× ARR for bootstrapped, founder-owned, niche SaaS at this scale | Market comparables (Resengo, Tablebooker deal context) | Estimated |
| EBITDA multiple | 6×–10× EBITDA for profitable niche software, non-PE vendor | Market comparable | Estimated |
| Indicative EV range (ARR basis) | €3.9M–€8.0M | 3×–5× €1.3M–€1.6M ARR | Estimated |
| Indicative EV range (EBITDA basis) | €4.5M–€9.0M | 6×–10× ~€750K EBITDA | Estimated |
| Blended EV estimate | **€4M–€8M** | Combined ARR and EBITDA approach | Estimated |
| Equity (book) | €1,010,158 (2025) | companyweb.be | Confirmed |
| Pricing published | No — custom demo required | tablefever.com | Confirmed |

### Valuation commentary

At €4M–€8M enterprise value, TableFever is well within SolStein's acquisition range for a primary target. The company's profitability (52%+ net margin), growth rate (~30% YoY), and unique market position (last Belgian independent) justify the upper end of the range. The founder's demonstrated willingness to discuss acquisition offers (2022 declined; 2025 status unclear) is a meaningful pricing signal — a deal is possible without a premium-on-premium bidding war, absent competing offers.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | **5** | 100% founder-owned; no PE; no debt overhang; founder openly receiving acquisition offers; 2022 offer declined (independence-minded) but 2025 offer publicly acknowledged; clean deal structure | companyweb.be; vierbordjes.be; Nieuwsblad |
| Revenue scale fit | High | **3** | ARR ~€1.3M–€1.6M — at low end of €1M–€15M thesis range but growing at ~30% CAGR; profitable (€731K net income); very strong margin for size | companyweb.be |
| Geographic fit | High | **5** | 100% Belgium; Flemish market; operational in Sint-Denijs-Westrem (Ghent); natural adjacency to NL (former Resengo territory) | tablefever.com; all sources |
| Tech stack modernity | Medium | **3** | Web-based SaaS (modern delivery); Reserve with Google live; no POS API; no custom API publicly available; mobile early apps (2016) on Obj-C/Java — current state unknown; website builder in-house | tablefever.com; Zenchef comparison; aciety.com |
| Customer lock-in | Medium | **4** | Multi-product entanglement: reservation widget embedded on restaurant website + CRM + voucher system + social media + website hosting; migration friction is substantial; no commission model reduces churn incentive for restaurants; 30-day trial shows confidence | tablefever.com/en/solutions; product analysis |
| Vertical depth | Medium | **4** | Only independent Belgian restaurant reservation SaaS; pure-play focus; Flemish-language service; Gault&Millau integration; deep HORECA positioning consistent with SolStein thesis | manda.be; vierbordjes.be; tablefever.com |
| Integration potential | Low | **2** | No public API documented; not listed as feature; Zenchef comparison explicitly shows "POS & Custom APIs integrations: –"; integration into a broader SolStein stack would require API build-out | Zenchef comparison table |
| Growth trajectory | Low | **4** | Gross margin: €675K (2022) → €1.41M (2025) = +109% in 3 years; customer count ~1K (2023) → 2K (2025); 40% of Belgian restaurants still untapped; Zenchef consolidation created migration demand | companyweb.be; Nieuwsblad; HLN |

### Composite Score Calculation

| Weight class | Dimensions | Scores | Weight | Weighted contribution |
|---|---|---|---|---|
| High (×3) | Ownership, Revenue, Geographic | 5, 3, 5 | 3 each | 45 |
| Medium (×2) | Tech stack, Lock-in, Vertical | 3, 4, 4 | 2 each | 22 |
| Low (×1) | Integration, Growth | 2, 4 | 1 each | 6 |
| **Total** | | | **17** | **73** |

**Composite Score: 73 / 17 = 4.3 / 5.0**

### Confidence Band

| Confidence level | Data points in this analysis |
|---|---|
| Confirmed | ~55% — KBO filing, financials, founder name, addresses, Zenchef approach/decline, customer count, product features, market structure |
| Estimated | ~30% — ownership %, ARR, EBITDA, valuation, 2025 offer outcome, founder age, Belgian market size |
| Unknown | ~15% — full cap table, exact pricing, tech stack internals, Bancontact support, 2025 offer terms |

**Confidence band: Medium-High.** Core deal-relevant facts (ownership, independence, financials, acquisition history) are Confirmed or Estimated with strong source support. Valuation and ARR involve standard estimation from public filings.

---

## Overall M&A Assessment

**TableFever is SolStein's highest-priority Belgian acquisition target.**

The combination of three factors is rare and time-sensitive:

1. **Monopoly position**: Last independent Belgian restaurant reservation SaaS after Zenchef absorbed Resengo and Tablebooker. No comparable asset exists in this sub-vertical.
2. **Confirmed acquisition openness**: Founder has declined one offer (Zenchef, 2022) and received at least one more (2025). The progression from outright rejection to public acknowledgment is a meaningful signal. The 2022 decline was from Zenchef — a PE-backed integrator. SolStein's founder-friendly, niche-HORECA thesis is structurally differentiated.
3. **Clean deal structure**: No PE, no co-founders, no complex cap table. Small team. Profitable. Book equity of €1M. A deal at €4M–€8M EV is straightforward to structure.

**Risks:**
- Founder may still decline; independence has been his revealed preference
- Company scale is small — SolStein would need to invest in sales and product post-acquisition
- No public API limits immediate integration into a broader platform
- Revenue is Belgium-only; geographic expansion is untested

---

## Recommended Next Step

**Initiate a direct, confidential outreach to Stef van der Schueren.**

The approach should:
- Be founder-to-founder (or senior non-PE principal) — not a banker or intermediary
- Emphasize the SolStein HORECA niche thesis: operator, not financial acquirer
- Acknowledge TableFever's independence and Stef's 2022 decision to decline Zenchef
- Frame acquisition as a growth partnership, not an exit
- Propose a casual conversation (no NDA at first contact)

LinkedIn profile: [linkedin.com/in/stef-van-der-schueren-51322063](https://be.linkedin.com/in/stef-van-der-schueren-51322063)
Company contact: tablefever.com/en/contact
