# TableFever — Corporate History & M&A Feasibility

**Research date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Status**: Active independent — priority acquisition candidate

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | TableFever BV (formerly TableFever BVBA) | companyweb.be / KBO | Confirmed |
| Enterprise number | BE 0559.892.314 | KBO / companyweb.be | Confirmed |
| VAT number | BE 0559.892.314 | tablefever.com/en/algemene-voorwaarden | Confirmed |
| Legal form | SRL/BV (Société à Responsabilité Limitée) | companyweb.be 2021 filing | Confirmed |
| Founded | 19 August 2014 | KBO via companyweb.be, sentometrics.com | Confirmed |
| Status | Active | companyweb.be (last balance sheet: 2025) | Confirmed |
| Registered office | Pauwelstraat(Moe) 106A, 9500 Geraardsbergen | companyweb.be (Jan 2025 filing) | Confirmed |
| Operational office | Kortrijksesteenweg 1033, 9051 Sint-Denijs-Westrem | tablefever.com/en | Confirmed |
| Principal activity | Activities of advertising agencies (NACE) | companyweb.be | Confirmed |
| Founder & General Manager | Stef van der Schueren | LinkedIn (be.linkedin.com/in/stef-van-der-schueren-51322063), F6S profile | Confirmed |
| Founder age | ~43 (as of 2025) | Nieuwsblad article headline (2025) | Estimated |
| Side venture | PITTIG.be (owner) | LinkedIn, Facebook profile Stef VdS | Confirmed |
| Employees (FTE) | 4.6 FTE (2025), 3.3 (2024), 3.2 (2023), 2.2 (2022) | companyweb.be annual filings | Confirmed |
| LinkedIn headcount | ~7 employees | LinkedIn company page (tablefever) | Estimated |
| Funding rounds | None identified | Crunchbase, public records search | Unknown |
| PE/VC investors | None identified | All public sources searched | Unknown |
| Still independent | Yes — fully founder-owned as of 2026-04-30 | Multiple sources; no acquisition announcement found | Confirmed |

---

## Registered Office History

All address changes are drawn from Belgian State Gazette (ejustice.just.fgov.be) filings as listed in companyweb.be.

| Date | Publication Type | Detail |
|---|---|---|
| 19 Aug 2014 | Founding | Incorporated as TableFever BVBA |
| 11 Feb 2021 | Registered Office — Modification Legal Form | Converted from BVBA → SRL under new Belgian Companies Code (WVV/CSA) |
| 6 Sep 2021 | Registered Office | Address change |
| 5 Jul 2022 | Modification Legal Form — Resignations/Appointments | Board/officer change; details not publicly available without subscription |
| 22 Mar 2024 | Registered Office | Address change |
| 7 Jan 2025 | Registered Office | Move to Geraardsbergen (current registered office) |

---

## Ownership & M&A History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership structure | Single founder-owned; no shareholders identified beyond Stef van der Schueren | companyweb.be, public filings | Estimated |
| External investment | None found | No Crunchbase entry, no press releases | Unknown |
| 2022 acquisition approach | Zenchef approached TableFever in 2022 — offer **declined** by founder | vierbordjes.be interview with Stef Van der Schueren | Confirmed |
| Quote (founder, 2022 offer) | *"Wij werden in 2022 door hen benaderd. Ze wilden ons overnemen, maar ik heb het aanbod afgeslagen."* ("We were approached by them in 2022. They wanted to take us over, but I declined the offer.") | vierbordjes.be, direct founder quote | Confirmed |
| 2025 acquisition offer | Nieuwsblad article headline states founder has received "een mooi overnamebod" (a nice acquisition offer); outcome not disclosed | Nieuwsblad (2025), article not fully accessible | Estimated |
| Current acquisition status | Independent — no deal announced | All public sources as of 2026-04-30 | Confirmed |
| Prior name changes | None identified | KBO, companyweb.be | Confirmed |

---

## M&A Timeline

```mermaid
timeline
    title TableFever Corporate & Market Timeline
    2012 : Tablebooker launched (Steven Schutter & Johannes De Ridder)
    2014 : TableFever founded (Aug 19) by Stef van der Schueren
    2015 : Resto Group acquires Tablebooker
         : Belgian market: 3 dominant players — Resengo, Tablebooker, TableFever
    2021 : TableFever converts BVBA → SRL under new Belgian Companies Code
    2022 : Zenchef + Formitable merge (PSG Equity backing)
         : Zenchef approaches TableFever — offer DECLINED by founder
    2023 : Zenchef acquires Resengo (Sep 2023)
    2024 : Zenchef acquires Tablebooker (Feb 2024)
         : TableFever becomes LAST INDEPENDENT Belgian restaurant reservation SaaS
    2025 : TableFever reaches 2,000 restaurant customers
         : New acquisition offer received by founder (Nieuwsblad 2025) — outcome undisclosed
    2026 : TableFever still fully independent (as of Apr 2026)
```

---

## Corporate Structure

```mermaid
graph TD
    SVS["Stef van der Schueren\n(Founder & General Manager, ~43)"]
    TF["TableFever BV\nBE 0559.892.314\nFounded: 19 Aug 2014\nGeraardsbergen / Sint-Denijs-Westrem"]
    PITTIG["PITTIG.be\n(Separate venture, same owner)"]

    SVS -->|"100% owner (estimated)"| TF
    SVS -->|"Owner"| PITTIG
    TF -->|"Serves"| REST["~2,000 Belgian\nrestaurant clients"]
```

---

## Competitive Landscape: Belgian Restaurant Reservation SaaS

| Company | Founded | Status | Acquirer | Year |
|---|---|---|---|---|
| Resengo | 2003 | **Acquired** | Zenchef / Formitable (PSG Equity) | Sep 2023 |
| Tablebooker | 2012 | **Acquired** | Zenchef (via Resto Group from 2015) | Feb 2024 |
| **TableFever** | **2014** | **Independent** | — (offer declined 2022; new offer 2025) | — |
| Zenchef | 2010 (FR) | Active — PE-backed | PSG Equity | Ongoing |
| The Fork (TripAdvisor) | 2007 (FR) | Active — corporate-backed | TripAdvisor | 2014 |

> **Key finding**: TableFever is confirmed by manda.be (M&A news source) as "the only remaining competitor" in the Belgian restaurant reservation SaaS segment following Zenchef's absorption of Resengo and Tablebooker.

---

## M&A Feasibility Assessment

### Is TableFever the last independent Belgian restaurant reservation platform?

**Yes — confirmed.** The manda.be article on the Tablebooker acquisition explicitly states: *"After two takeovers in Belgium, there is only one competitor left: TableFever, founded in 2014."* This was corroborated by the vierbordjes.be industry analysis article.

### Has Zenchef or any other acquirer approached them?

**Yes — confirmed.** Zenchef approached TableFever in 2022. The founder explicitly declined. A subsequent, unidentified acquirer made an offer circa 2025 (per Nieuwsblad headline); the outcome is not publicly disclosed. The founder's use of the phrase *"al een mooi overnamebod naast me neergelegd"* (already a nice acquisition offer placed beside me) in a May 2025 Nieuwsblad profile is significant — it is neither a clear acceptance nor a refusal, unlike the explicit 2022 rejection.

### Funding and PE overhang?

**None identified.** No funding rounds, no PE/VC investors, no Crunchbase profile. The company has been entirely bootstrapped since 2014. Equity has grown entirely from retained earnings: from €624K (2022) to €1.0M (2025).

### Succession signals?

**Emerging.** Founder is ~43 years old — not at retirement age, but the fact that he has now received at least two acquisition approaches and is publicly discussing them in press suggests growing openness. He also runs a second business (PITTIG.be) with a team of 4–5 FTE at TableFever, which creates scaling constraints. No formal succession plan identified.

### Overall M&A feasibility

| Factor | Assessment |
|---|---|
| Ownership structure | Founder-owned, no blockers |
| PE overhang | None |
| Founder openness | Demonstrated — received and publicly acknowledged two acquisition approaches |
| Precedent | 2022 offer declined (Zenchef); 2025 offer status unclear |
| Market position | Only independent Belgian restaurant reservation SaaS |
| Deal blockers | Founder may place non-financial conditions; small team limits due diligence complexity; no disclosed financials beyond gross margin |

**Verdict: High M&A feasibility.** No structural blockers. Founder is independent-minded (declined 2022 offer) but publicly discussing acquisition interest, which is a meaningful signal of openness. The market window is now — Zenchef has consolidated the segment, leaving SolStein as a potential friendly acquirer with a differentiated, non-PE pitch.
