# Tablebooker — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Status**: ACQUIRED — Not available for SolStein (see M&A Feasibility below)

---

## KBO Registration Data

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| KBO Number | 0849.393.861 | [North Data / KBO](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| EUID | BEKBOBCE.0849.393.861 | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Legal Form | BV (Besloten Vennootschap) | [en.tablebooker.com/contact](https://en.tablebooker.com/contact) | Confirmed |
| Registration Date | 08 October 2012 | [North Data publications](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Registered Address | Lozenberg 11, 1932 Zaventem, Belgium | [North Data / PitchBook](https://pitchbook.com/profiles/company/466910-20) | Confirmed |
| NACE 62.01 | Computer programming activities | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| NACE 82.99 | Other business support service activities n.e.c. | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| NACE 73.12 | Media representation | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Original Registered City | Ghent area → Zaventem | Various | Estimated |
| Current Status | Active (as Zenchef subsidiary) | [PitchBook](https://pitchbook.com/profiles/company/466910-20) | Confirmed |
| Current Parent | Zenchef (PSG Equity-backed) | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding Year | 2012 | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Co-Founder 1 | Nicolas de Borrekens | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Co-Founder 2 | Paul Slootmans (also CEO through 2024) | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Early Incubator / Additional Founder | Tom Vroemans (November Five, Antwerp digital agency) — incubator 2013–2015 | [The Org / Tom Vroemans LinkedIn](https://theorg.com/org/november-five/org-chart/tom-vroemans) | Estimated |
| Additional Early Team (Crunchbase) | Gerrit Michiels, Johannes De Ridder, Kristof Bossuyt, Ruben Van den Bossche, Steven Schutter | [Crunchbase](https://www.crunchbase.com/organization/tablebooker) | Estimated |
| Founding Capital | €20,000 | [North Data KBO publications](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Innovation Award | Received shortly after founding (year unknown) | [Lightspeed integration page](https://www.lightspeedhq.com/integrations/tablebooke/) | Estimated |

---

## Capital History

| Period | Share Capital | Source | Confidence |
|---|---|---|---|
| Oct 2012 (founding) | €20,000 | [North Data KBO](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Intermediate increase | €68,750 | [North Data KBO](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Later increase | €100,150 | [North Data KBO](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Post-2024 (Zenchef era) | €12,394.66 | [North Data KBO annual report 2024](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |

> Capital reduction to €12,394.66 post-acquisition likely reflects internal restructuring as Zenchef subsidiary.

---

## M&A History

### Event 1: Acquisition by RestoGroup (2015)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Acquirer | RestoGroup BVBA (Belgium) | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Year | 2015 | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Deal Terms | Undisclosed | Multiple sources | Confirmed (not disclosed) |
| Tom Vroemans exit | November Five incubation ended (~2015) | [Tom Vroemans LinkedIn](https://be.linkedin.com/in/tomvroemans) | Estimated |
| Post-acquisition structure | Tablebooker B.V. becomes subsidiary of RestoGroup/Restobookings Group Sàrl | [North Data KBO filings](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Restobookings Group entity | Luxembourg-registered holding (Sàrl) | [North Data KBO filings](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |

### Event 2: Acquisition by Zenchef (February 2024)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Acquirer | Zenchef (French-Dutch, PSG Equity majority shareholder) | [MandA.be](https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/) | Confirmed |
| Announcement Date | 20 February 2024 | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Completion Date | 1 March 2024 | [Tracxn](https://tracxn.com/d/companies/tablebooker/__I5MHBwMZ5wfykhIGZ9DJsFnLqpWvqz0VjHVfwP08LBE) | Confirmed |
| Deal Terms | Undisclosed | [Tracxn](https://tracxn.com/d/acquisitions/acquisitions-by-zenchef/__4rDJ9iBBN8TjD5H8MWIB7YPh-tEeEWjxdLjM1M3TRCI) | Confirmed (not disclosed) |
| Sold from | RestoGroup / Restobookings Group Sàrl | [MandA.be](https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/) | Confirmed |
| PSG Equity role | Majority shareholder of Zenchef since Sep 2022 (€50M+ investment) | [PSG Equity portfolio](https://psgequity.com/portfolio/zenchef) / [PrivSource](https://www.privsource.com/acquisitions/deal/psg-equity-invests-over-50-million-in-zenchef-krSgp9) | Confirmed |
| Paul Slootmans exit role | VP Revenue Belgium & Luxembourg at Zenchef | [Zenchef announcement](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Nicolas de Borrekens | No longer director (per KBO filings post-2024) | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Current director | Validor Management BV | [North Data KBO 2024 publication](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Post-acquisition API status | Deprecated — migrating to ZenchefOS | [api.tablebooker.be](https://api.tablebooker.be/) | Confirmed |

---

## Name & Brand Changes

| Period | Legal / Brand Name | Notes | Confidence |
|---|---|---|---|
| 2012–present | Tablebooker B.V. | No legal name change found | Confirmed |
| 2024+ | Branded "Tablebooker by Zenchef" | Consumer platform retains Tablebooker brand; Tablemanager migrates to ZenchefOS | Confirmed |
| Luxembourg | Tablemanager.lu rebranded to Tablemanager by Zenchef | [tablemanager.lu](https://www.tablemanager.lu/en/) | Confirmed |

---

## Directors History (from KBO / North Data)

| Period | Directors / Board | Source | Confidence |
|---|---|---|---|
| 2012 (founding) | 6 directors (including de Borrekens, Slootmans and others) | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| 2015–2022 | Nicolas De Borrekens + Paul Slootmans | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| 2021–2023 | Nicolas de Borrekens + Paul Slootmans + Restobookings Group Sàrl (as entity board member) | [North Data annual reports 2021–2022](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| 2024 transition | Paul Slootmans as manager; Nicolas de Borrekens no longer director | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| 2024+ | Validor Management BV as director | [North Data 2024 annual report](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |

---

## Tablebooker Group Entities (pre-Zenchef)

| Entity | Type | Notes | Confidence |
|---|---|---|---|
| Tablebooker B.V. | Core tech / B2B platform | Belgian BV, main KBO entity | Confirmed |
| Resto.be | B2C restaurant discovery website | Belgium's largest restaurant booking portal | Confirmed |
| RestoDays | Gastronomy events / promotional days | Annual Belgian dining events campaign | Confirmed |
| Restofactory | Restaurant website building service | Specialized restaurant web design | Confirmed |
| Restobookings Group Sàrl | Luxembourg holding entity | Parent/board entity 2021–2024 | Confirmed |

---

## Investment Rounds

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Disclosed funding rounds | None publicly disclosed | Crunchbase, PitchBook | Confirmed (none found) |
| November Five incubation | Early-stage venture support 2013–2015 (non-disclosed amount) | [Tom Vroemans LinkedIn](https://be.linkedin.com/in/tomvroemans) | Estimated |
| RestoGroup acquisition 2015 | Undisclosed amount | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed (not disclosed) |
| Zenchef acquisition 2024 | Undisclosed amount | [Tracxn acquisitions](https://tracxn.com/d/acquisitions/acquisitions-by-zenchef/__4rDJ9iBBN8TjD5H8MWIB7YPh-tEeEWjxdLjM1M3TRCI) | Confirmed (not disclosed) |

---

## Corporate Structure Diagram

```mermaid
graph TD
    A["Nicolas de Borrekens + Paul Slootmans<br/>(Co-Founders, 2012)"]
    B["November Five / Tom Vroemans<br/>(Incubator, 2013–2015)"]
    C["Tablebooker B.V.<br/>KBO 0849.393.861<br/>Founded Oct 2012"]
    D["RestoGroup BVBA<br/>(Acquired Tablebooker, 2015)"]
    E["Restobookings Group Sàrl<br/>(Luxembourg Holding, ~2021–2024)"]
    F["Zenchef Group<br/>(Acquired Feb 2024)"]
    G["PSG Equity<br/>(Majority shareholder Zenchef, €50M+ Sep 2022)"]
    H["Formitable (NL)<br/>Merged 2023"]
    I["Resengo (NL/BE)<br/>Acquired 2023"]

    A -->|Founded| C
    B -->|Incubated| C
    D -->|Acquired 2015| C
    E -->|Holding 2021–2024| D
    G -->|€50M+ Sep 2022| F
    H -->|Merged early 2023| F
    I -->|Acquired late 2023| F
    F -->|Acquired Mar 2024| C
```

---

## Corporate Timeline

```mermaid
timeline
    title Tablebooker Corporate Timeline
    2012 : Founded by Nicolas de Borrekens & Paul Slootmans
         : KBO registration 08 Oct 2012
         : BV, €20,000 capital
    2013 : November Five (Tom Vroemans) becomes incubator
         : Early product development, Ghent / Antwerp
    2015 : Acquired by RestoGroup BVBA
         : Tom Vroemans exits
         : Tablebooker scales as Belgian market leader
    2017 : Belgian market leader status achieved
         : Active in Belgium, Luxembourg, France, Netherlands
         : Won innovation award
    2021 : Restobookings Group Sàrl appears as board entity
         : Capital at €100,150
    2022 : PSG Equity invests €50M+ in Zenchef (Sep 2022)
         : Zenchef begins European consolidation strategy
    2023 : Zenchef merges with Formitable (NL)
         : Zenchef acquires Resengo (NL/BE)
         : Tablebooker manages 25M seats annually
    2024 : Zenchef acquires Tablebooker (Feb 20, 2024)
         : Paul Slootmans → VP Revenue BE/LU at Zenchef
         : Nicolas de Borrekens exits director role
         : API deprecated, migrating to ZenchefOS
         : Capital reduced to €12,394.66
```

---

## M&A Feasibility Assessment

> **VERDICT: NOT AVAILABLE FOR SOLSTEIN ACQUISITION**

| Criterion | Assessment | Detail |
|---|---|---|
| **Availability** | ❌ Not available | Fully acquired by Zenchef, February/March 2024 |
| **Ownership type** | ❌ PE-backed subsidiary | PSG Equity is majority shareholder of Zenchef |
| **Founder-owned?** | ❌ No | Founders exited or absorbed into Zenchef; not founder-owned since 2015 |
| **PE overhang** | ❌ PE-controlled | PSG Equity (>€50M invested) drives Zenchef strategy |
| **Independently acquirable?** | ❌ No | Integrated into Zenchef group; API deprecated; brand being migrated |
| **Carve-out feasibility** | ❌ Very low | Deep integration with ZenchefOS, CoverManager combination announced 2025 |
| **SolStein thesis fit** | ❌ Does not fit | Violates "no PE overhang" and "founder-owned" criteria |

**Recommended action**: Remove from active target list. Monitor whether Zenchef divests Belgian operations, but probability is low given PSG Equity consolidation strategy.

---

## Sources

| # | Source | URL | Used For |
|---|---|---|---|
| 1 | Zenchef acquisition press release | https://www.zenchef.com/tablebooker-joins-zenchef | Founding, founders, acquisition, group structure |
| 2 | MandA.be acquisition article | https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/ | Acquisition details, PSG Equity |
| 3 | North Data / KBO | https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861 | KBO data, directors, capital history |
| 4 | PitchBook profile | https://pitchbook.com/profiles/company/466910-20 | Employees, address, acquisition status |
| 5 | Crunchbase | https://www.crunchbase.com/organization/tablebooker | Additional founders, operating status |
| 6 | Tracxn | https://tracxn.com/d/companies/tablebooker/__I5MHBwMZ5wfykhIGZ9DJsFnLqpWvqz0VjHVfwP08LBE | Employees 2021, acquisition date |
| 7 | Tracxn acquisitions by Zenchef | https://tracxn.com/d/acquisitions/acquisitions-by-zenchef/__4rDJ9iBBN8TjD5H8MWIB7YPh-tEeEWjxdLjM1M3TRCI | Deal terms undisclosed |
| 8 | PSG Equity portfolio | https://psgequity.com/portfolio/zenchef | PSG Equity investment |
| 9 | PrivSource | https://www.privsource.com/acquisitions/deal/psg-equity-invests-over-50-million-in-zenchef-krSgp9 | PSG Equity €50M+ investment |
| 10 | HorecaTrends.com | https://www.horecatrends.com/en/tablebooker-from-belgium-joins-zenchef/ | Independent acquisition confirmation |
| 11 | Tablebooker API docs | https://api.tablebooker.be/ | API deprecation, ZenchefOS migration |
| 12 | Tablemanager.lu | https://www.tablemanager.lu/en/ | Luxembourg rebranding to ZenchefOS |
| 13 | The Org — Tom Vroemans | https://theorg.com/org/november-five/org-chart/tom-vroemans | November Five incubation 2013–2015 |
| 14 | Lightspeed integration page | https://www.lightspeedhq.com/integrations/tablebooke/ | Product features, market leadership |
| 15 | en.tablebooker.com/contact | https://en.tablebooker.com/contact | KBO number, legal form, address |
