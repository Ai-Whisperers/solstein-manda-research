# Tablebooker — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Status**: ❌ NOT AN ACTIVE TARGET — Acquired by Zenchef (PSG Equity) Feb 2024

---

## Executive Summary

Tablebooker was Belgium's leading restaurant reservation platform, founded in 2012 in Ghent, acquired by RestoGroup in 2015, and ultimately acquired by Zenchef (PSG Equity-backed) in February 2024. As of 2026, Tablebooker operates as a fully integrated subsidiary of Zenchef, with its API deprecated and product migrating to ZenchefOS. **It does not qualify as a SolStein acquisition target**: it is PE-controlled, not founder-owned, and not independently acquirable.

This analysis is preserved for competitive landscape context and as a reference data point for Belgian restaurant reservation market valuation benchmarks.

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Tablebooker B.V. | [KBO / en.tablebooker.com/contact](https://en.tablebooker.com/contact) | Confirmed |
| KBO number | 0849.393.861 | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Founded | October 2012 | [North Data KBO](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Headquarters | Lozenberg 11, 1932 Zaventem, Belgium | [PitchBook](https://pitchbook.com/profiles/company/466910-20) | Confirmed |
| Current parent | Zenchef (majority owned by PSG Equity) | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Employees | 17 (PitchBook, 2026); 12 (Tracxn, Dec 2021) | [PitchBook](https://pitchbook.com/profiles/company/466910-20) / [Tracxn](https://tracxn.com/d/companies/tablebooker/__I5MHBwMZ5wfykhIGZ9DJsFnLqpWvqz0VjHVfwP08LBE) | Estimated |
| Revenue (standalone) | Not publicly disclosed | PitchBook, Crunchbase | Unknown |
| Resto.be group revenue | ~$5.9M (RocketReach estimate for broader group) | [RocketReach](https://rocketreach.co/restobe-profile_b5c2c8d2f42e0f34) | Estimated |
| Business model | SaaS B2B (Tablemanager) + B2C portal (tablebooker.com) | [Lightspeed integration](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Operating countries | Belgium, Luxembourg, France, Netherlands + 1 (5 total) | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Seats managed (2023) | 25 million | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Restaurant clients at acquisition | 3,000+ | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Belgium market position | #1 market leader in restaurant reservations (at time of acquisition) | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) / [Zenchef](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Belgian restaurant clients | ~3,000 (Tablebooker standalone); ~6,000 combined with Resengo under Zenchef | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Belgium total restaurants market | ~24,000–30,000 hospitality establishments (estimation) | Market context | Estimated |
| Estimated market share (BE, reservations) | 20–30% of digitized restaurant reservations in Belgium | Estimated from 3,000/total | Estimated |
| Key partner platforms | Resto.be (Belgium's largest restaurant site), RestoDays, Jong Keukengeweld, The Mastercooks of Belgium | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Notable restaurant clients | 't Aards Paradijs, Barge, L'Horizon, Divin by Sepi, Neon, Hofke Van Bazel | [HorecaTrends](https://www.horecatrends.com/en/tablebooker-from-belgium-joins-zenchef/) | Confirmed |
| Starred restaurants | Yes — serves Michelin-level establishments | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Main competitor remaining in BE | TableFever (founded 2014) | [MandA.be](https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/) | Confirmed |
| Pan-European competitor | TheFork (TripAdvisor) | [MandA.be](https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/) | Confirmed |
| Monthly visits | 1+ million (Tablebooker.com) | [Lightspeed integration page](https://www.lightspeedhq.com/integrations/tablebooke/) | Estimated |
| Monthly bookings (Zenchef group) | 6.2 million across Europe | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |

---

## 3. Product & Technology

### Core Products

| Product | Description | Source | Confidence |
|---|---|---|---|
| Tablemanager (B2B SaaS) | Cloud-based reservation management: reservations, guest data, table availability, gift cards, deposit/payment | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Tablephone | Unique feature converting inbound restaurant phone calls to digital reservations | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Tablebooker.com (B2C) | Consumer restaurant discovery and booking portal for Belgium/Luxembourg | [en.tablebooker.com](https://en.tablebooker.com/) | Confirmed |
| Gift card management | Online sale of restaurant gift cards with direct payout | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Deposits / menu payments | No-show prevention via deposits or full menu prepayment | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Resto.be portal | Belgium's largest restaurant website (B2C); powered by Tablebooker tech | [en.tablebooker.com/about](https://en.tablebooker.com/about) | Confirmed |
| Restofactory | Restaurant website building service | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| RestoDays | Belgian gastronomy events platform | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |

### Technology Stack

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Deployment model | Cloud SaaS | [Crunchbase](https://www.crunchbase.com/organization/tablebooker) / [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| API | REST API existed (api.tablebooker.be); now deprecated post-Zenchef | [api.tablebooker.be](https://api.tablebooker.be/) | Confirmed |
| CMS integration | Drupal module for reservation widget | [Drupal.org](https://www.drupal.org/project/tablebooker) | Confirmed |
| POS integration | Lightspeed POS (bidirectional) | [Lightspeed integration page](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Google integration | Google "Reserve a Table" — bookings direct from Google Search | [Crunchbase](https://www.crunchbase.com/organization/tablebooker) | Confirmed |
| Mobile apps | iOS (App Store) and Android (Google Play) consumer apps | [Apple App Store](https://apps.apple.com/be/app/tablebooker/id720782377) / [Google Play](https://play.google.com/store/apps/details?id=be.tablebooker.app) | Confirmed |
| Migration path | Migrating to ZenchefOS (Zenchef's unified platform) | [api.tablebooker.be](https://api.tablebooker.be/) / [tablemanager.lu](https://www.tablemanager.lu/en/) | Confirmed |
| Primary language stack | Unknown (not publicly disclosed) | — | Unknown |
| Reviews/reputation data | 250,000+ customer reviews on platform | [en.tablebooker.com](https://en.tablebooker.com/) | Confirmed |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned? | No — not since 2015 acquisition by RestoGroup | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Current ownership | Zenchef (controlled by PSG Equity) | [MandA.be](https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/) | Confirmed |
| PE overhang | Yes — PSG Equity majority shareholder of Zenchef since Sep 2022 | [PSG Equity portfolio](https://psgequity.com/portfolio/zenchef) | Confirmed |
| PSG Equity investment | >€50 million in Zenchef (Sep 2022) | [PrivSource](https://www.privsource.com/acquisitions/deal/psg-equity-invests-over-50-million-in-zenchef-krSgp9) | Confirmed |
| Nicolas de Borrekens | No longer director of Tablebooker B.V. (post 2024 KBO filing) | [North Data](https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861) | Confirmed |
| Paul Slootmans | VP Revenue Belgium & Luxembourg at Zenchef (employed, not owner) | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Succession signal | N/A — both founders absorbed or departed | — | Confirmed |
| SolStein fit | ❌ Fails "founder-owned" and "no PE overhang" criteria | SolStein M&A thesis | Confirmed |
| Independently acquirable? | No — deeply integrated into Zenchef / ZenchefOS | [api.tablebooker.be](https://api.tablebooker.be/) | Confirmed |
| Carve-out probability | Very low — PSG Equity consolidation strategy targets growth, not divestiture | [PSG Equity + CoverManager 2025](https://psgequity.com/news/covermanager-and-zenchef-join-forces-to-create-a-leading-european-restaurant-revenue-management-platform) | Estimated |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue (standalone Tablebooker) | Not disclosed | Private company | Unknown |
| Revenue (Tablebooker group / Resto.be) | ~$5.9M estimated (RocketReach, covers broader group) | [RocketReach](https://rocketreach.co/restobe-profile_b5c2c8d2f42e0f34) | Estimated |
| Headcount growth | 12 (Dec 2021) → 17 (2026) — modest organic growth | [Tracxn](https://tracxn.com/d/companies/tablebooker/__I5MHBwMZ5wfykhIGZ9DJsFnLqpWvqz0VjHVfwP08LBE) / [PitchBook](https://pitchbook.com/profiles/company/466910-20) | Estimated |
| Restaurant client growth | Unknown pre-2024; 3,000 at acquisition | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Estimated |
| Seats managed | 25 million in 2023 | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Post-acquisition trajectory | Being subsumed into ZenchefOS; standalone metrics no longer reported | [api.tablebooker.be](https://api.tablebooker.be/) | Confirmed |
| Profitability | Unknown | — | Unknown |
| Belgian revenue share | Likely 80–90% of standalone revenues (Belgium + Luxembourg) | Market structure | Estimated |

### ARR Estimation Model

> Given ~3,000 restaurants × estimated €600–1,200/year average subscription = **€1.8M–€3.6M ARR estimate** (standalone Tablemanager B2B). Additional revenue from Resto.be media/advertising and event revenue (RestoDays) suggests total group revenue likely in the **€3M–€6M** range. This estimate is consistent with RocketReach's ~$5.9M group-level figure.

| Component | Estimate | Basis |
|---|---|---|
| Tablemanager SaaS (3,000 restaurants) | €1.8M–€3.6M ARR | €600–€1,200/restaurant/year (market rate) |
| Resto.be advertising/media | €500K–€1.5M | 1M+ monthly visits, display + sponsorship revenue |
| RestoDays events | €100K–€500K | Ticket revenue + restaurant participation fees |
| Restofactory websites | €100K–€300K | ~200–500 restaurant websites |
| **Total estimated group revenue** | **€2.5M–€6M** | Consistent with RocketReach ~$5.9M |

---

## 6. HORECA Vertical Depth

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Restaurant vertical focus | Pure-play restaurant reservations (no hotel, no retail) | [en.tablebooker.com](https://en.tablebooker.com/) | Confirmed |
| Belgium GDPR compliance | Belgian BV — operates under Belgian/EU GDPR; no documented violations | General EU context | Estimated |
| Bancontact integration | No direct evidence of Bancontact (Belgian payment method) integration | — | Unknown |
| Commission-free model | Yes — explicitly commission-free, unlike TheFork | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| CRM capabilities | Guest data management within Tablemanager | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Marketing tools | No-show reduction (deposits), gift cards, Google Reserve integration | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |
| Reviews platform | 250,000+ reviews on tablebooker.com | [en.tablebooker.com](https://en.tablebooker.com/) | Confirmed |
| Event partnerships | Jong Keukengeweld, Mastercooks of Belgium, RestoDays | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Restaurant website building | Yes (Restofactory) — full digital presence offering | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) | Confirmed |
| Workforce / POS | Not a core offering; POS integration via Lightspeed partnership | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) | Confirmed |

---

## 7. Valuation & Business Model

### Business Model

| Revenue Stream | Type | Notes | Confidence |
|---|---|---|---|
| Tablemanager subscription | Recurring SaaS (monthly/annual per restaurant) | Pricing not publicly listed; inquiry required | Confirmed (model); Estimated (price) |
| Resto.be advertising | Media / CPM / sponsorship | Belgium's largest restaurant site | Confirmed |
| RestoDays event revenue | Transactional | Annual gastronomy promotion days | Confirmed |
| Restofactory website fees | Project + maintenance | Restaurant web design | Confirmed |
| No reservation commissions | Commission-free model | Key differentiator vs TheFork | Confirmed |

### Valuation Context

| Metric | Value | Basis | Confidence |
|---|---|---|---|
| Estimated group ARR | €2.5M–€6M | ARR model above | Estimated |
| SaaS revenue multiple (comparable) | 3–6× ARR (niche B2B SaaS, Belgium, pre-PE) | Market comps (Resengo, Formitable) | Estimated |
| Estimated standalone valuation (2023 pre-acquisition) | €7.5M–€25M | 3–6× ARR on €2.5M–€6M | Estimated |
| Zenchef acquisition price | Undisclosed | [Tracxn](https://tracxn.com/d/acquisitions/acquisitions-by-zenchef/__4rDJ9iBBN8TjD5H8MWIB7YPh-tEeEWjxdLjM1M3TRCI) | Unknown |
| Current standalone value | Not applicable (integrated into Zenchef) | — | N/A |

> Valuation is academic — Tablebooker is not independently acquirable. Retained for benchmark purposes when evaluating other Belgian reservation companies.

---

## 8. M&A Attractiveness Scorecard

> **Context**: Scores assess Tablebooker as it existed immediately before the Zenchef acquisition (2023 state), for historical benchmark value. Current scores reflect that it is no longer independently acquirable.

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | **1** | PE-owned subsidiary (PSG Equity → Zenchef); not founder-owned since 2015; both founders absorbed or departed | [MandA.be](https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/) |
| **Revenue scale fit** | High | **3** | Estimated €2.5M–€6M group revenue — within SolStein's €1M–€15M target band, but not independently accessible | [RocketReach](https://rocketreach.co/restobe-profile_b5c2c8d2f42e0f34) |
| **Geographic fit** | High | **5** | Pure Belgian market leader; Belgium + Luxembourg primary; NL presence; perfect geographic fit | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) |
| **Tech stack modernity** | Medium | **4** | Cloud SaaS, REST API, Google Reserve integration, mobile apps — modern foundation; API deprecated post-acquisition | [api.tablebooker.be](https://api.tablebooker.be/) |
| **Customer lock-in** | Medium | **4** | Market leader with 3,000+ restaurants; Tablephone unique feature; deep integration with Lightspeed, Google; high switching cost | [Lightspeed](https://www.lightspeedhq.com/integrations/tablebooke/) |
| **Vertical depth** | Medium | **5** | Pure-play Belgian restaurant reservation + marketing ecosystem; Resto.be, RestoDays, Restofactory create moat | [Zenchef press release](https://www.zenchef.com/tablebooker-joins-zenchef) |
| **Integration potential** | Low | **2** | REST API existed but is now deprecated; ZenchefOS migration underway; integration increasingly locked into Zenchef stack | [api.tablebooker.be](https://api.tablebooker.be/) |
| **Growth trajectory** | Low | **3** | Modest headcount growth (12→17); 25M seats in 2023 shows scale; trajectory unclear post-acquisition | [Tracxn](https://tracxn.com/d/companies/tablebooker/__I5MHBwMZ5wfykhIGZ9DJsFnLqpWvqz0VjHVfwP08LBE) |

### Composite Score

| Calculation | Value |
|---|---|
| Weighted score (High=3, Medium=2, Low=1) | (1×3 + 3×3 + 5×3 + 4×2 + 4×2 + 5×2 + 2×1 + 3×1) ÷ (3+3+3+2+2+2+1+1) |
| Numerator | 3 + 9 + 15 + 8 + 8 + 10 + 2 + 3 = **58** |
| Denominator | 3+3+3+2+2+2+1+1 = **17** |
| **Composite Score** | **3.4 / 5.0** |
| **Confidence Band** | **Low** — majority of financial and ownership data is Estimated or Unknown |

> **Interpretation**: The 3.4 composite score is misleading — it reflects strong product/market characteristics (geography, depth, lock-in) that would have made Tablebooker an attractive target in 2020–2022. However, the Ownership dimension (score 1) is a hard blocker that renders the composite score irrelevant for SolStein's acquisition process.

### Overall Assessment

**Tablebooker is a case study, not a target.**

Tablebooker represented exactly the type of company SolStein would target: Belgian market leader, founder-managed through 2015, niche HORECA focus, commission-free SaaS model, strong customer lock-in. It was in the SolStein sweet spot before RestoGroup acquired it in 2015 and before PSG Equity entered via Zenchef in 2022.

The 2024 Zenchef acquisition closes any remaining acquisition window. With API deprecation, ZenchefOS migration, and a PSG Equity-funded consolidation strategy combining Zenchef, Formitable, Resengo, Tablebooker, and CoverManager into a single pan-European platform, Tablebooker is being systematically integrated and will not re-emerge as an independent acquirable entity in the near to medium term.

### Recommended Next Step

1. **Remove from active target list** — close the research file as "Acquired/Not available."
2. **Monitor TableFever** (Ghent, 2014) — the only remaining independent Belgian restaurant reservation competitor per MandA.be; potentially acquirable before it follows the same path.
3. **Use Tablebooker as valuation benchmark** — 3,000 restaurant clients, €2.5M–€6M estimated revenue, acquired by a well-capitalised strategic buyer. Comparable SaaS multiples of 3–6× ARR provide a reference for pricing other Belgian reservation targets.
4. **Watch Zenchef** — if PSG Equity eventually exits Zenchef, the Belgian operations (Tablebooker + Resengo brands) could become available in a secondary transaction, but this is a 3–5 year horizon at best.

---

## Data Confidence Summary

| Category | Confirmed | Estimated | Unknown |
|---|---|---|---|
| Company registration / KBO | 9 data points | 1 | 0 |
| Founders & ownership | 6 | 4 | 0 |
| M&A events | 8 | 2 | 2 (deal prices) |
| Product & technology | 12 | 2 | 1 |
| Market position | 9 | 3 | 0 |
| Financials | 2 | 5 | 3 |
| **Overall** | **~60%** | **~30%** | **~10%** |

> Confidence is adequate for a Go/No-Go decision. Financial data weakness is acceptable given the target is not actionable.

---

## Sources

| # | Source | URL |
|---|---|---|
| 1 | Zenchef acquisition press release | https://www.zenchef.com/tablebooker-joins-zenchef |
| 2 | MandA.be — acquisition article | https://manda.be/articles/zenchef-continues-consolidation-with-acquisition-of-tablebooker/ |
| 3 | North Data / KBO filings | https://www.northdata.com/Tablebooker%20B%C2%B7V%C2%B7,%20Zaventem/KBO%200849.393.861 |
| 4 | PitchBook profile 2026 | https://pitchbook.com/profiles/company/466910-20 |
| 5 | Crunchbase | https://www.crunchbase.com/organization/tablebooker |
| 6 | Tracxn company profile | https://tracxn.com/d/companies/tablebooker/__I5MHBwMZ5wfykhIGZ9DJsFnLqpWvqz0VjHVfwP08LBE |
| 7 | Tracxn — Zenchef acquisitions | https://tracxn.com/d/acquisitions/acquisitions-by-zenchef/__4rDJ9iBBN8TjD5H8MWIB7YPh-tEeEWjxdLjM1M3TRCI |
| 8 | PSG Equity — Zenchef portfolio | https://psgequity.com/portfolio/zenchef |
| 9 | PSG + CoverManager announcement | https://psgequity.com/news/covermanager-and-zenchef-join-forces-to-create-a-leading-european-restaurant-revenue-management-platform |
| 10 | PrivSource — PSG €50M investment | https://www.privsource.com/acquisitions/deal/psg-equity-invests-over-50-million-in-zenchef-krSgp9 |
| 11 | HorecaTrends.com | https://www.horecatrends.com/en/tablebooker-from-belgium-joins-zenchef/ |
| 12 | Lightspeed integration page | https://www.lightspeedhq.com/integrations/tablebooke/ |
| 13 | en.tablebooker.com | https://en.tablebooker.com/ |
| 14 | Tablebooker API deprecation notice | https://api.tablebooker.be/ |
| 15 | Tablemanager.lu (ZenchefOS migration) | https://www.tablemanager.lu/en/ |
| 16 | RocketReach — Resto.be financials | https://rocketreach.co/restobe-profile_b5c2c8d2f42e0f34 |
| 17 | Tom Vroemans / November Five (The Org) | https://theorg.com/org/november-five/org-chart/tom-vroemans |
| 18 | Drupal integration module | https://www.drupal.org/project/tablebooker |
| 19 | Apple App Store — Tablebooker app | https://apps.apple.com/be/app/tablebooker/id720782377 |
| 20 | Google Play — Tablebooker app | https://play.google.com/store/apps/details?id=be.tablebooker.app |
