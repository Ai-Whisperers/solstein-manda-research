# Systor

**Category**: Hospitality IT
**Country**: DE
**City**: Frankfurt
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Systor @HORECA_IT/systor/
@research-horeca-company Systor @HORECA_IT/systor/
```
