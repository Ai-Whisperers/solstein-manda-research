# Systor — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — very limited public data

---

## Executive Summary

Systor is listed in the SolStein research brief as a Frankfurt-based Hospitality IT company providing IT solutions for hotels and gastronomy. Extensive research could not identify a company named "Systor GmbH" or "Systor" as a Frankfurt hospitality IT provider. The name "Sycor" (a different company, IT services for manufacturing/healthcare based in Göttingen) was found but is unrelated. This company may be a very small regional hospitality IT consultancy or reseller with minimal online presence.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | Systor | SolStein research brief | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Frankfurt, Hesse, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany | SolStein research brief | Estimated |
| Primary activity | IT solutions for hotels and gastronomy (reported) | SolStein research brief | Estimated |

---

## Research Methodology & Limitations

Searches conducted:
- "Systor GmbH Frankfurt hospitality IT hotel"
- "Systor Computertechnik hotel gastronomy Germany"
- Northdata.de searches (no relevant results)

**Note**: "Sycor GmbH" (Göttingen, IT consulting for manufacturing/healthcare) was found but is an unrelated company. "Systor" as a hospitality IT company in Frankfurt could not be confirmed.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — company existence not confirmed |
| **SolStein thesis fit** | Very poor — Germany-only, unconfirmed existence, likely small |
| **Research confidence** | Very low |

**Verdict**: Company identity and existence not confirmed. Cannot assess.

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| Web search results (inconclusive) | Multiple searches; no match found | Negative result |
