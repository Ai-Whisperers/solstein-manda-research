# Systor — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Unconfirmed entity; insufficient data for analysis

---

## Research Limitations

Systor's existence as a Frankfurt hospitality IT company could not be confirmed through public web research. All data points are Unknown. This analysis serves as a placeholder noting the research attempt.

---

## 1–7. All Data Points

All Unknown — company identity not confirmed.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown | No source |
| Revenue scale fit | High | 1 | Assumed micro-scale (no online presence) | Estimated |
| Geographic fit | High | 1 | Germany (Frankfurt) only | SolStein brief |
| Tech stack modernity | Medium | — | Unknown | No source |
| Customer lock-in | Medium | — | Unknown | No source |
| Vertical depth | Medium | — | Unknown | No source |
| Integration potential | Low | — | Unknown | No source |
| Growth trajectory | Low | — | Unknown | No source |

**Composite Score**: ~1.0 / 5.0

**Confidence Band**: Very Low

**Overall M&A Assessment**: Cannot assess. Company existence not confirmed. **Recommended Next Step**: Remove from active research or conduct direct Handelsregister search at Amtsgericht Frankfurt.

---

*Sources: SolStein research brief only*
