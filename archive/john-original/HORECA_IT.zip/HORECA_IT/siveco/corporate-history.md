# Siveco — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — very limited public data; possible naming confusion

---

## Executive Summary

The SolStein research brief lists "Siveco" as a Munich-based hotel PMS provider serving the DACH market. Extensive research could not identify a hotel PMS company named "Siveco" in Munich, Germany. The only prominent companies named "Siveco" found in research are:

1. **Siveco Group** — A French CMMS/asset management software company (founded 1986, headquartered in France); unrelated to hotel PMS
2. **SIVECO Romania** — A Romanian software development company (founded 1992); unrelated to hotel PMS

It is possible that "Siveco Munich hotel PMS" refers to a very small, regional German hotel software company with minimal online presence, or that there is a naming confusion in the research brief. No Handelsregister entries for "Siveco GmbH" in Munich could be confirmed through web research.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | Siveco | SolStein research brief | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Munich, Bavaria, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany (reported) | SolStein research brief | Estimated |
| Primary activity | Hotel PMS for DACH market (reported) | SolStein research brief | Estimated |

---

## Disambiguation Note

| Entity | Location | Activity | Relevance |
|---|---|---|---|
| Siveco Group | France (Paris area) | CMMS / asset management software (Coswin) | NOT the company referenced; unrelated to hotel PMS |
| SIVECO Romania | Bucharest, Romania | Business software development | NOT the company referenced |
| Siveco Munich hotel PMS | Munich, Germany (reported) | Hotel PMS for DACH | IDENTITY UNCONFIRMED |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | Unknown | No public source found | Unknown |
| Founders | Unknown | No public source found | Unknown |
| History | Unknown | No public source found | Unknown |

---

## Research Methodology & Limitations

Searches conducted:
- "Siveco hotel software Munich DACH"
- "Siveco Hotelsoftware Deutschland"
- "Siveco GmbH Munich hotel"
- Northdata.de searches (no results for Siveco Munich)

**Possible explanations**:
1. The company may operate under a different legal name than "Siveco"
2. The company may be so small it has no meaningful online footprint
3. There may be a naming error in the research brief (possible confusion with "Sivecos" or a similar name)

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — company existence not confirmed |
| **SolStein thesis fit** | Potentially interesting if confirmed as founder-owned Munich hotel PMS; but Germany-only = geographic mismatch |
| **Research confidence** | Very low — company identity unconfirmed |

**Verdict**: Identity of "Siveco Munich hotel PMS" is **unconfirmed**. Cannot assess feasibility without confirming the legal entity.

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| Siveco Group (unrelated) | https://www.siveco.com/en/ | Disambiguation |
| Web search results (inconclusive) | Multiple searches; no Munich hotel PMS company found | Negative result |
