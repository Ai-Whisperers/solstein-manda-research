# Siveco — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Unconfirmed entity; insufficient data for analysis

---

## Research Limitations

The company "Siveco" as described in the SolStein research brief (Munich-based hotel PMS for DACH) could not be confirmed through public web research. The only "Siveco" companies found are a French CMMS company and a Romanian software company — both unrelated to hotel PMS. This analysis cannot be meaningfully completed without confirming the legal entity.

---

## 1–7. All Data Points

| Category | Status |
|---|---|
| Company Fundamentals | Unknown — entity not confirmed |
| HORECA Market Position | Unknown |
| Product & Technology | Unknown |
| M&A Ownership & Succession | Unknown |
| Financial Growth & Trajectory | Unknown |
| HORECA Vertical Depth | Unknown |
| Valuation & Business Model | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown — entity not confirmed | No source |
| Revenue scale fit | High | — | Unknown | No source |
| Geographic fit | High | 1 | Germany (Munich) only — no NL/BE | SolStein brief |
| Tech stack modernity | Medium | — | Unknown | No source |
| Customer lock-in | Medium | — | Unknown | No source |
| Vertical depth | Medium | — | Unknown | No source |
| Integration potential | Low | — | Unknown | No source |
| Growth trajectory | Low | — | Unknown | No source |

**Composite Score**: Insufficient data

**Confidence Band**: Very Low — entity existence not confirmed

**Overall M&A Assessment**: Cannot assess. Company identity requires confirmation before any M&A analysis is possible.

**Recommended Next Step**: Contact SolStein research brief author for source clarification. Conduct direct Handelsregister search at Amtsgericht München for "Siveco" entities. Consider whether the name refers to a subsidiary of Siveco Group (France) or a different entity entirely.

---

*Sources: SolStein research brief only; no independent public sources confirmed. Siveco Group (France) is unrelated.*
