# HotelPARTNER — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Privately held — Swiss-headquartered (not German)

---

## Executive Summary

HotelPartner Revenue Management (operating as HotelPartner Management AG) is a Swiss-headquartered company providing revenue management and distribution services to hotels across the DACH region and the UK. Founded in 2006 by Oliver Meyer, the company operates through its proprietary "TET-Synergy" model combining Teams, Expertise, and Technology. It is **not primarily a PMS provider** as described in the SolStein brief — it is a managed revenue management service using the HotelPartner Performance Platform (HPP) that integrates with hotels' existing PMS systems. The company serves approximately 500 partner hotels, has ~41 employees, and offices in Switzerland, Austria, Germany (Hamburg), and the UK. **Note**: The SolStein brief places HotelPARTNER in "Ismaning/Munich, DE" but the company is headquartered in Schindellegi, Switzerland.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | HotelPartner Management AG | hotelpartner.com/about-us; PitchBook | Confirmed |
| Trade name | HotelPartner | hotelpartner.com | Confirmed |
| Legal form | AG (Aktiengesellschaft) | PitchBook | Confirmed |
| Registered HQ | Schindellegi, Switzerland | PitchBook | Confirmed |
| Reported DE location | Hamburg (office) | hotelpartner.com/about-us | Confirmed |
| SolStein brief location | "Ismaning/Munich, DE" | SolStein research brief | Estimated |
| Country (legal HQ) | Switzerland | PitchBook | Confirmed |
| DACH presence | Germany, Austria, Switzerland + UK | hotelpartner.com/about-us | Confirmed |
| Primary activity | Revenue management services + distribution for hotels | hotelpartner.com | Confirmed |
| Website | hotelpartner.com | hotelpartner.com | Confirmed |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | 2006 | hotelpartner.com/about-us; PitchBook | Confirmed |
| Founder | Oliver Meyer | hotelpartner.com/about-us | Confirmed |
| Origin | Revenue management services for independent hotels in the DACH region | hotelpartner.com | Confirmed |
| Initial focus | DACH hotel revenue optimization | hotelpartner.com | Confirmed |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership type | Privately held | PitchBook (private status) | Confirmed |
| PE involvement | None identified | PitchBook | Confirmed |
| External funding | None identified | PitchBook | Confirmed |
| Founder ownership | Oliver Meyer returned as CEO March 2025; likely major or controlling shareholder | hotelpartner.com | Estimated |

---

## Key Leadership

| Date | Role | Person | Source | Confidence |
|---|---|---|---|---|
| 2006–present | Founder | Oliver Meyer | hotelpartner.com | Confirmed |
| 2006–2018 | CEO | Oliver Meyer (original tenure) | hotelpartner.com | Estimated |
| 2018–2025 | CEO | Rainer M. Willa | hotelpartner.com | Confirmed |
| Mar 1, 2025 | CEO (return) | Oliver Meyer (founder returns as CEO) | hotelpartner.com | Confirmed |
| Mar 1, 2025 | Chairman of Board | Rainer M. Willa (transitions from CEO) | hotelpartner.com | Confirmed |

---

## M&A History

No external M&A events identified. HotelPartner appears to have grown organically from 120 to 500+ partner hotels without acquisitions.

---

## Corporate Structure

```mermaid
graph TD
    A["Oliver Meyer<br/>(Founder & CEO since Mar 2025)"]
    B["HotelPartner Management AG<br/>(Schindellegi, Switzerland)"]
    C["Offices in:<br/>Switzerland (Lausanne, Bern)<br/>Austria (Vienna, Salzburg)<br/>Germany (Hamburg)<br/>UK (London)"]
    D["HotelPartner Performance Platform (HPP)<br/>(Proprietary technology)"]

    A -->|"Founder / CEO"| B
    B --> C
    B --> D

    style B fill:#f9f,stroke:#333
    style D fill:#bbf,stroke:#333
```

---

## Corporate Timeline

```mermaid
timeline
    title HotelPartner — Corporate Timeline
    2006 : Founded by Oliver Meyer
         : Revenue management services for DACH hotels
    2006-2018 : Organic growth phase
              : Expanded from 120 to 500+ partner hotels
              : DACH + UK expansion
    2018 : Rainer M. Willa becomes CEO
         : Oliver Meyer likely transitions to board
    2018-2025 : Continued growth under Willa
              : Offices in CH, AT, DE (Hamburg), UK (London)
    Mar 2025 : Leadership restructuring
             : Oliver Meyer returns as CEO
             : Rainer M. Willa becomes Chairman
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Potentially available — privately held, no PE, founder returning as CEO may signal transition thinking |
| **Ownership structure** | Clean private structure; founder-controlled (likely); no external investors identified |
| **SolStein thesis fit** | Poor fit — Swiss HQ, Germany is secondary market only; revenue management service (not pure SaaS PMS); ~500 hotels suggests revenue >€5M |
| **Succession signals** | Ambiguous — founder returning as CEO in 2025 could signal growth phase OR succession preparation |
| **Role for SolStein** | Reference for DACH hotel tech valuations; not a direct target |

**Verdict**: HotelPartner is **not a SolStein target** — Swiss HQ, wrong geography, and operates as a managed service rather than a self-serve SaaS PMS. However, the founder's return to the CEO role in 2025 is worth monitoring as a potential future succession signal.

---

## Sources

| Source | URL | Type |
|---|---|---|
| HotelPartner — About Us | https://hotelpartner.com/about-us/ | Primary (company site) |
| HotelPartner — leadership restructuring | https://hotelpartner.com/blog/restructuring-at-hotelpartner-revenue-management... | Primary (company blog) |
| PitchBook — HotelPartner profile | https://pitchbook.com/profiles/company/507011-32 | Secondary (company DB) |
| HotelPartner home | https://hotelpartner.com/ | Primary (company site) |
