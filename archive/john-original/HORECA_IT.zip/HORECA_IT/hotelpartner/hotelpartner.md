# HotelPARTNER

**Category**: Hotel PMS
**Country**: DE
**City**: Ismaning
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history HotelPARTNER @HORECA_IT/hotelpartner/
@research-horeca-company HotelPARTNER @HORECA_IT/hotelpartner/
```
