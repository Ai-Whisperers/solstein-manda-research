# HotelPARTNER — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE/CH)
**M&A Role**: DACH hotel revenue management reference; NOT a primary SolStein target

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | HotelPartner Management AG | PitchBook | Confirmed |
| HQ | Schindellegi, Switzerland | PitchBook | Confirmed |
| DE presence | Hamburg office (and likely DE-based account managers) | hotelpartner.com/about-us | Confirmed |
| Founded | 2006 | hotelpartner.com; PitchBook | Confirmed |
| CEO | Oliver Meyer (founder, returned Mar 2025) | hotelpartner.com | Confirmed |
| Ownership | Privately held; founder-controlled | PitchBook; hotelpartner.com | Confirmed |
| Employees | ~41 (PitchBook) | PitchBook | Estimated |
| Revenue | Not publicly disclosed; estimated €5–15M based on 500 hotel clients | Estimated | Estimated |
| Countries | DACH (primary) + UK | hotelpartner.com | Confirmed |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Partner hotels | ~500 | hotelpartner.com; CEO blog post | Confirmed |
| Market segment | 3–5 star independent hotels in DACH + UK | hotelpartner.com | Confirmed |
| DACH presence | Germany, Austria, Switzerland | hotelpartner.com | Confirmed |
| NL/BE presence | None identified | No source | Unknown |
| Product positioning | Revenue management as a service + technology platform | hotelpartner.com | Confirmed |
| Competitive differentiation | "TET-Synergy" = Teams + Expertise + Technology (managed service model, not pure SaaS) | hotelpartner.com | Confirmed |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | HotelPartner Performance Platform (HPP) | hotelpartner.com | Confirmed |
| Model type | Managed revenue management service (not self-serve SaaS PMS) | hotelpartner.com | Confirmed |
| Web booking engine | "B.E. Quick" web booking engine | hotelpartner.com | Confirmed |
| PMS integration | Integrates with existing hotel PMS (does not replace PMS) | hotelpartner.com | Confirmed |
| Channel management | Distribution and channel management included | hotelpartner.com | Confirmed |
| TSE compliance | N/A — not a POS system | N/A | N/A |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Owner | Oliver Meyer (founder) — likely majority shareholder | hotelpartner.com | Estimated |
| PE involvement | None | PitchBook | Confirmed |
| Succession signals | Founder returning to CEO role (March 2025) — ambiguous signal | hotelpartner.com | Confirmed |
| Exit readiness | Unknown; founder returning could mean either exit preparation or renewed growth commitment | Assessment | Estimated |
| Management depth | Rainer M. Willa (former CEO, now Chairman) provides management continuity | hotelpartner.com | Confirmed |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not publicly disclosed | No source | Unknown |
| Estimated revenue | €5–15M (based on 500 hotels × estimated €10–30K ARPU for managed revenue management) | Estimated | Estimated |
| Growth trajectory | Grew from 120 to 500+ hotels (Rainer Willa's 10-year tenure) | CEO anniversary blog | Confirmed |
| Profitability | Unknown; managed service model typically profitable at scale | Assessment | Unknown |
| Funding | None — fully bootstrapped | PitchBook | Confirmed |

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Hotel focus | Yes — exclusively hotels (3–5 star independent) | hotelpartner.com | Confirmed |
| Revenue management expertise | Deep — 20 years in DACH hotel revenue optimization | hotelpartner.com | Confirmed |
| PMS depth | Integrates with PMS; does not build or sell PMS | hotelpartner.com | Confirmed |
| DACH regulation | Swiss-based; understands CH/DE/AT hotel market | hotelpartner.com | Confirmed |
| Restaurant/F&B | Not primary focus | hotelpartner.com | Confirmed |

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | Managed service fee (% of revenue or fixed monthly per hotel) | hotelpartner.com | Estimated |
| Estimated ARR | €5–15M | Estimated | Estimated |
| Estimated valuation | €10–30M (2–3x revenue for managed service company) | Estimated | Estimated |
| Capital efficiency | High — bootstrapped to 500 hotels with ~41 employees | PitchBook; hotelpartner.com | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 3 | Founder-owned, no PE — positive; but Swiss HQ and returning founder (not obvious succession) | PitchBook; hotelpartner.com |
| Revenue scale fit | High | 2 | Estimated €5–15M ARR — within range but managed service model differs from SolStein's SaaS preference | Estimated |
| Geographic fit | High | 1 | Switzerland HQ; Germany presence only (Hamburg office); no NL/BE | hotelpartner.com |
| Tech stack modernity | Medium | 3 | Proprietary HPP platform; integrates with existing PMS; modern web booking engine | hotelpartner.com |
| Customer lock-in | Medium | 4 | 500 hotels integrated; switching costs high for revenue management service | Assessment |
| Vertical depth | Medium | 3 | Deep hotel expertise; but revenue management service only (not PMS/POS) | hotelpartner.com |
| Integration potential | Low | 3 | Designed to integrate with PMS systems; API-friendly by nature | hotelpartner.com |
| Growth trajectory | Low | 3 | 4x growth in hotel count over 10 years; steady trajectory | CEO anniversary post |

**Composite Score**: ~2.4 / 5.0

**Confidence Band**: Medium — ownership confirmed, financials estimated

**Overall M&A Assessment**: HotelPartner is **not a SolStein acquisition target** in its current form. It is Swiss-headquartered (not NL/BE), operates as a managed revenue management service (not pure SaaS PMS), and the founder's return to the CEO role in March 2025 creates ambiguity about exit intent. The company's bootstrapped profile and founder control are attractive characteristics in isolation, but geography and business model fail SolStein's primary filters.

**Recommended Next Step**: Monitor for succession signals. If Oliver Meyer shows exit interest post-2026, and if SolStein's thesis expands to include DACH managed hotel services, revisit. Currently: no action recommended.

---

*Sources: hotelpartner.com, PitchBook, hotelpartner.com/blog*
