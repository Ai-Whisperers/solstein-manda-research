# Valk Solutions — Deep Analysis

**Research Date**: 2026-04-30
**Researcher**: SolStein M&A Research Agent
**Category**: Retail omnichannel software (with hospitality adjacency via Countr POS)
**Country**: Netherlands
**Verdict**: NOT an acquisition target — PE-backed, wrong vertical, wrong scale

---

## Identity Alert

> **This is not the company you were looking for.** Valk Solutions (valksolutions.nl) is a Dutch retail omnichannel software company, NOT a hotel PMS/distribution company. It is NOT related to Van der Valk Hotels. It has been majority-owned by PE (GSG GENII / Bregal Unternehmerkapital) since May 2023.
>
> The Van der Valk Hotels IT arm is **Valk Digital** — an internal captive unit, not a standalone acquirable company.
>
> Recommendation: Remove Valk Solutions from the SolStein HORECA pipeline and add a note about the identity confusion to prevent future misdirection.

---

## 1. Company Fundamentals

### Legal Entity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Valk Solutions B.V. | Kompass | Confirmed |
| KvK number | 30209227 | Kompass | Estimated |
| Legal form | BV (Besloten Vennootschap) | Kompass | Confirmed |
| Founded as business | 1989 | valksolutions.nl/about-us | Confirmed |
| Incorporated as BV | ~2005 | Kompass | Estimated |
| HQ | Vlasakker 5, 3417 XT Montfoort, Netherlands | valksolutions.nl | Confirmed |
| Secondary office | Ketelhavenstraat 37, 5045 NG Tilburg | valksolutions.nl | Estimated |

### Employees

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Employees (2026) | ~94–100 | PitchBook; GENII press release | Estimated |
| Headcount milestone | 100+ reached by 2022 | valksolutions.nl/about-us | Confirmed |
| R&D investment | Min. 10% of annual revenues | valksolutions.nl | Confirmed |

### Revenue

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Own revenue (ARR) | Not publicly disclosed | — | Unknown |
| Platform transaction volume | €4B+ annual client retail sales processed | gsg-genii.com 2023 press release | Confirmed |
| Revenue scale estimate | Likely €10M–€30M ARR (based on 100 employees + SaaS model + GENII-level deal size) | Estimated from headcount, industry benchmarks | Estimated |
| Revenue in SolStein range (€1–15M)? | Probably above range | — | Estimated |

### Ownership

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Current majority owner | GSG GENII Software Group (Munich) | gsg-genii.com | Confirmed |
| PE backers behind GENII | Bregal Unternehmerkapital + Elvaston | gsg-genii.com | Confirmed |
| Founder shareholding | Robert Valk retains significant minority | gsg-genii.com | Confirmed |
| CEO | Karin Valk (family member of founder) | gsg-genii.com | Confirmed |
| Founder-owned? | No — majority PE since May 2023 | gsg-genii.com | Confirmed |

**Critical note on group vs. standalone**: Valk Solutions is the *acquiree*, not a standalone acquirable entity post-2023. GENII has a buy-and-build strategy and is actively acquiring more companies into the Valk Solutions group. There is no exit signal.

---

## 2. HORECA Market Position

### Is Valk Solutions a HORECA Company?

**No — it is primarily a retail software company.** Its vertical coverage:

| Vertical | Role | Product | Revenue Significance |
|---|---|---|---|
| Food retail | Primary | ASPOS (supermarkets, food chains) | Core/primary |
| Fashion retail | Primary | PFA (fashion ERP/WMS) | Major |
| DIY / convenience | Primary | ASPOS | Major |
| **Hospitality (HORECA)** | **Adjacent / secondary** | **Countr POS (table service, kitchen, catering)** | **Minority** |
| Leisure / transport | Adjacent | Countr (ticketing, public transport POS) | Minor |
| Books / pets / beauty | Secondary | ASPOS | Minor |

### Hospitality Customers (via Countr)

Countr, acquired by Valk Solutions in 2021, provides:
- Cloud POS for hospitality venues (restaurants, cafes, bars)
- Table management and kitchen display systems
- Mobile ordering (handheld ordering for table service)
- Ticketing and catering for leisure venues and public transport

Countr is NOT a hotel PMS, channel manager, or distribution system. It is a point-of-sale and table management tool — analogous to a restaurant POS, not a hotel operations system.

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Hospitality product | Countr POS (cloud-based) | valksolutions.nl/solutions-overview | Confirmed |
| Hotel PMS product | None | valksolutions.nl/solutions-overview | Confirmed |
| Channel manager / distribution | None | valksolutions.nl/solutions-overview | Confirmed |
| Named hospitality customers | Not disclosed | — | Unknown |
| Customers beyond Van der Valk Hotels | Moot — no relationship exists | — | Confirmed |
| External hospitality market? | Yes, via Countr — but restaurant/catering, not hotel | valksolutions.nl | Confirmed |

### Key competitors in hospitality POS (via Countr)

Lightspeed Hospitality, Untill, Horecavita, Qompanion — all in the SolStein pipeline.

---

## 3. Product & Technology

### Core Products

| Product | Description | Vertical | Status |
|---|---|---|---|
| **ASPOS** | Unified commerce cloud platform — POS, OMS, PIM, loyalty, e-commerce, BI | Retail (food, fashion, DIY) | Core flagship, actively developed |
| **PFA** | Fashion ERP and WMS — sizes, colors, seasons, purchasing, logistics | Fashion retail | Acquired 2018, actively maintained |
| **Countr** | Cloud POS app — table service, kitchen mgmt, ticketing, catering | Hospitality, leisure, transport | Acquired 2021 |
| **Obur** | Hospitality/catering software | HORECA-adjacent | Acquired 2021 |

### Technology Stack Assessment

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Architecture | Cloud-native, fully browser-based | valksolutions.nl/about-us | Confirmed |
| API | REST API with 100+ interactive services | valksolutions.nl/solutions-overview | Confirmed |
| Deployment model | SaaS / hosted (no on-premise servers required) | valksolutions.nl/about-us | Confirmed |
| Platform modernization | ASPOS is the cloud-native successor to legacy ProPOSS (2001) | valksolutions.nl/about-us | Confirmed |
| Integration strategy | Open API, supports best-of-breed and best-of-suite | valksolutions.nl/solutions-overview | Confirmed |
| Annual version updates | All customers moved to latest version annually | valksolutions.nl/about-us | Confirmed |
| Security certifications | ISO 27001, ISAE 3402 Type 1 and 2 | valksolutions.nl/about-us | Confirmed |
| R&D investment | Min. 10% of revenues | valksolutions.nl/about-us | Confirmed |
| In-house development | Yes — dedicated in-house development team | valksolutions.nl/about-us | Confirmed |

**Technology verdict**: Valk Solutions is genuinely cloud-native and technically modern. The ASPOS platform is browser-based, REST API-first, and fully hosted. ISO 27001 and ISAE 3402 certifications are above-average for an SME software firm. Technology quality is not the issue — the problem is vertical fit and ownership structure.

---

## 4. M&A Ownership & Succession

### Ownership Structure (Post-May 2023)

```
Bregal Unternehmerkapital + Elvaston
        ↓ (PE backers)
GSG GENII Software Group (Munich) ← Majority shareholder since May 2023
        ↓
Valk Solutions B.V. (Montfoort, NL)
        ↑
Robert Valk ← Significant minority stake; active in product/key accounts
Karin Valk ← CEO, continuing full-time
```

### Acquisition Context

GSG GENII is a Munich-based software group operating a classic PE buy-and-build strategy across five verticals: Manufacturing, Retail, Distribution, Public Services, and Laboratories. Valk Solutions joined the Retail vertical. GENII has 2,400+ employees, 25+ locations, and €340M combined group revenue.

Since the 2023 acquisition, Valk Solutions has continued its own acquisitions (Bovertis 2024, Cocosoft 2025), confirming GENII's intent to grow — not exit — this asset.

### M&A Blockers for SolStein

| Blocker | Severity | Analysis |
|---|---|---|
| PE majority ownership | **Fatal** | GENII/Bregal is majority holder. SolStein thesis requires founder-owned, no PE overhang. Disqualified. |
| Not HORECA vertical | **Fatal** | ASPOS is a retail platform. No hotel PMS, no channel manager, no distribution software. |
| Likely above €15M ARR | **Significant** | 100 employees, 10%+ R&D budget, €4B+ client transactions. Revenue almost certainly above SolStein's sweet spot. |
| Active buy-and-build mode | **Significant** | GENII will not sell a 2023 acquisition with active post-close M&A; no exit signal whatsoever. |
| Leadership continuity | **Moderate** | Karin Valk is active CEO; Robert Valk active in product. No succession signal. |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Own ARR | Not publicly disclosed | — | Unknown |
| Client transaction volume | €4B+ annually | gsg-genii.com 2023 | Confirmed |
| Platform users | 35,000+ | valksolutions.nl | Confirmed |
| Estimated own revenue | €10M–€30M ARR (industry benchmark: ~€100K–€200K per employee for SaaS) | Benchmark model | Estimated |
| Headcount growth | 25 employees in 2009 → 100+ in 2022 → ~94 post-GENII (some headcount normalization) | valksolutions.nl / PitchBook | Estimated |
| Acquisitions 2021–2025 | 5+ acquisitions (Countr, Obur, Bovertis, Cocosoft + earlier) | valksolutions.nl / PitchBook | Confirmed |
| DACH expansion | Germany customers since 2016; GENII deal enables further DACH push | valksolutions.nl; gsg-genii.com | Confirmed |
| France expansion | ASPOS live in France (Wibra retail chain) | valksolutions.nl news 2025/2026 | Estimated |

**Trajectory**: Strong growth through acquisitions and organic customer additions. Platform volume grew from €3B (2020) to €4B+ (2023). Post-GENII, expansion is accelerating into DACH and France. Not a declining or distressed business.

---

## 6. HORECA Vertical Depth

### Assessment

Valk Solutions is **not** a deep HORECA vertical player. Its hospitality exposure is:

1. **Countr POS** (acquired 2021): Cloud POS for hospitality venues — restaurants, bars, canteens, stadiums, transit. Competes with Lightspeed, Square, Untill. Does NOT provide hotel PMS, revenue management, channel management, or distribution. It is a table/order management system.

2. **Obur** (acquired 2021): Hospitality/catering focus — details not publicly available. Likely a smaller catering-specific tool.

| HORECA Depth Dimension | Valk Solutions | Score |
|---|---|---|
| Hotel PMS | None | 0/5 |
| Channel manager / OTA distribution | None | 0/5 |
| Revenue management | None | 0/5 |
| Restaurant POS | Yes (Countr) | 3/5 |
| Kitchen management | Yes (Countr) | 3/5 |
| Table management | Yes (Countr) | 3/5 |
| Hospitality F&B | Partial (Countr/Obur) | 2/5 |
| **Overall HORECA depth** | **Shallow — restaurant POS only** | **2/5** |

**Conclusion**: Valk Solutions is a retail company with a restaurant POS appendage (Countr). It does not compete with hotel PMS companies (Mews, Misterbook, Booking Experts) or channel managers (Cubilis). The HORECA depth does not justify inclusion in the SolStein HORECA pipeline.

---

## 7. Valuation & Business Model

### Business Model

| Dimension | Detail | Source | Confidence |
|---|---|---|---|
| Model | SaaS subscription (cloud-hosted, all-inclusive) | valksolutions.nl | Confirmed |
| Pricing model | Not publicly disclosed (per-location or per-user likely) | — | Unknown |
| Revenue types | SaaS licence + professional services (consultancy, training, onboarding) | valksolutions.nl/solutions-overview | Confirmed |
| Customer base | Retail chains — Primera, Mitra, Udea, Wildkamp, Wibra (named) | valksolutions.nl | Confirmed |
| Contract stickiness | Mission-critical (daily transactions); high switching costs | valksolutions.nl | Estimated |
| Transaction model | Platform processes client transactions (POS/OMS); revenue from SaaS fee | — | Estimated |

### Valuation Estimate

| Input | Value | Source | Confidence |
|---|---|---|---|
| Estimated ARR | €10M–€30M (rough estimate) | Industry benchmarks (100 employees, SaaS) | Estimated |
| GENII deal multiple | Not disclosed; mid-market software typically 3–6x ARR | Benchmark | Estimated |
| Implied valuation | €30M–€180M range | Benchmark model | Estimated |
| Investability for SolStein | Not acquirable (PE-owned; likely too large) | Analysis | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | **1** | PE majority (GENII/Bregal/Elvaston) since May 2023. Fatal disqualifier. | gsg-genii.com 2023-04-19 |
| Revenue scale fit | High | **2** | Estimated €10–30M ARR — likely above SolStein's €15M ceiling. 100 employees. | Industry benchmark |
| Geographic fit | High | **3** | NL-headquartered, NL/BE customers plus DACH expansion. Geography fits but company does not. | valksolutions.nl |
| Tech stack modernity | Medium | **5** | Genuinely cloud-native, browser-based ASPOS, REST API, ISO 27001, ISAE 3402, 10% R&D. Excellent. | valksolutions.nl |
| Customer lock-in | Medium | **4** | Mission-critical retail POS/OMS; daily transaction dependency; high switching costs. | valksolutions.nl; gsg-genii.com |
| Vertical depth | Medium | **1** | Retail omnichannel, not HORECA. Hotel PMS: none. Channel manager: none. Only Countr POS (F&B adjacent). | valksolutions.nl solutions overview |
| Integration potential | Low | **4** | REST API with 100+ services; open integration architecture; supports third-party connectors. | valksolutions.nl/solutions-overview |
| Growth trajectory | Low | **4** | Strong growth: acquisitions through 2025, DACH/France expansion, GENII backing. Not distressed. | valksolutions.nl; gsg-genii.com |

### Composite Score

**Weighted composite**: ~2.1 / 5.0

> **Calculation**: (1×High + 2×High + 3×High + 5×Med + 4×Med + 1×Med + 4×Low + 4×Low)
> Weights: High=3, Medium=2, Low=1. Total weight=15.
> Score = (1×3 + 2×3 + 3×3 + 5×2 + 4×2 + 1×2 + 4×1 + 4×1) / 15 = (3+6+9+10+8+2+4+4)/15 = 46/15 ≈ **3.1 / 5.0**
>
> However, PE ownership (score 1) and wrong vertical (score 1) are both fatal disqualifiers that override the composite score arithmetic. The two Fatal blockers render the composite meaningless.

**Confidence Band**: Medium-High (most data points confirmed; own revenue unknown but doesn't change verdict).

### Overall Assessment

**Rating: NOT RECOMMENDED — Remove from Pipeline**

Valk Solutions is a well-run, technically modern, growing Dutch software company. But it fails the SolStein thesis on three fatal dimensions simultaneously:

1. **Ownership**: PE-majority owned since May 2023. SolStein explicitly targets founder-owned, no-PE companies.
2. **Vertical**: Retail omnichannel, not HORECA. No hotel PMS. No channel manager. No hotel distribution.
3. **Identity mismatch**: The original brief assumed a relationship to Van der Valk Hotels — this is incorrect. They are completely unrelated.

The Countr POS subsidiary has a restaurant-adjacency that could theoretically be of interest, but Countr is not separately acquirable — it is a brand inside GENII's portfolio.

### Recommended Next Step

| Action | Priority | Detail |
|---|---|---|
| Remove from HORECA pipeline | Immediate | Valk Solutions does not belong in the SolStein target list |
| Add disambiguation note to README | Immediate | Prevent future confusion between "Valk Solutions" and "Van der Valk Hotels IT arm" |
| Research Valk Digital separately | Optional | Van der Valk Hotels' internal IT arm — but it is captive, not acquirable |
| No outreach | — | No basis for M&A approach |

---

## Appendix: Valk Solutions vs. Van der Valk Hotels — Disambiguation

| Dimension | Valk Solutions B.V. | Van der Valk Hotels / Valk Digital |
|---|---|---|
| Founded | 1989 by Robert Valk | Hotel group: ca. 1929; "Valk Digital" IT arm: recent |
| Founder family | Valk (Robert Valk — unrelated) | Van der Valk family (different family) |
| Business | Retail omnichannel software | Hotel operations / internal IT |
| Product | ASPOS, Countr, PFA | Apaleo PMS + Shiji PMS + custom apps via Valk Digital |
| HQ | Montfoort, NL | Utrecht / The Hague area |
| Ownership | GENII/Bregal (PE-majority) | Van der Valk family (private hotel group) |
| Acquirability | Not acquirable (PE-owned) | Not acquirable (captive unit) |
| Relation to each other | None | None |
| HORECA depth | Shallow (Countr POS only) | Captive hotel IT (not a product company) |

---

*Sources: valksolutions.nl (about-us, solutions-overview, business-types), gsg-genii.com (press release 2023-04-19), Kompass (xk.kompass.com), PitchBook (pitchbook.com), LinkedIn (John Staunton, Countr International), apaleo.com (Valk Exclusief customer story), shijigroup.com (Van der Valk Hotels PMS), trengo.com (Valk Digital case study), omniboost.io (Valk Exclusief PMS migration).*
