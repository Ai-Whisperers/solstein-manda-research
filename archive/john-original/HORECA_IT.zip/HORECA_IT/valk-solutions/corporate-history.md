# Valk Solutions — Corporate History

**Research Date**: 2026-04-30
**Researcher**: SolStein M&A Research Agent
**Target Profile**: Dutch retail omnichannel software company (ASPOS platform)
**Key Finding**: Valk Solutions is NOT a hotel PMS company and is NOT related to Van der Valk Hotels. It is a PE-backed retail software company — not an acquisition target for SolStein.

---

## Executive Alert: Identity Clarification

> **Critical disambiguation**: The research brief assumed Valk Solutions was a hotel PMS company and possibly a subsidiary of Van der Valk Hotels. Both assumptions are incorrect.
>
> - **Valk Solutions** (valksolutions.nl) = Robert Valk's retail omnichannel software company. Founded 1989. Majority PE-acquired by GSG GENII in April 2023. Primary product: ASPOS. Headquarters: Montfoort, Netherlands. NO relation to Van der Valk Hotels.
> - **Van der Valk Hotels** = Dutch hotel group (family Van der Valk). Internal IT arm: **Valk Digital** (not for sale). External PMS: Apaleo (Valk Exclusief) + Shiji (broader group).
>
> These are completely separate entities with different founders, ownership structures, and business models. The name similarity ("Valk") is coincidental — both derive from common Dutch surnames.

---

## 1. Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Valk Solutions B.V. | Kompass / KvK | Confirmed |
| KvK number | 30209227 | Kompass company profile | Estimated |
| VAT number | NL815830117B01 | Kompass company profile | Estimated |
| Legal form | Besloten Vennootschap (BV) | Kompass | Confirmed |
| BV incorporation year | 2005 | Kompass (vs 1989 as sole proprietorship) | Estimated |
| Founding year (as business) | 1989 | valksolutions.nl/about-us | Confirmed |
| Primary HQ address | Vlasakker 5, 3417 XT Montfoort, Netherlands | valksolutions.nl / Kompass | Confirmed |
| Secondary address | Ketelhavenstraat 37, 5045 NG Tilburg | valksolutions.nl | Estimated |
| City | Montfoort (primary) | valksolutions.nl | Confirmed |
| Country | Netherlands | valksolutions.nl | Confirmed |
| Industry (SBI) | IT consulting and software services | KvK classification | Estimated |
| Core product | ASPOS — omnichannel cloud retail platform | valksolutions.nl | Confirmed |
| Website | valksolutions.nl | Direct | Confirmed |
| Parent company (2026) | GSG GENII Software Group | gsg-genii.com press release 2023-04-19 | Confirmed |
| Employees (2026) | ~94–100 | PitchBook profile / GENII announcement | Estimated |

---

## 2. Founders & Leadership

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder | Robert Valk | valksolutions.nl/about-us | Confirmed |
| Founding mode | Sole proprietorship in student chamber | valksolutions.nl/about-us | Confirmed |
| Current CEO | Karin Valk | gsg-genii.com press release | Confirmed |
| CEO relationship to founder | Karin Valk (family — likely daughter of Robert Valk) | valksolutions.nl (family business reference) | Estimated |
| Founder post-acquisition role | Retains significant shareholding; active in product strategy and key accounts | gsg-genii.com press release 2023-04-19 | Confirmed |
| CEO post-acquisition role | Full-time CEO, continuing post-GENII acquisition | gsg-genii.com press release 2023-04-19 | Confirmed |
| Group CTO | John Staunton (also CTO at Countr International; AI Board Member at GENII) | LinkedIn (John Staunton profile) | Estimated |

---

## 3. Ownership Structure

### Pre-2023 (Founder-Owned)

Valk Solutions was a family-owned business from 1989 through to April 2023. Robert Valk founded the company and Karin Valk took on the CEO role. Robert retained an active role in product and customer strategy. No external PE or VC investment events have been publicly documented prior to 2023.

### Post-2023 (PE-Backed via GENII)

In April 2023, GSG GENII Software Group acquired a **majority share** in Valk Solutions. GENII is backed by:
- **Bregal Unternehmerkapital** (German PE firm, mid-market buy-and-build)
- **Elvaston** (PE fund)

Robert Valk retained a significant (minority) shareholding. Karin Valk continued as CEO. The transaction completed in May 2023.

| Ownership Layer | Entity | Notes | Confidence |
|---|---|---|---|
| Majority shareholder (2023–present) | GSG GENII Software Group | German-headquartered software buy-and-build PE | Confirmed |
| Minority/founding shareholder | Robert Valk | Retained significant stake | Confirmed |
| PE backers behind GENII | Bregal Unternehmerkapital + Elvaston | Funds advising GENII | Confirmed |
| GENII Group CEO | Matthias Siekmann | Munich-based | Confirmed |
| Valk Solutions CEO | Karin Valk | Continuing full-time post-acquisition | Confirmed |
| Relation to Van der Valk Hotels | None | Completely separate families/entities | Confirmed |

---

## 4. Is Valk Solutions Related to Van der Valk Hotels?

**Answer: No. They are completely separate entities.**

| Question | Answer | Source | Confidence |
|---|---|---|---|
| Is Valk Solutions a subsidiary of Van der Valk Hotels? | No | Corporate records; no cross-ownership documented | Confirmed |
| Is Valk Solutions a software arm of Van der Valk Hotels? | No | Van der Valk Hotels IT arm is "Valk Digital" (internal) | Confirmed |
| Do they share founders or owners? | No | Different families (Robert Valk vs. Van der Valk family) | Confirmed |
| Does Valk Solutions provide PMS to Van der Valk Hotels? | No | Van der Valk Hotels uses Apaleo + Shiji PMS | Confirmed |
| Is "Valk" a coincidence? | Yes — both derive from common Dutch surnames | Name analysis | Estimated |

**Van der Valk Hotels** (the hotel group) has its own internal IT arm called **Valk Digital**, which builds the tech stack for Valk Exclusief (43 hotels, Netherlands + Germany) on top of the Apaleo open PMS platform. Valk Digital is a captive unit — not a standalone acquirable software company.

---

## 5. M&A History & Acquisition Timeline

Valk Solutions has been an active acquirer, consolidating adjacent retail and hospitality software companies under its ASPOS platform umbrella.

| Year | Event | Details | Source | Confidence |
|---|---|---|---|---|
| 1989 | Founded | Robert Valk launches as sole proprietorship | valksolutions.nl/about-us | Confirmed |
| 1990 | First NL & BE customers | Tailor-made software for early clients | valksolutions.nl/about-us | Confirmed |
| 1995 | VideoTrend | First generic product (DOS-based) for rental stores | valksolutions.nl/about-us | Confirmed |
| 2001 | ProPOSS | Windows-based POS for SME retailers | valksolutions.nl/about-us | Confirmed |
| 2005 | BV incorporation | Sole prop becomes Besloten Vennootschap | Kompass | Estimated |
| 2009 | 25+ employees | Growth milestone | valksolutions.nl/about-us | Confirmed |
| 2011 | ASPOS launched | Cloud-based retail platform for large organisations | valksolutions.nl/about-us | Confirmed |
| 2016 | Germany customers | First DACH expansion | valksolutions.nl/about-us | Confirmed |
| 2017 | Acquisition: Tabaronde | Target details not publicly specified | valksolutions.nl/about-us | Confirmed |
| 2018 | Acquisition: PFA | Fashion ERP and WMS software | valksolutions.nl/about-us | Confirmed |
| 2019 | Acquisition: First Focus | Technology/services (details limited) | valksolutions.nl/about-us | Confirmed |
| 2020 | €3B+ transactions milestone | Platform processes €3B+ annual client sales | valksolutions.nl/about-us | Confirmed |
| 2021 | Acquisition: Countr | Cloud POS for hospitality, leisure, transport (Amsterdam) | valksolutions.nl/about-us | Confirmed |
| 2021 | Acquisition: Obur | Hospitality/catering software | valksolutions.nl/about-us | Confirmed |
| 2022 | 100+ employees | Headcount milestone | valksolutions.nl/about-us | Confirmed |
| 2023-04-19 | PE acquisition by GENII | GSG GENII acquires majority share; Bregal + Elvaston backing | gsg-genii.com 2023-04-19 | Confirmed |
| 2023-05 | Transaction completed | GENII acquisition closes | gsg-genii.com | Confirmed |
| 2024 | Acquisition: Bovertis | Details not publicly available | PitchBook profile | Estimated |
| 2025 | Acquisition: Cocosoft | valksolutions.nl news headline (no public detail) | valksolutions.nl | Estimated |

---

## 6. Corporate Structure Diagram

```mermaid
graph TD
    BU[Bregal Unternehmerkapital] --> GENII
    EL[Elvaston Capital] --> GENII
    GENII[GSG GENII Software Group\nMunich, Germany] -->|Majority shareholder since May 2023| VS
    RV[Robert Valk\nFounder] -->|Significant minority stake| VS

    VS[Valk Solutions B.V.\nMontfoort, Netherlands\nKvK 30209227]

    VS -->|Brand / Division| ASPOS[ASPOS Platform\nOmnichannel Retail Cloud]
    VS -->|Acquired 2018| PFA[PFA\nFashion ERP & WMS]
    VS -->|Acquired 2021| COUNTR[Countr International\nHospitality / Leisure POS]
    VS -->|Acquired 2021| OBUR[Obur\nHospitality Catering]
    VS -->|Acquired 2017| TAB[Tabaronde]
    VS -->|Acquired 2019| FF[First Focus]
    VS -->|Acquired 2024| BOV[Bovertis]
    VS -->|Acquired 2025| COCO[Cocosoft]

    VDV[Van der Valk Hotels Group\nDutch hotel group — SEPARATE entity]
    VDV -->|Internal IT arm| VD[Valk Digital\nCaptive IT — NOT acquirable]
    VDV -->|Uses external PMS| AP[Apaleo PMS\nValk Exclusief: 43 hotels]
    VDV -->|Uses external PMS| SH[Shiji Enterprise PMS\n74 hotels globally]
```

---

## 7. Corporate Timeline

```mermaid
timeline
    title Valk Solutions — Corporate History
    section Founder Era (Bootstrapped)
        1989 : Founded — Robert Valk sole proprietorship
        1990 : First NL & BE clients — bespoke software
        1995 : VideoTrend — DOS-based rental store product
        2001 : ProPOSS — Windows POS for retail SMEs
        2005 : Incorporated as BV (Besloten Vennootschap)
        2009 : 25+ employees milestone
    section Growth & Acquisition Phase
        2011 : ASPOS cloud platform launched — flagship retail product
        2016 : First German (DACH) customers
        2017 : Acquires Tabaronde
        2018 : Acquires PFA (fashion ERP/WMS)
        2019 : Acquires First Focus
        2020 : Platform crosses €3B annual transaction value
        2021 : Acquires Countr (hospitality POS) + Obur (catering)
        2022 : 100+ employees milestone
    section PE-Backed Phase (GENII)
        2023 : GENII acquires majority share — Bregal Unternehmerkapital + Elvaston back
        2024 : Acquires Bovertis
        2025 : Acquires Cocosoft — France expansion (Wibra goes live)
```

---

## 8. M&A Feasibility Assessment

### Critical Blockers

| Blocker | Severity | Detail |
|---|---|---|
| PE-backed ownership | **FATAL** | GENII/Bregal/Elvaston is majority owner since May 2023. Fails SolStein's "no PE overhang" criterion by definition. |
| Wrong vertical | **Fatal** | Valk Solutions is a retail omnichannel software company (supermarkets, fashion, DIY), not a HORECA/hotel PMS company. |
| Scale likely too large | **Major** | 100+ employees, €4B+ in client transaction volume, multi-million ARR — likely above SolStein's €1–15M ARR sweet spot. |
| Active acquiree building | **Major** | GENII is in active buy-and-build mode; Valk Solutions acquired Bovertis (2024) and Cocosoft (2025). GENII will not sell. |
| No succession gap | **Major** | Karin Valk (CEO) is active; Robert Valk is active. No succession signal. |

### Feasibility Summary

**M&A Feasibility: Not Feasible — Remove from Pipeline**

Valk Solutions does not fit any element of the SolStein M&A thesis:
1. Not founder-owned (PE-majority since 2023)
2. Not HORECA vertical (retail omnichannel)
3. Not in SolStein's revenue range (likely above €15M ARR)
4. Not available (GENII is a buy-and-build holding with no exit signal)
5. Not a hotel/restaurant PMS (ASPOS is retail; Countr is hospitality POS — adjacent but not core HORECA vertical)

The only partial intersection with HORECA is the **Countr** subsidiary (hospitality/leisure POS, acquired 2021), but Countr is now a brand under GENII/Valk Solutions — not separately acquirable.

---

## 9. Data Point Index

| # | Data Point | Value | Source | Confidence |
|---|---|---|---|---|
| 1 | Legal name | Valk Solutions B.V. | Kompass | Confirmed |
| 2 | KvK number | 30209227 | Kompass | Estimated |
| 3 | Founding year | 1989 (sole prop); 2005 (BV) | valksolutions.nl; Kompass | Confirmed |
| 4 | Founder | Robert Valk | valksolutions.nl | Confirmed |
| 5 | CEO | Karin Valk | gsg-genii.com | Confirmed |
| 6 | HQ | Montfoort, Netherlands | valksolutions.nl | Confirmed |
| 7 | Core product | ASPOS (omnichannel retail cloud) | valksolutions.nl | Confirmed |
| 8 | Employees | ~94–100 | PitchBook / GENII press | Estimated |
| 9 | Majority owner | GSG GENII Software Group | gsg-genii.com 2023-04-19 | Confirmed |
| 10 | PE backers | Bregal Unternehmerkapital + Elvaston | gsg-genii.com | Confirmed |
| 11 | Acquisition date | May 2023 (signed April 2023) | gsg-genii.com | Confirmed |
| 12 | Robert Valk shareholding post-deal | Significant minority | gsg-genii.com | Confirmed |
| 13 | HORECA vertical | Retail, with hospitality adjacency via Countr POS | valksolutions.nl | Confirmed |
| 14 | Hotel PMS product | None | valksolutions.nl solutions page | Confirmed |
| 15 | Van der Valk Hotels relation | None — separate families and entities | Corporate research | Confirmed |
| 16 | Annual R&D investment | Min. 10% of revenues | valksolutions.nl | Confirmed |
| 17 | ISO 27001 certified | Yes | valksolutions.nl | Confirmed |
| 18 | ISAE 3402 declaration | Type 1 and 2 | valksolutions.nl | Confirmed |
| 19 | Platform transaction volume | €4B+ annual client sales processed | gsg-genii.com | Confirmed |
| 20 | Own revenue (ARR) | Not publicly disclosed | — | Unknown |
| 21 | M&A feasibility for SolStein | Not feasible | Analysis | Confirmed |

---

*Sources: valksolutions.nl/about-us, gsg-genii.com press release 2023-04-19, Kompass company profile (xk.kompass.com), PitchBook profile, LinkedIn (John Staunton), apaleo.com (Valk Exclusief PMS), shijigroup.com (Van der Valk Hotels PMS).*
