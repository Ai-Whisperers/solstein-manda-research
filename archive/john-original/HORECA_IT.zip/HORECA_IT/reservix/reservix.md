# Reservix

**Category**: Ticketing/Events
**Country**: DE
**City**: Freiburg
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Reservix @HORECA_IT/reservix/
@research-horeca-company Reservix @HORECA_IT/reservix/
```
