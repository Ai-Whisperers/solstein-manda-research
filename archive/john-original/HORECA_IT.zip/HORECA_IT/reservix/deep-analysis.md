# Reservix GmbH — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: DE event ticketing reference; NOT a primary SolStein acquisition target

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Reservix GmbH | Northdata.com | Confirmed |
| HQ | Freiburg im Breisgau, Germany | reservix.net | Confirmed |
| Founded | 2003 | reservix.net; Tracxn | Confirmed |
| CEO | Helge Hollander | Crunchbase | Confirmed |
| Founders | Johannes Güntert, Johannes Tolle | reservix.net | Confirmed |
| Ownership | Privately held; TiXOO AG and Reservix France Sàrl as shareholders | Northdata.com | Confirmed |
| Employees | ~480 | reservix.net | Confirmed |
| Locations | 9–10 offices in Germany and Austria | reservix.net | Confirmed |
| Revenue | Not publicly disclosed; estimated €20–40M (480 employees in ticketing sector) | Estimated | Estimated |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary vertical | Event ticketing (concerts, theatre, sports, festivals) | reservix.net | Confirmed |
| HORECA relevance | Peripheral — provides ticketing infrastructure that some hospitality venues (hotels, event spaces) use | reservix.net | Estimated |
| Restaurant reservation features | Not the core product; focuses on event ticketing, not table reservations | reservix.net | Confirmed |
| DACH presence | Germany (primary) + Austria; France (Reservix France Sàrl) | Northdata.com; reservix.net | Confirmed |
| Customer segments | Event organizers (theatres, concert halls, sports clubs), not HORECA operators | reservix.net | Confirmed |
| NL/BE presence | None identified | No source | Unknown |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Core product | Full-service ticketing platform (B2C portal + B2B organizer tools) | reservix.net | Confirmed |
| Technology | Print@home ticketing; online ticket booking; seating plan integration | reservix.net | Confirmed |
| Platform type | Web-based SaaS | reservix.net | Estimated |
| Mobile offering | Unknown | No source | Unknown |
| TSE compliance | Relevant for any POS components; not confirmed | Industry requirement | Unknown |
| Integration ecosystem | Unknown; typical event ticketing integrations (payment processors, scanning hardware) | Industry standard | Estimated |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership clarity | Moderate — TiXOO AG and Reservix France Sàrl as shareholders complicate clean exit | Northdata.com | Confirmed |
| PE involvement | None identified | Tracxn; Crunchbase | Confirmed |
| Founder status | Founders (Güntert, Tolle) not confirmed in current management; CEO is Helge Hollander | Crunchbase | Estimated |
| Acquisition history | Active acquirer (Tic Tec 2009, Tixoo 2013, ADticket 2015) — growth-oriented | reservix.net | Confirmed |
| Succession signals | Unknown | No source | Unknown |

---

## 5. Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not publicly disclosed | No public filing | Unknown |
| Estimated revenue | €20–40M (estimated based on ~480 employees in SaaS ticketing) | Estimated | Estimated |
| Growth trajectory | 20+ years of growth; multiple acquisitions indicate ambition | reservix.net | Estimated |
| Profitability | Unknown; bootstrapped growth suggests profitability | No source | Unknown |
| Funding | None — fully bootstrapped | Tracxn; Crunchbase | Confirmed |

---

## 6. HORECA Vertical Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| HORECA specialization | Limited — event ticketing is adjacent, not core HORECA | reservix.net | Confirmed |
| German fiscal compliance | Applicable but not a HORECA-specific compliance story | Industry | Unknown |
| Restaurant booking | Not a primary product; focuses on event tickets, not table reservations | reservix.net | Confirmed |
| Hotel/F&B integration | Potential for hotel event management, but not confirmed | Not confirmed | Unknown |

---

## 7. Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | Transaction fees on ticket sales + SaaS platform fee for organizers | reservix.net | Estimated |
| Estimated ARR | €20–40M (estimated) | Calculated | Estimated |
| Estimated valuation | €40–100M (estimated; 2–3x revenue for bootstrapped DE ticketing platform) | Estimated | Estimated |
| Acquisition attractiveness for SolStein | Low — wrong vertical and wrong geography | Assessment | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 2 | Privately held, no PE — positive; but complex shareholder structure (TiXOO AG, Reservix France) makes clean exit harder | Northdata.com |
| Revenue scale fit | High | 3 | Estimated €20–40M — slightly above SolStein's €1–15M range, but unclear financials | Estimated |
| Geographic fit | High | 1 | Germany + Austria + France; zero NL/BE presence | reservix.net |
| Tech stack modernity | Medium | 3 | Web-based ticketing platform; 20+ year history suggests some legacy but also product maturity | reservix.net |
| Customer lock-in | Medium | 4 | Event organizers deeply integrated; switching ticketing platforms is complex for venues | Industry assessment |
| Vertical depth | Medium | 1 | Event ticketing — not HORECA POS/PMS; peripheral HORECA relevance only | reservix.net |
| Integration potential | Low | 2 | Ticketing platform unlikely to integrate cleanly with HORECA tech stack | Assessment |
| Growth trajectory | Low | 3 | 20+ years of growth; stable but not a high-growth SaaS | reservix.net |

**Composite Score**: ~2.0 / 5.0

**Confidence Band**: Low — revenue and ownership details largely unknown

**Overall M&A Assessment**: Reservix is **not a SolStein acquisition target**. It operates in event ticketing (not HORECA POS/PMS), is Germany-only, and has a complex multi-entity ownership structure. Its 20+ year bootstrapped history and M&A track record make it an interesting case study for DE software company valuations, but it falls entirely outside SolStein's NL/BE HORECA thesis.

**Recommended Next Step**: No direct follow-up recommended. Use as a reference point for understanding the German ticketing/reservation adjacent market.

---

*Sources: reservix.net, Northdata.com (HRB 700054), Tracxn, Crunchbase*
