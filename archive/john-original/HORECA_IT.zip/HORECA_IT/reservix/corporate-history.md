# Reservix GmbH — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Privately held — active independent operation

---

## Executive Summary

Reservix GmbH is a German full-service event ticketing company headquartered in Freiburg im Breisgau, founded in 2003 by software developer Johannes Güntert and conductor Johannes Tolle. The company originated from the ticketing needs of the John Sheppard Ensemble choral group, where the founders developed a "print@home" ticketing solution. Over 20+ years, Reservix grew through organic growth and acquisitions (Tic Tec GmbH in 2009, Tixoo in 2013, merged with ADticket in 2015) to become one of Germany's leading regional ticketing platforms with approximately 480 employees across 9–10 locations in Germany and Austria. The company is privately held with no external VC funding identified. CEO is Helge Hollander.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | Reservix GmbH | Northdata.com; Crunchbase | Confirmed |
| Handelsregister | Amtsgericht Freiburg, HRB 700054 | Northdata.com | Confirmed |
| Registered address | Freiburg im Breisgau, Germany | Northdata.com; reservix.net | Confirmed |
| Legal form | GmbH (Gesellschaft mit beschränkter Haftung) | Northdata.com | Confirmed |
| Country | Germany | Multiple sources | Confirmed |
| Primary activity | Event ticketing (full-service: B2C ticket portal + B2B ticketing platform for organizers) | reservix.net | Confirmed |
| Website | reservix.net / reservix.de | reservix.net | Confirmed |
| CEO / Managing Director | Helge Hollander | Crunchbase | Confirmed |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | 2003 | Tracxn; reservix.net/en/das-sind-wir | Confirmed |
| Founders | Johannes Güntert (software developer), Johannes Tolle (conductor) | reservix.net/en/das-sind-wir | Confirmed |
| Origin story | Founders developed print@home ticketing for the John Sheppard Ensemble (choral group); seating plan booking solution for choir concerts | reservix.net/en/das-sind-wir | Confirmed |
| Original focus | Event ticketing for performing arts (choir, theatre, concerts) | reservix.net | Confirmed |
| Original location | Freiburg im Breisgau | Multiple sources | Confirmed |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership type | Privately held; no VC funding identified | Tracxn (unfunded); Crunchbase | Confirmed |
| PE involvement | None identified | Tracxn; Crunchbase | Confirmed |
| Shareholders (public record) | Reservix France Sàrl and TiXOO AG listed as shareholders | Northdata.com | Confirmed |
| Founder ownership | Unknown (not publicly disclosed) | No public source | Unknown |
| External funding rounds | None | Tracxn; Crunchbase | Confirmed |

---

## M&A History

| Date | Event Type | Target / Partner | Detail | Source | Confidence |
|---|---|---|---|---|---|
| 2009 | Acquisition | Tic Tec GmbH | Acquired regional competitor Tic Tec GmbH | reservix.net/en/das-sind-wir | Confirmed |
| 2013 | Acquisition | Tixoo (Berlin) | Acquired Berlin-based Tixoo; TiXOO AG now listed as shareholder | reservix.net/en/das-sind-wir | Confirmed |
| 2015 | Merger | ADticket (Frankfurt) | Merged with Frankfurt-based ADticket; created larger national platform | reservix.net/en/das-sind-wir | Confirmed |
| Post-merger | Entity established | Reservix France Sàrl | Established French subsidiary; suggests international expansion | Northdata.com | Estimated |

---

## Corporate Structure

```mermaid
graph TD
    A["Reservix GmbH<br/>(Amtsgericht Freiburg, HRB 700054)<br/>Freiburg im Breisgau, DE"]
    B["TiXOO AG<br/>(Shareholder — Berlin acquisition 2013)"]
    C["Reservix France Sàrl<br/>(French subsidiary)"]
    D["ADticket<br/>(Frankfurt — merged 2015)"]

    B -->|"Shareholder"| A
    C -->|"Shareholder/Subsidiary"| A
    D -->|"Merged 2015"| A

    style A fill:#f9f,stroke:#333
    style C fill:#bbf,stroke:#333
```

---

## Corporate Timeline

```mermaid
timeline
    title Reservix GmbH — Corporate Timeline
    2003 : Founded by Johannes Güntert and Johannes Tolle
         : Origin: ticketing for John Sheppard Ensemble choir
         : Print@home + seating plan booking solution
    2009 : Acquired Tic Tec GmbH
         : First M&A; regional competitor consolidation
    2013 : Acquired Tixoo (Berlin)
         : Berlin presence; TiXOO AG becomes shareholder
    2015 : Merged with ADticket (Frankfurt)
         : Significant scale-up; national footprint
    2016+ : Growth to 480 employees
          : 9-10 locations in Germany and Austria
          : Established Reservix France Sàrl
    2026 : ~480 employees, 9 locations DE + AT
          : CEO Helge Hollander
          : No external funding raised
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Potentially available — privately held, no PE, no obvious acquirer announced |
| **Ownership structure** | Complex: TiXOO AG and Reservix France Sàrl as shareholders; not pure founder-owned |
| **SolStein thesis fit** | Poor fit — event ticketing is not HORECA POS/PMS; geography is DE not NL/BE |
| **Scale** | With ~480 employees and 20+ year history, likely >€20M revenue; outside SolStein's primary target range |
| **Role for SolStein** | Use as reference for German event/reservation technology valuations; not a direct target |

**Verdict**: Reservix is a **reference company** for the DE ticketing/reservation market. Its 20+ year history, bootstrapped growth, and multi-acquisition M&A strategy make it an interesting case study. However, it falls entirely outside SolStein's NL/BE HORECA thesis — both geographically and by vertical (event ticketing vs. HORECA POS/PMS).

---

## Sources

| Source | URL | Type |
|---|---|---|
| Reservix — Company history page | https://www.reservix.net/en/das-sind-wir/ | Primary (company site) |
| Northdata — Reservix GmbH HRB 700054 | https://www.northdata.com/Reservix%20GmbH,%20Freiburg%20i%C2%B7%20Breisgau/Amtsgericht%20Freiburg%20HRB%20700054 | Secondary (company DB) |
| Tracxn — Reservix profile | https://tracxn.com/d/companies/reservix | Secondary (company DB) |
| Crunchbase — Reservix profile | https://www.crunchbase.com/organization/reservix | Secondary (company DB) |
| Reservix website | https://www.reservix.net/en/ | Primary (company site) |
