# Gastroglück — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — very limited public data; possible naming confusion

---

## Executive Summary

"Gastroglück" (German: "Gastronomy Luck/Fortune") is listed in the SolStein research brief as a Hamburg-based digital guest management software company for gastronomy. Research could not identify a software company named "Gastroglück" in Hamburg. The search results for digital guest management software in Germany returned companies such as "gastromatic" (personnel management, Hamburg area) and "DigitalGuest" (Denmark). Notably, one search result explicitly described a page about "gastromatic" as "Gastroglück" — this may indicate a confusion between the brands, or gastromatic might operate a product line or subdomain called Gastroglück. Gastromatic is a legitimate Hamburg-area personnel management software for the gastronomy sector.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | Gastroglück | SolStein research brief | Estimated |
| Possible alternative identity | gastromatic (personnel management for gastronomy, Hamburg area) | Web search result | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Hamburg, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany | SolStein research brief | Estimated |
| Primary activity | Digital guest management for gastronomy (reported) | SolStein research brief | Estimated |

---

## Possible Match: gastromatic

During research, a web search result page for gastromatic.com described the company as "Gastroglück" — suggesting either:
1. gastromatic uses "Gastroglück" as a brand/product name
2. The research brief confused the two names

**gastromatic overview** (if this is the intended company):

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Brand | gastromatic | gastromatic.com | Estimated |
| Focus | Personnel management for gastronomy (shift planning, time tracking, payroll) | gastromatic.com | Estimated |
| Location | Hamburg area (Germany) | gastromatic.com | Estimated |
| Description | "Deine Software für Personalmanagement" (Your software for personnel management) | gastromatic.com | Estimated |

**Note**: If the SolStein brief means gastromatic, it is a legitimate Hamburg-based SaaS company for gastronomy personnel management — NOT "digital guest management" as described.

---

## Research Methodology & Limitations

Searches conducted:
- "Gastroglueck Hamburg digital guest management Germany"
- "Gastroglueck GmbH gastronomy software Hamburg"
- Hamburg gastronomy software databases

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — company identity not confirmed |
| **SolStein thesis fit** | Very poor — Germany-only; possible confusion with gastromatic (personnel management, not guest management) |
| **Research confidence** | Very low |

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| gastromatic.com (possible match) | https://www.gastromatic.com/de/ | Secondary (possible match) |
| Web search results (inconclusive) | Multiple searches; gastromatic found as possible match | Negative/partial |
