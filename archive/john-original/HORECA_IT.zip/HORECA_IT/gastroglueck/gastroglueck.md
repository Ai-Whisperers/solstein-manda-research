# Gastrogluck

**Category**: Restaurant Software
**Country**: DE
**City**: Hamburg
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Gastrogluck @HORECA_IT/gastroglueck/
@research-horeca-company Gastrogluck @HORECA_IT/gastroglueck/
```
