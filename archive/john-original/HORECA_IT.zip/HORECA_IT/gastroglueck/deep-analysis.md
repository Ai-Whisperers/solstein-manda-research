# Gastroglück — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Unconfirmed entity; possible gastromatic reference; insufficient data

---

## Research Limitations

"Gastroglück" as a Hamburg digital guest management company could not be confirmed. A possible match is gastromatic (Hamburg-area personnel management for gastronomy), but this is unconfirmed. The two products (digital guest management vs. personnel management) are distinct — clarification from the research brief author is needed.

---

## Possible Alternative: gastromatic Profile (if applicable)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Company | gastromatic | gastromatic.com | Estimated |
| Focus | Personnel management SaaS for gastronomy | gastromatic.com | Estimated |
| Location | Hamburg, Germany | gastromatic.com | Estimated |
| Products | Shift planning, time tracking, payroll for restaurants | gastromatic.com | Estimated |
| Ownership | Unknown — appears privately held | No source | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown | No source |
| Revenue scale fit | High | — | Unknown | No source |
| Geographic fit | High | 1 | Germany (Hamburg) — no NL/BE | SolStein brief |
| Tech stack modernity | Medium | — | Unknown | No source |
| Customer lock-in | Medium | — | Unknown | No source |
| Vertical depth | Medium | 3 | Gastronomy personnel management (if gastromatic) — solid vertical depth | gastromatic.com |
| Integration potential | Low | — | Unknown | No source |
| Growth trajectory | Low | — | Unknown | No source |

**Composite Score**: Insufficient data

**Confidence Band**: Very Low

**Overall M&A Assessment**: Entity identity not confirmed. If gastromatic is the intended company, it would be a Germany-only personnel management SaaS — not a SolStein target (wrong geography, different vertical from HORECA POS/PMS). No action recommended until identity is confirmed.

---

*Sources: SolStein research brief; gastromatic.com (possible match)*
