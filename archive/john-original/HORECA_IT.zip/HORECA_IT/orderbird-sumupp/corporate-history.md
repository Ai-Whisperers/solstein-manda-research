# Orderbird (ex-Garmondo) / SumUp Context — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Clarification required — SumUp did NOT acquire orderbird; research brief contains error

---

## Executive Summary

The SolStein research brief lists this entry as "Orderbird (ex-Garmondo) — Tablet POS for restaurants (acquired by SumUp)" with folder `orderbird-sumupp`. This entry requires clarification:

**The acquisition facts**: orderbird AG (the actual company) was **NOT acquired by SumUp**. It was acquired by **Nexi Group** (via Nets A/S) in May 2022 for ~€130M. SumUp is a separate UK-headquartered fintech company that has pursued its own acquisition strategy (Goodtill, Tiller, Fivestars) but did not acquire orderbird.

**SumUp context**: SumUp GmbH (German entity) is a major European payment technology and POS company that competes with orderbird in the German restaurant POS market. SumUp has been an active acquirer in the hospitality tech space.

This file documents SumUp's relevant M&A activity in the German restaurant POS/HORECA space, as this appears to be the intended context for this landscape entry.

---

## Clarification: orderbird vs. SumUp

| Aspect | Reality | SolStein Brief Claim |
|---|---|---|
| Acquirer of orderbird | Nexi Group (via Nets A/S) | "SumUp" (incorrect) |
| Acquisition date | May 2022 | Not specified |
| Deal value | ~€130M | Not specified |
| "Garmondo" entity | Not a publicly registered entity name | "Garmondo (orderbird)" |

---

## SumUp — Corporate Overview

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | SumUp Limited (UK holding); SumUp GmbH (German subsidiary) | Wikipedia; sumup.com | Confirmed |
| HQ | London, UK (legal); Berlin, DE (major office + DE operations) | Wikipedia | Confirmed |
| Founded | 2012 | Wikipedia | Confirmed |
| Founders | Jan Degenhard, Marc-Alexander Christ, Stefan Jeschonnek (originally) | Wikipedia | Confirmed |
| Ownership | PE-backed: Advent International, Bain Capital, Goldman Sachs, Temasek, others | Wikipedia | Confirmed |
| Last valuation | ~€8.5B (2022 funding round) | Wikipedia | Estimated |
| Revenue | >€500M (estimated) | Wikipedia | Estimated |
| Employees | 3,000+ | Wikipedia | Estimated |
| Countries | 35+ countries | sumup.com | Confirmed |

---

## SumUp M&A Activity (HORECA Relevant)

| Date | Company Acquired | Country | Category | Value | Source | Confidence |
|---|---|---|---|---|---|---|
| 2020 | Goodtill | UK | Restaurant POS (iPad-based) | Undisclosed | Wikipedia | Confirmed |
| 2021 | Tiller | France | Restaurant POS + management | Undisclosed | Wikipedia | Confirmed |
| 2021 | Fivestars | USA | Loyalty/CRM for restaurants | ~$317M | Wikipedia | Confirmed |
| Ongoing | Various smaller payment/POS companies | Multiple | POS / payment | Various | Wikipedia | Estimated |

---

## Corporate Timeline (SumUp in HORECA Context)

```mermaid
timeline
    title SumUp — HORECA-Related M&A Timeline
    2012 : SumUp founded (London/Berlin)
         : Mobile card reader for SMBs
    2020 : Acquired Goodtill (UK restaurant iPad POS)
    2021 : Acquired Tiller (French restaurant POS)
         : Acquired Fivestars (US loyalty/CRM, ~$317M)
    2022 : SumUp valued at ~€8.5B
         : Competes with orderbird in DE restaurant POS
    2022 : Nexi acquires orderbird (NOT SumUp)
    2026 : SumUp continues DACH POS expansion
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | NOT available — SumUp is PE-backed, large-scale, not acquirable by SolStein |
| **SolStein thesis fit** | Zero fit — wrong scale, wrong ownership structure, wrong geography (global) |
| **Role for SolStein** | Competitive context — SumUp is a major competitor to any DACH POS target SolStein might acquire |

**Verdict**: This entry is based on a factual error (orderbird was NOT acquired by SumUp). SumUp is a major European fintech/POS company that is not an acquisition target. For the correct orderbird acquisition history, see the `orderbird` folder. This folder serves as a clarification note and SumUp competitive context file.

---

## Sources

| Source | URL | Type |
|---|---|---|
| SumUp Wikipedia | https://en.wikipedia.org/wiki/SumUp | Secondary (encyclopedia) |
| SumUp website | https://sumup.com | Primary (company site) |
| TechCrunch — Nexi acquires orderbird (NOT SumUp) | https://techcrunch.com/2022/05/12/nexi-the-italian-payments-giant-buys-germanys-orderbird-for-140-150m-to-expand-its-smb-strategy/ | Secondary (news) |
