# Orderbird (ex-Garmondo)

**Category**: POS System
**Country**: DE
**City**: Berlin
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Orderbird (ex-Garmondo) @HORECA_IT/orderbird-sumupp/
@research-horeca-company Orderbird (ex-Garmondo) @HORECA_IT/orderbird-sumupp/
```
