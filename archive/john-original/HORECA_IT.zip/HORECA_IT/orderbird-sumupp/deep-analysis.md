# Orderbird (ex-Garmondo) / SumUp Context — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Competitive context only; based on research brief naming error (orderbird was acquired by Nexi, not SumUp)

---

## Research Note

This folder was created based on a research brief entry that states orderbird was "acquired by SumUp." This is factually incorrect — orderbird AG was acquired by Nexi Group in May 2022. This deep-analysis file provides SumUp's profile as competitive context for the German HORECA POS market.

For the full orderbird corporate history, see: `../orderbird/corporate-history.md`

---

## 1. Company Fundamentals (SumUp — Competitive Context)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | SumUp Limited (UK holding); SumUp GmbH (DE) | Wikipedia | Confirmed |
| HQ | London, UK (legal HQ) + Berlin, DE (major operations) | Wikipedia | Confirmed |
| Founded | 2012 | Wikipedia | Confirmed |
| CEO | Marc-Alexander Christ (co-founder) | Wikipedia | Confirmed |
| Ownership | PE-backed: Advent International, Bain Capital, Goldman Sachs AM, Temasek | Wikipedia | Confirmed |
| Valuation | ~€8.5B (2022) | Wikipedia | Estimated |
| Employees | 3,000+ | Wikipedia | Estimated |
| Revenue | >€500M estimated | Wikipedia | Estimated |
| Countries | 35+ | sumup.com | Confirmed |

---

## 2. HORECA Market Position (SumUp)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| DE POS market | Competes with orderbird (Nexi), Lightspeed Restaurant (Gastrofix) | CBInsights | Confirmed |
| HORECA products | SumUp POS + SumUp for Restaurants (via Goodtill + Tiller acquisitions) | sumup.com | Confirmed |
| Acquired restaurant POS companies | Goodtill (UK, 2020), Tiller (FR, 2021) | Wikipedia | Confirmed |
| DACH restaurant POS | Growing presence via SumUp POS; competes with orderbird | sumup.com/de | Confirmed |

---

## 8. M&A Attractiveness Scorecard

> **Note**: SumUp is a competitive reference, not an acquisition target.

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | PE-backed at €8.5B valuation — completely outside SolStein scope | Wikipedia |
| Revenue scale fit | High | 1 | >€500M revenue — 33–500x above SolStein's target range | Wikipedia |
| Geographic fit | High | 2 | DE presence strong; NL/BE present; but global company not NL/BE-focused | sumup.com |
| Tech stack modernity | Medium | 5 | Cloud-native, mobile-first, modern payment tech | sumup.com |
| Customer lock-in | Medium | 4 | Integrated payment processing + POS = sticky | Assessment |
| Vertical depth | Medium | 3 | Broad SMB (retail + restaurant); HORECA is one of many verticals | sumup.com |
| Integration potential | Low | 4 | Open API; extensive partner ecosystem | sumup.com |
| Growth trajectory | Low | 5 | Active M&A; 35+ country expansion; PE growth mandate | Wikipedia |

**Composite Score**: ~2.2 / 5.0 (blocked entirely by scale and ownership)

**Confidence Band**: Medium — public company info well-established

**Overall M&A Assessment**: SumUp is **definitively not a SolStein target**. It is a €8.5B+ PE-backed European fintech giant. Its relevance to SolStein is as a **competitive threat**: any NL/BE restaurant POS company that SolStein targets will need to articulate how it competes with (or differentiates from) SumUp POS in the local market. SumUp's acquisition of Goodtill (UK) and Tiller (FR) signals aggressive hospitality POS consolidation; similar moves in NL/BE could affect SolStein's target pipeline.

**Recommended Next Step**: Track SumUp's NL/BE hospitality POS moves as a **competitive risk signal** for SolStein's NL/BE targets. If SumUp announces entry into NL/BE, accelerate outreach to remaining independent NL/BE POS targets.

---

*Sources: Wikipedia (SumUp), sumup.com, TechCrunch, CBInsights*
