# Triometric — Deep Analysis

**Category**: Analytics / Hotel Distribution BI (B2B API Analytics)
**Country**: UK (St Albans, Hertfordshire, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; bootstrapped niche B2B; distribution analytics layer)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Triometric | triometric.net | Confirmed |
| HQ | St Albans, Hertfordshire, UK | triometric.net | Confirmed |
| Founded | ~2004–2006 (est. from "20 years experience" claim) | triometric.net/about | Estimated |
| Founders | Not publicly identified | — | Unknown |
| Ownership | Likely founder/owner-managed (no PE confirmed) | No public info | Estimated |
| Employees | Small team; not disclosed | — | Unknown |
| Revenue | Not disclosed | — | Unknown |
| External funding | Not confirmed | — | Unknown |
| Business model | SaaS/on-premise analytics platform (Trio Enterprise, Trio Express, Trio Data Engine) | triometric.net | Confirmed |
| Product | API performance monitoring + XML/JSON analytics for hotel/travel distribution | triometric.net | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary sector | B2B hotel distribution / travel technology | triometric.net | Confirmed |
| Customer type | Hotel distributors, aggregators, OTAs, bedbanks, travel enterprises | triometric.net | Confirmed |
| End beneficiary | Hotels (indirectly via distributors); not direct hotel customers | triometric.net | Confirmed |
| UK market | Primary | triometric.net | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | Likely some EU clients (travel distribution is global) | Inferred | Estimated |
| Named clients | HotelX, GameHub, GoodTravel | triometric.net | Confirmed |

Triometric is **upstream** from direct hotel operations — it serves the technology companies that connect hotels to OTAs, not the hotels themselves. This makes it tangentially relevant to HORECA IT but not a direct SolStein category target.

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Trio Enterprise | Enterprise-grade; cloud or on-premise; high-volume API analytics | triometric.net | Confirmed |
| Trio Express | Cloud SaaS; mid-sized distributors | triometric.net | Confirmed |
| Trio Data Engine | Data aggregation + BI preparation | triometric.net | Confirmed |
| API analytics | Real-time monitoring of XML/JSON API traffic | triometric.net | Confirmed |
| Anomaly detection | Published 3-part series Feb–Apr 2026 on anomaly detection for travel API | triometric.net | Confirmed |
| NDC support | Monitors IATA NDC connectivity | triometric.net | Confirmed |
| Tech stack | Enterprise analytics; likely Java/Python backend; on-premise + cloud | Inferred | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Ownership | Likely founder/owner-managed | No public info | Estimated |
| PE backing | None confirmed | — | Unknown |
| Succession signal | Unknown — no public leadership information | — | Unknown |
| Acquisition likelihood | Low visibility; niche B2B with no confirmed exit interest | — | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not disclosed | — | Unknown |
| Growth | Unknown | — | Unknown |
| Market trend | IATA NDC, AI in travel distribution driving API analytics demand | Industry context | Confirmed |
| Active content | Publishing anomaly detection series Apr 2026 — company is active | triometric.net | Confirmed |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Direct HORECA impact | Indirect — serves B2B travel distribution layer | triometric.net | Confirmed |
| Hotel inventory analytics | Core — tracks hotel room availability and booking API traffic | triometric.net | Confirmed |
| Restaurant/F&B | Not applicable | — | Confirmed |
| UK travel distribution | UK and international travel distribution companies | triometric.net | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS/licence subscription for analytics platform | triometric.net | Estimated |
| ARR estimate | Unknown; likely £500K–£3M (niche B2B specialist) | Educated guess | Estimated |
| Acquisition value | Unknown | — | Unknown |
| SolStein fit | No — wrong vertical; UK only; distribution analytics not HORECA operations | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 3 | Likely founder/owner-managed (no PE); but no succession signal visible | Estimated |
| Revenue scale fit | High | 2 | Estimated sub-£3M — may be within range but data unavailable | Estimated |
| Geographic fit | High | 1 | UK (St Albans); no NL/BE market strategy confirmed | triometric.net |
| Tech stack modernity | Medium | 3 | Enterprise analytics; some cloud; legacy on-premise components | triometric.net |
| Customer lock-in | Medium | 4 | B2B analytics deeply embedded in distribution workflows | triometric.net |
| Vertical depth | Medium | 1 | B2B travel distribution — not direct HORECA operations; wrong category | triometric.net |
| Integration potential | Low | 3 | API analytics by nature integrates broadly | triometric.net |
| Growth trajectory | Low | 3 | Active; NDC/AI trends support growth; micro company | triometric.net |

### Composite Score

**Weighted Composite: 2.1 / 5.0**

*(Geographic fit = 1; vertical depth = 1 — both significant for SolStein evaluation)*

**Confidence Band**: Very Low — almost all data unknown except product and geography.

### Overall M&A Assessment

Triometric is **not a SolStein target** — it serves the B2B travel distribution layer, not direct HORECA operations. Geography is UK (not NL/BE). Revenue and ownership are largely unknown. Its value to SolStein is as a **hotel distribution analytics reference** — demonstrating how hotel data flows through distribution APIs, which is relevant context for any SolStein investment in hotel PMS or channel management.

### Recommended Next Step

No pursuit. File as distribution analytics context. No equivalent NL/BE B2B hotel distribution analytics company identified.

---

*Sources: triometric.net, triometric.net/about-triometric/, triometric.net/analytic-solutions-for-travel/.*
