# Triometric — Corporate History

**Category**: Analytics / Hotel Distribution BI
**Country**: UK (St Albans, Hertfordshire, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; bootstrapped niche B2B analytics)

---

## Summary Assessment

Triometric is a **St Albans–based, specialist B2B analytics company** providing API performance monitoring and XML/JSON analytics for the travel distribution industry. With approximately 20 years of experience, it serves hotel distributors, aggregators, and travel enterprises with real-time search and booking data analytics. It is a small, niche provider with no confirmed external funding. Not a SolStein target (wrong vertical — B2B travel distribution, not direct HORECA operations) but a **hotel distribution analytics benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Triometric | triometric.net | Confirmed |
| HQ | St Albans, Hertfordshire, UK | triometric.net | Confirmed |
| Founded | ~2004–2006 (approx, based on "20 years experience" claim in 2026) | triometric.net/about | Estimated |
| Founders | Not publicly identified | — | Unknown |
| Employees | Small team; not disclosed | — | Unknown |
| External funding | Not confirmed | — | Unknown |
| Revenue | Not disclosed | — | Unknown |
| Companies House | Not confirmed in research | — | Unknown |
| Product | API analytics platform for hotel/travel distribution (Trio Enterprise, Trio Express, Trio Data Engine) | triometric.net | Confirmed |
| Target customers | B2B hotel distributors, aggregators, travel enterprises | triometric.net | Confirmed |
| Named clients | HotelX, GameHub, GoodTravel (examples) | triometric.net | Confirmed |
| Sectors | Hotel distribution, airline, B2B travel | triometric.net | Confirmed |
| Active content (2026) | Anomaly Detection series published Feb–Apr 2026 | triometric.net | Confirmed |

---

## Founding & History

Triometric has approximately **20 years of experience** (as stated on triometric.net as of 2026), placing founding around **2004–2006**. The company is privately held and appears to be bootstrapped or very lightly capitalised. No PE backing, funding rounds, or acquisitions are recorded in public sources.

The company occupies a specialised niche: **API analytics for the B2B hotel distribution layer**. This is the "plumbing" of hotel connectivity — monitoring the XML/JSON API traffic between hotel inventory aggregators (bedbanks), OTAs, and hotel chains. As hotel distribution increasingly moves through API connections and NDC (New Distribution Capability), Triometric's analytics becomes more critical for distributors managing complex booking flows.

Products offered:
- **Trio Enterprise**: On-premise or cloud; enterprise-grade for high-volume B2B travel distributors
- **Trio Express**: Cloud SaaS for mid-sized distributors
- **Trio Data Engine**: Data aggregation and BI preparation tool

As of April 2026, Triometric continues to publish technical content on anomaly detection in API analytics — indicating an active, ongoing operation.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Founder(s) — unknown"]
    B["Triometric Ltd<br/>(St Albans, UK)"]
    C["B2B hotel distributors<br/>aggregators / OTAs / travel tech"]

    A -->|"Founder-owned (estimated)"| B
    B --> C
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Triometric — Key Milestones
    2004-2006 : Founded in St Albans, UK; API analytics for travel distribution
    2010s : Established client base among B2B hotel distributors; IATA NDC growth drives demand
    2026 : 20 years experience; Anomaly Detection blog series published; active operations
```

---

## M&A Feasibility Assessment

### Is Triometric an Acquisition Target for SolStein?

**Answer: Not suitable — wrong vertical (B2B travel distribution analytics, not HORECA operations).**

| Factor | Assessment |
|---|---|
| **Vertical** | B2B travel distribution / hotel API analytics — not direct HORECA operations software |
| **Geography** | UK (St Albans) |
| **Scale** | Unknown — likely small (niche B2B) |
| **Ownership** | Likely founder-owned; no confirmed PE |
| **Succession** | Unknown |
| **SolStein thesis** | Does not serve restaurants/hotels directly; serves intermediaries |

### Role for SolStein

1. **Distribution analytics benchmark**: Triometric demonstrates the hotel distribution analytics layer — relevant for understanding how hotel inventory flows through OTAs and bedbanks.
2. **Niche B2B signal**: Long-lived small specialist companies in travel tech are acquisition targets for larger distribution platforms.
3. **Tangential relevance**: Triometric does not serve the HORECA operations layer (POS, PMS, workforce, reservations) that SolStein targets.

---

*Sources: triometric.net, triometric.net/about-triometric/, triometric.net/analytic-solutions-for-travel/.*
