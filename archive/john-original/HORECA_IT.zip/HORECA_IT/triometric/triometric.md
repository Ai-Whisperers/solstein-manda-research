# Triometric

**Category**: Analytics
**Country**: UK
**City**: St Albans
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Triometric @HORECA_IT/triometric/
@research-horeca-company Triometric @HORECA_IT/triometric/
```
