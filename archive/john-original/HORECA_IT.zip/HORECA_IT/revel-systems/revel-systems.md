# Revel Systems

**Category**: POS System
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Revel Systems @HORECA_IT/revel-systems/
@research-horeca-company Revel Systems @HORECA_IT/revel-systems/
```
