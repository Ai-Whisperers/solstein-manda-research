# Revel Systems — Deep Analysis

**Category**: iPad POS System (Restaurants)
**Country**: USA (HQ San Francisco); UK (London office — European sales)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (US HQ; UK presence only; Shift4 Payments subsidiary since Mar 2024)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Revel Systems | revelsystems.com | Confirmed |
| US HQ | San Francisco, California, USA | Wikipedia | Confirmed |
| UK entity | REVEL SYSTEMS (GB) LIMITED (Companies House 09882972) | Companies House | Confirmed |
| UK address | 13th Floor, One Angel Court, London, EC2R 7HJ | Companies House | Confirmed |
| Founded | 2010 | Wikipedia | Confirmed |
| Founders | Lisa Falzone + Chris Ciabarra | Wikipedia | Confirmed |
| Ownership | Shift4 Payments Inc. (NYSE: FOUR) — acquired Mar 2024 | H&L report, Companies House | Confirmed |
| Restaurant customers | 18,000+ globally | H&L report | Confirmed |
| Revenue | Not disclosed | — | Unknown |
| Business model | Cloud POS software subscription + hardware + payment processing | revelsystems.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Global presence | 18,000+ restaurants globally | H&L report | Confirmed |
| US market | Primary; dominant domestic market | Wikipedia | Confirmed |
| UK market | Sales office; limited direct market share | Companies House, restoconnection.com | Estimated |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | European office (London); limited EU-specific strategy post-Brexit | Companies House | Estimated |
| Target customer | Restaurant chains, fast-casual, enterprise | revelsystems.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | iPad-based cloud POS | revelsystems.com | Confirmed |
| Payments integration | Shift4 Payments ecosystem (post-acquisition) | Shift4, H&L report | Confirmed |
| Loyalty | Paytronix integration (UK launched Jun 2024) | support.revelsystems.com | Confirmed |
| Deployment | Cloud SaaS + iPad hardware | revelsystems.com | Confirmed |
| Tech stack | iOS-native (iPad); cloud backend | revelsystems.com | Confirmed |
| Integrations | 500+ integrations (payments, loyalty, accounting, delivery) | revelsystems.com | Confirmed |
| Multi-language | Multi-language support; GCC/Middle East strong | supy.io | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Current owner | Shift4 Payments (NYSE: FOUR) | H&L report | Confirmed |
| Acquisition date | March 2024 | H&L report | Confirmed |
| UK PSC notification | January 2025 (Shift4 notified at Companies House) | Companies House | Confirmed |
| Founder Lisa Falzone | Departed prior to acquisition | Wikipedia | Estimated |
| Successor management | Shift4 corporate leadership | Shift4 IR | Estimated |
| Divestiture likelihood | Very low | Inferred | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not disclosed | — | Unknown |
| Shift4 group revenue | $3.2B+ (2024 estimate) | Shift4 investor filings | Estimated |
| Revel's contribution | Not disclosed separately | — | Unknown |
| UK growth | Not disclosed | — | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Restaurant focus | Pure restaurant POS | revelsystems.com | Confirmed |
| UK VAT compliance | Limited UK-specific features; primarily US-designed | restoconnection.com | Estimated |
| UK payment methods | Chip & PIN via Shift4 UK | support.revelsystems.com | Estimated |
| Multi-site | Enterprise multi-location management | revelsystems.com | Confirmed |
| Kitchen integration | Kitchen display system integration | revelsystems.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription + hardware + payments processing | revelsystems.com | Confirmed |
| Acquisition price | Not disclosed | H&L report | Unknown |
| Shift4 market cap | ~$5B (NYSE: FOUR, 2024) | Shift4 IR | Confirmed |
| SolStein fit | No — US company; global scale; acquired | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Owned by Shift4 Payments (NYSE-listed US company) | Companies House, H&L |
| Revenue scale fit | High | 1 | 18,000+ restaurant customers globally — far above SolStein target | H&L report |
| Geographic fit | High | 1 | US/Global; UK sales office only; no NL/BE strategy | Companies House |
| Tech stack modernity | Medium | 5 | Cloud-native iPad POS; payments integration; modern stack | revelsystems.com |
| Customer lock-in | Medium | 4 | POS creates high switching costs; Shift4 payments ecosystem deepens lock-in | revelsystems.com |
| Vertical depth | Medium | 4 | Restaurant POS specialism; 500+ integrations | revelsystems.com |
| Integration potential | Low | 5 | 500+ integrations; API marketplace | revelsystems.com |
| Growth trajectory | Low | 3 | Growth within Shift4 group; UK standalone trajectory unclear | Shift4 IR |

### Composite Score

**Weighted Composite: 2.1 / 5.0**

*(All three high-weight dimensions score 1)*

**Confidence Band**: Medium — acquisition facts confirmed; UK/financial details limited.

### Overall M&A Assessment

Revel Systems is **not an acquisition target** for SolStein under any scenario. It is a US-HQ'd, global-scale iPad POS company, now a subsidiary of a NYSE-listed payments corporation. Its UK presence is a sales office. Value to SolStein: iPad POS technology benchmark, and a signal that the global payments companies (Shift4, Toast, Square) are acquiring POS software companies — validating the acquisition trend in the sector.

### Recommended Next Step

No pursuit. Use as a global POS benchmark. Note Shift4/Toast/Square's acquisitive behaviour as validation that HORECA POS is a high-value, high-M&A sector.

---

*Sources: Companies House (09882972), H&L Restaurant Technology Market Update Nov 2024, Wikipedia (Revel Systems), revelsystems.com, restoconnection.com.*
