# Revel Systems — Corporate History

**Category**: iPad POS System (Restaurants)
**Country**: USA (San Francisco, CA — HQ); UK (London — European office)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (US HQ; UK presence only; acquired by Shift4 Payments 2024)

---

## Summary Assessment

Revel Systems is a **San Francisco–based iPad POS company** with a UK legal entity (London office for European sales). In **March 2024**, Revel Systems was **acquired by Shift4 Payments** (NYSE: FOUR), a major US payments processor. With 18,000+ restaurants globally and now part of a $1B+ revenue payments company, Revel is entirely outside SolStein's acquisition criteria. Relevant as a **US iPad POS benchmark** with limited UK presence.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Revel Systems | revelsystems.com | Confirmed |
| UK legal entity | REVEL SYSTEMS (GB) LIMITED | Companies House 09882972 | Confirmed |
| UK Companies House No. | 09882972 | gov.uk Companies House | Confirmed |
| UK registered address | 13th Floor, One Angel Court, London, EC2R 7HJ | Companies House | Confirmed |
| US HQ | San Francisco, California, USA | Wikipedia | Confirmed |
| Founded | 2010 | Wikipedia | Confirmed |
| Founders | Lisa Falzone + Chris Ciabarra | Wikipedia | Confirmed |
| Acquired by | Shift4 Payments Inc. (NYSE: FOUR) | H&L report Nov 2024; Companies House | Confirmed |
| Acquisition date | March 2024 | H&L Restaurant Technology Market Update Nov 2024 | Confirmed |
| Shift4 PSC notification (UK) | January 2025 (Companies House) | Companies House | Confirmed |
| Restaurant customers globally | 18,000+ | H&L report | Confirmed |
| UK distribution partner | Bluebird (historical) | restoconnection.com | Estimated |
| Product | iPad-based cloud POS for restaurants | revelsystems.com | Confirmed |
| Revenue | Not disclosed (privately held prior to Shift4 acquisition) | — | Unknown |
| Paytronix UK integration | Launched Jun 2024 (via Revel v2.79) | support.revelsystems.com | Confirmed |

---

## Founding & Corporate History

Revel Systems was founded in **San Francisco in 2010** by Lisa Falzone and Chris Ciabarra, originally as a retail-focused iPad POS before pivoting to restaurants. The company became one of the pioneers of **iPad-based cloud POS** for the restaurant and retail industry.

**UK entity** (REVEL SYSTEMS (GB) LIMITED, Companies House 09882972) was incorporated to support European sales, with London serving as the EMEA base. Distribution in the UK was handled partly through partner Bluebird.

**March 2024**: Revel Systems was **acquired by Shift4 Payments** (NYSE: FOUR), a major US payments processor and technology company. Shift4 formally notified as the **Person with Significant Control** of the UK entity in **January 2025** via Companies House.

Post-acquisition, Revel operates as part of Shift4's restaurant and hospitality payments ecosystem. The Paytronix loyalty integration (launched in the UK via Revel version 2.79 in June 2024) shows continued UK product development post-acquisition.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Shift4 Payments Inc.<br/>(NYSE: FOUR — San Francisco, CA)"]
    B["Revel Systems (US entity)<br/>(San Francisco, CA)"]
    C["REVEL SYSTEMS (GB) LIMITED<br/>(Companies House 09882972)<br/>(London, EC2R 7HJ)"]

    A -->|"Acquired Mar 2024"| B
    B -->|"Subsidiary"| C
    C --> D["UK/Europe restaurant market"]
```

---

## Funding History (pre-acquisition)

| Round | Date | Amount | Investors | Notes |
|---|---|---|---|---|
| Series A | 2011 | $7M | Andreessen Horowitz | Early VC backing |
| Series B | 2014 | $100M | — | Growth phase |
| Total raised (pre-acq) | — | ~$130M+ | — | Wikipedia / press |
| Acquisition | Mar 2024 | Undisclosed | Shift4 Payments | No acquisition price disclosed |

---

## Timeline of Critical Events

```mermaid
timeline
    title Revel Systems — Key Milestones
    2010 : Founded in San Francisco by Lisa Falzone + Chris Ciabarra
    2011 : Series A $7M (Andreessen Horowitz)
    2014 : Series B $100M; major growth
    2015 : UK entity REVEL SYSTEMS (GB) LIMITED incorporated (Companies House 09882972)
    2024 : Acquired by Shift4 Payments (Mar 2024); 18,000+ restaurants globally; Paytronix UK integration
    2025 : Shift4 notified as UK PSC (Jan 2025)
```

---

## M&A Feasibility Assessment

### Is Revel Systems an Acquisition Target for SolStein?

**Answer: No. Acquired by Shift4 Payments (US public company); no UK standalone.**

| Factor | Assessment |
|---|---|
| **Ownership** | Wholly owned by Shift4 Payments (NYSE: FOUR) |
| **Geography** | US HQ; UK sales office only |
| **Scale** | 18,000+ restaurant customers globally — far above SolStein target |
| **Succession** | Professional management; no founder access |
| **Exit pathway** | Would require Shift4 to divest — not applicable |

### Role for SolStein

1. **iPad POS benchmark**: Revel defines cloud iPad POS for restaurants — the global standard SolStein-type companies compete against.
2. **Shift4 ecosystem**: Shift4/Revel integration shows direction of payments + POS convergence.
3. **UK presence**: Only a sales office; no deep UK hospitality SaaS operation — confirms UK POS market is served by domestic players (Epos Now, Zonal) and global platforms with offices.

---

*Sources: Companies House (09882972), Wikipedia (Revel Systems), H&L Restaurant Technology Market Update Nov 2024, restoconnection.com, support.revelsystems.com.*
