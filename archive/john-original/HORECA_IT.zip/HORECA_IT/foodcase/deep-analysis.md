# Foodcase — Deep Analysis

**Category**: Inventory / Purchasing (stated in brief) — ACTUAL: Travel F&B Concepts
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

> **CRITICAL FLAG**: Foodcase International B.V. is **not a HORECA IT software company**. It is a food and beverage concept developer for the global travel industry (airlines, rail, cruise), headquartered in Wageningen, Netherlands. This is a fundamental category mismatch with SolStein's HORECA IT software thesis. The company designs and manufactures/sources physical food products — not software, SaaS, or inventory management tools. Analysis below documents the actual company for completeness, but M&A suitability is low due to category mismatch.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Foodcase International B.V. | creditsafe.com; KvK 55047599 | Confirmed |
| HQ address | Bronland 12L 1, 6708 WH Wageningen, Gelderland, Netherlands | creditsafe.com; linkedin.com | Confirmed |
| Founded | 2011 (Dealroom, Tracxn); 2012 (Creditsafe incorporation date) | dealroom.co; tracxn.com; creditsafe.com | Confirmed |
| CEO / MD | Wilbert de Louw (founder; stepped back from CEO in 2025, remains shareholder/board advisor) | linkedin.com/company/foodcase | Estimated |
| Ownership structure | Privately held; founder-owned with minority stakes from Oost NL and StartLife | pitchbook.com; tracxn.com | Estimated |
| Employees (FTE) | 11–18 (Tracxn: 18 as of Mar 2026) | tracxn.com; prospeo.io | Estimated |
| Revenue (latest estimate) | ~$1.45M (Prospeo) / <$5M (ZoomInfo) annually | prospeo.io; zoominfo.com | Estimated |
| Profitability | Unknown — no public financial data | N/A | Unknown |
| Website | foodcase-international.com; foodcase.nl (same destination) | live URL check | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | Netherlands (HQ); global client base (United Airlines, Icelandair, Deutsche Bahn) | foodcase-international.com; tracxn.com | Confirmed |
| Customer count | Unknown — portfolio shows major airline/rail clients but count not disclosed | foodcase-international.com | Unknown |
| Target verticals | Airlines, rail operators, cruise lines — NOT traditional HORECA (hotel/restaurant/café) | foodcase-international.com; zoominfo.com | Confirmed |
| Market share estimate | #29 of 56 active competitors in food/beverage products sector (Tracxn) | tracxn.com | Estimated |
| Key competitors | RJ Corp, Hain Celestial, Premier Foods (food product companies — not software) | tracxn.com | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Ambient meals, buy-on-board concepts, special meals (allergen-free/SPML), frozen meals, pre-order boxes, full tray solutions | foodcase-international.com | Confirmed |
| Tech stack | Not applicable — physical food product company; uses data-driven approaches for concept optimization | foodcase-international.com | Confirmed (not a software company) |
| Deployment model | Not applicable — physical product supply chain | N/A | N/A |
| API availability | Not applicable | N/A | N/A |
| Key integrations | Not applicable — supply chain/logistics focus | N/A | N/A |
| Mobile app | Not applicable | N/A | N/A |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Yes (majority; minority investors present) | pitchbook.com; linkedin.com | Estimated |
| Investor type | Regional VC: Oost NL; Accelerator: StartLife; Grant: Europa | pitchbook.com; tracxn.com | Estimated |
| PE ownership | No PE involvement | pitchbook.com; tracxn.com | Confirmed |
| Succession signals | Moderate — Wilbert de Louw stepped back from CEO in 2025, remains shareholder/board advisor | linkedin.com/company/foodcase | Estimated |
| Last funding date | March 2015 (Europa grant, $56.7K); equity rounds circa 2013 (Oost NL / IIG / PPM Oost) | tracxn.com; twitter.com/Foodcase | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown — no year-on-year public data; estimated <$5M total | zoominfo.com; prospeo.io | Estimated |
| Employee growth | 11 → 18 employees (slow, organic growth) | tracxn.com; prospeo.io | Estimated |
| New markets | International airline/rail expansion — United Airlines, Icelandair, Deutsche Bahn featured in portfolio | foodcase-international.com | Confirmed |
| Recent product launches | "Next generation ambient meals" range (per inflight-online.com) | inflight-online.com | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | N/A — Foodcase serves travel industry (airlines, rail), not HORECA | foodcase-international.com | Confirmed |
| GDPR/AVG compliance | Unknown | N/A | Unknown |
| Allergen management | Yes — core product differentiator; top-14 allergen-free certified, SPML (Special Meals) specialist | foodcase-international.com | Confirmed |
| Fiscal compliance NL | Unknown — Netherlands entity, presumably VAT registered | N/A | Unknown |
| iDEAL/Bancontact/Tikkie support | N/A — not a consumer-facing payment platform | N/A | N/A |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | B2B physical product supply — contracted per airline/operator; not SaaS | foodcase-international.com | Confirmed |
| Estimated ARR | N/A — not a recurring software revenue model; estimated annual revenue <$5M | zoominfo.com | Estimated |
| Estimated acquisition value | Not applicable for HORECA IT thesis. For reference: at 1× revenue, ~€1.3M–€4.5M; at 4× EBITDA, unknown (EBITDA undisclosed) | Proxy calculation | Estimated |
| Revenue per employee | ~$80K–$270K/employee ($1.45M–$5M ÷ 18 employees) | Calculation from prospeo.io; tracxn.com | Estimated |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 3 | Founder stepping back (succession signal), PE-free, minority VCs unlikely to block deal | linkedin.com; pitchbook.com |
| Revenue scale fit | High | 2 | Revenue at low end of thesis (est. ~$1.45M–$5M); but not SaaS/recurring model | prospeo.io; zoominfo.com |
| Geographic fit | High | 4 | Netherlands-registered and HQ'd; strong geographic alignment | creditsafe.com |
| Tech stack modernity | Medium | 1 | Not a technology company; no software/SaaS product | foodcase-international.com |
| Customer lock-in | Medium | 2 | Long-term airline/rail supply contracts may provide revenue stability, but clients are global travel not HORECA | foodcase-international.com |
| Vertical depth | Medium | 1 | Wrong vertical entirely — serves airlines/rail, not hotel/restaurant/café | foodcase-international.com |
| Integration potential | Low | 1 | No software integration value; physical product company incompatible with HORECA IT platform | N/A |
| Growth trajectory | Low | 2 | Slow organic growth; small team; no funding since 2015 | tracxn.com |

**Composite Score**: 2.0 / 5.0  
**Confidence Band**: Narrow (structural disqualifiers are confirmed — category mismatch is definitive)  
**Overall M&A Assessment**: Foodcase International B.V. is definitively not a HORECA IT software company and should be removed from SolStein's HORECA IT acquisition pipeline. It is a physical food product/concept company serving airlines and rail operators. The NL geography and PE-free structure are positives, and the founder succession signal (stepping back from CEO in 2025) is notable. However, the fundamental business model — food product supply chain, not software — is incompatible with a HORECA IT thesis. There is no SaaS, no recurring software revenue, no tech stack to acquire.  
**Recommended Next Step**: Remove from HORECA IT pipeline. If SolStein ever pursues a HORECA *supply chain* thesis (food/beverage procurement for travel catering), Foodcase could be reconsidered. For the current IT thesis, the research brief likely contained a naming error — the intended target may be a different company with a similar name (e.g., FoodStorm, FoodCost, HosCat, or another NL-based inventory management software for restaurants/hotels).
