# Foodcase — Corporate History

**Category**: Inventory / Purchasing (stated in brief) — ACTUAL CATEGORY: Travel Food Concepts (F&B for airlines/rail)
**Country**: NL
**Research Date**: 2026-04-30

> **RESEARCH NOTE**: The target brief described Foodcase as "inventory and purchasing software for hospitality." Research confirms that **Foodcase International B.V.** (foodcase.nl / foodcase-international.com) is **not a software company**. It is a Netherlands-based food and beverage concept developer specialising in ambient meals, buy-on-board solutions, and allergen-free recipes for airlines, rail operators, and cruise lines. The KvK number 55047599 is confirmed. There is no HORECA inventory software company called "Foodcase" found in NL. The category mismatch significantly affects M&A feasibility against SolStein's HORECA IT thesis. All data below reflects the actual Foodcase International B.V. entity.

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Foodcase International B.V. | creditsafe.com; KvK 55047599 | Confirmed |
| KvK Number | 55047599 | creditsafe.com | Confirmed |
| Registered City | Wageningen, Gelderland, NL (address: Bronland 12L 1, 6708 WH Wageningen) | creditsafe.com; linkedin.com/company/foodcase | Confirmed |
| Founding Year | 2011 (incorporated; Creditsafe lists 2012 incorporation date) | dealroom.co; tracxn.com; linkedin.com | Confirmed |
| Founders | Wilbert de Louw (CEO/Co-founder); Joleen van Wijk (Co-founder, Tracxn); Oscar Huizing (Co-founder, Dealroom) | tracxn.com; dealroom.co | Estimated (sources differ on co-founders) |
| Current Ownership | Privately held; founder Wilbert de Louw stepped back from CEO role in 2025, remains shareholder | linkedin.com/company/foodcase | Estimated |
| PE/Investor Ownership | Minority investors: Oost NL (regional VC), StartLife (accelerator/fund); no PE | pitchbook.com; twitter/Foodcase (2013 post about PPM Oost + IIG investment) | Estimated |
| Employees (FTE) | 11–18 (Tracxn: 18 as of Mar 2026; Prospeo: 11–20; ZoomInfo: <$5M revenue band) | tracxn.com; prospeo.io | Estimated |
| Estimated Revenue | ~$1.45M (Prospeo) / <$5M (ZoomInfo) | prospeo.io; zoominfo.com | Estimated |
| M&A History | No acquisitions made or received; no exits recorded | tracxn.com; pitchbook.com | Confirmed |
| Investment Rounds | 1 grant round (Mar 2015, $56.7K, from Europa); equity investment from Oost NL / IIG / PPM Oost (undisclosed amounts, circa 2013) | tracxn.com; twitter.com/Foodcase 2013 post | Estimated |
| Name Changes | Started as "Foodcase B.V." circa 2013 (per Twitter post); became Foodcase International B.V. | tracxn.com; twitter historical reference | Estimated |

---

## Corporate Structure

```mermaid
graph TD
    A[Wilbert de Louw - Founder / Shareholder] --> B[Foodcase International B.V. - Wageningen, NL]
    C[Oost NL / StartLife - Minority investors] --> B
    B --> D[F&B Concepts for Travel Industry]
    D --> E[Ambient Meals / Buy-on-Board]
    D --> F[Special Meals - Allergen-free]
    D --> G[Airline & Rail Clients]
```

---

## Timeline

```mermaid
timeline
    title Foodcase Key Events
    2011 : Founded by Wilbert de Louw and co-founders in Wageningen, NL
    2012 : Formally incorporated as Foodcase B.V. (Creditsafe incorporation date)
    2013 : PPM Oost and IIG invest in Foodcase (equity investment, amounts undisclosed)
    2015 : Europa grant round — $56.7K; StartLife involvement
    2018-2022 : International growth — airline clients including United Airlines, Icelandair, Deutsche Bahn
    2025 : Wilbert de Louw steps back from CEO role, remains shareholder and board advisor
    2026 : ~18 employees; revenue estimated <$5M
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Yes / Transitioning | Wilbert de Louw stepped back from CEO in 2025 — potential succession signal |
| PE-free | Yes | No PE ownership; regional VC (Oost NL) is minority only |
| Revenue in thesis range | Borderline | Revenue ~$1.45M–$5M — at the low end of €1M–€15M thesis range |
| Geographic fit (NL/BE) | Yes | Wageningen, Netherlands |
| Succession signal | Moderate | Founder stepping back from CEO is a classic pre-exit signal |
| Overall feasibility | **Low — Category Mismatch** | Foodcase is an F&B concepts/food company, not a HORECA IT/software company. The SolStein thesis targets software. Geographic fit is good and succession signal is present, but the business model is fundamentally incompatible with a HORECA IT acquisition thesis. |
