# GASTROpoint — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Privately held — small German company with limited public data

---

## Executive Summary

Gastropoint GmbH is a German company registered in Freilassing, Bavaria (not Munich as stated in the SolStein research brief), that develops and distributes software for the gastronomy, hotel, and tourism industries. The company is registered at Amtsgericht Traunstein under HRB 19181. Beyond the Handelsregister entry confirming its existence and corporate purpose, very limited public information is available. The company appears to be a small regional software vendor serving the Bavarian hospitality market.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | Gastropoint GmbH | Northdata.com (Amtsgericht Traunstein HRB 19181) | Confirmed |
| Handelsregister | Amtsgericht Traunstein, HRB 19181 | Northdata.com | Confirmed |
| Registered address | Freilassing, Bavaria, Germany | Northdata.com | Confirmed |
| SolStein brief location | "Munich, DE" (may be incorrect — registered in Freilassing) | SolStein research brief | Estimated |
| Legal form | GmbH | Handelsregister | Confirmed |
| Country | Germany | Northdata.com | Confirmed |
| Corporate purpose | Development and distribution of software for gastronomy, hotel, and tourism industries | Northdata.com | Confirmed |
| Website | gastropoint.de (reported; unverified) | SolStein research brief | Estimated |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | Unknown | No public source beyond Handelsregister | Unknown |
| Founders | Unknown | No public source found | Unknown |
| Location detail | Freilassing is ~25km from Munich/Salzburg border area | Geography | Confirmed |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership type | Privately held GmbH | Handelsregister | Confirmed |
| PE involvement | None identified | Assessment | Estimated |
| External funding | None identified | Assessment | Estimated |
| Shareholders | Unknown | Not publicly disclosed | Unknown |

---

## M&A History

No M&A events identified.

---

## Corporate Structure

```mermaid
graph TD
    A["Gastropoint GmbH<br/>(Amtsgericht Traunstein, HRB 19181)<br/>Freilassing, Bavaria, DE"]
    B["Software for Gastronomy / Hotel / Tourism<br/>(Core product — details unknown)"]

    A --> B

    style A fill:#f9f,stroke:#333
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Potentially available — privately held GmbH |
| **Scale** | Likely micro-business (small regional software vendor in Freilassing) |
| **SolStein thesis fit** | Very poor — Germany-only, wrong geography, micro-scale, product details unclear |
| **Research confidence** | Low — only Handelsregister existence confirmed |

**Verdict**: Gastropoint GmbH is confirmed to exist but appears to be a micro-scale regional hospitality software company in Freilassing, Bavaria. It falls entirely outside SolStein's NL/BE acquisition thesis.

---

## Sources

| Source | URL | Type |
|---|---|---|
| Northdata — Gastropoint GmbH Freilassing | https://www.northdata.com/Gastropoint%20GmbH,%20Freilassing/Amtsgericht%20Traunstein%20HRB%2019181 | Secondary (company DB/registry) |
| SolStein research brief | Internal document | Internal |
