# GASTROpoint

**Category**: POS System
**Country**: DE
**City**: Munich
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history GASTROpoint @HORECA_IT/gastropoint/
@research-horeca-company GASTROpoint @HORECA_IT/gastropoint/
```
