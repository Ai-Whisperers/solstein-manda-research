# GASTROpoint — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: Small German regional hospitality software reference; NOT a SolStein target

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Gastropoint GmbH | Northdata.com (HRB 19181) | Confirmed |
| HQ | Freilassing, Bavaria, Germany | Northdata.com | Confirmed |
| Founded | Unknown | No public source | Unknown |
| CEO / Owner | Unknown | No public source | Unknown |
| Ownership | Private GmbH | Handelsregister | Confirmed |
| Employees | Unknown (likely <10 for micro-regional vendor) | Estimated | Estimated |
| Revenue | Unknown (likely <€1M) | Estimated | Estimated |
| Countries | Germany (Bavaria/Salzburg border region) | Geography | Estimated |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Market segment | Gastronomy, hotel, tourism software | Northdata.com (corporate purpose) | Confirmed |
| Customer count | Unknown | No public source | Unknown |
| Geographic focus | Bavaria / Austria border region (Freilassing) | Geography | Estimated |
| NL/BE presence | None expected | Assessment | Estimated |

---

## 3–7. Product, M&A, Financial, Vertical, Valuation

All Unknown — insufficient public data. Northdata.com Handelsregister entry is the only confirmed source.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 2 | Private GmbH — potentially founder-owned; no PE (positive) | Handelsregister |
| Revenue scale fit | High | 1 | Likely <€1M — below SolStein's minimum threshold | Estimated |
| Geographic fit | High | 1 | Bavaria, Germany — no NL/BE | Northdata.com |
| Tech stack modernity | Medium | — | Unknown | No source |
| Customer lock-in | Medium | — | Unknown | No source |
| Vertical depth | Medium | 2 | Gastronomy/hotel/tourism focus (per Handelsregister); scope unclear | Northdata.com |
| Integration potential | Low | — | Unknown | No source |
| Growth trajectory | Low | — | Unknown | No source |

**Composite Score**: ~1.2 / 5.0

**Confidence Band**: Very Low

**Overall M&A Assessment**: Gastropoint GmbH is **not a SolStein target**. It is a micro-scale regional software company in Freilassing (Bavaria), confirmed to exist but with minimal public data. Zero NL/BE presence; Germany-only. Revenue likely well below SolStein's €1M threshold.

**Recommended Next Step**: No action. Remove from active research.

---

*Sources: Northdata.com (Amtsgericht Traunstein HRB 19181), SolStein research brief*
