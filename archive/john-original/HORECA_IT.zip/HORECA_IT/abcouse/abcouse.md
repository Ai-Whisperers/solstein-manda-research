# Abcouse

**Category**: Restaurant Software
**Country**: BE
**City**: Ghent
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Abcouse @HORECA_IT/abcouse/
@research-horeca-company Abcouse @HORECA_IT/abcouse/
```
