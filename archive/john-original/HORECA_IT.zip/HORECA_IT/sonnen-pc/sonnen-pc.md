# Sonnen PC

**Category**: POS System
**Country**: DE
**City**: Leipzig
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Sonnen PC @HORECA_IT/sonnen-pc/
@research-horeca-company Sonnen PC @HORECA_IT/sonnen-pc/
```
