# Sonnen PC — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — very limited public data

---

## Executive Summary

Sonnen PC is reported to be a Leipzig-based provider of POS systems for hotels and gastronomy. Extensive research could not confirm this company's existence or locate any Handelsregister entries, company website, or credible corporate information. The name "Sonnen PC" could refer to a small regional IT company or POS dealer in Saxony. This appears to be a micro-business with very minimal online presence. Note: "Sonnen GmbH" is an unrelated German energy storage company (Wildpoldsried); "Sonnen PC" as a POS vendor is not to be confused with it.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | Sonnen PC | SolStein research brief | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Leipzig, Saxony, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany | SolStein research brief | Estimated |
| Primary activity | POS systems for hotels and gastronomy | SolStein research brief | Estimated |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | Unknown | No public source found | Unknown |
| Founders | Unknown | No public source found | Unknown |
| History | Unknown | No public source found | Unknown |

---

## Research Methodology & Limitations

The following searches were conducted without returning specific information about Sonnen PC as a hospitality POS company in Leipzig:

- Web search: "Sonnen PC Leipzig hotel gastronomy POS"
- Web search: "SonnenPC GmbH hotel software Germany"
- The primary search results returned references to "Sonnen GmbH" (energy storage company) and "Hotel Sonne" venues — both unrelated

**Likely explanation**: Sonnen PC Leipzig appears to be a very small regional IT/POS company with minimal online presence. Direct Handelsregister query in Leipzig/Saxony courts would be required to locate the legal entity.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — no ownership data available |
| **SolStein thesis fit** | Very poor — Germany-only, unconfirmed company existence, likely micro-scale |
| **Research confidence** | Very low — insufficient public data |

**Verdict**: Insufficient data to assess. Likely a very small regional POS dealer/integrator with no meaningful scale.

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| Web search results (inconclusive) | Multiple URLs searched; no match found | Negative result |
