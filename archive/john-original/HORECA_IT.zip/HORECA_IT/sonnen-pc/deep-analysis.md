# Sonnen PC — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: DE POS market reference; insufficient data for meaningful analysis

---

## Research Limitations

Sonnen PC has no identifiable public data footprint. All searches for this company as a Leipzig-based hospitality POS vendor returned no results. This analysis consists entirely of placeholder entries with Unknown confidence. Direct Handelsregister searches in Saxony courts (Amtsgericht Leipzig, Dresden) would be required to confirm legal entity details.

---

## 1–7. All Data Points

| Category | Status |
|---|---|
| Company Fundamentals | Unknown — no public data |
| HORECA Market Position | Unknown |
| Product & Technology | Unknown |
| M&A Ownership & Succession | Unknown |
| Financial Growth & Trajectory | Unknown |
| HORECA Vertical Depth | Unknown |
| Valuation & Business Model | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown | No source |
| Revenue scale fit | High | 1 | Assumed micro-business based on complete absence of online presence | Estimated |
| Geographic fit | High | 1 | Germany (Leipzig) — no NL/BE | SolStein brief |
| Tech stack modernity | Medium | — | Unknown | No source |
| Customer lock-in | Medium | — | Unknown | No source |
| Vertical depth | Medium | — | Unknown | No source |
| Integration potential | Low | — | Unknown | No source |
| Growth trajectory | Low | — | Unknown | No source |

**Composite Score**: ~1.0 / 5.0 (insufficient data; Germany-only)

**Confidence Band**: Very Low — nearly all Unknown

**Overall M&A Assessment**: Sonnen PC is **not a relevant SolStein acquisition target**. Insufficient public data exists to assess the company. Likely a micro-scale regional POS dealer in Leipzig with no NL/BE presence.

**Recommended Next Step**: Remove from active research list. If confirmation is needed, direct Handelsregister query at Amtsgericht Leipzig or direct company outreach.

---

*Sources: SolStein research brief only; no independent public sources confirmed*
