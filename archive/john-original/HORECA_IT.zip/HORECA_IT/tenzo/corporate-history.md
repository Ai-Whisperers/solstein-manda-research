# Tenzo — Corporate History

**Category**: Analytics / AI-Powered Restaurant Operations
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; VC-backed, US expansion phase)

---

## Summary Assessment

Tenzo is a **VC-backed, London-based** AI restaurant analytics company founded in 2016. With ~$15.2M raised across multiple rounds (most recently $5M Series A extension in April 2026), it is in growth mode but remains small (~38 employees, ~$1.1M revenue estimate). While technically interesting (AI analytics for restaurant operations), it is UK-focused with US expansion ambitions — not NL/BE oriented. Useful as a **restaurant analytics benchmark**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Tenzo | tenzo.io / amadeuscapital.com | Confirmed |
| Founded | 2016 | tracxn.com, amadeuscapital.com | Confirmed |
| Founders | Christian Mouysset + Adam Taylor | amadeuscapital.com, techfundingnews.com | Confirmed |
| HQ | London, UK | amadeuscapital.com, tracxn.com | Confirmed |
| Registered address | Gerrards Cross, England (per PitchBook) | PitchBook | Confirmed |
| Employees | ~38 | PitchBook | Estimated |
| Revenue estimate | ~$1.1M (2025 per Getlatka; note: small sample) | Getlatka (low confidence) | Estimated |
| Total funding | ~$15.2M | PitchBook | Estimated |
| Funding round 1 | £600K seed (April 2017) | tracxn.com | Confirmed |
| Funding round 2 | $1.8M (November 2018; led S28 Capital, Acequia, Force Over Mass) | thespoon.tech | Confirmed |
| Funding round 3 | $5M Series A (May 2023; led Amadeus Capital Partners + S28 Capital) | amadeuscapital.com | Confirmed |
| Funding round 4 | $5M Series A extension (April 21, 2026; led Edge.vc) | amadeuscapital.com | Confirmed |
| Round 4 other investors | Amadeus Capital Partners, YourVC, Frontive Holdings (customer) | amadeuscapital.com | Confirmed |
| Current ownership | VC-backed; not PE; founders likely still active | amadeuscapital.com | Estimated |
| Product category | AI restaurant PerformanceOps (sales, labour, inventory analytics) | amadeuscapital.com, tenzo.io | Confirmed |
| UK focus | Primary market: UK restaurant chains | tenzo.io | Confirmed |
| US expansion | $5M round (Apr 2026) earmarked for US market entry | amadeuscapital.com | Confirmed |

---

## Founding & History

Christian Mouysset and Adam Taylor founded **Tenzo in London in 2016** with the thesis that restaurant operators were drowning in disconnected data across POS, labour, inventory, and finance systems — but lacked tools to turn that data into actionable insights.

Tenzo built an analytics platform that integrates with restaurant POS, labour scheduling, and inventory systems to provide a unified performance dashboard — helping operators understand real-time sales trends, labour costs, and inventory waste across locations.

**Funding timeline:**
- **Apr 2017**: £600K seed; initial product development
- **Nov 2018**: $1.8M led by S28 Capital (US/UK); food waste AI angle
- **May 2023**: $5M Series A led by Amadeus Capital Partners (Cambridge-based deep tech VC) + S28 Capital; scaled UK customer base
- **Apr 21, 2026**: $5M Series A extension led by Edge.vc; Amadeus Capital, YourVC, Frontive Holdings participate; US expansion earmarked

Tenzo has evolved its positioning from "food waste AI" to "AI PerformanceOps" — a broader restaurant operations intelligence play.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Christian Mouysset (Co-Founder)"]
    B["Adam Taylor (Co-Founder)"]
    C["Tenzo Ltd<br/>(London, UK)"]
    D["Amadeus Capital Partners"]
    E["Edge.vc"]
    F["S28 Capital"]
    G["YourVC"]
    H["Frontive Holdings (customer-investor)"]
    I["Force Over Mass / Acequia Capital (early)"]

    A -->|"Co-founder"| C
    B -->|"Co-founder"| C
    D -->|"Series A + A-ext"| C
    E -->|"Series A-ext lead"| C
    F -->|"Seed + Series A"| C
    G -->|"Series A-ext"| C
    H -->|"Series A-ext"| C
    I -->|"Nov 2018 round"| C
```

---

## Funding Timeline

| Round | Date | Amount | Lead Investor | Notes |
|---|---|---|---|---|
| Seed | Apr 2017 | £600K | — | Initial product |
| Seed extension | Nov 2018 | $1.8M | S28 Capital | Acequia Capital, Force Over Mass |
| Series A | May 2023 | $5M | Amadeus Capital Partners | S28 Capital participates |
| Series A extension | Apr 21, 2026 | $5M | Edge.vc | Amadeus, YourVC, Frontive Holdings |
| **Total raised** | | **~$15.2M** | | PitchBook estimate |

---

## Timeline of Critical Events

```mermaid
timeline
    title Tenzo — Key Milestones
    2016 : Founded by Christian Mouysset + Adam Taylor in London
    2017 : £600K seed round; product launched
    2018 : $1.8M funding; food waste / AI analytics positioning
    2023 : $5M Series A (Amadeus Capital lead); UK restaurant chains customer base scaled
    2026 : $5M Series A extension (Edge.vc lead); US expansion announced; AI PerformanceOps positioning
```

---

## M&A Feasibility Assessment

### Is Tenzo an Acquisition Target for SolStein?

**Answer: Not suitable for SolStein — wrong geography, VC-backed, US expansion phase.**

| Factor | Assessment |
|---|---|
| **Scale** | ~38 employees; ~$1.1M revenue estimate — within SolStein's ARR range BUT geography wrong |
| **Geography** | UK primary; US expansion earmarked; no NL/BE strategy |
| **Ownership** | VC-backed (Edge.vc, Amadeus); founders may still be active — but investors need an exit |
| **Revenue** | Sub-$2M — at very low end; analytics category; not deep HORECA operations |
| **Exit pathway** | Series A extension suggests growth, not imminent exit |

### Role for SolStein

1. **Analytics benchmark**: Tenzo defines AI-powered restaurant analytics for the UK market.
2. **Competitive signal**: If any NL/BE restaurant analytics company exists at similar scale, it could be a SolStein target.
3. **Technology reference**: Integration-first analytics (POS + labour + inventory) as a product pattern.

---

*Sources: amadeuscapital.com (press release Apr 2026), techfundingnews.com, thespoon.tech, tracxn.com, PitchBook, Getlatka.*
