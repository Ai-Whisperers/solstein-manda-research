# Tenzo — Deep Analysis

**Category**: Analytics / AI-Powered Restaurant Operations (PerformanceOps)
**Country**: UK (London, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; VC-backed, US expansion phase)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Tenzo Ltd | Companies House (inferred) | Estimated |
| HQ | London, UK | amadeuscapital.com | Confirmed |
| Founded | 2016 | tracxn.com | Confirmed |
| Founders | Christian Mouysset + Adam Taylor | amadeuscapital.com | Confirmed |
| Ownership | VC-backed; founders likely retain stakes | amadeuscapital.com | Estimated |
| Employees | ~38 | PitchBook | Estimated |
| Revenue | ~$1.1M (Getlatka 2025 estimate — low confidence) | Getlatka | Estimated |
| Total funding | ~$15.2M | PitchBook | Estimated |
| Latest round | $5M Series A extension (Apr 2026, Edge.vc lead) | amadeuscapital.com | Confirmed |
| Business model | SaaS analytics subscription (per location/per user) | tenzo.io | Confirmed |
| Product category | AI PerformanceOps — restaurant analytics for sales, labour, inventory | amadeuscapital.com, tenzo.io | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Primary; UK restaurant chains | tenzo.io | Confirmed |
| US market | Expansion earmarked (Apr 2026 round) | amadeuscapital.com | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| EU presence | Not a stated priority | amadeuscapital.com | Estimated |
| Target customer | Multi-site restaurant operators (5–500 locations) | tenzo.io | Confirmed |
| Known UK customers | Nando's (reported), other UK chains | Press mentions | Estimated |
| Customer count | Not disclosed | — | Unknown |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | Unified restaurant performance dashboard | tenzo.io | Confirmed |
| Data integrations | POS systems (Lightspeed, Square, etc.), labour scheduling (Fourth, etc.), inventory | tenzo.io | Confirmed |
| AI features | Demand forecasting, labour optimisation, anomaly detection | amadeuscapital.com | Confirmed |
| Deployment | Cloud SaaS | tenzo.io | Confirmed |
| Mobile | Mobile dashboard for operators | tenzo.io | Confirmed |
| Tech stack | Cloud-native; API integrations; Python/ML backend | Inferred | Estimated |
| Key differentiator | Unified data layer across POS + labour + inventory; AI recommendations | tenzo.io | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| PE backing | No — VC-backed (Edge.vc, Amadeus Capital, S28, YourVC) | amadeuscapital.com | Confirmed |
| Founder status | Both founders likely active (early-stage VC company) | Inferred | Estimated |
| Investor exit horizon | Series A suggests 3–5 years to Series B/exit | Standard VC lifecycle | Estimated |
| Succession gap | Not applicable at this stage (young company) | — | Estimated |
| Acquisition appetite | Unlikely to be acquired before Series B | Standard VC terms | Estimated |

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Employees | Funding | Source | Confidence |
|---|---|---|---|---|---|
| 2025 | ~$1.1M (estimate) | ~38 | $15.2M total | Getlatka (low conf), PitchBook | Estimated |
| Apr 2026 | Series A ext ($5M) | ~38 | US expansion | amadeuscapital.com | Confirmed |

Revenue estimate from Getlatka ($1.1M) should be treated with low confidence — Getlatka methodology for private companies is approximate. True ARR likely £1–3M based on headcount and customer base.

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Restaurant focus | Pure play restaurant analytics | tenzo.io | Confirmed |
| UK VAT compliance | Analytics only; not a POS/payments system | tenzo.io | Confirmed |
| Labour cost analysis | UK NMW, NLW tracking in labour analytics | tenzo.io | Estimated |
| Menu performance | Recipe-level sales analytics | tenzo.io | Confirmed |
| Waste reduction | Inventory/waste analytics module | thespoon.tech | Confirmed |
| POS agnostic | Integrates with multiple POS providers | tenzo.io | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS per-location subscription | tenzo.io | Confirmed |
| ARR estimate | £1M–£3M (estimated) | Headcount/funding inference | Estimated |
| Valuation (implied) | $15–30M post-money (at $5M Series A extension) | VC round sizing norms | Estimated |
| Acquisition price | £5M–£15M (estimated for full acquisition) | Industry comparable | Estimated |
| SolStein fit | No — UK/US focus; VC-backed; no NL/BE presence | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 2 | VC-backed (not founder-only); investors need exit but company in growth phase | amadeuscapital.com |
| Revenue scale fit | High | 3 | ~£1–3M ARR — within range, but analytics-only category; no deep HORECA ops | Getlatka, PitchBook |
| Geographic fit | High | 1 | UK/US focused; no NL/BE strategy | amadeuscapital.com |
| Tech stack modernity | Medium | 5 | Cloud-native; AI-first; API integrations | tenzo.io |
| Customer lock-in | Medium | 3 | Data platform creates stickiness, but POS switching does not affect Tenzo | tenzo.io |
| Vertical depth | Medium | 3 | Restaurant analytics only; not full-stack hospitality | tenzo.io |
| Integration potential | Low | 5 | API-first; built for integration ecosystem | tenzo.io |
| Growth trajectory | Low | 4 | Active funding; US expansion planned; Series A+ stage | amadeuscapital.com |

### Composite Score

**Weighted Composite: 2.5 / 5.0**

*(Geographic fit = 1 (high weight) is the decisive blocker for SolStein)*

**Confidence Band**: Low — revenue estimate unreliable; ownership structure partially confirmed.

### Overall M&A Assessment

Tenzo is **not a SolStein target** — it is UK/US focused with VC backing and no NL/BE presence. Its value is as a **restaurant analytics benchmark**. If a comparable NL/BE restaurant analytics company exists (founder-owned, €1–5M ARR), that company would score higher on SolStein's scorecard.

### Recommended Next Step

No pursuit. Tenzo is a useful tech reference. Search for NL/BE equivalents in restaurant analytics / operational intelligence as direct SolStein candidates.

---

*Sources: amadeuscapital.com (Apr 2026), techfundingnews.com, thespoon.tech, tracxn.com, PitchBook, Getlatka, tenzo.io.*
