# Tenzo

**Category**: Analytics
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Tenzo @HORECA_IT/tenzo/
@research-horeca-company Tenzo @HORECA_IT/tenzo/
```
