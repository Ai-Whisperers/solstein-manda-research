# Cures Werkt — Deep Analysis

**Category**: Workforce / HR
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | openkvk.nl — no match | Unknown |
| HQ address | Amsterdam, NL (claimed) | Task brief only | Unknown |
| Founded | Unknown | No public record | Unknown |
| CEO / MD | Unknown | No public record | Unknown |
| Ownership structure | Unknown | No public record | Unknown |
| Employees (FTE) | Unknown | No LinkedIn page found | Unknown |
| Revenue (latest estimate) | Unknown | No financial data found | Unknown |
| Profitability | Unknown | No financial data found | Unknown |
| Website | cureswerkt.nl (exists, HTTP 503 on 2026-04-30) | Direct fetch attempt | Unknown |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | NL (claimed) | Task brief | Unknown |
| Customer count | Unknown | No public data | Unknown |
| Target verticals | Hospitality / HORECA HR & Payroll (claimed) | Task brief | Unknown |
| Market share estimate | Unknown | No public data | Unknown |
| Key competitors | JAM! Horeca, Kolibrie Payroll, AFAS, Nmbrs, Loket.nl | Dutch HORECA HR market research | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | HR and payroll software for hospitality (claimed) | Task brief | Unknown |
| Tech stack | Unknown | No public data | Unknown |
| Deployment model | Unknown — likely SaaS or web-based | Sector inference | Unknown |
| API availability | Unknown | No public data | Unknown |
| Key integrations | Unknown | No public data | Unknown |
| Mobile app | Unknown | No public data | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No public data | Unknown |
| Investor type | Unknown | No public data | Unknown |
| PE ownership | Unknown | No public data | Unknown |
| Succession signals | Unknown | No public data | Unknown |
| Last funding date | Unknown | No public data | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No public data | Unknown |
| Employee growth | Unknown | No LinkedIn history | Unknown |
| New markets | Unknown | No public data | Unknown |
| Recent product launches | Unknown | No public data | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Unknown | No public data | Unknown |
| GDPR/AVG compliance | Unknown | No public data | Unknown |
| Allergen management | Not applicable (HR/payroll product) | Sector inference | N/A |
| Fiscal compliance NL — Horeca CAO | Unknown | No public data | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown — likely relevant for payroll disbursements | No public data | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown | No public data | Unknown |
| Estimated ARR | Unknown | No public data | Unknown |
| Estimated acquisition value | Unknown | No public data | Unknown |
| Revenue per employee | Unknown | No public data | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot score — no ownership data | — |
| Revenue scale fit | High | N/A | Cannot score — no revenue data | — |
| Geographic fit | High | N/A | Amsterdam, NL claimed; unverified | Task brief |
| Tech stack modernity | Medium | N/A | Cannot score — no product data | — |
| Customer lock-in | Medium | N/A | HR/payroll = high switching cost in theory; unverified | Sector inference |
| Vertical depth | Medium | N/A | Cannot score — no product detail | — |
| Integration potential | Low | N/A | Cannot score — no tech data | — |
| Growth trajectory | Low | N/A | Cannot score — no growth data | — |

**Composite Score**: N/A — Insufficient data
**Confidence Band**: Wide (high uncertainty)
**Overall M&A Assessment**: No verifiable public data exists for Cures Werkt. The domain `cureswerkt.nl` is registered and its server responds (HTTP 503), confirming the company likely exists. No KvK registration, LinkedIn presence, or public product information was found. If genuine, a niche Amsterdam-based HR/payroll provider for HORECA could be strategically interesting — payroll software typically has very high switching costs and recurring revenue — but this cannot be assessed without direct engagement.
**Recommended Next Step**: Access cureswerkt.nl when the server becomes available; attempt LinkedIn search and direct email outreach; request KvK extract for Amsterdam-registered software companies in the HR/payroll space (SBI code 6201/6202 or 7830); check Dutch HORECA industry associations for member companies.

---

## 9. Competitive Landscape — Dutch HORECA HR & Payroll

| Competitor | HQ | Positioning | Notes |
|---|---|---|---|
| JAM! Horeca | Netherlands | Payroll & HR specialist for hospitality | [jamhoreca.nl](https://jamhoreca.nl) |
| Kolibrie Payroll | Netherlands | Legal employer / payroll outsourcing | [kolibriepayroll.nl](https://www.kolibriepayroll.nl) |
| AFAS Software | Leusden, NL | General ERP/HR/payroll for NL market | Large, broad market |
| Nmbrs | Amsterdam, NL | Cloud payroll SaaS | Developer-friendly API |
| Loket.nl | Amsterdam, NL | SME payroll cloud | Broad market |

*Sources: company websites, ensun.io, saasadviser.co (accessed 2026-04-30)*

---

## 10. Research Methodology & Limitations

**Searches conducted**:
- openkvk.nl — "cures werkt", "cures werkt amsterdam" — no specific match
- Google — multiple query variants in Dutch and English
- LinkedIn — company search returned HTTP 404
- Direct website — cureswerkt.nl returns HTTP 503 (server exists, service down)
- Google cache — no cache entry for cureswerkt.nl
- Crunchbase, PitchBook, Tracxn — no results

**Limitation**: The company has a registered domain but no accessible public website or social media presence. Data cannot be confirmed without direct company contact or a paid registry extract.
