# Cures Werkt — Corporate History

**Category**: Workforce / HR
**Country**: NL
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Unknown | openkvk.nl — no specific match for "Cures Werkt" as a tech/HR company | Unknown |
| KvK Number | Unknown | openkvk.nl search returned unrelated results | Unknown |
| Registered City | Amsterdam (claimed) | Task brief; not verified in KvK | Unknown |
| Founding Year | Unknown | No public record found | Unknown |
| Founders | Unknown | No public record found | Unknown |
| Current Ownership | Unknown | No public record found | Unknown |
| PE/Investor Ownership | Unknown | No public record found | Unknown |
| Employees (FTE) | Unknown | No LinkedIn company page found | Unknown |
| Estimated Revenue | Unknown | No financial data found | Unknown |
| M&A History | Unknown | No public record found | Unknown |
| Investment Rounds | Unknown | No public record found | Unknown |
| Name Changes | Unknown | No public record found | Unknown |

---

## Research Notes

**Domain status**: The domain `cureswerkt.nl` exists and responds (HTTP 503 Service Unavailable on 2026-04-30), indicating an active server but temporarily unavailable service. The domain is registered and hosted. No cached version was retrievable via Google cache.

**Alternative domain checked**: `cures-werkt.nl` — not separately verified; may redirect.

**KvK search**: A search on [openkvk.nl](https://openkvk.nl/search?q=cures+werkt) for "cures werkt" returned 1,579 general results (common Dutch words "cures" and "werkt"), none of which match a specific Amsterdam-based HR/payroll software company for the HORECA sector.

**LinkedIn**: A search for "Cures Werkt" as a LinkedIn company returned HTTP 404, indicating no such company page exists or is publicly accessible.

**Disambiguation**: "Cures Werkt" does not match any known public Dutch HR/payroll software company. The Dutch HORECA payroll/HR software market includes known players such as JAM! Horeca (jamhoreca.nl) and Kolibrie Payroll, but "Cures Werkt" is not among them in public sources.

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown — Founder / Owner] --> B[Cures Werkt NL — Operating Entity]
    B --> C[HR & Payroll SaaS — HORECA Sector]
```

*Structure is entirely inferred from task brief; no primary sources available.*

---

## Timeline

```mermaid
timeline
    title Cures Werkt — Key Events (Reconstructed)
    Unknown : Founded — year not established
    2026-04-30 : Research conducted — cureswerkt.nl returns HTTP 503
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | No ownership data found |
| PE-free | Unknown | No investor data found |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No financial data found |
| Geographic fit (NL/BE) | Likely Yes | Claimed Amsterdam, NL; unverified |
| Succession signal | Unknown | No public signal found |
| Overall feasibility | Unknown | Insufficient data to assess |

---

## Research Confidence Summary

Research across openkvk.nl, kvk.nl, LinkedIn, Google, Dutch tech media, and direct website access produced **no verifiable data** about Cures Werkt as a Dutch HORECA HR/payroll software company. The domain `cureswerkt.nl` is active (server responds) but inaccessible. A **direct outreach** or **paid KvK extract** would be required to confirm basic corporate facts.

**Comparable active Dutch HORECA HR/payroll players** (for context):
- JAM! Horeca ([jamhoreca.nl](https://jamhoreca.nl)) — payroll & HR specialist for hospitality
- Kolibrie Payroll ([kolibriepayroll.nl](https://www.kolibriepayroll.nl)) — HR/payroll outsourcing for HORECA
