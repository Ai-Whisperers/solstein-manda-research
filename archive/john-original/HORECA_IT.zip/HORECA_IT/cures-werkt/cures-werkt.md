# Cures Werkt

**Category**: Workforce
**Country**: NL
**City**: Amsterdam
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Cures Werkt @HORECA_IT/cures-werkt/
@research-horeca-company Cures Werkt @HORECA_IT/cures-werkt/
```
