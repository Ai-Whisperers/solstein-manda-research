# MaaS (Meals as a Service) — Deep Analysis

**Category**: Online Ordering (B2B)
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## Research Methodology

Extensive web research was conducted on 2026-04-30 using 12+ targeted searches across OpenKvK.nl, kvk.nl, LinkedIn, Crunchbase, Dealroom, Google, and direct website fetches. No public-facing company profile was found matching "MaaS (Meals as a Service)" as a B2B food ordering platform in Amsterdam. All fields below are marked accordingly.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | OpenKvK.nl — no result | Unknown |
| HQ address | Amsterdam, NL (per brief) | Brief only | Estimated |
| Founded | Unknown | No public record | Unknown |
| CEO / MD | Unknown | No LinkedIn company page found | Unknown |
| Ownership structure | Unknown | No KvK or investor data found | Unknown |
| Employees (FTE) | Unknown | No LinkedIn company page found | Unknown |
| Revenue (latest estimate) | Unknown | No financial data available | Unknown |
| Profitability | Unknown | No financial data available | Unknown |
| Website | Unknown (maas.nl resolves to MAAS International BV vending company) | Direct fetch | Unknown |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | NL (assumed per brief) | Brief only | Estimated |
| Customer count | Unknown | No data found | Unknown |
| Target verticals | Corporate catering / hospitality B2B food ordering (per brief) | Brief only | Estimated |
| Market share estimate | Unknown | No data found | Unknown |
| Key competitors | Feedr (Eatfirst NL BV), DIS Daily Catering, Alma Catering Amsterdam, MeetMeals, GetChef's | Web research | Confirmed |

### Competitive Context (Netherlands B2B Corporate Catering / Online Ordering)

The Dutch B2B corporate meal ordering market includes the following confirmed players:
- **Feedr / Eatfirst Netherlands BV**: Cloud canteen service for offices; well-funded UK-origin platform with NL operations. Strong brand.
- **DIS Daily Catering** (eatdis.nl): Amsterdam-based B2B daily office lunch provider, est. 2015.
- **Alma Catering Amsterdam**: Chef-crafted B2B office catering in Amsterdam.
- **MeetMeals** (meetmeals.nl): Platform for ordering homemade office meals; B2B dashboard feature.
- **GetChef's**: Amsterdam social enterprise focused on reducing food waste in corporate/canteen settings.

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | B2B food ordering platform for corporate catering / hospitality (per brief) | Brief only | Estimated |
| Tech stack | Unknown | No product website or GitHub found | Unknown |
| Deployment model | Unknown | No data | Unknown |
| API availability | Unknown | No data | Unknown |
| Key integrations | Unknown | No data | Unknown |
| Mobile app | Unknown | No app store listing found | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No ownership data found | Unknown |
| Investor type | Unknown | No Crunchbase / Dealroom record | Unknown |
| PE ownership | Unknown | No PE tracking data found | Unknown |
| Succession signals | Unknown | No leadership data found | Unknown |
| Last funding date | Unknown | No fundraise records found | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No financial data | Unknown |
| Employee growth | Unknown | No headcount data | Unknown |
| New markets | Unknown | No data | Unknown |
| Recent product launches | Unknown | No press releases or product pages found | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Corporate catering, B2B hospitality food ordering (per brief) | Brief only | Estimated |
| GDPR/AVG compliance | Unknown | No privacy policy or product terms found | Unknown |
| Allergen management | Unknown | No product details available | Unknown |
| Fiscal compliance NL | Unknown | No product details available | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown | No payment documentation found | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown | No pricing page found | Unknown |
| Estimated ARR | Unknown | No financial data | Unknown |
| Estimated acquisition value | Unknown | Cannot estimate without revenue or headcount data | Unknown |
| Revenue per employee | Unknown | No data on either metric | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot assess — no ownership data | — |
| Revenue scale fit | High | N/A | Cannot assess — no revenue data; likely sub-€1M given zero public presence | — |
| Geographic fit | High | 3 | Amsterdam, NL per brief — aligns with thesis geography | Brief |
| Tech stack modernity | Medium | N/A | No product information available | — |
| Customer lock-in | Medium | N/A | B2B food ordering has moderate switching costs if integrated with ERP/HR | Market knowledge |
| Vertical depth | Medium | N/A | B2B food ordering for HORECA/corporate is a valid niche | Market knowledge |
| Integration potential | Low | N/A | Unknown without product information | — |
| Growth trajectory | Low | N/A | No data | — |

**Composite Score**: Insufficient data — N/A
**Confidence Band**: Wide (very limited public information)
**Overall M&A Assessment**: MaaS (Meals as a Service) has no publicly discoverable corporate profile as of 2026-04-30. The company either trades under a different legal name, is pre-revenue, or has exceptionally limited digital footprint. Without confirmed KvK registration, revenue data, or product information, SolStein cannot assess M&A feasibility at this time.
**Recommended Next Step**: Attempt direct outreach to the company via any known contact (e.g., domain registrant WHOIS, LinkedIn search for "Meals as a Service Amsterdam" or "MaaS horeca Amsterdam"). Consider engaging a Dutch company registry data provider (e.g., Companyweb NL, Bureau van Dijk) for a comprehensive search using SIC code 6202 (software) + Amsterdam postcode + founding year range 2018–2025.
