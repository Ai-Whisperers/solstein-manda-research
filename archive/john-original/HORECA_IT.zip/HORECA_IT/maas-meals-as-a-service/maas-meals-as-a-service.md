# MaaS (Meals as a Service)

**Category**: Online Ordering
**Country**: NL
**City**: Amsterdam
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history MaaS (Meals as a Service) @HORECA_IT/maas-meals-as-a-service/
@research-horeca-company MaaS (Meals as a Service) @HORECA_IT/maas-meals-as-a-service/
```
