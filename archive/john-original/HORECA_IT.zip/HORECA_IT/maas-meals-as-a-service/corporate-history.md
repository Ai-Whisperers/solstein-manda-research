# MaaS (Meals as a Service) — Corporate History

**Category**: Online Ordering (B2B)
**Country**: NL
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Unknown | OpenKvK.nl search returned no results for "meals as a service" or "MaaS" as B2B food platform | Unknown |
| KvK Number | Unknown | OpenKvK.nl — no matching entry found | Unknown |
| Registered City | Amsterdam (per brief) | Brief only — not confirmed via primary source | Estimated |
| Founding Year | Unknown | No public record found | Unknown |
| Founders | Unknown | No public record found | Unknown |
| Current Ownership | Unknown | No public record found | Unknown |
| PE/Investor Ownership | Unknown | No public record found | Unknown |
| Employees (FTE) | Unknown | LinkedIn company page not found | Unknown |
| Estimated Revenue | Unknown | No financial data found | Unknown |
| M&A History | None found | No public record found | Unknown |
| Investment Rounds | None found | No Crunchbase, Dealroom, or press record found | Unknown |
| Name Changes | Unknown | No historical KvK record available | Unknown |

---

## Research Notes

Extensive web research (10+ searches) conducted on 2026-04-30 yielded no publicly discoverable company operating under the name "MaaS (Meals as a Service)" or "Meals as a Service" as a B2B food ordering platform in Amsterdam, NL. Key findings:

- **OpenKvK.nl**: Search for "meals as a service" returned generic "as-a-service" companies; none matched a B2B food ordering platform in Amsterdam.
- **KvK.nl**: Search page failed to load; no direct result available.
- **LinkedIn**: No company page found for "MaaS Meals as a Service" or similar.
- **Crunchbase / Dealroom**: No matching Dutch startup found.
- **Web searches**: Closest entities found are MAAS International BV (vending company, Son en Breugel, est. 1889, owned by Belgian Miko Group — unrelated) and various B2B corporate food platforms (Feedr/Eatfirst Netherlands BV, DIS Daily Catering) that do not operate under the "MaaS" brand.
- **maas.nl**: Resolves to MAAS International BV (vending/beverage services), not a B2B food ordering platform.

The company may trade under a different legal name, may be a very recently incorporated entity not yet indexed, or may have very limited digital footprint. Research should continue via direct outreach or Dutch trade register API.

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown — Founder / Parent] --> B[Operating Company NL — Legal Entity Unknown]
    B --> C[MaaS B2B Food Ordering Platform]
```

---

## Timeline

```mermaid
timeline
    title MaaS Key Events
    Unknown : Founded — year not publicly available
    2026-04-30 : SolStein M&A research initiated — no public record found
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | Ownership structure not publicly available |
| PE-free | Unknown | No investor data found |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No financial data; likely pre-scale or very small given zero public presence |
| Geographic fit (NL/BE) | Estimated Yes | Brief states Amsterdam, NL — not independently confirmed |
| Succession signal | Unknown | No leadership data found |
| Overall feasibility | Unknown | Insufficient data to assess; company may not have significant scale yet |

---

## Recommended Next Steps

1. Direct outreach to confirm legal entity name and KvK number via WHOIS for any domain matching "maas-app.nl", "maas.io" or similar.
2. Search Dutch Trade Register API (kvk.nl/producten-bestellen) using SIC codes for food software / online ordering platforms in Amsterdam.
3. LinkedIn manual search for founders or employees referencing "Meals as a Service" platform in NL.
4. Check Dealroom.co and Crunchbase Pro for Dutch food-tech startups with "meals" or "corporate catering platform" tags in Amsterdam.
