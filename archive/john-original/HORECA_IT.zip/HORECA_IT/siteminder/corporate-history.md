# SiteMinder — Corporate History

**Category**: Hotel PMS / Distribution / Channel Manager
**Country**: Australia (Sydney HQ; ASX-listed); UK (London office)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (AU HQ; ASX-listed; global scale)

---

## Summary Assessment

SiteMinder is an **ASX-listed (SDR) Australian hotel commerce platform** providing channel management, booking engines, and revenue management tools for hotels worldwide. With **A$224.3M FY2025 revenue**, a London UK office among its global offices, and 450+ OTA connections, it is a global-scale public company entirely outside SolStein's acquisition criteria. Relevant as the **global benchmark for hotel channel management and distribution**.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | SiteMinder Limited | ASX: SDR | Confirmed |
| ASX ticker | SDR | siteminder.com/investor-relations | Confirmed |
| HQ | Sydney, Australia | siteminder.com, LinkedIn | Confirmed |
| Founded | 2006 | LinkedIn | Confirmed |
| UK office | London, UK | siteminder.com, LinkedIn | Confirmed |
| Other offices | Bangkok, Barcelona, Berlin, Dallas, Galway, Manila, Mexico City, Pune | siteminder.com | Confirmed |
| Revenue FY2025 | A$224.3M | intelligentinvestor.com.au | Confirmed |
| Exchange | Australian Securities Exchange (ASX) | ASX: SDR | Confirmed |
| Ownership | Public (ASX-listed); no single controlling shareholder | ASX filing | Confirmed |
| Core products | Channel Manager, Booking Engine, Revenue Management, Distribution | siteminder.com | Confirmed |
| OTA connections | 450+ | siteminder.com | Confirmed |
| Key recognition | #1 Channel Manager 2026 (self-reported) | siteminder.com | Confirmed |
| UK entity | SiteMinder UK entity registered; London office for UK/European sales | siteminder.com | Confirmed |
| Hotel customers | Not disclosed; largest hotel channel management platform globally | siteminder.com | Confirmed |

---

## Founding & Corporate History

SiteMinder was founded in **Sydney, Australia in 2006** with the vision of democratising hotel distribution — giving independent and mid-market hotels the same OTA connectivity tools that large chains had. The company built the world's most widely connected hotel channel management platform.

**Growth milestones:**
- 2006: Founded in Sydney
- 2000s–2010s: Scaled to become globally dominant hotel channel manager
- 2021: **IPO on the ASX** (Australian Securities Exchange) under ticker **SDR** — raising capital for global expansion
- 2022–2025: Continued expansion across all global markets; London, Berlin, Barcelona, Dallas, and other regional offices established; FY2025 revenue A$224.3M

The **London UK office** serves as SiteMinder's European commercial hub, with the UK and European hotel markets as significant revenue contributors.

**FY2025 performance**: A$224.3M revenue — consistent with the company's position as the world's largest hotel channel management platform.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["ASX Public Shareholders<br/>(SiteMinder Limited — ASX: SDR)"]
    B["SiteMinder Limited<br/>(Sydney, Australia — Global HQ)"]
    C["UK / European Operations<br/>(London office)"]
    D["Other Regional Offices<br/>(Bangkok, Barcelona, Berlin, Dallas, Galway, Manila, Mexico City, Pune)"]

    A -->|"Public shareholders"| B
    B --> C
    B --> D
```

---

## Timeline of Critical Events

```mermaid
timeline
    title SiteMinder — Key Milestones
    2006 : Founded in Sydney, Australia; hotel channel management platform
    2010s : Global expansion; 450+ OTA connections; dominant market position
    2021 : IPO on ASX (ticker: SDR)
    2024-2025 : FY2025 revenue A$224.3M; AI distribution platform launched; 450+ OTAs; London + global offices
    2026 : #1 channel manager (self-reported); 9 global offices including London
```

---

## M&A Feasibility Assessment

### Is SiteMinder an Acquisition Target for SolStein?

**Answer: No. ASX-listed public company; A$224M+ revenue; global scale.**

| Factor | Assessment |
|---|---|
| **Scale** | A$224.3M revenue (~€135M) — 9–135x above SolStein's target range |
| **Ownership** | ASX-listed public company — no founder-owned angle; requires full public market acquisition |
| **Geography** | Australian HQ; global operations including UK; not NL/BE-focused |
| **Succession** | Professional management; no succession gap |
| **Exit pathway** | Would require delisting acquisition at significant premium — not applicable |

### Role for SolStein

1. **Channel management benchmark**: SiteMinder defines the hotel distribution and channel management category globally. Any NL/BE channel management company is benchmarked against this.
2. **EU hotel distribution**: The fact that SiteMinder has offices in Barcelona, Berlin, and London (not NL/BE) suggests NL/BE hotels connect to OTAs through either SiteMinder or regional alternatives.
3. **NL/BE opportunity**: Small NL/BE channel management or PMS-with-channel companies at €1–10M ARR, founder-owned, represent the SolStein opportunity in this category.

---

*Sources: siteminder.com, siteminder.com/investor-relations, intelligentinvestor.com.au (ASX: SDR), LinkedIn (SiteMinder company profile), siteminder.com/news/siteminder-partner-awards-2025/.*
