# SiteMinder

**Category**: Hotel PMS/Distribution
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history SiteMinder @HORECA_IT/siteminder/
@research-horeca-company SiteMinder @HORECA_IT/siteminder/
```
