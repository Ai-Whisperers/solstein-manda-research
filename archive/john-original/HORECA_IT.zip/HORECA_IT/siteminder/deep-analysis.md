# SiteMinder — Deep Analysis

**Category**: Hotel PMS / Distribution / Channel Manager
**Country**: Australia (Sydney HQ; ASX: SDR); UK (London office)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (AU HQ; ASX-listed; global hotel distribution platform)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal name | SiteMinder Limited | ASX: SDR | Confirmed |
| HQ | Sydney, Australia | siteminder.com | Confirmed |
| UK office | London, UK | siteminder.com | Confirmed |
| Founded | 2006 | LinkedIn | Confirmed |
| Ownership | ASX-listed public company (ticker: SDR) | siteminder.com/investor-relations | Confirmed |
| Revenue FY2025 | A$224.3M (~€135M) | intelligentinvestor.com.au | Confirmed |
| Employees | Not disclosed; large scale (estimated 1,000–2,000) | Scale inference | Estimated |
| Business model | SaaS hotel commerce platform (channel + booking + revenue management) | siteminder.com | Confirmed |
| OTA connections | 450+ | siteminder.com | Confirmed |
| Key products | Channel Manager, Booking Engine, Revenue Management, AI Distribution | siteminder.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Global position | #1 hotel channel manager (self-reported 2026) | siteminder.com | Confirmed |
| Customers | Not disclosed; global hotel market leader | siteminder.com | Estimated |
| UK presence | London office; UK hotels significant customer segment | siteminder.com | Confirmed |
| EU presence | Barcelona, Berlin offices; EU hotels significant | siteminder.com | Confirmed |
| NL/BE presence | Not a stated priority office; but NL/BE hotels likely use platform | siteminder.com | Estimated |
| Target customer | Hotels of all sizes (boutique to enterprise) | siteminder.com | Confirmed |
| OTA network | 450+ OTAs; Booking.com, Expedia, Airbnb, etc. | siteminder.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Channel Manager | Core product; distributes hotel rates to 450+ OTAs | siteminder.com | Confirmed |
| Booking Engine | Direct booking conversion tool | siteminder.com | Confirmed |
| Revenue Management | Pricing and yield management tools | siteminder.com | Confirmed |
| AI Distribution | AI-era hotel distribution (2026 launch) | siteminder.com | Confirmed |
| Channels Plus | Premium channel expansion product | FY25 Annual Report | Confirmed |
| Dynamic Revenue Plus | Dynamic pricing AI tool | FY25 Annual Report | Confirmed |
| Deployment | Cloud SaaS; API-first | siteminder.com | Confirmed |
| Tech stack | Cloud-native; enterprise-scale data platform | siteminder.com | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Ownership | Public shareholders (ASX-listed) | ASX: SDR | Confirmed |
| IPO year | 2021 | ASX filings | Confirmed |
| Founder status | Not prominently featured in current management; professional CEO | siteminder.com | Estimated |
| Acquisition target? | Would require full public market takeover bid — not applicable | — | Confirmed |
| Strategic context | ASX-listed; potential acquisition target for large travel tech (Booking Holdings, Expedia) | Industry speculation | Estimated |

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Source | Confidence |
|---|---|---|---|
| FY2025 | A$224.3M | intelligentinvestor.com.au | Confirmed |
| Prior years | Available via ASX filings | ASX: SDR | Confirmed |
| Growth | Consistent growth; AI product investment in 2025–2026 | FY25 Annual Report | Confirmed |
| Profitability | Approaching/at profitability (typical for growth SaaS at this scale) | ASX filings | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Hotel distribution | Market-defining; 450+ OTA connections | siteminder.com | Confirmed |
| Revenue management | Pricing optimisation for hotels | siteminder.com | Confirmed |
| EU/UK hotel compliance | Full EU/UK payment and data compliance | siteminder.com | Confirmed |
| Multi-currency | Global multi-currency platform | siteminder.com | Confirmed |
| UK VAT / EU VAT | Compliant (global platform) | siteminder.com | Confirmed |
| STR / vacation rentals | Not primary focus; hotel-focused | siteminder.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription per hotel + connection fees | siteminder.com | Confirmed |
| ARR | ~A$224M (=~€135M) | intelligentinvestor.com.au | Confirmed |
| Market capitalisation | Varies; ASX: SDR; roughly A$1.5–2.5B range (typical for SaaS at this scale) | ASX market data | Estimated |
| Revenue multiple | ~7–11x ARR (typical for public SaaS) | Derived | Estimated |
| SolStein fit | No — public company; A$224M ARR; global | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | ASX-listed public company; no founder-owned angle; no private ownership | ASX: SDR |
| Revenue scale fit | High | 1 | A$224M ARR — ~9–150x above SolStein's €1–15M target | intelligentinvestor.com.au |
| Geographic fit | High | 2 | UK + EU offices; EU/NL/BE hotels use platform; but AU HQ + global, not NL/BE-focused | siteminder.com |
| Tech stack modernity | Medium | 5 | Cloud-native; API-first; AI distribution; 450+ OTA integrations | siteminder.com |
| Customer lock-in | Medium | 5 | Channel management creates highest hospitality lock-in (all OTA distribution runs through it) | siteminder.com |
| Vertical depth | Medium | 5 | Market-defining hotel distribution platform; deep revenue management | siteminder.com |
| Integration potential | Low | 5 | 450+ OTA integrations; open API; PMS integrations | siteminder.com |
| Growth trajectory | Low | 4 | Consistent growth; AI product investment; approaching profitability | FY25 Annual Report |

### Composite Score

**Weighted Composite: 2.5 / 5.0**

*(Ownership = 1, revenue scale = 1 — high-weight decisive blockers)*

**Confidence Band**: High — public company with confirmed financials; UK presence confirmed.

### Overall M&A Assessment

SiteMinder is **not an acquisition target** for SolStein in any scenario. It is a global, ASX-listed hotel commerce platform with A$224M ARR. Its value to SolStein is as the **definitive channel management benchmark**: any NL/BE hotel PMS or channel management company is evaluated against what SiteMinder provides at global scale.

**NL/BE observation**: SiteMinder has offices in Barcelona and Berlin but not Amsterdam or Brussels — suggesting NL/BE hotel distribution is served through either SiteMinder's platform (self-serve) or regional PMS+channel management providers. This gap is an opportunity for NL/BE hotel PMS companies with integrated channel management.

### Recommended Next Step

No pursuit. Use as global channel management benchmark. Evaluate NL/BE hotel PMS companies with OTA channel integration (Misterbook, Cubilis) against SiteMinder's product breadth.

---

*Sources: siteminder.com, siteminder.com/investor-relations, intelligentinvestor.com.au (ASX: SDR), LinkedIn (SiteMinder company profile), FY25 Annual Report.*
