# Beambox — Corporate History

**Category**: Guest WiFi / Marketing Automation
**Country**: UK (Bristol, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; bootstrapped, micro-scale)

---

## Summary Assessment

Beambox is a **bootstrapped, Bristol-based** guest WiFi marketing platform founded in 2015 by Callum Short. With no external funding, ~5 employees, ~$525K revenue (2024 estimate), and 12,000+ business customers globally, it is an organically grown micro-SaaS company. An M&A offer was noted in April 2025 (outcome unknown). Beambox is too small for SolStein's operational interest but is a useful **guest WiFi benchmark**. Note: the user listed HQ as London — research confirms Bristol.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Beambox | beambox.com | Confirmed |
| HQ | Bristol, UK (not London as initially listed) | Getlatka, tracxn.com | Confirmed |
| Founded | 2015 | Getlatka, tracxn.com | Confirmed |
| Founder | Callum Short (Cal Short) | FE International case study | Confirmed |
| Employees | ~5 | Getlatka (Oct 2022 data) | Estimated |
| Revenue (2024) | ~$525.1K | Getlatka | Estimated |
| External funding | $0 (unfunded / bootstrapped) | Getlatka, tracxn.com | Confirmed |
| M&A offer | April 2025 (amount/outcome not disclosed) | Getlatka | Confirmed |
| Business customers | 12,000+ globally | beambox.com | Confirmed |
| Product | Cloud-managed guest WiFi marketing platform (data capture + email/SMS + reviews) | beambox.com | Confirmed |
| Target sectors | Restaurants, hotels, retail, salons | beambox.com | Confirmed |
| Hardware | "Plug & Play" WiFi access point + cloud software | beambox.com | Confirmed |

---

## Founding & History

**Callum Short** founded Beambox in **Bristol in 2015** with a vision to help small hospitality and retail businesses turn their guest WiFi into a marketing asset. The product captures customer data at the WiFi login stage (captive portal) and uses that data for automated email/SMS marketing, review management, and loyalty campaigns.

Beambox has been deliberately bootstrapped — no external investors, growing through organic customer acquisition and direct sales. Short documented his journey building and exiting (partial?) a SaaS business in a case study with **FE International** (a SaaS acquisition marketplace) — suggesting the founder has considered a sale.

**April 2025**: Getlatka notes an M&A offer. The outcome of this offer is not confirmed in research. If the company was sold, the acquirer has not been publicly announced.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Callum Short (Founder)"]
    B["Beambox<br/>(Bristol, UK — bootstrapped)"]
    C["12,000+ business customers<br/>globally (restaurants, hotels, retail)"]

    A -->|"Sole/primary owner"| B
    B --> C
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Beambox — Key Milestones
    2015 : Founded by Callum Short in Bristol; guest WiFi marketing platform
    2022 : ~5 employees; ~$525K revenue; 12,000+ businesses; zero external funding
    2025 : M&A offer received (Apr 2025); outcome unknown
    2026 : Active; 12,000+ businesses; beambox.com operating
```

---

## M&A Feasibility Assessment

### Is Beambox an Acquisition Target for SolStein?

**Answer: Not suitable — UK (Bristol); too small; potential prior M&A offer.**

| Factor | Assessment |
|---|---|
| **Scale** | ~$525K revenue — below SolStein's €1M+ ARR floor |
| **Geography** | UK (Bristol) only; no NL/BE presence |
| **Ownership** | Bootstrapped founder-owned (positive signal) BUT already received M&A offer |
| **Succession** | Founder interested in exit (FE International case study, M&A offer) |
| **Exit pathway** | M&A offer in Apr 2025 — may already have been acquired |

### Role for SolStein

1. **Guest WiFi benchmark**: Defines the product category (captive portal WiFi data capture + marketing automation) at SMB scale.
2. **Bootstrapped exit pattern**: Confirms that bootstrapped WiFi marketing companies do get acquired (M&A offer received). Equivalent NL/BE company might be accessible.
3. **Revenue scale**: $525K revenue is too small for SolStein's €1–15M target range. But validates the category exists at this micro scale.

---

*Sources: beambox.com, Getlatka (getlatka.com/companies/beambox), tracxn.com, FE International case study (feinternational.com).*
