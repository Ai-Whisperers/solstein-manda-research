# Beambox — Deep Analysis

**Category**: Guest WiFi / Marketing Automation
**Country**: UK (Bristol, England — not London)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; bootstrapped micro-SaaS; M&A offer Apr 2025)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Beambox | beambox.com | Confirmed |
| HQ | Bristol, UK | Getlatka, tracxn.com | Confirmed |
| Founded | 2015 | Getlatka | Confirmed |
| Founder | Callum Short | FE International case study | Confirmed |
| Ownership | Founder-owned (bootstrapped); M&A offer Apr 2025 | Getlatka, FE International | Confirmed |
| Employees | ~5 | Getlatka | Estimated |
| Revenue | ~$525.1K (2024) | Getlatka | Estimated |
| External funding | $0 | Getlatka, tracxn.com | Confirmed |
| M&A offer | Received April 2025; outcome unknown | Getlatka | Confirmed |
| Business model | SaaS subscription + hardware (WiFi access point) | beambox.com | Confirmed |
| Customers | 12,000+ businesses globally | beambox.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK market | Primary; UK SMB hospitality and retail | beambox.com | Confirmed |
| International customers | 12,000+ globally (including UK, US, international) | beambox.com | Confirmed |
| NL/BE presence | Not confirmed | — | Unknown |
| HORECA verticals | Restaurants, hotels, cafes, retail, salons | beambox.com | Confirmed |
| Target customer | SMB (1–10 locations) | beambox.com | Confirmed |
| Market position | Niche; one of many guest WiFi platforms | tracxn.com | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | Guest WiFi marketing platform (captive portal + data capture + campaigns) | beambox.com | Confirmed |
| Hardware | Plug-and-play WiFi access point (connects to existing router) | beambox.com | Confirmed |
| Software | Cloud-based marketing automation | beambox.com | Confirmed |
| Data capture | Customer visit frequency, dwell time, demographic data via WiFi login | beambox.com | Confirmed |
| Marketing automation | Email, SMS, review management, loyalty | beambox.com | Confirmed |
| AI features | AI-powered email templates | beambox.com | Confirmed |
| Deployment | Hardware (Plug & Play AP) + Cloud SaaS | beambox.com | Confirmed |
| Pricing | SaaS subscription + hardware purchase | beambox.com | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Ownership | Founder-owned (Callum Short) | FE International | Confirmed |
| PE backing | None | Getlatka | Confirmed |
| Founder exit interest | Yes — FE International case study suggests exit consideration; M&A offer Apr 2025 | FE International, Getlatka | Confirmed |
| M&A offer outcome | Unknown — not publicly disclosed | Getlatka | Unknown |
| Current status | Likely still active (beambox.com operating as of Apr 2026) | beambox.com | Estimated |

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Employees | Source | Confidence |
|---|---|---|---|---|
| 2024 | ~$525.1K | ~5 | Getlatka | Estimated |
| Growth rate | Unknown | — | — | Unknown |
| Customers | 12,000+ | beambox.com | Confirmed |

$525K revenue / 12,000+ customers implies ~$44/customer/year average — very low, suggesting micro-SMB pricing. Organic growth maintained with 5-person team. Lean, bootstrapped, profitable likely.

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| WiFi marketing | Core capability | beambox.com | Confirmed |
| UK GDPR compliance | Data capture via WiFi requires GDPR consent | UK GDPR | Confirmed |
| Review management | Google Reviews automation | beambox.com | Confirmed |
| Loyalty | Basic loyalty features | beambox.com | Confirmed |
| Multi-location | Limited multi-location management | beambox.com | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription + hardware unit price | beambox.com | Estimated |
| ARR estimate | ~$500K | Getlatka | Estimated |
| Acquisition value | £300K–£1.5M (4–15x EBITDA for micro-SaaS) | FE International market norms | Estimated |
| SolStein fit | No — too small; UK (Bristol); potential prior acquisition | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 4 | Bootstrapped founder-owned; founder exit interest confirmed; but M&A offer already received | Getlatka, FE International |
| Revenue scale fit | High | 1 | ~$525K — below SolStein's €1M+ floor | Getlatka |
| Geographic fit | High | 1 | UK (Bristol); no NL/BE presence | beambox.com |
| Tech stack modernity | Medium | 4 | Cloud SaaS + hardware; AI email templates; modern marketing automation | beambox.com |
| Customer lock-in | Medium | 3 | WiFi hardware creates some lock-in; marketing platform switching is easy | beambox.com |
| Vertical depth | Medium | 2 | WiFi marketing only; not deep HORECA operations | beambox.com |
| Integration potential | Low | 3 | Some integrations; limited ecosystem | beambox.com |
| Growth trajectory | Low | 2 | Micro-scale; organic growth; micro-SMB market | Getlatka |

### Composite Score

**Weighted Composite: 2.0 / 5.0**

*(Revenue scale = 1, geographic fit = 1 — high-weight blockers)*

**Confidence Band**: Low — revenue estimated; M&A outcome unknown; minimal public financial data.

### Overall M&A Assessment

Beambox is **not a SolStein target** — too small (sub-€1M ARR), UK-only, and may have already been acquired (M&A offer Apr 2025). It is a useful **guest WiFi product benchmark** at the SMB micro-SaaS end. If any NL/BE guest WiFi marketing company exists at €1–5M ARR, founder-owned, it would be a better-fitting SolStein candidate.

### Recommended Next Step

No pursuit. Use as guest WiFi category benchmark. Note founder-exit interest pattern (FE International + M&A offer) as evidence that micro-SaaS HORECA WiFi founders do seek exits. Monitor NL/BE guest WiFi companies.

---

*Sources: beambox.com, Getlatka, tracxn.com, FE International (feinternational.com/blog/case-study-beambox).*
