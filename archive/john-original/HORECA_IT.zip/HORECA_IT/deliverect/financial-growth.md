# Financial & Growth Deep-Dive — Deliverect

**Research Date**: 2026-04-30
**Data Availability**: Medium-High — Belgian statutory accounts via Tracxn/KBO (FY2024 confirmed); funding rounds confirmed via PRNewswire + TechCrunch; revenue estimates 2019–2023 from secondary sources (Latka, Growjo) cross-checked against operational metrics; employee data from LinkedIn + Tracxn + Globalization Partners case study.

---

### Revenue Timeline

| Year | Revenue | Currency | EUR Equivalent | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| 2026 (est.) | ~€38–42M | EUR | €38–42M | ~+15% | Extrapolation from 2024 trajectory | Estimated |
| 2025 (est.) | ~€36–40M | EUR | €36–40M | ~+10% | Extrapolation from 2024; no new data | Estimated |
| 2024 | €33.8M | EUR | €33.8M | +17% | Tracxn (Belgian statutory accounts, FY2024) | Confirmed (statutory) |
| 2023 | ~€29M | USD $31.7M | ~€29M | +45% | Latka (CEO interview); EUR/USD avg 2023 ≈1.08 | Estimated |
| 2022 | ~€18–20M | EUR | ~€18–20M | ~+58% | Estimated: 32,000 clients × implied ARPU; no direct filing | Estimated (proxy) |
| 2021 | ~€12M | USD $14M | ~€12M | — | Latka (CEO interview); EUR/USD avg 2021 ≈1.18 | Estimated |
| 2020 | ~€2.5M | EUR | ~€2.5M | — | Proxy: Series B raised Apr 2020; 750% order growth signal; very early-stage | Estimated (proxy) |
| 2019 | ~€0.5M | EUR | ~€0.5M | — | Proxy: Series A Apr 2019; 4–5 pilot clients; effectively pre-revenue | Estimated (proxy) |

> **Note on revenue discrepancy**: Latka reports $44.7M for 2024 (≈€41M at 1.09 EUR/USD), while Tracxn reports €33.8M from Belgian statutory accounts. The gap (~€7M) likely reflects revenue booked in non-Belgian subsidiaries not captured in the Belgian legal entity filing. The statutory figure is used as primary. Latka's figure may be closer to global group ARR.

**Revenue CAGR (3yr, 2021→2024)**: ~**41%** (€12M → €33.8M)
**Revenue CAGR (5yr, 2019→2024)**: ~**132%** (€0.5M → €33.8M; primarily reflects hypergrowth from near-zero base)

#### Revenue Trend Chart

```mermaid
xychart-beta
    title "Deliverect Revenue Trend (EUR M, estimated)"
    x-axis [2020, 2021, 2022, 2023, 2024]
    y-axis "EUR Millions" 0 --> 40
    line [2.5, 12, 19, 29, 34]
```

---

### Profitability

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| EBITDA (current) | Unknown — not disclosed; likely negative (still investing in growth) | — | Unknown |
| EBITDA Margin | Unknown; VC-funded SaaS at this stage typically -20% to -40% EBITDA margin | — | Estimated |
| Net Profit / Loss | Not disclosed; Belgian KBO filings not yet publicly accessible for FY2024 in detail | KBO/NBB | Unknown |
| Recurring Revenue % | ~90%+ (subscription SaaS per location; minimal one-time setup) | Pricing model analysis; industry standard | Estimated |
| SaaS / Subscription Revenue % | ~90%+ (cloud-native; Tabesto hardware adds minor non-recurring revenue post-Dec 2024) | deliverect.com pricing | Estimated |
| Revenue per Employee (EUR) | ~€73K | Calculated: €33.8M ÷ 462 employees (2026) | Estimated |

> **Profitability note**: Revenue-per-employee of €73K is below the €100–150K benchmark for efficient SaaS companies, consistent with a growth-mode company still investing heavily in international sales, support, and product. Hardware revenue from Tabesto kiosks (post Dec 2024) will add lower-margin product revenue.

---

### Funding & Investment History

| Date | Round | Amount | Lead Investor(s) | Valuation | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| Sep 2018 | Seed | ~$0.1M | — (founders + angels) | — | Tracxn; PitchBook | Estimated |
| Apr 2019 | Series A | $3.4M | Newion, Smartfin Capital | — | Tracxn; Seedtable | Confirmed |
| Apr 2020 | Series B | €16.25M (~$17.6M) | OMERS Ventures | — | deliverect.com blog; PRNewswire | Confirmed |
| Apr 2021 | Series C | $65M | DST Global Partners, Redpoint Ventures | — | deliverect.com/series-c blog | Confirmed |
| Jan 2022 | Series D | $150M (official) | Coatue Management, Alkeon Capital Management | $1.4B (post-money) | PRNewswire; TechCrunch; deliverect.com | Confirmed |

> **Series D amount note**: Deliverect's own blog, TechCrunch, and PRNewswire consistently report $150M for Series D (bringing total to ~$240M). Tracxn and iTnews report $208M / $332M total — this discrepancy may reflect additional tranches, convertible notes, or secondary transactions not publicly announced. The $150M/$240M figures are used as primary.

**Total Raised**: ~$240M officially (Series A through D); potentially $332M per Tracxn (including undisclosed tranches)
**Latest Valuation**: $1.4B (post-money, Jan 2022 Series D) — no new round since; current fair-value likely $200–500M given SaaS multiple compression post-2022
**Current Investors**: Coatue Management, Alkeon Capital Management (Series D leads); DST Global Partners, Redpoint Ventures (Series C leads); OMERS Ventures (Series B lead); Newion, Smartfin Capital (Series A)
**War Chest Signals**: ~$150M raised in Jan 2022; subsequent M&A (ChatFood, Tabesto — both undisclosed but likely <$20M each); burn rate estimated at €15–25M/year (headcount + global offices); remaining runway uncertain but no new financing in 4+ years signals approaching cashflow breakeven or investor pressure for exit

---

### Employee Timeline

| Year | Headcount | YoY Growth | Source | Confidence |
| --- | --- | --- | --- | --- |
| 2026 (current) | ~462 | -1% | LinkedIn company page; Tracxn (Mar 2026: 461) | Confirmed |
| 2025 | ~465 | -7% | Interpolated between 2024 and 2026 data | Estimated |
| 2024 | ~470–500 | -6% | Latka (470); Growjo (532); Tracxn range | Estimated |
| 2023 | ~500 | +43% | Deliverect blog: "more than 500 dedicated professionals"; Globalization Partners case study (30→500) | Confirmed |
| 2022 | ~350 | +338% | Estimated: mid-point of rapid scaling post-Series D; Globalization Partners: 40 new markets using EOR | Estimated (proxy) |
| 2021 | 80 | — | Tracxn (Dec 31, 2021: 80 employees) | Confirmed |
| 2019 | ~30 | — | Globalization Partners case study: "30 employees, 5 offices" | Confirmed |

**Employee CAGR (3yr, 2021→2024)**: ~**81%** (80 → ~470)
**Employee CAGR (2yr post-peak, 2023→2026)**: **-3%** (headcount plateauing / modest contraction since peak in 2023)
**Current Open Positions**: Not systematically tracked; careers page shows 30–50 roles (product, engineering, enterprise sales focus) as of Apr 2026
**Hiring Hotspots**: Ghent (engineering/product), London (enterprise sales), Austin TX (US expansion), Dubai (MENA)

> **Headcount trajectory signal**: Rapid scale-up 2021→2023 (×6 headcount) fueled by Series D capital; plateau and slight contraction 2023→2026 reflects post-growth-mode efficiency focus and absence of new funding round. This is a common pattern for late-stage VC-backed SaaS companies optimizing toward profitability before exit.

#### Employee Growth Chart

```mermaid
xychart-beta
    title "Deliverect Employee Growth"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "Headcount" 0 --> 550
    line [80, 350, 500, 485, 465, 462]
```

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
| --- | --- | --- | --- | --- | --- |
| 2018–2019 | Founded; initial clients | BE, NL | Ghent HQ; first restaurant clients in Belgium and Netherlands; 5 offices by end of 2019 | deliverect.com; KBO | Confirmed |
| Apr 2019 | Series A funded | BE/NL/UK | Funds used to enter UK market (London first major international target) | Tracxn; Globalization Partners | Estimated |
| Apr 2020 | Series B + COVID acceleration | BE, NL, UK, ES, FR | €16.25M raised; COVID lockdowns spike delivery demand; rapid client acquisition across W. Europe | deliverect.com/series-b blog | Confirmed |
| Oct 2020 | New market announcements | Nordics, AU, UAE, MX | Explicit expansion announcement: Nordics, Australia, UAE, Mexico added | PRNewswire Oct 2020 | Confirmed |
| Apr 2021 (Series C) | 30 markets globally | Global | Offices: Ghent, London, Madrid, Toronto, New York, Dubai, Paris, Edinburgh, Mexico City, Amersfoort | deliverect.com/series-c blog | Confirmed |
| Jan 2022 (Series D) | Unicorn + 20,000+ clients | Global 50+ countries | $150M to accelerate to 50+ countries; Deliverect Marketplace launched; 200M orders by end 2022 | deliverect.com | Confirmed |
| 2022–2023 | 40 new markets via EOR | Global | Used Globalization Partners (EOR) to enter 40 new markets in 2 years; 500 employees in new geographies | Globalization Partners case study | Confirmed |
| 2023 | ChatFood acquisition | UAE/MENA | ChatFood headquartered Dubai; strengthened MENA social/dine-in ordering capabilities | deliverect.com/acquires-chatfood | Confirmed |
| 2024 | Tabesto acquisition | FR/EU | French kiosk company; strengthened in-store omnichannel in France and W. Europe | BusinessWire Dec 2024 | Confirmed |
| Jul 2025 | 1B orders milestone | Global | 1 billion cumulative orders across all markets | TechPulseMEA Jul 2025 | Confirmed |
| Apr 2026 | Papa Johns partnership | US | Multi-unit enterprise partnership with Papa Johns US | PRNewswire Mar 2026 | Confirmed |

**Primary Market**: Global (founded in Belgium; revenue spread across 52 countries)
**NL/BE Market**: Historical founding market; NL/BE website + local support maintained; NL/BE estimated 5–10% of current revenue given global scale
**International Revenue %**: Not disclosed; estimated 85%+ outside NL/BE based on global client distribution
**Expansion Trajectory**: Intercontinental from 2020 onward; 30 countries by Apr 2021, 50+ by Jan 2022, 52 by 2026 — classic VC-funded "plant the flag" global expansion strategy. Expansion now consolidated and focused on enterprise accounts in major markets.

---

### M&A Activity

| Date | Target / Event | Deal Size | Capability / Market Gained | Strategic Rationale | Source | Confidence |
| --- | --- | --- | --- | --- | --- | --- |
| May 10, 2023 | ChatFood (Dubai) | Undisclosed (estimated <$15M) | Social media ordering (WhatsApp, Instagram), dine-in QR, loyalty programs | Expand from delivery-only to full omnichannel; add D2C/direct channels to complement delivery aggregation | deliverect.com; PRNewswire May 2023 | Confirmed (price unconfirmed) |
| Dec 3, 2024 | Tabesto SAS (France) | Undisclosed (estimated <$20M) | Self-order kiosk hardware + software for QSR / fast casual; in-store ordering | Complete omnichannel stack: delivery + dine-in QR + kiosk; enter hardware-adjacent market | BusinessWire Dec 2024 | Confirmed (price unconfirmed) |

**Divestitures**: None identified (2018–2026)
**Been Acquired By**: No — Deliverect remains independent VC-backed company as of Apr 2026
**M&A Pattern**: Deliberate capability-building acquisitions, not geographic plays. Both ChatFood and Tabesto fill specific product gaps in the "beyond delivery" omnichannel vision: ChatFood adds social + dine-in ordering channels; Tabesto adds the in-store kiosk vertical. Combined with Deliverect's core delivery aggregation, these build a complete restaurant commerce platform. The pattern signals preparation for a larger strategic exit (IPO or acquisition by a delivery platform or POS consolidator).

---

### SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
| --- | --- | --- | --- |
| Deployment Model | Cloud-native SaaS from day 1 (founded 2018 as cloud-only) | deliverect.com/developers | Confirmed |
| Cloud Revenue % (current) | ~90%+ (Tabesto hardware adds minor non-recurring post-Dec 2024) | Product analysis; pricing model | Estimated |
| Recurring Revenue % | ~90%+ (subscription per location; minimal one-time fees) | Pricing model; industry standard for SaaS | Estimated |
| Payment Integrations | iDEAL (NL), Bancontact (BE), Stripe, and others via Tabesto kiosk and Deliverect Direct | deliverect.com; manda.be | Confirmed |
| Platform Stack | API-first REST + webhook architecture; Node.js/React ecosystem (inferred from job postings); cloud-native microservices | deliverect.com/developers; LinkedIn job postings | Estimated |
| API / Integration Model | Open partner API; 1,000+ integrations (POS, delivery platforms, payment, e-commerce); developer portal active | deliverect.com/developers | Confirmed |
| Migration Status | N/A — cloud-native from founding; no on-premise legacy to migrate | — | Confirmed |

---

### Growth Scorecard

| Dimension | Score (1–10) | Evidence Summary |
| --- | --- | --- |
| Revenue Growth | **9** | 3yr CAGR ~41% (€12M→€34M, 2021–2024); 5yr CAGR ~132%; exceeds 30% threshold for top-tier score |
| Funding Momentum | **3** | No new rounds since Jan 2022 ($150M Series D); $0 raised in last 3yr (2023–2026); investor pressure for exit building |
| Employee Growth | **10** | 3yr CAGR ~81% (80→470, 2021–2024); aggressive intercontinental hiring using EOR model; headcount ×6 in 3 years |
| Geographic Expansion | **10** | 30 countries by Apr 2021; 52+ countries by 2026; entered 3+ new countries every year for 5 consecutive years; intercontinental |
| M&A Activity | **7** | 2 bolt-on acquisitions in last 3yr (ChatFood May 2023, Tabesto Dec 2024); clear capability-building pattern (dine-in + kiosk) |
| SaaS Maturity | **10** | Cloud-native from founding 2018; >90% recurring revenue; 1,000+ open API integrations; iDEAL/Bancontact/Stripe payments |
| **COMPOSITE SCORE** | **8.2** | **Rocket — explosive growth, heavy historic investment, global market disruptor** |

**Classification Thresholds**:

- **Rocket** (avg 7.0–10.0): Explosive growth, heavy investment, market disruptor ← **Deliverect**
- **Riser** (avg 5.0–6.9): Strong growth signals, investing in future, accelerating
- **Steady** (avg 3.0–4.9): Stable but not transforming, evolutionary
- **Dinosaur** (avg 1.0–2.9): Flat or declining, legacy mode, no visible investment

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "Deliverect Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "SaaS"]
    y-axis "Score" 0 --> 10
    bar [9, 3, 10, 10, 7, 10]
```

---

### Key Financial Insights for SolStein M&A Pipeline

1. **Growth Rocket, Wrong Scale**: Deliverect scores 8.2/10 on the Growth Scorecard — a genuine "Rocket" by any measure. However, this growth confirms its unsuitability as a SolStein acquisition target: at €34–45M ARR with 52-country reach, it requires a $500M–$1.5B acquirer.

2. **Funding Gap Risk**: No new external funding since January 2022 (4+ years). With Coatue (a crossover hedge fund) expecting liquidity typically within 5–8 years of investment, exit pressure intensifies from 2027. Deliverect will either IPO or be acquired by a major platform in 2026–2028 — not by SolStein.

3. **Revenue Quality**: ~90%+ recurring revenue, cloud-native, 1,000+ integrations, and payment integrations across NL/BE/EU — the SaaS fundamentals are best-in-class. Revenue-per-employee (€73K) reflects growth-mode spending, not efficiency.

4. **Headcount Peak Signal**: Peak headcount ~500 in 2023 declining to ~462 in 2026. This plateau (without new capital) suggests the company is transitioning from growth mode to profitability mode — typical pre-exit behavior.

5. **M&A Pattern**: Two acquisitions in 18 months (ChatFood + Tabesto) indicate the company is building toward a complete restaurant commerce platform rather than staying in its delivery aggregation niche. Strategic acquirers (DoorDash, Uber Eats, Oracle Hospitality) would acquire the complete stack.

6. **SolStein Relevance**: Use Deliverect's SaaS metrics as benchmarks when valuing smaller HORECA IT targets. Any NL/BE POS or delivery software company must demonstrate compatibility with Deliverect's 1,000+ integration ecosystem — those with existing Deliverect integration partnerships have defensible positioning; those competing directly face existential risk.

---

### Sources

| Source | URL | Type | Confidence |
| --- | --- | --- | --- |
| Tracxn Company Profile (FY2024 revenue, employee count) | https://tracxn.com/d/companies/deliverect/ | Secondary (statutory accounts) | High |
| Tracxn Funding & Investors | https://tracxn.com/d/companies/deliverect/funding-and-investors | Secondary | High |
| Deliverect Series B blog | https://www.deliverect.com/en-us/blog/deliverect/we-have-raised-eur16-25-million-in-funding | Primary | Confirmed |
| Deliverect Series C blog | https://www.deliverect.com/en-us/blog/deliverect/we-re-rocketing-30m-orders-1b-in-gmv-and-usd65-million-in-series-c-funding | Primary | Confirmed |
| Deliverect Series D / Unicorn blog | https://www.deliverect.com/en-us/blog/deliverect/unicorn-status-series-d-funding-and-approaching-100m-orders-processed | Primary | Confirmed |
| PRNewswire Series D ($150M) | https://www.prnewswire.com/news-releases/deliverect-raises-150-million-in-series-d-funding-as-it-reaches-100-million-orders-processed-301466980.html | Primary (press) | Confirmed |
| TechCrunch Series D | https://techcrunch.com/2022/01/24/deliverect-raises-150m-at-a-1-4b-valuation-to-streamline-online-and-offline-food-orders/ | Secondary | Confirmed |
| Deliverect 2022 Recap | https://www.deliverect.com/en-us/blog/deliverect/deliverect-2022-recap-a-year-to-share-and-be-proud-of | Primary | Confirmed |
| Deliverect 2023 Recap | https://www.deliverect.com/en-us/blog/deliverect/deliverect-by-the-numbers-2023-recap | Primary | Confirmed |
| Getlatka revenue estimate | https://getlatka.com/companies/deliverect | Secondary (CEO interview) | Estimated |
| Growjo revenue/headcount | https://growjo.com/company/Deliverect | Secondary | Estimated |
| Globalization Partners case study (headcount/expansion) | https://www.globalization-partners.com/case-studies/deliverect/ | Secondary | Confirmed |
| Deliverect ChatFood acquisition | https://www.deliverect.com/en-us/deliverect-acquires-chatfood | Primary | Confirmed |
| Deliverect Tabesto acquisition (BusinessWire) | https://www.businesswire.com/news/home/20241203248801/en | Primary (press) | Confirmed |
| PRNewswire Series B (Oct 2020 expansion) | https://www.prnewswire.com/news-releases/deliverect-expands-services-to-new-markets-on-account-of-high-demand-301162874.html | Secondary | Confirmed |
| TechPulseMEA (1B orders Jul 2025) | https://techpulsemea.com/deliverect-achieves-major-milestone-of-one-billion-global-orders/ | Secondary | Confirmed |
| PRNewswire Papa Johns partnership (Mar 2026) | https://www.prnewswire.com/news-releases/papa-johns-selects-deliverect-302715114.html | Secondary | Confirmed |
| LinkedIn company page (current headcount) | https://www.linkedin.com/company/deliverecthq | Primary | Confirmed |
