# Deliverect — Corporate History

**Category**: Online Ordering / Order Management / Delivery Aggregation
**Country**: Belgium (HQ)
**City**: Ghent
**Research Date**: 2026-04-30
**Analyst Note**: Unicorn-status company ($1.4B valuation, Jan 2022). VC-backed with $294M–$332M raised. Not a realistic SolStein acquisition target — included as a reference and landscape company.

---

## Identity & Registration

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Deliverect SA (NV) | companyweb.be | Confirmed |
| KBO number | BE 0692.623.253 | companyweb.be | Confirmed |
| Legal form | SA / Naamloze Vennootschap | companyweb.be | Confirmed |
| KBO registration date | 15 March 2018 | companyweb.be | Confirmed |
| Commercial launch | September 2018 | Deliverect about-us; multiple press | Confirmed |
| Registered address | Foreestelaan 82, 9000 Gent | companyweb.be | Confirmed |
| Deliverect Foundation KBO | BE 0770.651.439 | northdata.com | Confirmed |
| Primary NACE / activity | Software for food delivery order management | Tracxn, companyweb.be | Confirmed |

---

## Founders

| Name | Role | Background | Source | Confidence |
|---|---|---|---|---|
| Zhong Xu | Co-Founder & CEO | Belgian (Ghent University); built POSIOS iPad POS software ~2010–2011; father in restaurant software industry | LinkedIn; alejandrocremades.com; grokipedia.com | Confirmed |
| Jan Hollez | Co-Founder & CTO | — | deliverect.com/about-us | Confirmed |
| Jelte Vrijhoef | Co-Founder & CPO | — | deliverect.com/about-us | Confirmed |
| Jérôme Laredo | Co-Founder & President | — | deliverect.com/about-us | Confirmed |

**Predecessor**: Zhong Xu previously co-founded **POSIOS** (~2010–2011), an iPad-based POS software company, giving him deep prior experience in restaurant technology before founding Deliverect.

---

## Funding History

| Round | Date | Amount | Lead Investor(s) | Participating Investors | Source | Confidence |
|---|---|---|---|---|---|---|
| Seed | 4 Sep 2018 | $58K | imec.istart | — | Tracxn | Estimated |
| Series A | 2 Apr 2019 | $3.37M | Newion, SmartFin | — | Tracxn, seedtable.com | Confirmed |
| Series B | 29 Apr 2020 | €16.25M (~$17.6M) | OMERS Ventures | Newion, Smartfin, founders | PRNewswire; deliverect.com blog | Confirmed |
| Series C | 21 Apr 2021 | $65M | DST Global Partners, Redpoint Ventures | OMERS, Newion, Smartfin | deliverect.com blog; tech.eu | Confirmed |
| Series D | 24 Jan 2022 | $208M (announced as "over $150M") | Coatue Management, Alkeon Capital Management | OMERS Ventures + existing | Tracxn; deliverect.com blog; betakit.com | Confirmed |
| **Total raised** | — | **~$294M–$332M** | — | — | Tracxn ($332M); seedtable ($258M); divergence due to currency conversions and bridge instruments | Estimated |

> Note: Official press releases cited "over $150M" for Series D; Tracxn records the round as $208M. The discrepancy is common in VC rounds where secondary tranches close later.

### Key Investors

| Investor | Type | Geography | Rounds | Source | Confidence |
|---|---|---|---|---|---|
| imec.istart | University accelerator / seed fund | Belgium | Seed | Tracxn | Confirmed |
| Newion | VC | Netherlands | A, B, C | Tracxn; newion.com | Confirmed |
| SmartFin | VC | Belgium | A, B, C | Tracxn | Confirmed |
| OMERS Ventures | Corporate VC | Canada (global) | B, C, D | OMERS Ventures website | Confirmed |
| DST Global Partners | Growth VC | Global (Hong Kong/UK) | C | deliverect.com blog | Confirmed |
| Redpoint Ventures | VC | USA | C | deliverect.com blog | Confirmed |
| Coatue Management | Hedge fund / growth equity | USA | D | deliverect.com blog | Confirmed |
| Alkeon Capital Management | Growth equity | USA | D | deliverect.com blog | Confirmed |

---

## Unicorn Status & Valuation

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Unicorn status achieved | January 2022 (Series D) | deliverect.com/unicorn-status blog | Confirmed |
| Post-money valuation (Series D) | $1.4 billion | deliverect.com/unicorn-status blog | Confirmed |
| Current valuation (2026) | Unknown — no subsequent funding round disclosed; likely flat or down-round territory given broader tech market | — | Unknown |

---

## M&A Events — Acquisitions Made by Deliverect

Deliverect has itself been an acquirer, expanding its platform through two bolt-on acquisitions:

| Date | Target | Country | Sector | Deal Terms | Outcome | Source | Confidence |
|---|---|---|---|---|---|---|---|
| May 2023 | **ChatFood** | UAE / Global | Social media ordering, dine-in QR, loyalty | Undisclosed | Integrated into Deliverect platform; expanded omnichannel capabilities (dine-in, QR, WhatsApp ordering) | deliverect.com/acquires-chatfood; restaurantdive.com | Confirmed |
| 3 Dec 2024 | **Tabesto** | France | Restaurant self-order kiosks (all-in-one hardware + software) | Undisclosed; 60 Tabesto staff absorbed | Tabesto CEO Guillaume Hourmant appointed Head of Deliverect Kiosk; integrated into Deliverect omnichannel stack | BusinessWire; deliverect.com press; manda.be | Confirmed |

**Has Deliverect itself been acquired?** No. As of 2026-04-30, no acquisition of Deliverect has been reported. The company remains independent and VC-backed.

---

## Name Changes & Corporate Events

| Date | Event | Details | Source | Confidence |
|---|---|---|---|---|
| Mar 2018 | KBO registration | Deliverect SA registered in Ghent | companyweb.be | Confirmed |
| Sep 2018 | Commercial launch | Product launched to market | deliverect.com/about-us | Confirmed |
| Apr 2020 | Series B / COVID growth inflection | COVID-19 drove massive acceleration in delivery orders; company 10× growth reported in 2020 | OMERS Ventures case study | Estimated |
| Apr 2021 | Series C milestone | Processed 30M orders; $1B GMV | deliverect.com/series-c blog | Confirmed |
| Jan 2022 | Unicorn status | $1.4B valuation on Series D | deliverect.com/unicorn blog | Confirmed |
| May 2023 | ChatFood acquisition | Expanded into dine-in / social ordering | deliverect.com | Confirmed |
| Dec 2024 | Tabesto acquisition | Expanded into in-store kiosk hardware | BusinessWire | Confirmed |
| Jul 2025 | 1 billion orders milestone | Cumulative 1 billion orders processed globally | techpulsemea.com | Confirmed |
| Mar 2026 | Papa Johns partnership | Selected to modernize delivery ops across US restaurants | PRNewswire | Confirmed |

---

## Current Scale (as of 2026)

| Metric | Value | Source | Confidence |
|---|---|---|---|
| Employees | ~400–463 | Tracxn (461, Mar 2026); RocketReach (402); ZoomInfo (201–500) | Estimated |
| Annual revenue | ~€33.8M (FY2024) | Tracxn (FY2024 Belgian accounts) | Estimated |
| GMV processed | $11B in 2024 | Zhong Xu LinkedIn (processed over $11B GMV in 2024) | Estimated |
| Orders processed (cumulative) | 1 billion+ (milestone Jul 2025) | techpulsemea.com | Confirmed |
| Active locations served | 96,000+ | deliverect.com homepage | Estimated |
| Countries | 52 | deliverect.com | Confirmed |
| Integration partners | 1,000+ | deliverect.com | Confirmed |
| Offices | ~13 (including Ghent HQ) | deliverect.com/unicorn blog | Estimated |

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Deliverect SA (NV)<br/>KBO BE0692.623.253<br/>Ghent, Belgium<br/>Founded 15 Mar 2018"] --> B["Product Platform<br/>Order Aggregation / POS Integration<br/>96,000+ locations / 52 countries"]
    A --> C["Deliverect Foundation<br/>KBO BE0770.651.439<br/>CSR / social impact arm"]
    A --> D["ChatFood<br/>Acquired May 2023<br/>Social + dine-in ordering"]
    A --> E["Tabesto<br/>Acquired Dec 2024<br/>Restaurant kiosk hardware (France)"]

    F["imec.istart (Seed)"] --> A
    G["Newion / SmartFin (A, B, C)"] --> A
    H["OMERS Ventures (B, C, D)"] --> A
    I["DST Global / Redpoint (C)"] --> A
    J["Coatue / Alkeon (D)"] --> A

    style A fill:#1a6fc4,color:#fff
    style B fill:#2e86ab,color:#fff
    style C fill:#6b717e,color:#fff
    style D fill:#3d9970,color:#fff
    style E fill:#3d9970,color:#fff
```

---

## Corporate Timeline (Mermaid)

```mermaid
timeline
    title Deliverect Corporate Timeline
    2018 : KBO registration (Mar 2018)
         : Commercial launch Sep 2018
         : Seed $58K from imec.istart
    2019 : Series A $3.37M — Newion + SmartFin
    2020 : Series B €16.25M — OMERS Ventures leads
         : COVID-19 accelerates delivery adoption
    2021 : Series C $65M — DST Global + Redpoint
         : 30M orders / $1B GMV milestone
    2022 : Series D $208M — Coatue + Alkeon
         : Unicorn status at $1.4B valuation (Jan 2022)
         : 20,000+ customers in 40 markets
    2023 : ChatFood acquisition (social / dine-in ordering)
    2024 : Tabesto acquisition (French kiosk hardware)
         : $11B GMV processed in 2024
    2025 : 1 billion cumulative orders milestone (Jul 2025)
    2026 : Papa Johns partnership (Mar 2026)
         : 96,000+ locations / 52 countries
```

---

## M&A Feasibility Assessment

### Is Deliverect a Realistic Acquisition Target for SolStein?

**Verdict: NO — Reference Company Only**

| Assessment Dimension | Finding |
|---|---|
| **Scale** | €33.8M revenue, $1.4B valuation, 400+ employees — 100× larger than SolStein's target range |
| **Ownership** | 8 institutional VC investors including Coatue (US hedge fund), DST Global, OMERS; no founder-controlled cap table |
| **Funding overhang** | $294M–$332M raised; investors require a liquidation event (IPO or strategic sale to a major platform) |
| **Exit trajectory** | Likely strategic sale to a major delivery platform (DoorDash, Uber, Just Eat) or IPO — not a founder-negotiated sale |
| **Geography** | Global footprint (52 countries); not a NL/BE-focused niche player |
| **SolStein fit** | Zero fit on ownership, revenue scale, and M&A feasibility criteria |

**Why keep as reference?** Deliverect is the dominant player in the delivery aggregation / order management space in Benelux and globally. It sets the market standard, competitive benchmark, and technology reference point for all HORECA IT companies in this space.

---

## Sources

| Source | URL | Type |
|---|---|---|
| CompanyWeb Belgium | https://www.companyweb.be/en/0692623253/deliverect | Primary (trade register) |
| Deliverect About Us | https://www.deliverect.com/en-us/about-us | Primary (company) |
| Deliverect Series B announcement | https://www.deliverect.com/en-us/blog/deliverect/we-have-raised-eur16-25-million-in-funding | Primary (company) |
| Deliverect Series C announcement | https://www.deliverect.com/en-us/blog/deliverect/we-re-rocketing-30m-orders-1b-in-gmv-and-usd65-million-in-series-c-funding | Primary (company) |
| Deliverect Series D / Unicorn announcement | https://www.deliverect.com/en-us/blog/deliverect/unicorn-status-series-d-funding-and-approaching-100m-orders-processed | Primary (company) |
| Deliverect ChatFood acquisition | https://www.deliverect.com/en-us/deliverect-acquires-chatfood | Primary (company) |
| Deliverect Tabesto acquisition | https://www.businesswire.com/news/home/20241203248801/en | Primary (press release) |
| PRNewswire Series B | https://www.prnewswire.com/news-releases/food-tech-start-up-deliverect-raises-16-25-million-to-expand-internationally-301049467.html | Secondary |
| Tracxn Funding Profile | https://tracxn.com/d/companies/deliverect/funding-and-investors | Secondary |
| BetaKit / OMERS Series D | https://betakit.com/omers-ventures-reinvests-in-deliverect-as-part-of-150-million-usd-series-d-round/ | Secondary |
| Alejandro Cremades (Zhong Xu interview) | https://alejandrocremades.com/zhong-xu/ | Secondary |
| TechPulseMEA (1 billion orders) | https://techpulsemea.com/deliverect-achieves-major-milestone-of-one-billion-global-orders/ | Secondary |
| Growjo (revenue estimate) | https://growjo.com/company/Deliverect | Estimated |
| Northdata (Deliverect Foundation) | https://www.northdata.com/Deliverect%20Foundation,%20Gent/KBO%200770.651.439 | Secondary |
