# Deliverect

**Category**: Online Ordering
**Country**: BE
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Not started |
| deep-analysis.md | Not started |
| inancial-growth.md | Not started |

---

## How to Run Research

```
@research-horeca-company-history Deliverect @HORECA_IT/deliverect/
@research-horeca-company Deliverect @HORECA_IT/deliverect/
```
