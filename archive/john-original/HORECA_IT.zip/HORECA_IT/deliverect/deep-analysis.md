# Deliverect — Deep Analysis

**Category**: Online Ordering / Order Management / Delivery Aggregation
**Country**: Belgium (HQ); Global (52 countries)
**Research Date**: 2026-04-30
**M&A Verdict**: **NOT a target** — Unicorn ($1.4B), VC-backed ($294M–$332M raised), global scale. Reference company for market benchmarking only.

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founded | September 2018 (KBO: 15 Mar 2018) | companyweb.be; deliverect.com | Confirmed |
| HQ | Foreestelaan 82, 9000 Gent, Belgium | companyweb.be | Confirmed |
| Legal entity | Deliverect SA (NV) — KBO BE 0692.623.253 | companyweb.be | Confirmed |
| Founders | Zhong Xu (CEO), Jan Hollez (CTO), Jelte Vrijhoef (CPO), Jérôme Laredo (President) | deliverect.com/about-us | Confirmed |
| Employees (2026) | ~400–463 | Tracxn (461); RocketReach (402); ZoomInfo (201–500) | Estimated |
| Annual revenue (FY2024) | ~€33.8M | Tracxn (Belgian statutory accounts) | Estimated |
| Revenue (alternative estimates) | $44.7M (Latka); $33.1M (Growjo); $12.6M (ZoomInfo — likely understated) | Multiple secondary | Estimated |
| **Best revenue estimate** | **~€33–€45M ARR** | Tracxn + Growjo + Latka triangulation | Estimated |
| GMV processed (2024) | $11B | Zhong Xu LinkedIn profile | Estimated |
| Total funding raised | ~$294M–$332M | Tracxn ($332M); Seedtable ($258M) | Estimated |
| Valuation (last known) | $1.4B (Jan 2022, Series D) | deliverect.com/unicorn-status | Confirmed |
| Valuation (current, 2026) | Unknown — no round since Jan 2022; market conditions suggest flat or down from $1.4B | — | Unknown |
| Offices | ~13 global offices | deliverect.com unicorn blog | Estimated |
| Countries active | 52 | deliverect.com homepage | Confirmed |

**Summary**: Deliverect is a high-growth, post-unicorn SaaS company with approximately €34–45M in ARR, ~450 employees, $11B annual GMV, and a global footprint of 96,000+ locations across 52 countries. It is at the scale of a late-stage private company preparing for a liquidity event (IPO or strategic sale).

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Locations served (2026) | 96,000+ | deliverect.com homepage | Estimated |
| Customers at Series D (Jan 2022) | 20,000+ | deliverect.com/unicorn-status | Confirmed |
| Customers in 2024 (Latka estimate) | ~10,000 paying customers | getlatka.com | Estimated |
| Cumulative orders processed | 1 billion+ (milestone Jul 2025) | techpulsemea.com | Confirmed |
| Orders processed milestone (Series C, Apr 2021) | 30 million | deliverect.com/series-c | Confirmed |
| Orders processed (approaching Series D, Jan 2022) | ~100 million | deliverect.com/unicorn-status | Confirmed |
| GMV processed (2024) | $11B | Zhong Xu LinkedIn | Estimated |
| Average revenue increase for customers | +25% (company claim) | deliverect.com/unicorn-status | Estimated |
| NL/BE market presence | Yes — Dutch-language website; NL dedicated domain (en-nl); BE headquarters | deliverect.com/en-nl | Confirmed |
| NL/BE vs global share | Unknown — NL/BE likely 5–15% of revenue given global scale | — | Unknown |
| Integration partners | 1,000+ | deliverect.com homepage | Confirmed |
| Key NL delivery platforms integrated | Thuisbezorgd (Just Eat), Uber Eats NL, Deliveroo | deliverect.com integrations | Confirmed |
| Key BE delivery platforms integrated | Uber Eats BE, Deliveroo BE | deliverect.com integrations | Confirmed |
| Enterprise clients (notable) | Papa Johns (US, Mar 2026); international chains, dark kitchens, QSR franchises | PRNewswire; deliverect.com/customers | Confirmed |

**NL/BE Context**: Deliverect was founded in Ghent and built its initial traction in the Belgian and Dutch markets. The NL/BE markets were the proving ground for the product (2018–2020). However, the company rapidly globalized and NL/BE now represents a small portion of the overall customer base. The company still maintains dedicated NL/BE websites and local support.

---

## 3. Product & Technology

### Core Platform

| Capability | Description | Source | Confidence |
|---|---|---|---|
| Order aggregation | Connects 3rd-party delivery platforms (Uber Eats, Deliveroo, Thuisbezorgd, etc.) directly to POS systems in real time | deliverect.com | Confirmed |
| Menu synchronization | Two-way sync: push menus from POS to delivery channels; update centrally | deliverect.com/pos-systems | Confirmed |
| Analytics & reporting | Order performance dashboards, revenue reporting, failure rate tracking | deliverect.com | Confirmed |
| Deliverect Dispatch | Last-mile delivery management; fleet optimization | deliverect.com | Confirmed |
| Deliverect Direct | First-party digital ordering (own channel / white-label) | deliverect.com | Confirmed |
| Deliverect Sentinel | Real-time store monitoring; uptime and order failure alerts | deliverect.com | Confirmed |
| ChatFood (acquired May 2023) | Social media ordering (WhatsApp, Instagram), dine-in QR ordering, loyalty | deliverect.com/acquires-chatfood | Confirmed |
| Tabesto Kiosk (acquired Dec 2024) | All-in-one self-order kiosk hardware + software for QSR / fast food | BusinessWire | Confirmed |

### Integration Ecosystem

| Category | Count / Examples | Source | Confidence |
|---|---|---|---|
| Total integration partners | 1,000+ | deliverect.com | Confirmed |
| POS integrations | Wide range including Oracle Hospitality, Lightspeed, Square, Lightspeed, Revel, NCR, unTill, and many more | deliverect.com/integrations/pos-systems | Confirmed |
| Delivery platforms | Uber Eats, Deliveroo, Just Eat / Thuisbezorgd, DoorDash, Grubhub, and 100+ others | deliverect.com | Confirmed |
| Payment platforms | iDEAL (NL), Bancontact (BE), Stripe, and others via Tabesto kiosk | deliverect.com; manda.be | Estimated |
| eCommerce / direct ordering | Shopify, WooCommerce, direct ordering via Deliverect Direct | deliverect.com | Confirmed |

### Technology Stack

| Element | Assessment | Source | Confidence |
|---|---|---|---|
| Architecture | API-first; cloud-native SaaS | deliverect.com | Confirmed |
| API type | REST API with webhook support; robust real-time order injection | deliverect.com/developers | Confirmed |
| Uptime claim | High injection rate (99%+ implied); Sentinel for monitoring | deliverect.com | Estimated |
| AI/ML | AI-powered features mentioned (menu optimization, analytics) — specifics unclear | deliverect.com homepage | Estimated |
| Mobile | Delivery Manager app for mobile management | deliverect.com | Confirmed |
| Hardware | Tabesto kiosk hardware (post Dec 2024 acquisition) | BusinessWire | Confirmed |

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership type | VC-backed; multiple institutional investors | Tracxn; Crunchbase | Confirmed |
| Founder equity (estimated) | Heavily diluted after 5 rounds and $294M+ raised; founders likely hold <15% combined | — | Estimated |
| Investor control | Coatue, OMERS, DST Global, Redpoint, Alkeon hold board seats and liquidation preferences | Tracxn | Estimated |
| PE overhang | No PE; growth VC / crossover investors (Coatue is a hedge fund / crossover investor) | — | Confirmed |
| Succession signal | None — Zhong Xu is active CEO; strong public profile | LinkedIn | Confirmed |
| Exit strategy | IPO or strategic acquisition by major delivery platform (DoorDash, Uber, Just Eat) most likely | — | Estimated |
| Acquisition by SolStein | **Impossible** — valuation $1.4B+, VC control, no alignment with SolStein thesis | — | Confirmed |

**Key insight**: The investor composition is notable. Coatue Management is a US-based hedge fund / crossover investor that typically requires liquidity within 5–8 years. The Series D closed January 2022, meaning investor pressure for exit likely intensifies from 2027 onward. Any exit will be a major strategic sale or IPO — not a founder-negotiated SME acquisition.

---

## 5. Financial Growth & Trajectory

| Period | Metric | Value | Source | Confidence |
|---|---|---|---|---|
| 2020 | COVID growth | ~10× growth in order volumes; Series B secured | OMERS Ventures case study | Estimated |
| Apr 2021 (Series C) | Orders / GMV | 30M orders processed; $1B GMV | deliverect.com/series-c | Confirmed |
| Jan 2022 (Series D) | Orders / customers | ~100M orders; 20,000+ customers | deliverect.com/unicorn | Confirmed |
| 2023 | M&A activity | ChatFood acquired May 2023 | deliverect.com | Confirmed |
| 2024 | GMV | $11B processed | Zhong Xu LinkedIn | Estimated |
| 2024 | Revenue (FY) | ~€33.8M | Tracxn | Estimated |
| Jul 2025 | Orders milestone | 1 billion cumulative orders | techpulsemea.com | Confirmed |
| 2026 | Active locations | 96,000+ | deliverect.com | Estimated |
| 2026 | Countries | 52 | deliverect.com | Confirmed |
| 2026 | Employees | ~400–463 | Tracxn; RocketReach | Estimated |

**Growth signal**: From 30M orders (Apr 2021) → 100M orders (Jan 2022) → 1B cumulative (Jul 2025) in under 4 years. Revenue growing from estimated $3–5M in 2019 to ~€34–45M in 2024. This is hyper-growth typical of funded SaaS scaleups. Revenue growth has likely slowed post-2022 as the market normalizes.

---

## 6. HORECA Vertical Depth

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Core vertical | Online food delivery order management for restaurants, dark kitchens, QSR, retail | deliverect.com | Confirmed |
| Delivery platform coverage | Uber Eats, Deliveroo, Thuisbezorgd (NL), DoorDash, Grubhub, 100+ platforms globally | deliverect.com/integrations | Confirmed |
| POS coverage | unTill (NL/BE), Oracle, Lightspeed, Square, NCR, 200+ POS systems | deliverect.com/pos-systems | Confirmed |
| NL-specific integrations | Thuisbezorgd; iDEAL (payment) | deliverect.com/en-nl | Confirmed |
| BE-specific integrations | Uber Eats BE, Deliveroo BE; Bancontact (payment) | deliverect.com | Confirmed |
| Dine-in | Yes — ChatFood (QR ordering, table ordering) | deliverect.com | Confirmed |
| In-store kiosk | Yes — Tabesto (Dec 2024) | BusinessWire | Confirmed |
| Dark kitchen / ghost kitchen | Explicit product segment | deliverect.com | Confirmed |
| Enterprise / chain management | Multi-location menu management, centralized reporting | deliverect.com/enterprise | Confirmed |
| Retail (grocery delivery) | Deliverect Retail product line | deliverect.com/deliverect-retail | Confirmed |
| Customer types | Small diners, QSR chains, dark kitchens, grocery / convenience, enterprise chains | deliverect.com/customers | Confirmed |

**Vertical depth verdict**: Extremely deep. Deliverect is the dominant order aggregation middleware in the global HORECA delivery space. It has successfully expanded from pure delivery aggregation into kiosks, dine-in, first-party ordering, and analytics — building a full omnichannel commerce stack for food operators.

---

## 7. Valuation & Business Model

### Business Model

| Element | Description | Source | Confidence |
|---|---|---|---|
| Pricing model | SaaS subscription per location + potential transaction/volume fees | Industry standard; getlatka.com | Estimated |
| Revenue per location (estimated) | ~€350–500/month per location (implied from €34M revenue ÷ ~96K locations, but many are on tiered plans) | Triangulation | Estimated |
| Customer segments | SMB restaurants (self-serve), enterprise chains (custom contracts) | deliverect.com | Confirmed |
| Lock-in mechanism | Deep POS integration; menu sync dependency; switching costs high once integrated | deliverect.com | Confirmed |
| Adjacent revenue | Tabesto hardware sales (post Dec 2024); professional services | — | Estimated |

### Valuation Benchmarks

| Metric | Value | Source | Confidence |
|---|---|---|---|
| Last disclosed valuation | $1.4B (Jan 2022, Series D) | deliverect.com/unicorn | Confirmed |
| Revenue multiple (at unicorn) | ~35–50× ARR (typical for high-growth SaaS in 2022 market) | Market context | Estimated |
| Current implied valuation | ~$200M–$500M (applying current SaaS multiples of 5–15× on ~€35M ARR, post-2022 correction) | Estimated triangulation | Estimated |
| IPO readiness | Likely 2–4 years away; revenue scale and profitability path needed | — | Unknown |
| Strategic acquisition value | $500M–$1.5B range for a major delivery platform or POS consolidator | — | Estimated |

**Note**: The 2022 unicorn valuation of $1.4B was set during peak SaaS multiples. Given the 2022–2024 SaaS market correction, the real-time valuation is likely lower. However, Deliverect's strategic value to a major acquirer (DoorDash, Uber, Just Eat Takeaway, Oracle Hospitality) could sustain a premium valuation.

---

## 8. M&A Attractiveness Scorecard

> Scored against SolStein's acquisition thesis: founder-owned, €1M–€15M ARR, NL/BE focus, niche HORECA, no PE overhang.

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | **1** | 8 institutional VC investors; Coatue (US crossover hedge fund) controls; founders heavily diluted; zero chance of founder-negotiated sale at SolStein scale | Tracxn; Crunchbase |
| **Revenue scale fit** | High | **1** | ~€34–45M ARR — 2–45× above SolStein's €1M–€15M target ceiling; requires $500M+ acquirer | Tracxn (FY2024) |
| **Geographic fit** | High | **2** | Founded in Ghent; Dutch-language site; NL/BE historically important — but now 52 countries, NL/BE is a small fraction of revenue and business focus | deliverect.com/en-nl |
| **Tech stack modernity** | Medium | **5** | API-first cloud-native SaaS; 1,000+ integrations; AI-powered analytics; modern omnichannel stack — best-in-class | deliverect.com |
| **Customer lock-in** | Medium | **5** | Deep POS integration creates very high switching costs; menu sync dependency; multi-year enterprise contracts common | deliverect.com; industry analysis |
| **Vertical depth** | Medium | **5** | Dominant in delivery aggregation; expanded into kiosk, dine-in, analytics, retail — full HORECA omnichannel stack | deliverect.com |
| **Integration potential** | Low | **5** | REST API; open architecture; 1,000+ existing integrations — maximally open | deliverect.com/developers |
| **Growth trajectory** | Low | **4** | Hyper-growth 2018–2022; post-unicorn growth moderating but still strong; 1B orders milestone Jul 2025; Papa Johns partnership Mar 2026 | Multiple |

### Composite Score

| Calculation | Value |
|---|---|
| Weighted score (High dimensions ×3, Medium ×2, Low ×1) | See below |
| Ownership attractiveness (High, ×3) | 1 × 3 = 3 |
| Revenue scale fit (High, ×3) | 1 × 3 = 3 |
| Geographic fit (High, ×3) | 2 × 3 = 6 |
| Tech stack modernity (Medium, ×2) | 5 × 2 = 10 |
| Customer lock-in (Medium, ×2) | 5 × 2 = 10 |
| Vertical depth (Medium, ×2) | 5 × 2 = 10 |
| Integration potential (Low, ×1) | 5 × 1 = 5 |
| Growth trajectory (Low, ×1) | 4 × 1 = 4 |
| **Total weighted** | **51** |
| **Max possible** | **1×3 + 1×3 + 1×3 + 1×2 + 1×2 + 1×2 + 1×1 + 1×1 = (3+3+3+2+2+2+1+1) = 17 dimensions × 5 = 85** |
| **Composite (normalized to 5.0)** | **51/85 × 5 = 3.0 / 5.0** |

> **Important caveat**: The composite score of 3.0/5.0 is misleading in isolation. The two "High weight" criteria — ownership attractiveness and revenue scale fit — both score **1/5**. These are the criteria SolStein weights most. Deliverect is an excellent company that scores highly on product quality dimensions, but is entirely misaligned with SolStein's acquisition criteria on the dimensions that matter most.

### Confidence Band

| Category | Fraction Confirmed | Impact |
|---|---|---|
| Corporate identity / KBO | 100% Confirmed | Tight |
| Funding rounds | 90% Confirmed | Tight |
| Revenue / employees | ~40% Confirmed (statutory accounts via Tracxn) | Moderate |
| Product capabilities | 95% Confirmed | Tight |
| NL/BE market share | Unknown | Widens band |
| Current valuation | Unknown (last round Jan 2022) | Widens band |

**Overall confidence band**: ±0.3 on composite score. Sufficient for classification purposes.

---

## Overall Assessment

**Deliverect is the leading order aggregation SaaS platform in the HORECA delivery space globally.** Founded in Ghent in 2018, it has grown from a Belgian startup to a $1.4B-valued unicorn in under 4 years, processing over 1 billion orders across 96,000+ restaurant locations in 52 countries. With ~€34–45M in ARR, $11B in GMV (2024), and backing from Coatue, DST Global, OMERS, and Redpoint Ventures, it operates at a completely different scale and ownership structure than SolStein's target profile.

**Acquisition by SolStein**: Categorically not feasible. The company requires a $500M–$1.5B acquirer — a major delivery platform, POS consolidator, or enterprise software group. Any exit will be investor-driven, not founder-initiated.

**Strategic relevance to SolStein**:
1. **Technology benchmark**: Deliverect defines best practice for order aggregation middleware. Any SolStein portfolio company in this space must integrate with or position against Deliverect.
2. **Integration partner**: Deliverect's 1,000+ integrations include most NL/BE POS systems SolStein might acquire — making Deliverect a likely integration partner, not a competitor.
3. **Valuation reference**: Deliverect's metrics (revenue multiples, GMV per location, integration counts) provide benchmarks for valuing smaller players in the same space.
4. **Market signal**: Deliverect's 2024 acquisitions (ChatFood, Tabesto) signal the market is consolidating toward full omnichannel stacks — smaller single-channel players face displacement risk.

---

## Recommended Next Step

**Tier 3 — Reference / Landscape.** No further acquisition research warranted. Use Deliverect as:
- Market benchmark for order aggregation SaaS in NL/BE
- Technology reference for integration requirements
- Competitive threat assessment for any SolStein target in delivery/POS space
- Valuation multiple reference (revenue multiples, GMV metrics)

---

## Sources

| Source | URL | Type |
|---|---|---|
| CompanyWeb Belgium | https://www.companyweb.be/en/0692623253/deliverect | Primary (trade register) |
| Deliverect About Us | https://www.deliverect.com/en-us/about-us | Primary (company) |
| Deliverect Series C blog | https://www.deliverect.com/en-us/blog/deliverect/we-re-rocketing-30m-orders-1b-in-gmv-and-usd65-million-in-series-c-funding | Primary (company) |
| Deliverect Series D / Unicorn blog | https://www.deliverect.com/en-us/blog/deliverect/unicorn-status-series-d-funding-and-approaching-100m-orders-processed | Primary (company) |
| Deliverect ChatFood acquisition | https://www.deliverect.com/en-us/deliverect-acquires-chatfood | Primary (company) |
| Deliverect Tabesto acquisition | https://www.businesswire.com/news/home/20241203248801/en | Primary (press release) |
| PRNewswire Series B | https://www.prnewswire.com/news-releases/food-tech-start-up-deliverect-raises-16-25-million-to-expand-internationally-301049467.html | Secondary |
| Tracxn Company Profile | https://tracxn.com/d/companies/deliverect/ | Secondary |
| Tracxn Funding & Investors | https://tracxn.com/d/companies/deliverect/funding-and-investors | Secondary |
| Growjo Revenue Estimate | https://growjo.com/company/Deliverect | Secondary (estimated) |
| Latka Revenue Estimate | https://getlatka.com/companies/deliverect | Secondary (estimated) |
| Zhong Xu LinkedIn | https://www.linkedin.com/in/zhongyuanxu | Secondary |
| Alejandro Cremades interview | https://alejandrocremades.com/zhong-xu/ | Secondary |
| TechPulseMEA (1B orders) | https://techpulsemea.com/deliverect-achieves-major-milestone-of-one-billion-global-orders/ | Secondary |
| Papa Johns partnership | https://www.prnewswire.com/news-releases/papa-johns-selects-deliverect-302715114.html | Secondary |
| manda.be Tabesto article | https://manda.be/articles/zhong-xu-ceo-deliverect-about-acquisition-tabesto/ | Secondary |
| BetaKit OMERS Series D | https://betakit.com/omers-ventures-reinvests-in-deliverect-as-part-of-150-million-usd-series-d-round/ | Secondary |
