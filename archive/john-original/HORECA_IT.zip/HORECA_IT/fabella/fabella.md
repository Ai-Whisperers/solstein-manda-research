# Fabella

**Category**: Restaurant Software
**Country**: DE
**City**: Stuttgart
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Fabella @HORECA_IT/fabella/
@research-horeca-company Fabella @HORECA_IT/fabella/
```
