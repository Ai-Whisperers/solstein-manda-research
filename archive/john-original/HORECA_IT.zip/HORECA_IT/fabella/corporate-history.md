# Fabella — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — possible naming confusion; very limited public data

---

## Executive Summary

The SolStein research brief lists "Fabella" as a Stuttgart-based restaurant software company providing digital menus and ordering platforms. Extensive research could not identify a Stuttgart restaurant software company named "Fabella." The only "Fabella" company found in research is "Fabella" (by Wanderword) — an eLearning/interactive audio platform founded by Swedish entrepreneurs with no connection to restaurant software. This may represent either a very small regional company with no online presence, or a naming confusion in the research brief. Alternative Stuttgart-area restaurant software companies exist (e.g., Gastronovi in Bremen, resmio) but none named Fabella.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | Fabella | SolStein research brief | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Stuttgart, Baden-Württemberg, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany | SolStein research brief | Estimated |
| Primary activity | Digital menu and ordering platform (reported) | SolStein research brief | Estimated |

---

## Disambiguation

| Entity | Description | Relevant? |
|---|---|---|
| Fabella (by Wanderword) | eLearning/interactive audio platform; Swedish founders | NOT relevant — different company |
| SolStein brief "Fabella Stuttgart" | Restaurant digital menu/ordering platform | IDENTITY UNCONFIRMED |

---

## Research Methodology & Limitations

Searches conducted:
- "Fabella restaurant software Stuttgart Germany"
- "Fabella digital menu ordering platform"
- Northdata.de searches (no Stuttgart restaurant software company named Fabella found)

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — company existence not confirmed |
| **SolStein thesis fit** | Very poor — Germany-only, unconfirmed existence |
| **Research confidence** | Very low |

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| Fabella.io (unrelated eLearning company) | https://www.fabella.io | Disambiguation |
