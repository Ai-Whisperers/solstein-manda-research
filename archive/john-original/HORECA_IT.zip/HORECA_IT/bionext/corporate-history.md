# Bionext — Corporate History

**Research Date**: 2026-04-30
**Researcher**: AI due-diligence agent
**Sources**: KBO Public Search, bionext.be (medical lab), web search, Belgian company databases

---

## Research Finding: Name Collision with Medical Laboratory Chain

Research reveals a significant name collision:

### Bionext (Medical) — Belgium/Luxembourg
- **bionext.be** and **bionext.lu** belong to a medical analysis laboratory group headquartered in Luxembourg
- Offers blood tests and medical diagnostic services across Luxembourg and Belgium
- This is the dominant Google result for "Bionext Belgium"
- **Not a HORECA software company**

### Bionext (HORECA software) — Belgium, Brussels
- Listed in SolStein's research brief as "Horeca Software, Brussels, BE"
- **No verifiable public company record found** in KBO, Crunchbase, LinkedIn, or Belgian company databases for a horeca-focused software company named Bionext
- No matching website, LinkedIn page, or product reviews found
- KBO name search returned no results for "Bionext" as a Belgian software entity

**Possible explanations**:
1. **Legal name differs from brand**: The company may be registered under a Belgian KBO number with a different corporate name
2. **Very small / micro-company**: Below the threshold for significant digital presence
3. **Recently launched**: Too new to be indexed
4. **Rebranded / acquired**: Former brand name, now operating under a different identity
5. **Data error in research brief**: The company may be mis-categorized or mis-named

---

## Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name (HORECA) | Unknown | KBO — no match | Unknown |
| KBO enterprise number | Unknown | Not found | Unknown |
| Domain bionext.be | Medical laboratory (Bionext Luxembourg) | URL test | Confirmed |
| Domain bionext.lu | Medical laboratory (Bionext Luxembourg) | URL test | Confirmed |
| HQ address | Brussels, Belgium | Research brief | Unknown |
| Founding year | Unknown | Not found | Unknown |
| Founders | Unknown | Not found | Unknown |
| Product | Horeca management and POS software | Research brief | Unknown |
| Revenue | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Investment | Unknown | Not found | Unknown |

---

## Corporate Structure

```mermaid
graph TD
    A[Bionext Horeca Software?<br/>Brussels, Belgium<br/>Legal entity unknown] --> B[Unknown founders/management]
    B --> C[Research status: Unverifiable]
    D[Bionext — Medical Lab<br/>Luxembourg/Belgium<br/>bionext.be / bionext.lu] --> E[DIFFERENT COMPANY — name collision]
```

---

## Corporate Timeline

```mermaid
timeline
    title Bionext — Timeline (data insufficient)
    Unknown : Reported as Brussels-based horeca management and POS software provider
    2026-04-30 : Research — no HORECA software company named Bionext found; name collision with medical lab
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Identity verification** | CRITICAL — name collides with Luxembourg medical lab; HORECA entity unverifiable |
| **Recommended action** | Primary research required: KBO NACE search in Brussels (1000–1210 postal codes), Belgian HORECA software association outreach |
