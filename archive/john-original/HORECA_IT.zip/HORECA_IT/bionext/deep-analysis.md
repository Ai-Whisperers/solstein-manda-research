# Bionext — Deep Analysis

**Research Date**: 2026-04-30
**Category**: Horeca Software (POS & Management)
**Country**: BE | **City**: Brussels
**Research Quality**: Very Low — name collision with medical lab; no HORECA software entity found

---

> **⚠ IDENTITY ALERT**: The name "Bionext" in Belgium/Luxembourg refers to a medical analysis laboratory chain (bionext.be, bionext.lu). No Belgian HORECA software company named Bionext was found in KBO, Crunchbase, LinkedIn, or any Belgian company database. This analysis cannot be completed without primary research.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | KBO — no match for HORECA software | Unknown |
| KBO number | Unknown | Not found | Unknown |
| HQ | Brussels, Belgium | Research brief | Unknown |
| Founded | Unknown | Not found | Unknown |
| CEO | Unknown | Not found | Unknown |
| Ownership | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Revenue | Unknown | Not found | Unknown |
| Funding | Unknown | Not found | Unknown |
| Note | bionext.be belongs to a Luxembourg medical lab | URL test | Confirmed |

---

## 2–7. All Categories

All fields in sections 2 through 7: **Unknown** — no public data found for a Belgian HORECA software company named Bionext.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot assess | Not found |
| Revenue scale fit | High | N/A | Cannot assess | Not found |
| Geographic fit | High | N/A | Cannot assess | Not found |
| Tech stack modernity | Medium | N/A | Cannot assess | Not found |
| Customer lock-in | Medium | N/A | Cannot assess | Not found |
| Vertical depth | Medium | N/A | Cannot assess | Not found |
| Integration potential | Low | N/A | Cannot assess | Not found |
| Growth trajectory | Low | N/A | Cannot assess | Not found |

**Composite Score**: N/A

**Confidence Band**: None

---

### Overall M&A Assessment

**Rating: INCOMPLETE — Company identity unverifiable**

No HORECA software company named Bionext could be confirmed as an active Belgian entity. The primary obstacle is a name collision with a Luxembourg medical laboratory. Primary research (KBO direct search, HORECA community contacts, LinkedIn) is essential before this target can be evaluated.

---

### Recommended Next Step

1. Search KBO for Brussels-based companies (1000–1210) in NACE 62.01/62.09 with similar phonetics or alt spellings
2. Reach out to Federhorecabruxelles (Brussels horeca federation) for member list
3. Check Google for "bionext horeca" or "bionext kassasysteem" or "bionext restaurant" in Belgian search context
4. If unverifiable: remove from active target list
