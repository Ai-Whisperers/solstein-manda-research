# Bionext

**Category**: Horeca Software
**Country**: BE
**City**: Brussels
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Bionext @HORECA_IT/bionext/
@research-horeca-company Bionext @HORECA_IT/bionext/
```
