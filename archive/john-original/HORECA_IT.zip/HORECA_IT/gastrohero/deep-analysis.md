# GastroHero — Deep Analysis

**Research Date**: 2026-04-30
**Category**: Restaurant POS (as listed in brief)
**Country**: BE | **City**: Antwerp
**Research Quality**: Very Low — Belgian POS company identity unverified; confusion with German kitchen equipment company

---

> **⚠ IDENTITY ALERT**: The domain gastrohero.be belongs to a German kitchen equipment company (GastroHero GmbH, PE-backed by AURELIUS Group, Holzwickede/Hamm, Germany). No Belgian POS software company named "GastroHero" has been found in KBO, Crunchbase, LinkedIn, or Belgian company databases. All data below is Unknown unless otherwise stated.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity (BE) | Unknown | KBO — no match | Unknown |
| KBO number | Unknown | Not found | Unknown |
| HQ | Antwerp, Belgium | Research brief | Unknown |
| Founded | Unknown | Not found | Unknown |
| CEO / Management | Unknown | Not found | Unknown |
| Ownership | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Revenue / ARR | Unknown | Not found | Unknown |
| German homonym | GastroHero GmbH — PE-owned, kitchen equipment, Germany | AURELIUS Group | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary markets | Belgium (assumed) | Research brief | Unknown |
| Product | POS system for gastronomy | Research brief | Unknown |
| All other fields | Unknown | Not found | Unknown |

---

## 3. Product & Technology

All fields: **Unknown** — no product information found for a Belgian GastroHero POS software company.

| Field | Value | Source | Confidence |
|---|---|---|---|
| Deployment | Unknown | Not found | Unknown |
| Tech stack | Unknown | Not found | Unknown |
| API | Unknown | Not found | Unknown |
| Bancontact | Unknown | Not found | Unknown |
| Fiscal receipt (BE/GKS) | Unknown | Not found | Unknown |

---

## 4. M&A Ownership & Succession

All fields: **Unknown** — company existence not confirmed.

---

## 5. Financial Growth & Trajectory

All fields: **Unknown** — no financial data available.

---

## 6. HORECA Vertical Depth

All fields: **Unknown**.

---

## 7. Valuation & Business Model

All fields: **Unknown** — cannot estimate without confirmed company identity.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot assess | Not found |
| Revenue scale fit | High | N/A | Cannot assess | Not found |
| Geographic fit | High | N/A | Cannot assess | Not found |
| Tech stack modernity | Medium | N/A | Cannot assess | Not found |
| Customer lock-in | Medium | N/A | Cannot assess | Not found |
| Vertical depth | Medium | N/A | Cannot assess | Not found |
| Integration potential | Low | N/A | Cannot assess | Not found |
| Growth trajectory | Low | N/A | Cannot assess | Not found |

**Composite Score**: N/A

**Confidence Band**: None — company existence unconfirmed

---

### Overall M&A Assessment

**Rating: INCOMPLETE — Company existence must be verified before assessment**

The Belgian "GastroHero" POS software company cannot be confirmed as an active entity. The gastrohero.be domain belongs to a German PE-backed kitchen equipment company. Primary research is required to determine if:
- A Belgian GastroHero POS company exists under a different legal name
- The company has ceased operations
- The research brief contains an error regarding this entry

---

### Recommended Next Step

1. Contact Antwerp-based HORECA IT reseller and VAR community directly
2. Check KBO NACE 62.01/62.09 registrations in Antwerp (2000/2018/2020/2030 postal areas)
3. Search Belgian HORECA association (Horeca Vlaanderen / Federhorecabruxelles) member directories
4. If still unverifiable after 2 weeks, remove from target list
