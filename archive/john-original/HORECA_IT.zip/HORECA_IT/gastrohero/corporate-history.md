# GastroHero — Corporate History

**Research Date**: 2026-04-30
**Researcher**: AI due-diligence agent
**Sources**: KBO Public Search, Crunchbase, Tracxn, AURELIUS Group website, Trustpilot, gastrohero.be

---

## Research Finding: Significant Identity Ambiguity

Research reveals **two distinct companies** sharing the name "GastroHero":

### Company A — GastroHero GmbH (GERMANY, kitchen equipment)
- Headquartered in Holzwickede/Hamm, North Rhine-Westphalia, Germany
- B2B e-commerce vendor of professional kitchen equipment and restaurant supplies (NOT software)
- Founded 2013 by Mark Baukmann, Jens Schütte, Andreas Korsus
- Acquired by AURELIUS Group (PE) in 2023 (~80% stake)
- Operates gastrohero.be as a Belgian localized storefront for equipment sales
- **Not a POS software provider. Not Belgian. Not the research target.**

### Company B — GastroHero (BELGIUM, POS software, Antwerp)
- Listed in SolStein's research brief as "Restaurant POS, Antwerp, BE"
- **No verifiable public company record found** in KBO, Crunchbase, LinkedIn, or Belgian company databases
- No Belgian legal entity named "GastroHero" in KBO search
- No Belgian software company website identified
- Domain gastrohero.be redirects to the German kitchen equipment company's Belgian storefront

**Critical note**: The confusion between the German kitchen equipment company and a hypothetical Belgian POS software company is significant. It is possible that:
1. The Belgian GastroHero POS company does not exist or has been discontinued
2. The company operates under a different legal name (e.g., "GastroHero Solutions BV" or similar)
3. It is a very small reseller/VAR of another POS system using the GastroHero brand

---

## Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name (BE POS) | Unknown | KBO — no match found | Unknown |
| KBO enterprise number | Unknown | Not found | Unknown |
| Legal form | Unknown | Not found | Unknown |
| Founding year | Unknown | Not found | Unknown |
| Founders | Unknown | Not found | Unknown |
| HQ address | Antwerp, Belgium (from research brief) | Research brief | Unknown |
| Website | gastrohero.be redirects to German kitchen equipment company | URL test | Confirmed |
| Product | POS for gastronomy (from brief) | Research brief | Unknown |
| Revenue / ARR | Unknown | Not found | Unknown |
| Employees | Unknown | Not found | Unknown |
| Investment rounds | Unknown | Not found | Unknown |
| GastroHero GmbH (DE) — PE-owned | AURELIUS Group holds ~80% | AURELIUS Group website | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A[GastroHero Belgium?<br/>Antwerp, BE<br/>Legal entity unknown] --> B[Research status: Cannot verify existence]
    C[GastroHero GmbH<br/>Holzwickede, Germany<br/>Kitchen Equipment — PE-owned] --> D[AURELIUS Group 80%]
    C --> E[gastrohero.be — Belgian storefront]
    note1[NOTE: These appear to be separate entities<br/>German company is NOT the research target]
```

---

## Corporate Timeline

```mermaid
timeline
    title GastroHero — Research Timeline
    2013 : GastroHero GmbH founded in Germany (Dortmund area) — kitchen equipment
    2023 : AURELIUS Group acquires 80% of GastroHero GmbH
    2026-04-30 : Research — Belgian POS software "GastroHero" cannot be verified
```

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Identity verification** | CRITICAL ISSUE — cannot confirm existence of Belgian POS software company named GastroHero |
| **German company** | PE-owned kitchen equipment company — entirely different business, not acquirable under SolStein thesis |
| **Recommended action** | Escalate to primary research: contact Antwerp HORECA IT community, check KBO with alternate legal names, verify if this is a reseller/VAR using the brand |
