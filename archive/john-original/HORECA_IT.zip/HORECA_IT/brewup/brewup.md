# BrewUp

**Category**: Brewery Software
**Country**: DE
**City**: Cologne
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history BrewUp @HORECA_IT/brewup/
@research-horeca-company BrewUp @HORECA_IT/brewup/
```
