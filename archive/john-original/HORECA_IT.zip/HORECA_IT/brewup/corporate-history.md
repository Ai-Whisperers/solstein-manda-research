# BrewUp — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — possible naming confusion with European brewers knowledge portal

---

## Executive Summary

"BrewUp" is listed in the SolStein research brief as a Cologne-based ERP software company for breweries and beverage logistics. Research found that "BrewUp" (brewup.eu) is actually a **knowledge portal for European brewers** operated by **The Brewers of Europe** (based in Brussels, Belgium) — not an ERP software company and not based in Cologne. There does not appear to be a Cologne-based ERP company named BrewUp. Brewery ERP software in Germany is a niche market served by a few specialized providers (e.g., BrewMan, various SAP-based systems) but none publicly named BrewUp in Cologne. This may represent a very small startup, a defunct company, or a naming error.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | BrewUp | SolStein research brief | Estimated |
| Legal entity name | Unknown (as Cologne ERP company) | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Cologne, North Rhine-Westphalia, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown | No public source found | Unknown |
| Country | Germany (reported) | SolStein research brief | Estimated |
| Primary activity | ERP for breweries and beverage logistics (reported) | SolStein research brief | Estimated |

---

## Disambiguation

| Entity | Description | Relevant? |
|---|---|---|
| BrewUp (brewup.eu) | Knowledge portal for brewers; operated by The Brewers of Europe (Brussels) | NOT the company referenced |
| BrewMan (Premier Systems) | Brewery management software for Germany; UK-based company | Not the same company |
| SolStein brief "BrewUp Cologne" | Brewery ERP Cologne | IDENTITY UNCONFIRMED |

---

## Research Methodology & Limitations

Searches conducted:
- "BrewUp Cologne brewery ERP software Germany"
- "BrewUp GmbH brewery software Cologne"
- German brewery software databases

All searches returned "BrewUp" as the Brewers of Europe knowledge portal (brewup.eu), not a Cologne ERP company.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — company existence not confirmed |
| **SolStein thesis fit** | Poor — brewery ERP is a niche adjacent to beverage hospitality, not core HORECA POS/PMS; Germany-only |
| **Research confidence** | Very low |

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| BrewUp (The Brewers of Europe) | https://brewup.eu/ | Disambiguation |
| BrewMan Germany (different company) | https://www.premiersystems.com/brewman-germany | Reference |
