# Lightspeed Hospitality — Corporate History

**Category**: POS / Restaurant
**Country**: NL (NL entity; global HQ: Canada)
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name (NL) | Lightspeed Netherlands B.V. | creditsafe.com / kompass.com | Confirmed |
| KvK Number | 17229470 | creditsafe.com (nl00903828) | Confirmed |
| Registered City | Amsterdam, 1051 LH | kompass.com — Haarlemmerweg 331, 1051 LH | Confirmed |
| NL Entity Founded | 2008 | creditsafe.com | Confirmed |
| Global Company Founded | 2005 | wikipedia.org/wiki/Lightspeed_Commerce | Confirmed |
| Founders | Dax Dasilva (founder & former CEO) | wikipedia.org/wiki/Lightspeed_Commerce | Confirmed |
| Current Ownership | Publicly traded — TSX: LSPD, NYSE: LSPD | lightspeedhq.com investor relations | Confirmed |
| PE/Investor Ownership | No PE; institutional shareholders (public markets) | lightspeedhq.com investor relations | Confirmed |
| Global Employees (FTE) | ~3,000 (FY2025) | macrotrends.net, wikipedia.org | Confirmed |
| Global Revenue (FY2025) | USD $1.076 billion (FY ended Mar 2025) | lightspeedhq.com/news FY2025 results | Confirmed |
| M&A History (as acquirer) | 12 acquisitions incl. Gastrofix (2020, EU hospitality, CAD 131M), Kounta (2019), NuORDER (2021), Ecwid (2021), Vend (2021) | tracxn.com, beehexa.com | Confirmed |
| Acquired by | Not acquired — remains independent public company | — | Confirmed |
| Investment Rounds | IPO on TSX Sep 2019; NYSE listing Mar 2020; multiple follow-on equity raises | wikipedia.org/wiki/Lightspeed_Commerce | Confirmed |
| Name Changes | None (Lightspeed POS → Lightspeed Commerce rebranding 2021) | wikipedia.org | Estimated |

---

## Corporate Structure

```mermaid
graph TD
    A[Lightspeed Commerce Inc.\nHQ: Montreal, Canada\nTSX: LSPD / NYSE: LSPD] --> B[Lightspeed Netherlands B.V.\nKvK 17229470\nAmsterdam, NL]
    A --> C[Lightspeed UK Ltd\nLondon]
    A --> D[Other international subsidiaries\nEU / APAC / NA]
    B --> E[HORECA / Restaurant POS\nNL & EMEA sales]
```

---

## Timeline

```mermaid
timeline
    title Lightspeed Commerce Key Events
    2005 : Founded by Dax Dasilva in Montreal, Canada
    2008 : Lightspeed Netherlands B.V. incorporated (KvK 17229470)
    2012 : First international office opened in Amsterdam
    2019 : IPO on Toronto Stock Exchange (TSX LSPD); Acquired Kounta (AUS hospitality)
    2020 : NYSE listing; Acquired Gastrofix (EU hospitality, CAD 131M)
    2021 : Acquired Vend, NuORDER (~USD 430M), Ecwid (~USD 500M); Rebranded to Lightspeed Commerce
    2024 : Announced ~10% workforce reduction; Strategic refocus on Hospitality EU + Retail NA
    2025 : FY2025 revenue USD 1.076B; USD 556M goodwill impairment charge; Adjusted EBITDA USD 53.7M
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | No | Publicly listed; Dax Dasilva stepped down as CEO in 2022 |
| PE-free | Yes | Public company; no PE ownership |
| Revenue in thesis range (€1M–€15M ARR) | No | Global revenue USD $1.076B FY2025; NL entity is a sales office, revenue not separately disclosed |
| Geographic fit (NL/BE) | Partial | Amsterdam office exists; NL is part of EMEA segment, not standalone |
| Succession signal | No | Public company with professional management |
| Overall feasibility | Very Low | Large-cap public company ($1B+ revenue); entirely outside acquisition thesis scope |
