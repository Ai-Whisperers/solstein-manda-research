# Lightspeed Hospitality — Deep Analysis

**Category**: POS / Restaurant
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity (NL) | Lightspeed Netherlands B.V. | creditsafe.com | Confirmed |
| HQ address (NL) | Haarlemmerweg 331, 1051 LH Amsterdam | hotelvak.eu, lightspeedhq.com/contact | Confirmed |
| Global HQ | 700 Saint-Antoine St. W, Montreal, QC, Canada | wikipedia.org/wiki/Lightspeed_Commerce | Confirmed |
| Founded (NL entity) | 2008 | creditsafe.com, kompass.com | Confirmed |
| Founded (global) | 2005 | wikipedia.org/wiki/Lightspeed_Commerce | Confirmed |
| CEO / MD | JP Chauvet (President & CEO, replaced Dax Dasilva in 2022) | wikipedia.org/wiki/Lightspeed_Commerce | Confirmed |
| Ownership structure | Public company — TSX: LSPD, NYSE: LSPD | lightspeedhq.com investor relations | Confirmed |
| Employees (FTE, global) | ~3,000 (FY2025) | macrotrends.net, wikipedia.org | Confirmed |
| Revenue (FY2025, ended Mar 31 2025) | USD $1.076 billion total; Subscription USD $344.8M; Transaction USD $697.3M | lightspeedhq.com/news/FY2025 | Confirmed |
| Profitability | Net loss USD $667.2M (incl. $556.4M non-cash goodwill impairment); Adj. EBITDA +$53.7M | lightspeedhq.com/news/FY2025 | Confirmed |
| Website | lightspeedhq.com | — | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | Global: 100+ countries; EU Hospitality primary growth focus | lightspeedhq.com FY2025 annual report | Confirmed |
| Customer count | 168,000+ customer locations globally (retail + hospitality combined) | portersfiveforce.com | Estimated |
| Target verticals | Restaurants, bars, cafes, hotels, nightclubs; also retail (separate segment) | lightspeedhq.com/pos/restaurant | Confirmed |
| Market share estimate | Top 3 global cloud POS provider; European hospitality identified as strategic growth segment | lightspeedhq.com FY2025 report | Estimated |
| Key competitors | Toast (US), Square for Restaurants, Revel Systems, Oracle MICROS, Tevalis, Agilysys | — | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Lightspeed Restaurant (K-Series): cloud POS, table management, menu management, KDS, payments | lightspeedhq.com/pos/restaurant | Confirmed |
| Tech stack | Cloud-native SaaS; iPad/tablet-based POS; real-time sync; AI analytics ("Benchmarks & Trends") | lightspeedhq.com/pos/restaurant, deliverect.com | Confirmed |
| Deployment model | Cloud (SaaS); offline mode supported | lightspeedhq.com | Confirmed |
| API availability | Yes — open API and partner integrations (400+) | lightspeedhq.com integrations | Confirmed |
| Key integrations | Resengo (reservations), Deliverect (delivery), Mews/Oracle/Cloudbeds/StayNTouch (PMS), accounting tools | lightspeedhq.com/integrations/resengo | Confirmed |
| Mobile app | Yes — Lightspeed Restaurant app (iOS/Android management) | lightspeedhq.com | Confirmed |
| Payment solution | Lightspeed Payments (embedded, card-present and online); launched EU 2023 | lightspeedhq.com/news/lightspeed-payments-expands-in-emea | Confirmed |
| Lightspeed Capital | Cash advance product for merchants; repayment linked to daily card volume | deliverect.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | No | Dax Dasilva stepped down as CEO Feb 2022; JP Chauvet took over | wikipedia.org/wiki/Lightspeed_Commerce | Confirmed |
| Investor type | Public institutional investors (TSX/NYSE) | lightspeedhq.com investor relations | Confirmed |
| PE ownership | No | Public company | Confirmed |
| Succession signals | None relevant — professional management team in place | — | Confirmed |
| Last funding date | Follow-on equity raise Sep 2020 (~CAD 810M); not since IPO 2019 | wikipedia.org | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | FY2023: ~USD $730M → FY2024: USD $909M → FY2025: USD $1.076B (18% YoY growth) | lightspeedhq.com/news/FY2025 | Confirmed |
| Employee growth | Peak ~3,500 (2022–2023); ~10% workforce reduction announced April 2024; stabilized ~3,000 | macrotrends.net | Confirmed |
| New markets | EU Hospitality named as primary growth engine for FY2026 alongside NA Retail | lightspeedhq.com FY2025 annual report | Confirmed |
| Recent product launches | Lightspeed Payments EU (5 European markets, 2023); AI analytics "Benchmarks & Trends" (2024) | lightspeedhq.com | Confirmed |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Full-service restaurants, QSR, bars, hotels (restaurant within hotel), nightclubs | lightspeedhq.com/pos/restaurant | Confirmed |
| GDPR/AVG compliance | Yes — cloud provider operating in EU; GDPR compliance documented | lightspeedhq.com | Confirmed |
| Allergen management | Supported via menu management module (ingredient-level tracking) | lightspeedhq.com | Estimated |
| Fiscal compliance NL | Supports NL fiscal requirements; Lightspeed Payments NL-certified | lightspeedhq.com/news/lightspeed-payments-expands-in-emea | Estimated |
| iDEAL/Bancontact/Tikkie support | iDEAL and Bancontact supported via Lightspeed Payments EU | lightspeedhq.com/news/lightspeed-payments-expands-in-emea | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | SaaS subscription + transaction-based payment processing fees; hardware sales | lightspeedhq.com | Confirmed |
| Estimated ARR | Subscription revenue USD $344.8M (FY2025); total revenue USD $1.076B | lightspeedhq.com/news/FY2025 | Confirmed |
| Market capitalization | ~CAD 1.5B–2B (approximate, public market; varies) | TSX: LSPD | Estimated |
| Revenue per employee | ~USD $359K/FTE (USD $1.076B ÷ 3,000) | calculated | Estimated |
| NL entity revenue | Not separately disclosed; NL is a sales/commercial office within EMEA segment | — | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Public company, no founder succession dynamic, institutional ownership | lightspeedhq.com / TSX |
| Revenue scale fit | High | 1 | USD $1.076B global revenue; thesis ceiling is €15M ARR — completely outside range | lightspeedhq.com/news/FY2025 |
| Geographic fit | High | 2 | Amsterdam office exists; however, NL is a minority sales territory within global EMEA | hotelvak.eu |
| Tech stack modernity | Medium | 5 | Best-in-class cloud-native POS; iPad-based, open API, AI analytics, embedded payments | lightspeedhq.com |
| Customer lock-in | Medium | 4 | High switching costs (POS migrations); embedded payments further increase stickiness | lightspeedhq.com |
| Vertical depth | Medium | 4 | Deep restaurant/hospitality feature set; hotel POS integration; acquired Gastrofix for EU | lightspeedhq.com |
| Integration potential | Low | 3 | Open API ecosystem (400+ integrations); could theoretically integrate but scale mismatch | lightspeedhq.com/integrations |
| Growth trajectory | Low | 3 | 18% revenue growth but net loss; workforce reduction; goodwill impairment USD $556M | lightspeedhq.com/news/FY2025 |

**Composite Score**: 2.3 / 5.0

**Confidence Band**: Narrow (publicly disclosed financials; strong data quality)

**Overall M&A Assessment**: Lightspeed Hospitality is a globally listed, large-cap software company entirely outside SolStein's acquisition thesis by scale, ownership type, and geography. The Dutch entity (Lightspeed Netherlands B.V., KvK 17229470) is a sales/commercial office, not an independent revenue-generating entity. With USD $1.076B in global revenue and 3,000 employees, this target is categorically not acquirable within the €1M–€15M ARR HORECA thesis. The product is best-in-class and could serve as a competitive reference point or integration partner.

**Recommended Next Step**: No acquisition pursuit. Consider evaluating Lightspeed as a potential integration/channel partner for a SolStein portfolio company given their open API ecosystem and EU HORECA focus.
