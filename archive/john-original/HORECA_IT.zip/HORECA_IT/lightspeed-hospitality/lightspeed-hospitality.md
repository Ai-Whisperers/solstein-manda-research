# Lightspeed Hospitality

**Category**: POS/Restaurant
**Country**: NL
**City**: Amsterdam
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Lightspeed Hospitality @HORECA_IT/lightspeed-hospitality/
@research-horeca-company Lightspeed Hospitality @HORECA_IT/lightspeed-hospitality/
```
