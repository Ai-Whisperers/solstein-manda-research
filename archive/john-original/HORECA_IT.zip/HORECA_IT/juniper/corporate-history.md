# Juniper — Corporate History

**Category**: Hotel PMS
**Country**: NL
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Unknown (not Juniper B.V. KvK 11014079 — see disambiguation) | openkvk.nl, transfirm.nl | Unknown |
| KvK Number | Unknown | openkvk.nl — no hotel PMS company matching | Unknown |
| Registered City | Utrecht (claimed) | Task brief; not verified in KvK | Unknown |
| Founding Year | Unknown | No public record found | Unknown |
| Founders | Unknown | No public record found | Unknown |
| Current Ownership | Unknown | No public record found | Unknown |
| PE/Investor Ownership | Unknown | No public record found | Unknown |
| Employees (FTE) | Unknown | No LinkedIn company page found | Unknown |
| Estimated Revenue | Unknown | No financial data found | Unknown |
| M&A History | Unknown | No public record found | Unknown |
| Investment Rounds | Unknown | No public record found | Unknown |
| Name Changes | Unknown | No public record found | Unknown |

---

## Research Notes

**Domain status**:
- `juniper-pms.nl` — HTTP 503 on 2026-04-30 (server active, service temporarily unavailable)
- `juniper.nl` — connection timeout on 2026-04-30 (domain may be active)
- `juniperbv.nl` — returns a placeholder page ("Secured Home of juniperbv.nl"), no content

**KvK search**: An openkvk.nl search for "juniper hotel" returned 4,909 general results. The most directly relevant was:

> **Juniper B.V.** — KvK 11014079 — Zaltbommel, Gelderland — Activity: "De handel in, alsmede het bewerken, repareren en onderhouden van bouw-, hout- en plaatmaterialen en producten" (construction/wood materials trading)

This is **NOT** the hotel PMS company. This Juniper B.V. is a construction materials company, not a hotel software provider.

**Disambiguation — entities named "Juniper" in the Netherlands**:
| Entity | KvK | Location | Activity |
|---|---|---|---|
| Juniper B.V. | 11014079 | Zaltbommel | Construction/wood materials |
| Juniper Networks International B.V. | 55416810 | Schiphol-Rijk | IT networking (Juniper Networks) |
| Juniper Europe B.V. | 88526267 | Amsterdam | Telehealth platform |
| Juniper Netherlands B.V. | 96986727 | Amsterdam | Unknown (recently registered) |

None of the above are hotel PMS companies in Utrecht.

**Global "Juniper" in hotel/PMS sector**:
- **Juniper Travel Technology** (ejuniper.com) — Spanish company (Palma de Mallorca), booking engine for travel agencies and tour operators; part of Constellation Software / Vela Software via Juniper Group; NOT a hotel PMS and NOT based in the Netherlands.

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown — Founder / Owner] --> B[Juniper NL — Operating Entity — Utrecht?]
    B --> C[Hotel PMS SaaS — HORECA]
```

*Structure is entirely inferred from task brief; no primary sources available.*

---

## Timeline

```mermaid
timeline
    title Juniper Hotel PMS — Key Events (Reconstructed)
    Unknown : Founded — year not established
    2026-04-30 : Research conducted — juniper-pms.nl returns HTTP 503
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | No ownership data found |
| PE-free | Unknown | No investor data found |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No financial data found |
| Geographic fit (NL/BE) | Likely Yes | Claimed Utrecht, NL; unverified |
| Succession signal | Unknown | No public signal found |
| Overall feasibility | Unknown | Insufficient data to assess |

---

## Research Confidence Summary

Research across openkvk.nl, kvk.nl, LinkedIn, Crunchbase, Google, and direct website access produced **no verifiable data** about Juniper as a Dutch Utrecht-based hotel PMS company. The domain `juniper-pms.nl` is active (server responds) but inaccessible. The domain `juniper.nl` times out. No Dutch hotel PMS company named Juniper is registered in the KvK.

A **direct outreach** or **paid KvK extract** would be required to confirm basic corporate facts. Given the company appears to have a domain registered and a server running, it likely exists as a small, early-stage or micro-cap software company.
