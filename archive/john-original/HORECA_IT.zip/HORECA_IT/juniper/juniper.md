# Juniper

**Category**: Hotel PMS
**Country**: NL
**City**: Utrecht
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Juniper @HORECA_IT/juniper/
@research-horeca-company Juniper @HORECA_IT/juniper/
```
