# Juniper — Deep Analysis

**Category**: Hotel PMS
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | openkvk.nl — no hotel PMS match | Unknown |
| HQ address | Utrecht, NL (claimed) | Task brief only | Unknown |
| Founded | Unknown | No public record | Unknown |
| CEO / MD | Unknown | No public record | Unknown |
| Ownership structure | Unknown | No public record | Unknown |
| Employees (FTE) | Unknown | No LinkedIn page found | Unknown |
| Revenue (latest estimate) | Unknown | No financial data found | Unknown |
| Profitability | Unknown | No financial data found | Unknown |
| Website | juniper-pms.nl (exists, HTTP 503 on 2026-04-30); juniper.nl (timeout) | Direct fetch attempts | Unknown |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | NL (claimed) | Task brief | Unknown |
| Customer count | Unknown | No public data | Unknown |
| Target verticals | Hotel / accommodation PMS (claimed) | Task brief | Unknown |
| Market share estimate | Unknown | No public data | Unknown |
| Key competitors | Mews, RoomRaccoon, Opera Cloud (Oracle), Cloudbeds, Van Hessen / OPERA, Smarthotel | Dutch hotel PMS market research | Estimated |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Hotel property management system (claimed) | Task brief | Unknown |
| Tech stack | Unknown | No public data | Unknown |
| Deployment model | Unknown — likely cloud/SaaS given domain existence | Sector inference | Unknown |
| API availability | Unknown | No public data | Unknown |
| Key integrations | Unknown | No public data | Unknown |
| Mobile app | Unknown | No public data | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No public data | Unknown |
| Investor type | Unknown | No public data | Unknown |
| PE ownership | Unknown | No public data | Unknown |
| Succession signals | Unknown | No public data | Unknown |
| Last funding date | Unknown | No public data | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No public data | Unknown |
| Employee growth | Unknown | No LinkedIn history | Unknown |
| New markets | Unknown | No public data | Unknown |
| Recent product launches | Unknown | No public data | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Hotel / accommodation (claimed) | Task brief | Unknown |
| GDPR/AVG compliance | Unknown | No public data | Unknown |
| Allergen management | Unlikely (PMS product, not F&B) | Sector inference | Unknown |
| Fiscal compliance NL — fiscal receipts / BTW | Unknown | No public data | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown — likely relevant for guest payment flows | Sector inference | Unknown |
| Channel manager integration | Unknown — critical for any Dutch hotel PMS | No public data | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown | No public data | Unknown |
| Estimated ARR | Unknown | No public data | Unknown |
| Estimated acquisition value | Unknown | No public data | Unknown |
| Revenue per employee | Unknown | No public data | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot score — no ownership data | — |
| Revenue scale fit | High | N/A | Cannot score — no revenue data | — |
| Geographic fit | High | N/A | Utrecht, NL claimed; unverified | Task brief |
| Tech stack modernity | Medium | N/A | Cannot score — no product data | — |
| Customer lock-in | Medium | N/A | Hotel PMS = inherently high switching costs | Sector inference |
| Vertical depth | Medium | N/A | Cannot score — no product detail | — |
| Integration potential | Low | N/A | Cannot score — no tech data | — |
| Growth trajectory | Low | N/A | Cannot score — no growth data | — |

**Composite Score**: N/A — Insufficient data
**Confidence Band**: Wide (high uncertainty)
**Overall M&A Assessment**: No verifiable public data exists for a Dutch hotel PMS company named Juniper in Utrecht. The domain `juniper-pms.nl` is active (HTTP 503) indicating the company likely exists in some form. Hotel PMS software inherently creates high customer lock-in (data migration, staff retraining, OTA connectivity) which aligns well with SolStein's thesis around switching costs. However, this company is indistinguishable from the more prominent global entities carrying the Juniper name, making due diligence particularly important to avoid confusion.
**Recommended Next Step**: Access juniper-pms.nl when the server becomes available; conduct a specific KvK search for Utrecht-registered software companies (SBI 6201/6202) with "juniper" in their name or trade name; check Dutch hotel industry associations (Koninklijke Horeca Nederland, Hotel Management Netherlands) for references; consider that the entity may be registered under a different legal name.

---

## 9. Disambiguation — "Juniper" Entities

Extensive research identified **four** entities named "Juniper" in the Netherlands — none are hotel PMS companies:

| Entity | KvK | City | Business | Relevant? |
|---|---|---|---|---|
| Juniper B.V. | 11014079 | Zaltbommel | Construction / wood materials trading | No |
| Juniper Networks International B.V. | 55416810 | Schiphol-Rijk | IT networking equipment | No |
| Juniper Europe B.V. | 88526267 | Amsterdam | Telehealth platform | No |
| Juniper Netherlands B.V. | 96986727 | Amsterdam | Unknown | Unlikely |

*Sources: openkvk.nl, northdata.com, transfirm.nl (accessed 2026-04-30)*

**Note**: Juniper Travel Technology (ejuniper.com, Spain) is a Constellation Software subsidiary providing booking engine software for travel agencies. It is **not** a hotel PMS and is **not** Dutch.

---

## 10. Competitive Landscape — Dutch Hotel PMS Market

| Competitor | HQ | Positioning | Notes |
|---|---|---|---|
| Mews | Amsterdam, NL | Cloud-native PMS, rapidly growing | €300M raised (2023); direct competitor |
| RoomRaccoon | Breda, NL | Independent hotels cloud PMS | Founded 2017, Dutch market leader for independents |
| Van Hessen | Netherlands | Oracle OPERA reseller/implementer | [vanhessen.nl](https://www.vanhessen.nl) |
| Cloudbeds | San Diego, USA | Global cloud PMS | Strong in NL market |
| Smarthotel | Netherlands | Hotel tech solutions | [smarthotel.nl](https://www.smarthotel.nl) |
| Runnr.ai | Utrecht, NL | Guest communication platform | Utrecht-based; may be confused with Juniper |

*Sources: F6S, Tracxn, hoteltechreport.com, company websites (accessed 2026-04-30)*

---

## 11. Research Methodology & Limitations

**Searches conducted**:
- openkvk.nl — "juniper", "juniper hotel", "juniper pms" — no Dutch hotel PMS match
- Google — multiple query variants in Dutch and English
- LinkedIn — no Dutch hotel PMS Juniper company page found
- Direct website — juniper-pms.nl returns HTTP 503 (server exists, service down)
- Direct website — juniper.nl times out (may be active)
- northdata.com, transfirm.nl — Juniper B.V. (KvK 11014079) found; construction company
- Crunchbase, PitchBook, Tracxn — no Dutch hotel PMS Juniper found

**Limitation**: Three unrelated companies and one global travel tech company share the "Juniper" name in the Netherlands context. The specific Utrecht hotel PMS company cannot be identified from public records. Direct outreach to `juniper-pms.nl` when the server recovers is the recommended immediate next step.
