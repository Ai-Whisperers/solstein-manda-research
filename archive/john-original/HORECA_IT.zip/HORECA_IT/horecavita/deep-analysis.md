# Horecavita — Deep Analysis

**Category**: Restaurant POS
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## Research Methodology

Extensive web research was conducted on 2026-04-30 using 12+ targeted searches across OpenKvK.nl, kvk.nl, LinkedIn, Crunchbase, Dealroom, Google, and direct website fetches. OpenKvK returned zero results for "horecavita". The LinkedIn company URL returned 404. The website horecavita.nl timed out on two separate attempts. No cached or archived version was accessible. All fields below are marked accordingly.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | OpenKvK.nl — zero results for "horecavita" | Unknown |
| HQ address | Amsterdam, NL (per brief) | Brief only | Estimated |
| Founded | Unknown | No public record | Unknown |
| CEO / MD | Unknown | No LinkedIn company page (404) | Unknown |
| Ownership structure | Unknown | No KvK or investor data | Unknown |
| Employees (FTE) | Unknown | No LinkedIn company page | Unknown |
| Revenue (latest estimate) | Unknown | No financial data | Unknown |
| Profitability | Unknown | No financial data | Unknown |
| Website | horecavita.nl (per brief) — currently unresponsive (timeout) | Direct fetch attempt 2026-04-30 | Estimated |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | NL (assumed per brief) | Brief only | Estimated |
| Customer count | Unknown | No data found | Unknown |
| Target verticals | Restaurant POS / HORECA management software (per brief) | Brief only | Estimated |
| Market share estimate | Unknown | No data found | Unknown |
| Key competitors | unTill, MplusKassa, Lightspeed NL, Bork Horeca, CashDesk, UniTouch, TONIT | Web research — confirmed active NL POS vendors | Confirmed |

### NL Restaurant POS Competitive Landscape

The Dutch HORECA POS market is well-established with several confirmed competitors:
- **unTill**: Dutch market leader in hospitality POS; cloud and on-premise solutions; 25+ years in market.
- **MplusKassa**: 120,000+ daily users NL/BE; strong SME penetration.
- **Lightspeed** (NL): International platform with Amsterdam office; restaurant + retail POS.
- **Bork Horeca**: Full-stack HORECA automation including POS, kitchen, and scheduling.
- **CashDesk**: Hoofddorp-based restaurant POS and delivery integrations.
- **UniTouch** (Biesbroeck Automation BV, Hulst — KvK 62182447): Cloud back-office POS for HORECA and retail; ~20 years experience.
- **TONIT**: 15+ years HORECA POS under "Ecash" brand.

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | POS and management software for HORECA (per brief) | Brief only | Estimated |
| Tech stack | Unknown | No product website accessible | Unknown |
| Deployment model | Unknown | No data | Unknown |
| API availability | Unknown | No data | Unknown |
| Key integrations | Unknown | No data | Unknown |
| Mobile app | Unknown | No app store listing found | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No ownership data | Unknown |
| Investor type | Unknown | No Crunchbase / Dealroom record | Unknown |
| PE ownership | Unknown | No PE tracking data | Unknown |
| Succession signals | Unknown | No leadership data | Unknown |
| Last funding date | Unknown | No fundraise records | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No financial data | Unknown |
| Employee growth | Unknown | No headcount data | Unknown |
| New markets | Unknown | No data | Unknown |
| Recent product launches | Unknown | No press or product pages found | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Restaurant POS (per brief); broader HORECA assumed | Brief only | Estimated |
| GDPR/AVG compliance | Unknown | No privacy policy found | Unknown |
| Allergen management | Unknown | No product details available | Unknown |
| Fiscal compliance NL | Unknown | No product details available | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown | No payment documentation found | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown | No pricing page accessible | Unknown |
| Estimated ARR | Unknown | No financial data | Unknown |
| Estimated acquisition value | Unknown | Cannot estimate without revenue or headcount | Unknown |
| Revenue per employee | Unknown | No data on either metric | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot assess — no ownership data | — |
| Revenue scale fit | High | N/A | Cannot assess — no revenue data; sub-scale likely given zero public presence | — |
| Geographic fit | High | 3 | Amsterdam, NL per brief — matches thesis geography | Brief |
| Tech stack modernity | Medium | N/A | No product information accessible | — |
| Customer lock-in | Medium | 3 | Restaurant POS typically has moderate-to-high switching costs (hardware, staff retraining, integrations) | Market knowledge |
| Vertical depth | Medium | N/A | NL HORECA POS niche is valid but highly competitive | Market knowledge |
| Integration potential | Low | N/A | Unknown without product information | — |
| Growth trajectory | Low | N/A | No data | — |

**Composite Score**: Insufficient data — N/A
**Confidence Band**: Wide (zero accessible public information)
**Overall M&A Assessment**: Horecavita has no verifiable public corporate footprint as of 2026-04-30. OpenKvK returns zero results, LinkedIn company page does not exist, and the website is unresponsive. The NL restaurant POS market is highly competitive and populated by established players. Without confirmed existence as a trading entity and revenue data, SolStein cannot make an M&A assessment.
**Recommended Next Step**: (1) WHOIS lookup for horecavita.nl to identify domain registrant and registrar. (2) Dutch Trade Register search for any entity with "vita" in name + NACE code 6202 + Amsterdam. (3) If entity confirmed active: request a KvK extract (uittreksel) and initiate direct outreach to verify revenue and ownership before investing further research time.
