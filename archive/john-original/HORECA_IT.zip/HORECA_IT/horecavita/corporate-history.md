# Horecavita — Corporate History

**Category**: Restaurant POS
**Country**: NL
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Unknown | OpenKvK.nl — "horecavita" returned zero results | Unknown |
| KvK Number | Unknown | OpenKvK.nl — no matching entry | Unknown |
| Registered City | Amsterdam (per brief) | Brief only — not confirmed via primary source | Estimated |
| Founding Year | Unknown | No public record found | Unknown |
| Founders | Unknown | No public record found | Unknown |
| Current Ownership | Unknown | No public record found | Unknown |
| PE/Investor Ownership | Unknown | No Crunchbase/Dealroom record found | Unknown |
| Employees (FTE) | Unknown | LinkedIn company page not found (404) | Unknown |
| Estimated Revenue | Unknown | No financial data available | Unknown |
| M&A History | None found | No press records or registry changes found | Unknown |
| Investment Rounds | None found | No investor tracking data found | Unknown |
| Name Changes | Unknown | No KvK historical record available | Unknown |

---

## Research Notes

Extensive web research (10+ searches) conducted on 2026-04-30 yielded no publicly discoverable company registered under the name "Horecavita" in the Netherlands. Key findings:

- **OpenKvK.nl**: Direct search for "horecavita" returned **zero results** (confirmed via direct page fetch).
- **kvk.nl**: Search portal failed to load for validation.
- **LinkedIn**: linkedin.com/company/horecavita returned **404 Not Found** — no company page exists.
- **Website horecavita.nl**: Connection **timed out** on two separate fetch attempts — site may be offline, parked, or behind a CDN firewall.
- **Wayback Machine**: Blocked (403 Forbidden) for horecavita.nl — no cached snapshot accessible.
- **Web searches (NL/EN)**: Searches for "horecavita kassasysteem", "horecavita Amsterdam POS", and "horecavita bedrijf Nederland" returned zero relevant results. Searches for "horecavita.nl" specifically found no indexed pages.
- **Confusion risk**: "Horecava" (horecava.nl) is a major annual Dutch hospitality trade fair (RAI Amsterdam); this is a distinct entity and is NOT Horecavita.

The company may use a different legal/trade name, may be a recently dissolved entity, or may have exceptionally limited digital presence. The domain horecavita.nl appears to exist but is currently unresponsive.

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown — Founder / Parent] --> B[Operating Company NL — Legal Entity Unknown]
    B --> C[Horecavita POS / Restaurant Management Platform]
```

---

## Timeline

```mermaid
timeline
    title Horecavita Key Events
    Unknown : Founded — year not publicly available
    2026-04-30 : SolStein M&A research initiated — no public record found
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | Ownership structure not publicly available |
| PE-free | Unknown | No investor data found; likely PE-free given minimal public presence |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No financial data; likely sub-scale given zero public presence |
| Geographic fit (NL/BE) | Estimated Yes | Brief states Amsterdam, NL |
| Succession signal | Unknown | No leadership data found |
| Overall feasibility | Unknown | Insufficient data to assess |

---

## Recommended Next Steps

1. Verify domain registrant via WHOIS for horecavita.nl to identify the legal entity behind the domain.
2. Search Dutch Trade Register via API or commercial data provider using "horeca" + "vita" name variations in Amsterdam municipality.
3. Contact domain host/registrar to ascertain if horecavita.nl is active or lapsed.
4. Conduct LinkedIn search for employees/founders listing "Horecavita" as employer.
5. Review the Horecava exhibitor database (horecava.nl) for any "Horecavita" entry in past years (2019–2025).
