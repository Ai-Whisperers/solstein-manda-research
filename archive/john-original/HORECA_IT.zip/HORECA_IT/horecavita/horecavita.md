# Horecavita

**Category**: Restaurant POS
**Country**: NL
**City**: Amsterdam
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Horecavita @HORECA_IT/horecavita/
@research-horeca-company Horecavita @HORECA_IT/horecavita/
```
