# Guestline

**Category**: Hotel PMS
**Country**: UK
**City**: Shrewsbury
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Guestline @HORECA_IT/guestline/
@research-horeca-company Guestline @HORECA_IT/guestline/
```
