# Guestline — Deep Analysis

**Category**: Hotel PMS (Property Management System)
**Country**: UK (Shrewsbury, Shropshire, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; acquired by Access Group Jul 2023; Riverside PE exit)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Guestline Ltd | Companies House (inferred) | Estimated |
| HQ | Shrewsbury, Shropshire, UK | PitchBook, phocuswire.com | Confirmed |
| Founded | 1991 (PitchBook) or 1997 (tracxn) | PitchBook / tracxn | Estimated |
| Founders | Not publicly identified | — | Unknown |
| Current ownership | The Access Group (Hg + TA Associates PE-backed) | theaccessgroup.com | Confirmed |
| Acquisition date | 11 July 2023 | theaccessgroup.com | Confirmed |
| Prior PE backer | The Riverside Company (2016–2023) | phocuswire.com | Confirmed |
| Employees | Not disclosed standalone; integrated into Access Group | — | Unknown |
| Revenue | Not disclosed | — | Unknown |
| Business model | Cloud hotel PMS SaaS subscription | guestline.com | Confirmed |
| Product | Cloud hotel PMS: reservations, front desk, channel management, distribution | guestline.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Venues at acquisition | 2,900+ | phocuswire.com | Confirmed |
| Countries at acquisition | 23 | phocuswire.com | Confirmed |
| UK market | Primary historical market | guestline.com | Confirmed |
| EU/international | 23-country presence at acquisition | phocuswire.com | Confirmed |
| NL/BE presence | Possible (23 countries); not specifically confirmed | phocuswire.com | Estimated |
| Target customer | Mid-market hotels; serviced apartments; boutique groups | guestline.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | Cloud hotel PMS | guestline.com | Confirmed |
| Channel management | Integrated channel manager (OTA connectivity) | guestline.com | Confirmed |
| Distribution | Hotel distribution and operations platform | phocuswire.com | Confirmed |
| Booking engine | Direct booking engine | guestline.com | Confirmed |
| Newbridge Software | Cloud retailing tech for restaurants/bars (acquired Oct 2022) | phocuswire.com | Confirmed |
| Deployment | Cloud-native SaaS | guestline.com | Confirmed |
| Integration | Now integrated with Access Hospitality suite (SHR, Omnifi, ResDiary) | theaccessgroup.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pre-2016 ownership | Founders / management | Historical pattern | Estimated |
| 2016–2023 | The Riverside Company (PE majority) | phocuswire.com | Confirmed |
| 2023–present | The Access Group | theaccessgroup.com | Confirmed |
| PE exit pattern | Riverside hold: 7 years → trade sale to Access | phocuswire.com | Confirmed |
| Founder involvement | Unknown post-PE acquisition | — | Unknown |
| Divestiture likelihood | Very low — core Access Hospitality product | theaccessgroup.com | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not disclosed | — | Unknown |
| Access Hospitality revenue impact | FY2023: £64.7M → FY2024: £118.8M (Guestline acquisition primary driver) | Access Annual Report FY2024 | Confirmed |
| Guestline contribution (estimate) | ~£30–50M ARR at time of acquisition | Derived from Access rev impact | Estimated |
| Growth (as Access subsidiary) | Tied to Access Hospitality platform growth | theaccessgroup.com | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK hotel PMS | Full hotel operations: reservations, front desk, housekeeping | guestline.com | Confirmed |
| Channel management | OTA connectivity (Booking.com, Expedia, etc.) | guestline.com | Confirmed |
| UK compliance | UK GDPR, UK financial reporting | guestline.com | Confirmed |
| International | 23-country operations; multi-currency | phocuswire.com | Confirmed |
| Restaurant/F&B | Via Newbridge Software acquisition | phocuswire.com | Confirmed |
| Reporting | Revenue management and performance reporting | guestline.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription per property/per room | guestline.com | Confirmed |
| ARR estimate at acquisition | £30M–£50M (inferred from Access revenue impact) | Derived | Estimated |
| Acquisition price | Not disclosed | phocuswire.com | Unknown |
| Riverside return | Likely 3–5x invested capital over 7 years | PE industry norms | Estimated |
| SolStein fit | No — acquired; UK/international; far above target range | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Wholly owned by The Access Group (PE-backed); not separable | theaccessgroup.com |
| Revenue scale fit | High | 1 | Estimated £30M–£50M ARR — far above SolStein's target | Derived |
| Geographic fit | High | 2 | UK primary; 23 countries including potential NL/BE; but not NL/BE focused | phocuswire.com |
| Tech stack modernity | Medium | 4 | Cloud-native hotel PMS; OTA integrations; active development | guestline.com |
| Customer lock-in | Medium | 5 | PMS creates strongest hospitality lock-in (all hotel data) | guestline.com |
| Vertical depth | Medium | 5 | Deep hotel PMS + channel management + F&B (via Newbridge) | guestline.com |
| Integration potential | Low | 4 | Integrated into Access Hospitality; marketplace | theaccessgroup.com |
| Growth trajectory | Low | 4 | Growing within Access Hospitality's accelerating platform | Access Annual Report |

### Composite Score

**Weighted Composite: 2.4 / 5.0**

*(High-weight dimensions: ownership = 1, revenue scale = 1, geographic fit = 2)*

**Confidence Band**: Medium — acquisition facts confirmed; revenue estimated.

### Overall M&A Assessment

Guestline is **not an acquisition target** for SolStein — it has been acquired and integrated. Its strategic importance is as the **definitive cloud hotel PMS benchmark for UK mid-market hotels**: 2,900+ venues, 23 countries, acquired at what is likely a £30–50M ARR level. Any NL/BE cloud hotel PMS at £1–10M ARR, founder-owned, represents the SolStein opportunity this benchmarks against.

### Recommended Next Step

No pursuit. Use Guestline as the cloud hotel PMS benchmark. Evaluate NL/BE hotel PMS companies (Misterbook, Juniper, Valk Solutions) against this profile for SolStein targeting.

---

*Sources: phocuswire.com (Access Group acquires Guestline), theaccessgroup.com, PitchBook, tracxn.com, guestline.com.*
