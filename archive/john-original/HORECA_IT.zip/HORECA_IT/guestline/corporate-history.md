# Guestline — Corporate History

**Category**: Hotel PMS (Property Management System)
**Country**: UK (Shrewsbury, Shropshire, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; PE-backed, acquired by Access Group Jul 2023)

---

## Summary Assessment

Guestline was a **Shrewsbury-based cloud hotel PMS** company, founded ~1991–1997, PE-backed by **The Riverside Company** from 2016. It was **acquired by The Access Group** (Access Hospitality division) on **11 July 2023**, exiting Riverside's portfolio. At time of acquisition it served 2,900+ venues in 23 countries. It is now fully integrated into Access Hospitality — not a standalone target.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Guestline | guestline.com | Confirmed |
| HQ | Shrewsbury, Shropshire, UK | PitchBook, phocuswire.com | Confirmed |
| Founded | 1991 (PitchBook) / 1997 (tracxn.com) — conflicting | PitchBook / tracxn | Estimated |
| Founders | Not publicly identified | — | Unknown |
| PE backer | The Riverside Company (2016–2023) | phocuswire.com, realdeals.eu.com | Confirmed |
| Riverside investment date | 2016 | phocuswire.com | Confirmed |
| Acquirer | The Access Group (Access Hospitality) | phocuswire.com | Confirmed |
| Acquisition date | 11 July 2023 | theaccessgroup.com | Confirmed |
| Acquisition seller | The Riverside Company | phocuswire.com | Confirmed |
| Acquisition terms | Not disclosed | phocuswire.com | Unknown |
| Venues at acquisition | 2,900+ | phocuswire.com | Confirmed |
| Countries at acquisition | 23 | phocuswire.com | Confirmed |
| Own acquisition: Newbridge Software | October 2022 (cloud retailing tech for restaurants/bars) | phocuswire.com | Confirmed |
| Current status | Subsidiary of The Access Group (Access Hospitality) | theaccessgroup.com | Confirmed |
| Revenue | Not publicly disclosed | — | Unknown |

---

## Founding & History

Guestline was founded in the early 1990s in **Shrewsbury, Shropshire**, as a hospitality software company. It developed an **on-premise hotel PMS** and gradually transitioned to a cloud-native platform.

**2016**: **The Riverside Company** (US-based global PE firm) acquired a majority stake to support international expansion and product investment. Under Riverside's ownership, Guestline accelerated its cloud PMS development and international growth.

**October 2022**: Guestline acquired **Newbridge Software**, a provider of cloud-based retailing technology for restaurants and bars — expanding its product suite beyond PMS.

**July 11, 2023**: **The Access Group** acquired Guestline from The Riverside Company. The deal was not priced publicly. Guestline's 2,900+ venues in 23 countries gave Access Hospitality a significant hotel PMS capability and international footprint. This acquisition doubled Access Hospitality's revenue (£64.7M → £118.8M in FY2024).

---

## Corporate Structure (Timeline — Pre and Post Acquisition)

```mermaid
graph TD
    A["Founders (unknown)"]
    B["Guestline Ltd<br/>(Shrewsbury, UK)"]
    C["The Riverside Company (PE)<br/>2016–2023"]
    D["The Access Group (Hg + TA Associates PE)<br/>Acquired Jul 11, 2023"]
    E["Access Hospitality Division"]
    F["Newbridge Software<br/>(acquired Oct 2022)"]

    A -->|"Pre-2016"| B
    C -->|"PE backing 2016"| B
    D -->|"Acquired Jul 2023"| B
    B -->|"Integrated into"| E
    B -->|"Acquired Oct 2022"| F
```

---

## PE Ownership Timeline

| Period | Owner | Role | Notes |
|---|---|---|---|
| ~1991–2016 | Founders / management | Owner-managed | ~25 years independent |
| 2016–2023 | The Riverside Company | Majority PE | International growth |
| Jul 2023–present | The Access Group | Full acquisition | Via Access Hospitality |

---

## Timeline of Critical Events

```mermaid
timeline
    title Guestline — Key Milestones
    1991 (or 1997) : Founded in Shrewsbury UK; hotel PMS development
    2016 : The Riverside Company acquires majority stake
    2022 : Newbridge Software acquired (Oct 2022); cloud retailing tech
    2023 : Acquired by The Access Group from Riverside (Jul 11, 2023); 2,900+ venues, 23 countries
    2024 : Integrated into Access Hospitality; Access Hospitality revenue doubles to £118.8M
```

---

## M&A Feasibility Assessment

### Is Guestline an Acquisition Target for SolStein?

**Answer: No. Fully integrated into The Access Group.**

| Factor | Assessment |
|---|---|
| **Ownership** | Wholly owned by The Access Group (PE-backed) |
| **Geography** | UK/international; no NL/BE-specific strategy |
| **Scale** | 2,900+ venues globally — far above SolStein range |
| **Succession** | N/A — corporate management under Access Group |
| **Exit pathway** | No — integrated into Access Hospitality platform |

### Role for SolStein

1. **Cloud hotel PMS benchmark**: Guestline defines cloud hotel PMS for the UK mid-market (2,900+ venues). NL/BE cloud hotel PMS companies at smaller scale are SolStein targets.
2. **Valuation reference**: Riverside held Guestline 7 years; exit to Access — PE-to-corporate trade sale pattern for UK hotel PMS.
3. **M&A pattern**: The Guestline acquisition confirms that cloud hotel PMS companies supporting 500–3,000 venues are strategic assets acquired by platforms (Access, Mews, etc.).

---

*Sources: phocuswire.com (Access Group acquires Guestline Jul 2023), theaccessgroup.com, PitchBook, tracxn.com, realdeals.eu.com, business-sale.com.*
