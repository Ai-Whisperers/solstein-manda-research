# Horeca Solutions — Deep Analysis

**Category**: Restaurant POS / HORECA (unverified as software company)
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

> **Important Caveat**: Research did not confirm the existence of a HORECA POS software company named "Horeca Solutions" in Amsterdam. The KvK-registered entity (34149622) is a terminated staffing VOF. The active horeca-solutions.nl domain is a catering personnel agency. This analysis reflects all information found; most fields are marked Unknown due to absence of a verifiable software company. SolStein should verify the correct target name before proceeding.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Horeca Solutions VOF (KvK 34149622, terminated) | northdata.com/Horeca%20Solutions,%20Amsterdam/KVK%2034149622 | Confirmed |
| HQ address | Amsterdam, Netherlands | northdata.com | Confirmed |
| Founded | Unknown | northdata.com (free tier; date not shown) | Unknown |
| CEO / MD | Unknown | No public source found | Unknown |
| Ownership structure | VOF (general partnership) — terminated | northdata.com | Confirmed |
| Employees (FTE) | Unknown | LinkedIn: no matching profile found | Unknown |
| Revenue (latest estimate) | Unknown | No financial source found | Unknown |
| Profitability | Unknown | No source | Unknown |
| Website | horeca-solutions.nl (separate 2022 staffing agency; not KvK 34149622) | horeca-solutions.nl | Confirmed — separate entity |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | Unknown | No product footprint found | Unknown |
| Customer count | Unknown | No source found | Unknown |
| Target verticals | Unknown (stated purpose: catering staffing, not software) | northdata.com | Unknown |
| Market share estimate | Unknown | No source | Unknown |
| Key competitors | Unknown | No market context found | Unknown |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Unknown — no software product found under this brand in NL | Multiple searches | Unknown |
| Tech stack | Unknown | No source | Unknown |
| Deployment model | Unknown | No source | Unknown |
| API availability | Unknown | No source | Unknown |
| Key integrations | Unknown | No source | Unknown |
| Mobile app | Unknown | No source | Unknown |

**Market Context**: The Dutch HORECA POS market includes established players such as unTill (market leader, 25+ years), Sjef (Amsterdam-based, cloud-native), CermePOS (NL/BE/DE), MplusKASSA (national reseller network), and DISH. No product named "Horeca Solutions POS" appears in any comparison site, integration registry, or customer review platform found during research.

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No source found | Unknown |
| Investor type | None detected | Crunchbase, Tracxn | Estimated |
| PE ownership | None detected | No source | Estimated |
| Succession signals | N/A — entity terminated | northdata.com | Confirmed |
| Last funding date | None found | Crunchbase, Tracxn | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No financial data found | Unknown |
| Employee growth | Unknown | No LinkedIn profile | Unknown |
| New markets | Unknown | No expansion news found | Unknown |
| Recent product launches | Unknown | No product found | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Unknown | No product found | Unknown |
| GDPR/AVG compliance | Unknown | No product or privacy policy found | Unknown |
| Allergen management | Unknown | No source | Unknown |
| Fiscal compliance NL | Unknown | No source | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown | No source | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown | No product or pricing page found | Unknown |
| Estimated ARR | Unknown | No revenue data | Unknown |
| Estimated acquisition value | Not calculable | Insufficient data | Unknown |
| Revenue per employee | Unknown | No data | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Entity terminated; no active software company confirmed | northdata.com |
| Revenue scale fit | High | N/A | No revenue data; no SaaS product confirmed | — |
| Geographic fit | High | N/A | Amsterdam address confirmed for KvK entity, but terminated | northdata.com |
| Tech stack modernity | Medium | N/A | No product found | — |
| Customer lock-in | Medium | N/A | No customer data found | — |
| Vertical depth | Medium | N/A | No HORECA software product confirmed | — |
| Integration potential | Low | N/A | No product or API found | — |
| Growth trajectory | Low | N/A | No growth signals | — |

**Composite Score**: N/A (insufficient data)
**Confidence Band**: Wide — critical data missing
**Overall M&A Assessment**: Research did not confirm the existence of a HORECA POS software company named "Horeca Solutions" in Amsterdam. The sole Dutch registry match (KvK 34149622) is a terminated catering staffing VOF with no identifiable software product. The active horeca-solutions.nl domain belongs to a separate staffing agency. This target cannot be assessed against the SolStein M&A thesis without additional clarification from the deal sourcing team.
**Recommended Next Step**: Verify the correct legal entity name, KvK number, or website URL with the lead source before conducting further research. Consider whether the intended target may operate under a different trade name (e.g., a branded product name rather than the legal company name). If confirmed as a staffing business, it falls outside the SolStein HORECA IT software thesis entirely.
