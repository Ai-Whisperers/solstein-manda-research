# Horeca Solutions — Corporate History

**Category**: Restaurant POS / HORECA Staffing (see research note)
**Country**: NL
**Research Date**: 2026-04-30

> **Research Note**: Extensive search found no HORECA POS software company operating under the legal name "Horeca Solutions" in Amsterdam. The only Dutch registry match (KvK 34149622) is a terminated catering staffing VOF. The domain horeca-solutions.nl belongs to a separate staffing agency founded in 2022. All data points below reflect verified registrations; POS software company identity remains **unconfirmed**.

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Horeca Solutions (VOF) | northdata.com/Horeca%20Solutions,%20Amsterdam/KVK%2034149622 | Confirmed |
| KvK Number | 34149622 | northdata.com | Confirmed |
| Registered City | Amsterdam, Netherlands | northdata.com | Confirmed |
| Founding Year | Unknown — registration date not disclosed on free tier | northdata.com | Unknown |
| Founders / Partners | Unknown — VOF partner names not publicly available | northdata.com (premium required) | Unknown |
| Current Ownership | Terminated (listed as "(term.)") | northdata.com | Confirmed |
| Legal Form | VOF (Vennootschap Onder Firma — general partnership) | northdata.com | Confirmed |
| Corporate Purpose | Employment agency for catering staff | northdata.com | Confirmed |
| PE/Investor Ownership | None detected | — | Unknown |
| Employees (FTE) | Unknown | — | Unknown |
| Estimated Revenue | Unknown | — | Unknown |
| M&A History | None found | — | Unknown |
| Investment Rounds | None found | — | Unknown |
| Name Changes | None found | — | Unknown |
| Domain horeca-solutions.nl | Separate staffing agency; founded 2022; not the KvK 34149622 entity | horeca-solutions.nl | Confirmed |

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown Partners / Founders] --> B["Horeca Solutions VOF — Amsterdam (KvK 34149622) — TERMINATED"]
    B --> C["Employment Agency for Catering Staff (stated purpose)"]
    D["horeca-solutions.nl entity (founded 2022, separate)"] --> E["Staffing Agency — Horeca Personnel"]
```

---

## Timeline

```mermaid
timeline
    title Horeca Solutions Key Events
    Unknown : VOF "Horeca Solutions" registered in Amsterdam (KvK 34149622)
    Unknown : Company terminated (listed as term. on Northdata)
    2022 : New separate entity "Horeca Solutions" launches horeca-solutions.nl as staffing agency
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | VOF structure typical of small founder-led businesses, but entity is terminated |
| PE-free | Unknown | No investor data found |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No revenue data; staffing agency profile does not fit SaaS ARR thesis |
| Geographic fit (NL/BE) | Yes | Amsterdam registered |
| Succession signal | N/A | Entity is terminated |
| Software / POS identity confirmed | No | KvK entity purpose is staffing, not software; no POS product found |
| Overall feasibility | **Not Applicable** | Cannot assess as M&A target — no POS software company confirmed under this name |

---

## Analyst Commentary

After conducting more than 10 web searches and checking Northdata, LinkedIn, Crunchbase, OpenKVK, Ensun, and direct domain inspection, **no HORECA POS software company operating as "Horeca Solutions" in Amsterdam could be verified**. The KvK entity (34149622) is a terminated staffing VOF. The active domain horeca-solutions.nl is a catering personnel agency (founded 2022). No POS product, cloud software, or SaaS business model was found under this brand name in the Netherlands. SolStein should verify the correct company name or website before proceeding with due diligence.
