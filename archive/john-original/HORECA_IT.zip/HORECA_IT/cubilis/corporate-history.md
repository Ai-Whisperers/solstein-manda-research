# Cubilis — Corporate History & M&A Profile

**Legal Entity**: STARDEKK NV  
**Brand**: Cubilis (primary product brand of Stardekk)  
**Headquarters**: Bruges, Belgium  
**Research Date**: 2026-04-30  
**Analyst**: SolStein M&A Research

---

## Data Point Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity name | STARDEKK NV | Tracxn / KBO public data | Confirmed |
| KBO registration number | 0474.598.036 | Tracxn (citing KBO) | Confirmed |
| Date of incorporation | April 12, 2001 | Tracxn (citing KBO) | Confirmed |
| Country of incorporation | Belgium | KBO / Tracxn | Confirmed |
| Headquarters city | Bruges (Brugge), Belgium | Multiple sources | Confirmed |
| Founder | Vincent Goemaere | Lighthouse press release, Crunchbase, Owler | Confirmed |
| Founder role at exit | Founder & CEO | Lighthouse acquisition press release (Feb 2024) | Confirmed |
| Product brand name | Cubilis | Company website, all sources | Confirmed |
| Secondary product brand | Bookingplanner (PMS front-desk) | Lightspeed integration page, PhocusWire | Confirmed |
| Fortino Capital investment | Growth equity partnership since 2020 | Fortino Capital portfolio page, hotelvak.eu | Confirmed |
| Fortino Capital exit | February 2024, via Lighthouse acquisition | Fortino Ventures press release | Confirmed |
| Acquirer | Lighthouse (formerly OTA Insight) | Multiple sources | Confirmed |
| Acquisition date | February 2024 | Lighthouse / Spectrum Equity press release | Confirmed |
| Acquisition status | Fully integrated into Lighthouse platform | LinkedIn/Instagram Stardekk redirects | Confirmed |
| Pre-acquisition funding type | Growth equity (Fortino Capital); bootstrapped prior | Tracxn, GetLatka | Confirmed |
| VC/external funding rounds | None disclosed prior to Fortino; classified as "unfunded" in some databases | Tracxn | Estimated |
| Revenue at acquisition (Dec 2023) | ~€5.67M | Tracxn (filing-derived) | Estimated |
| Employee count at acquisition | ~39 (Dec 2022) | Tracxn | Estimated |
| Customer count at acquisition | 3,000+ properties in 55 countries | Lighthouse acquisition press release | Confirmed |
| Spectrum Equity role | Investor in Lighthouse (not in Stardekk) | Spectrum Equity news page | Confirmed |
| Name changes | None known; always operated as Stardekk NV with brand Cubilis | All sources | Estimated |
| Post-acquisition brand | Stardekk products rebranded to "LH Plus" within Lighthouse | HotelTechReport | Estimated |

---

## Founding & Early History

Stardekk NV was incorporated on **April 12, 2001** in Belgium (KBO: 0474.598.036) by **Vincent Goemaere**. The company was headquartered in Bruges from inception. The core product — Cubilis — launched as a cloud-based channel manager targeting independent hotels, B&Bs, and short-term rental operators in the Benelux region.

The business was bootstrapped for approximately 19 years. During this period, Goemaere built a capital-efficient SaaS business reaching ~€5–6M ARR with approximately 39 employees and 3,000+ hotel customers across 55 countries.

---

## Investment Events

### 2020 — Fortino Capital Growth Equity Investment

**Fortino Capital** (Belgian growth equity firm, Brussels) became Stardekk's first institutional partner in **2020**. Fortino specialises in B2B SaaS companies in the Benelux and DACH markets. The investment amount has not been publicly disclosed. This represented the first and only external capital event in Stardekk's 19-year history prior to its acquisition.

- **Investor**: Fortino Capital (fortino.capital)
- **Type**: Growth equity
- **Date**: 2020 (exact month undisclosed)
- **Amount**: Not disclosed
- **Purpose**: Accelerate international expansion and product development

### February 2024 — Acquisition by Lighthouse

In **February 2024**, **Lighthouse** (formerly OTA Insight, backed by Spectrum Equity) acquired 100% of Stardekk, including the Cubilis channel manager and Bookingplanner PMS product lines. Fortino Capital fully exited its position.

- **Acquirer**: Lighthouse (lighthouse.com), formerly OTA Insight
- **Acquirer investors**: Spectrum Equity (growth equity); additional undisclosed investors
- **Acquirer scale**: Trusted by 65,000+ hotels in 185 countries at time of acquisition
- **Transaction type**: Full acquisition (100% of Stardekk)
- **Transaction amount**: Not publicly disclosed
- **Post-acquisition**: Stardekk team retained in Bruges; Cubilis product continues under Lighthouse umbrella, rebranded as "LH Plus" on Hotel Tech Report

---

## Corporate Structure Diagram

```mermaid
graph TD
    A["Vincent Goemaere<br/>(Founder / CEO)"] -->|founded 2001| B["STARDEKK NV<br/>KBO: 0474.598.036<br/>Bruges, Belgium"]
    B -->|product brand| C["Cubilis<br/>(Channel Manager + Booking Engine)"]
    B -->|product brand| D["Bookingplanner<br/>(PMS / Front-desk)"]
    E["Fortino Capital<br/>(Belgian growth equity)"] -->|growth equity investment 2020| B
    F["Lighthouse<br/>(formerly OTA Insight)<br/>Spectrum Equity-backed"] -->|full acquisition Feb 2024| B
    E -->|exit via acquisition 2024| F
```

---

## Corporate Timeline

```mermaid
timeline
    title Stardekk / Cubilis Corporate Timeline
    2001 : Stardekk NV incorporated (KBO 0474.598.036)
         : Vincent Goemaere as founder & CEO
         : Cubilis channel manager launched
         : Bruges, Belgium headquarters
    2001-2019 : Bootstrapped growth
              : Expanded to 3,000+ hotel properties
              : Grew to 55 countries
              : ~€5M+ ARR achieved organically
    2020 : Fortino Capital growth equity investment
         : First institutional capital raised
         : Focus on Benelux & DACH scale
    2020-2023 : Product expansion (Bookingplanner PMS)
              : 200+ OTA integrations
              : 400+ partner connections
              : ~39 employees, ~€5.67M revenue
    2024 Feb : Lighthouse (formerly OTA Insight) acquires Stardekk 100%
             : Fortino Capital exits
             : Cubilis continues as Lighthouse distribution product
             : Rebranded to "LH Plus" within Lighthouse platform
    2024+ : Full integration into Lighthouse commercial platform
          : Bruges team retained post-acquisition
          : Independent brand "Stardekk" retired
```

---

## M&A Feasibility Assessment

### Overall Verdict: **NOT AVAILABLE — Acquired (February 2024)**

Cubilis/Stardekk is **disqualified as an acquisition target** for SolStein. The company was fully acquired by Lighthouse in February 2024 and is now a product line within a larger PE/VC-backed global platform.

| Feasibility Factor | Assessment | Detail |
|---|---|---|
| **Independent entity** | No | 100% acquired by Lighthouse, Feb 2024 |
| **Founder-owned** | No | Vincent Goemaere sold to Lighthouse; Fortino Capital exited |
| **PE-free** | No | Was PE-backed (Fortino Capital, 2020); now under Lighthouse/Spectrum Equity |
| **Available for acquisition** | No | Fully integrated into Lighthouse; not for sale as standalone |
| **Historical thesis fit (pre-2020)** | Strong | Bootstrapped, founder-led, Belgian, niche HORECA, €5M+ ARR |
| **Historical thesis fit (2020–2024)** | Partial | PE overhang (Fortino) was a blocker even pre-Lighthouse |
| **Current thesis fit (2024+)** | None | Fully absorbed into global platform |

### Key Blocker

Stardekk/Cubilis is **definitively off-market**. It serves as a valuable **comparables benchmark** for SolStein's valuation work (Belgian SaaS hotel software, ~€5.67M ARR at exit to a strategic acquirer), but cannot be considered as a live target.

### Valuation Benchmark Insight

Lighthouse acquired Stardekk at an undisclosed price. Given:
- ~€5.67M ARR (Dec 2023)
- 3,000+ customers
- Strategic channel management assets  
- Market-leading position in Benelux hotel distribution

A reasonable assumption for comparable channel manager acquisitions in the 2023–2024 SaaS market is **4×–8× ARR**, implying a transaction value of approximately **€23M–€45M**. This is speculative and unconfirmed.

---

## Sources

| Source | URL | Type |
|---|---|---|
| Tracxn Cubilis profile | tracxn.com/d/companies/cubilis | Secondary / estimated financials |
| Lighthouse acquisition press release | spectrumequity.com/news/lighthouse-expands-into-distribution-with-acquisition-of-stardekk | Primary announcement |
| Fortino Capital portfolio | fortino.capital/portfolio/stardekk | Primary (investor) |
| Fortino exit press release | fortino.vc/news/fortino-capital-exits-stardekk | Primary |
| Hotelvak acquisition article | hotelvak.eu/en/hotel-news/stardekk-becomes-part-of-lighthouse | Secondary |
| Owler Cubilis profile | owler.com/company/cubilis | Secondary |
| HotelTechReport LH Plus | hoteltechreport.com/revenue-management/channel-managers/lh-plus | Secondary |
| Crunchbase Cubilis | crunchbase.com/organization/cubilis-channel-manager-booking-engine | Secondary |
| PhocusWire acquisition | phocuswire.com/Lighthouse-OTA-Insights-acquisition-Stardekk | Secondary |
| GetLatka Stardekk | getlatka.com/companies/stardekk.com | Secondary / estimated |
