# Cubilis — Deep Analysis

**Legal Entity**: STARDEKK NV (KBO: 0474.598.036)  
**Brand**: Cubilis / Bookingplanner  
**Category**: Hotel Channel Manager, Booking Engine, PMS  
**Country**: Belgium  
**City**: Bruges  
**Research Date**: 2026-04-30  
**Analyst**: SolStein M&A Research

> **CRITICAL STATUS NOTE**: Stardekk (Cubilis) was **fully acquired by Lighthouse in February 2024**. It is no longer available as an independent M&A target. This analysis is provided for (1) historical completeness, (2) market benchmarking, and (3) SolStein's valuation reference for comparable Belgian HORECA SaaS businesses.

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | STARDEKK NV | KBO / Tracxn | Confirmed |
| KBO number | 0474.598.036 | Tracxn (KBO-derived) | Confirmed |
| Incorporation date | April 12, 2001 | Tracxn (KBO-derived) | Confirmed |
| Headquarters | Bruges, Belgium | All sources | Confirmed |
| Founder & CEO | Vincent Goemaere | Lighthouse press release, Crunchbase | Confirmed |
| Employee count | ~39 (Dec 2022) | Tracxn | Estimated |
| Employee count (ZoomInfo) | 51–200 range | ZoomInfo | Estimated |
| Employee count (GetLatka 2025) | 36 (post-acquisition) | GetLatka | Estimated |
| Revenue (Dec 2023) | ~€5.67M | Tracxn (filing-derived) | Estimated |
| Revenue (USD, Dec 2023) | ~$6.14M | Tracxn | Estimated |
| Revenue (GetLatka 2025) | ~$4M | GetLatka | Estimated |
| Pricing model | SaaS, per-property subscription based on room count | exploretech.io, hotelub.fr | Confirmed |
| Starting price | ~$15/month (entry tier) | Tracxn, crozdesk.com | Estimated |
| Customer count | 3,000+ properties | Lighthouse acquisition press release | Confirmed |
| Countries served | 55 countries | Lighthouse acquisition press release | Confirmed |
| Current ownership | 100% Lighthouse (acquired Feb 2024) | Spectrum Equity, Lighthouse | Confirmed |

**Summary**: Stardekk was a lean, capital-efficient Belgian SaaS company with ~39 employees generating ~€5.67M ARR — a strong ratio of ~€145K revenue per employee. The business was highly founder-concentrated under Vincent Goemaere across 23 years of operation before the Lighthouse exit.

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary market | Belgium and Netherlands (Benelux) | rentioo.com, multiple reviews | Confirmed |
| Secondary markets | Germany, Austria, Switzerland (DACH) | rentioo.com | Estimated |
| Broader reach | 55 countries | Lighthouse press release | Confirmed |
| Total hotel customers | 3,000+ properties | Lighthouse press release | Confirmed |
| Customer types | Independent hotels, B&Bs, small chains, vacation rentals | Product pages, reviews | Confirmed |
| Market positioning | Mid-market channel manager for independent hotels; affordable vs enterprise | hotelub.fr, hoteltechreport.com | Confirmed |
| Competitive rank | 347th of 1,518 active competitors (Tracxn channel manager universe) | Tracxn | Estimated |
| OTA connections managed | 200+ OTAs (Booking.com, Expedia, Airbnb, Google) | Lighthouse press release, stayntouch.com | Confirmed |
| Total partner integrations | 400+ (PMS, payment, revenue management) | revcontrol.com, exploretech.io | Confirmed |
| Benelux market leader claim | "Market leading" in channel management for independent hotels in Benelux | Lighthouse acquisition press release | Estimated |
| Google Hotels integration | Yes — "best-of-class partnership" | Lighthouse press release | Confirmed |

**Summary**: Cubilis had a clear Benelux-first positioning for independent hotels. With 3,000 properties and 200+ OTA connections, it was a meaningful niche player rather than a global heavyweight. The brand was well established in Belgium and Netherlands among budget-to-mid tier independents.

---

## 3. Product & Technology

### Product Suite

| Product | Description | Status | Source | Confidence |
|---|---|---|---|---|
| Cubilis Channel Manager | Centralised dashboard; 2-way real-time sync across 200+ OTAs; prevents overbooking | Core product | revcontrol.com, stayntouch.com | Confirmed |
| Cubilis Booking Engine | Commission-free widget for hotel website; mobile-friendly, PCI-compliant; supports extras/packages | Core product | exploretech.io, hotelub.fr | Confirmed |
| Bookingplanner | Light PMS / front-desk calendar: check-in/out, housekeeping, guest profiles | Core product | Lightspeed integration page | Confirmed |
| Pricing Manager | Dynamic pricing based on demand, occupancy, and competitor rates | Add-on module | hotelub.fr | Confirmed |
| CMS / Website builder | Hotel website template module | Add-on module | hotelub.fr | Estimated |
| Reporting & Analytics | Booking performance, channel pace, revenue analytics | Included | hoteltechreport.com, revcontrol.com | Confirmed |

### Technology Characteristics

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Deployment | Cloud-based SaaS (100%) | Tracxn, all product sources | Confirmed |
| Architecture | Multi-tenant SaaS, web-based dashboard | Product pages | Confirmed |
| API connectivity | 2-way XML integrations; 400+ partner connections | revcontrol.com | Confirmed |
| OTA integration method | 2-way XML (industry standard) | stayntouch.com | Confirmed |
| Mobile | Mobile-friendly booking engine; app not prominently featured | hotelub.fr | Estimated |
| Tech stack | Not publicly disclosed; Belgian SaaS build circa 2001–2010, cloud-hosted | Unknown | Unknown |
| GDS connectivity | Yes — connects to GDS systems | crozdesk.com | Confirmed |

### Key PMS Integrations

| PMS System | Integration | Source | Confidence |
|---|---|---|---|
| Mews | Yes | vroomgeneve.ch | Confirmed |
| Protel | Yes | vroomgeneve.ch | Confirmed |
| Opera (Oracle) | Yes | vroomgeneve.ch | Confirmed |
| Fidelio | Yes | vroomgeneve.ch | Confirmed |
| Lodgegate | Yes | vroomgeneve.ch | Confirmed |
| StayNTouch | Yes (bidirectional) | stayntouch.com | Confirmed |

### Key OTA / Distribution Integrations

Booking.com, Expedia, Airbnb, Google Hotels, plus 200+ additional channels. Best-of-class partnership status confirmed with all four major channels.

### Payment Integrations

| Provider | Integration | Source | Confidence |
|---|---|---|---|
| Stripe | Yes | revcontrol.com | Confirmed |
| Mollie | Yes | revcontrol.com | Confirmed |
| Other providers | Via PCI-compliant booking engine | hotelub.fr | Estimated |

### Revenue Management Integrations

| Provider | Integration | Source | Confidence |
|---|---|---|---|
| RevControl | Yes (bidirectional) | revcontrol.com | Confirmed |

**Tech Summary**: Cubilis is a mature cloud SaaS product built over 23 years. Its 2-way XML architecture is standard for the industry. Integration breadth (400+ partners, 200+ OTAs) is a genuine competitive strength. The tech stack itself is not publicly disclosed, and given the 2001 origin, modernisation depth is unknown — this is a data gap.

---

## 4. M&A Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding structure | Bootstrapped sole founder (Vincent Goemaere) | Tracxn, GetLatka | Confirmed |
| Years founder-led | ~23 years (2001–2024) | Multiple sources | Confirmed |
| PE involvement | Fortino Capital growth equity since 2020 | Fortino Capital portfolio | Confirmed |
| PE exit | Feb 2024, via Lighthouse acquisition | Fortino Ventures exit press release | Confirmed |
| Current owner | Lighthouse (VC/PE-backed global platform) | All sources | Confirmed |
| Founder succession | Vincent Goemaere exited as founder/CEO at acquisition | Lighthouse press release | Confirmed |
| Post-acquisition Goemaere role | Not publicly disclosed | Unknown | Unknown |
| Independent entity status | No — fully integrated into Lighthouse | Stardekk social media, HotelTechReport | Confirmed |

**M&A Succession Summary**: The succession event already occurred — Goemaere sold to Lighthouse. Pre-Fortino (2001–2019), Stardekk would have been an archetypal SolStein target: bootstrapped, founder-led, Belgian, HORECA niche, €5M+ ARR. The Fortino entry in 2020 introduced PE overhang, and the Lighthouse acquisition in 2024 closed the window entirely.

---

## 5. Financial Growth & Trajectory

| Period | Revenue | Employees | Event | Source | Confidence |
|---|---|---|---|---|---|
| 2001–2019 | Not disclosed | Growing | Bootstrapped, organic | Inferred | Unknown |
| 2020 | Not disclosed | ~30s | Fortino Capital investment | Fortino | Estimated |
| Dec 2022 | Not disclosed | 39 | Employee count peak before acquisition | Tracxn | Estimated |
| Dec 2023 | ~€5.67M | ~39 | Revenue at acquisition filing | Tracxn | Estimated |
| 2024 (post-acq) | Part of Lighthouse | ~36 | Lighthouse consolidation | GetLatka | Estimated |

**Revenue per employee (2023)**: ~€145K — healthy for a Benelux B2B SaaS with 23 years of R&D amortised.

**Trajectory**: Tracxn notes employee count was 9% lower in Dec 2021 vs Dec 2022, suggesting modest headcount growth in the two years before acquisition. The organic revenue growth rate is unknown given no annual filings are publicly accessible. However, the Fortino Capital investment in 2020 suggests the business was at an inflection point seeking scale capital.

**Post-acquisition trajectory**: Now fully integrated into Lighthouse, revenue and headcount figures are no longer separately reported. Stardekk/Cubilis is now a product line within a 65,000-hotel global platform.

---

## 6. HORECA Vertical Depth

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Primary vertical | Hotel / accommodation (independent properties) | All product sources | Confirmed |
| Segment coverage | Hotels, B&Bs, hostels, vacation rentals, short-term rentals | exploretech.io, Lighthouse press release | Confirmed |
| Restaurant coverage | None — no F&B / restaurant POS products | Product pages | Confirmed |
| Vertical depth score | Deep in accommodation distribution; zero restaurant/F&B depth | All product sources | Confirmed |
| GDPR compliance | Yes — EU-based SaaS, booking engine PCI-compliant; GDPR applicable | hotelub.fr | Confirmed |
| Payment integration depth | Stripe, Mollie, PCI-compliant booking engine | revcontrol.com | Confirmed |
| Guest data handling | Guest profiles in Bookingplanner; GDPR-compliant collection | Product pages | Estimated |
| Loyalty / CRM | Not a core product feature | Product pages | Confirmed |
| Revenue management | Via Pricing Manager module and RevControl integration | hotelub.fr, revcontrol.com | Confirmed |
| Years in vertical | 23+ years (2001–2024) | KBO date | Confirmed |

**Vertical Summary**: Cubilis/Stardekk is deeply specialised in hotel distribution and online booking infrastructure. It has no overlap with restaurant/F&B tech. Its depth in accommodation channel management — across 200 OTAs and 400+ partner integrations — represents genuine switching costs and institutional knowledge. This vertical depth was a primary driver of Lighthouse's acquisition rationale.

---

## 7. Valuation & Business Model

### Business Model

| Element | Detail | Source | Confidence |
|---|---|---|---|
| Model type | Recurring SaaS subscription | Product pages | Confirmed |
| Pricing basis | Per property, based on room count | exploretech.io, hotelub.fr | Confirmed |
| Entry price | ~$15/month (smallest properties) | Tracxn | Estimated |
| Mid-tier price | Not publicly disclosed | Unknown | Unknown |
| Support fee | Mandatory "unlimited support" add-on fee reported | hotelub.fr (user review) | Estimated |
| Integration fees | Additional monthly fees for some third-party PMS integrations | hotelub.fr | Estimated |
| Gross margin profile | High (SaaS, cloud-hosted, low marginal cost) | Inferred | Estimated |
| Churn signals | Negative reviews cite contract inflexibility and support cost; switching costs are high due to OTA connection resets | hotelub.fr, hoteltechreport.com | Estimated |

### Estimated ARR Decomposition

Assumptions for cross-check:
- 3,000 properties
- Estimated average revenue per property: ~€1,890/year (€5.67M ÷ 3,000)
- This is ~€157/month/property — consistent with entry pricing + modules + support fees for small-medium properties

| Estimate | Value | Basis |
|---|---|---|
| Properties (confirmed) | 3,000+ | Lighthouse press release |
| Estimated avg ARPU/year | ~€1,890 | €5.67M ÷ 3,000 (Tracxn) |
| Estimated ARR | ~€5.67M | Tracxn filing-derived |
| Revenue per employee | ~€145K | €5.67M ÷ 39 |

### Acquisition Valuation Benchmark

Lighthouse's acquisition price is undisclosed. For benchmarking comparable acquisitions in 2023–2024 (channel manager, SaaS, 3,000 hotel customers, Benelux):

| Multiple | Implied Value |
|---|---|
| 4× ARR | ~€22.7M |
| 6× ARR | ~€34.0M |
| 8× ARR | ~€45.4M |

Lighthouse paid a strategic premium given the distribution asset value, OTA partnership depth, and Benelux customer base. A 5–7× ARR range is a reasonable estimate (€28M–€40M), though unconfirmed.

> **Confidence**: Speculative — transaction price not disclosed.

---

## 8. M&A Attractiveness Scorecard

> **Note**: Scores reflect Stardekk/Cubilis **as it existed at its peak independent state (pre-Fortino, 2019)** for historical calibration purposes — and to benchmark similar targets SolStein may identify. Current scores reflect **disqualification** due to acquisition status.

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | Fully acquired by Lighthouse (Feb 2024); previously had PE overhang (Fortino 2020). Not available. | Lighthouse press release; Fortino portfolio |
| Revenue scale fit | High | 4 | ~€5.67M ARR (Dec 2023) — sits comfortably within SolStein's €1M–€15M target band | Tracxn |
| Geographic fit | High | 5 | Headquartered in Bruges; primary markets Belgium and Netherlands — perfect Benelux fit | All sources |
| Tech stack modernity | Medium | 3 | Cloud SaaS confirmed; full XML 2-way integrations; underlying tech stack undisclosed (2001 origin raises uncertainty) | Product pages |
| Customer lock-in | Medium | 4 | 3,000 properties with deep OTA connection histories; switching costs are real (OTA re-setup, booking engine migration); reported contract inflexibility | hotelub.fr, hoteltechreport.com |
| Vertical depth | Medium | 5 | 23 years in hotel distribution; 200+ OTAs; 400+ partner integrations; market-leading Benelux position | Lighthouse press release |
| Integration potential | Low | 4 | 2-way XML API; 400+ existing partner integrations; open enough to extend | revcontrol.com, stayntouch.com |
| Growth trajectory | Low | 3 | Modest headcount growth pre-acquisition; Fortino investment suggests inflection point; specific revenue growth rate unknown | Tracxn, Fortino |

### Score Summary

| Metric | Value |
|---|---|
| **Composite Score (weighted)** | **1.8 / 5.0** (dragged to 1 by ownership disqualifier) |
| **Historical Composite (pre-2020, ownership excluded)** | **3.9 / 5.0** |
| **Confidence Band** | Narrow on ownership/geography/vertical (Confirmed); Wide on financials/tech stack (Estimated/Unknown) |

### Composite Score Weighting Calculation

| Dimension | Weight | Score | Weighted |
|---|---|---|---|
| Ownership attractiveness | 3 | 1 | 3 |
| Revenue scale fit | 3 | 4 | 12 |
| Geographic fit | 3 | 5 | 15 |
| Tech stack modernity | 2 | 3 | 6 |
| Customer lock-in | 2 | 4 | 8 |
| Vertical depth | 2 | 5 | 10 |
| Integration potential | 1 | 4 | 4 |
| Growth trajectory | 1 | 3 | 3 |
| **Total** | **17** | — | **61** |
| **Composite** | — | — | **61 ÷ (17×5) = 3.6 / 5.0 (ex-ownership)** |

> The ownership score of 1 (acquired/unavailable) is a **hard blocker**. Even with a 3.6/5.0 ex-ownership composite, SolStein cannot pursue this target.

---

## Overall Assessment

**Verdict: DISQUALIFIED — Acquired (February 2024)**

Cubilis/Stardekk was, in the period 2001–2019, an **ideal SolStein acquisition archetype**: Belgian founder-owned, bootstrapped, 23 years in the hotel HORECA niche, Benelux-primary, ~€5M ARR, no PE. The window closed in two stages: Fortino Capital's 2020 growth equity investment introduced PE overhang, and Lighthouse's February 2024 full acquisition removed the target from market entirely.

The business now operates as a product line within Lighthouse's global commercial platform. The Stardekk brand is being retired in favour of the Lighthouse identity.

**Value as a Benchmark**: Cubilis provides an excellent valuation and operational comparable for SolStein when assessing similar Belgian hotel SaaS targets. Key benchmarks:
- Revenue-per-employee: ~€145K (target for portfolio companies)
- ARPU: ~€1,890/property/year at 3,000 properties
- Exit multiple: ~5–7× ARR estimated for a strategic channel manager acquisition in 2024

---

## Recommended Next Step

**Cubilis/Stardekk**: No further research required. Mark as **Tier 2 — Secondary / Watch List (Acquired — Benchmark Only)**.

Redirect research effort to identify **similar, still-independent** Belgian or Dutch hotel channel manager / booking engine providers that match the pre-2020 Stardekk profile:
- Founder-owned hotel distribution SaaS
- Benelux-primary customer base
- €1M–€10M ARR
- No PE / no acquisition process underway

Potential comparable targets to investigate: **Resengo** (NL, reservations), **Misterbook** (NL, hotel PMS), **Booking Experts** (NL, vacation rental PMS).

---

## Source Index

| Source | URL | Used For | Type |
|---|---|---|---|
| Lighthouse acquisition press release | spectrumequity.com/news/lighthouse-expands-into-distribution-with-acquisition-of-stardekk | Acquisition facts, customer count, CEO quote | Primary |
| Tracxn Cubilis profile | tracxn.com/d/companies/cubilis | Revenue, employees, KBO, founding | Secondary (filing-derived) |
| Fortino Capital portfolio | fortino.capital/portfolio/stardekk | Investment confirmation | Primary (investor) |
| Fortino exit press release | fortino.vc/news/fortino-capital-exits-stardekk | Investment/exit dates | Primary |
| Hotelvak acquisition article | hotelvak.eu/en/hotel-news/stardekk-becomes-part-of-lighthouse | M&A context | Secondary |
| ExploreTech Cubilis channel manager | exploretech.io/en/product/stardekk-cubilis-channel-manager | Product features, integrations | Secondary |
| Hotelub Cubilis review 2025 | hotelub.fr/en/cubilis-review-how-good-is-this-vacation-rental-channel-manager | Product, pricing, user sentiment | Secondary |
| RevControl integration page | revcontrol.com/integrations/cubilis | OTA count, payment integrations | Secondary |
| StayNTouch integration | stayntouch.com/snt-integrations-new/cubilis | Product API/integration details | Secondary |
| HotelTechReport LH Plus | hoteltechreport.com/revenue-management/channel-managers/lh-plus | Post-acquisition product status | Secondary |
| Owler Cubilis | owler.com/company/cubilis | CEO name, founding, HQ | Secondary |
| Crunchbase Cubilis | crunchbase.com/organization/cubilis-channel-manager-booking-engine | Founding year, overview | Secondary |
| Rentioo Cubilis | rentioo.com/Companies/cubilis | Market geography (Benelux + DACH) | Secondary |
| Vroomgeneve Cubilis review | vroomgeneve.ch/en/is-cubilis-a-reliable-channel-manager | PMS integrations | Secondary |
| PhocusWire acquisition | phocuswire.com/Lighthouse-OTA-Insights-acquisition-Stardekk | M&A confirmation | Secondary |
| GetLatka Stardekk | getlatka.com/companies/stardekk.com | Revenue, headcount (estimated) | Secondary |
