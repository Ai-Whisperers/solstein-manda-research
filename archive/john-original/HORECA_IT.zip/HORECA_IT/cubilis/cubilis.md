# Cubilis

**Category**: Hotel PMS/Channel
**Country**: BE
**Research Status**: Done 2026-04-30

> **M&A Status**: DISQUALIFIED — Acquired by Lighthouse (Feb 2024). Benchmark use only.

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Done 2026-04-30 |
| deep-analysis.md | Done 2026-04-30 |

---

## How to Run Research

```
@research-horeca-company-history Cubilis @HORECA_IT/cubilis/
@research-horeca-company Cubilis @HORECA_IT/cubilis/
```
