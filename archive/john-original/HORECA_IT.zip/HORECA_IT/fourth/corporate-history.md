# Fourth — Corporate History

**Category**: Workforce / Inventory Management (F&B Hospitality)
**Country**: UK (London, England; dual HQ with Austin, Texas, USA)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; PE-backed US/UK hybrid)

---

## Summary Assessment

Fourth is a **Marlin Equity Partners–backed** workforce and inventory management platform for the global hospitality industry. Born from the 2019 merger of UK-based Fourth and US-based HotSchedules, it operates from dual headquarters in London and Austin, Texas. With a large global customer base in restaurants and hotels, Fourth is well outside SolStein's acquisition criteria (wrong geography, PE-backed, too large). It serves as a **workforce management benchmark** for the HORECA sector.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Fourth (formerly Fourth Enterprises) | fourth.com | Confirmed |
| Legal entity (UK) | Fourth Enterprises Ltd (UK entity) | Companies House (inferred) | Estimated |
| HQ (dual) | London, UK + Austin, Texas, USA | marlinequity.com, fourth.com | Confirmed |
| Founded | 1999 (original Fourth, London) | tracxn.com, ecipartners.com | Confirmed |
| Current ownership | Marlin Equity Partners + Insight Partners | marlinequity.com | Confirmed |
| PE backer 1 (2011–2015) | ECI Partners (UK PE) | ecipartners.com | Confirmed |
| PE backer 2 (2015–2019) | Insight Venture Partners | ecipartners.com | Confirmed |
| PE backer 3 (2019–present) | Marlin Equity Partners (lead) + Insight Partners | marlinequity.com | Confirmed |
| Merger date | July 2019 (Fourth + HotSchedules merged) | marlinequity.com | Confirmed |
| Merger counterpart | HotSchedules (Austin, TX — US workforce management) | marlinequity.com | Confirmed |
| Current CEO | Scott Collison (appointed March 2026) | tracxn.com | Confirmed |
| Key acquisition: Adaco | 2012 (inventory management) | ecipartners.com | Confirmed |
| Key acquisition: Team Hours | 2014 (scheduling) | ecipartners.com | Confirmed |
| Product flagship | Fourth iQ (AI-driven hospitality operations) | tracxn.com | Confirmed |
| Revenue | Not publicly disclosed | — | Unknown |
| Employees | Not disclosed; likely 500–1,000+ | Estimated from scale | Estimated |

---

## Founding & Corporate History

**Fourth** was founded in **London in 1999** as a workforce and cost control software company for the hospitality industry. Its platform focused on labour scheduling, payroll, and inventory management — all critical cost drivers for restaurants and hotels.

**ECI Partners** (UK PE firm) invested in 2011, financing an international expansion phase and two acquisitions:
- **Adaco** (2012) — inventory and procurement management system for hospitality
- **Team Hours** (2014) — scheduling software

**Insight Venture Partners** acquired the business from ECI Partners in **2015**, driving further growth before orchestrating the defining transaction: the **merger with HotSchedules** in 2019.

**HotSchedules** (Austin, Texas) was the leading US restaurant scheduling software company. The **July 2019 merger**, backed by **Marlin Equity Partners** and **Insight Partners**, created **Fourth Enterprises** — a combined entity claiming to be the world's leading end-to-end restaurant and hospitality management technology company.

The merged entity rebranded universally to **Fourth** in November 2020. By 2026, under CEO **Scott Collison** (appointed March 2026), Fourth operates its **Fourth iQ** AI platform for hospitality operations including workforce, inventory, and analytics.

---

## Acquisitions BY Fourth

| # | Company | Country | Date | Domain | Notes |
|---|---|---|---|---|---|
| 1 | Adaco | UK/US | 2012 | Inventory management | Hospitality procurement; acquired during ECI backing |
| 2 | Team Hours | US/UK | 2014 | Staff scheduling | Scheduling module; acquired during ECI backing |
| 3 | HotSchedules (merger) | USA | Jul 2019 | Restaurant scheduling | $100M+ deal; HotSchedules was market leader in US; Marlin/Insight backed |

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Marlin Equity Partners (lead PE)"]
    B["Insight Partners (co-investor)"]
    C["Fourth Enterprises Ltd<br/>(London, UK + Austin, TX)"]
    D["Original Fourth (UK, 1999)"]
    E["HotSchedules (USA, merged Jul 2019)"]
    F["Adaco (acquired 2012)"]
    G["Team Hours (acquired 2014)"]

    A -->|"Lead backer since Jul 2019"| C
    B -->|"Co-investor since Jul 2019"| C
    D -->|"Merged into"| C
    E -->|"Merged into Jul 2019"| C
    F -->|"Acquired 2012"| D
    G -->|"Acquired 2014"| D
```

---

## PE Ownership Timeline

| Period | PE Backer | Role | Notes |
|---|---|---|---|
| 2011–2015 | ECI Partners | Majority | UK PE; supported Adaco + Team Hours acquisitions |
| 2015–2019 | Insight Venture Partners | Majority | Pre-merger growth phase |
| 2019–present | Marlin Equity Partners (lead) + Insight Partners | Controlling | Post-merger structure |

---

## Timeline of Critical Events

```mermaid
timeline
    title Fourth — Key Milestones
    1999 : Founded in London as workforce/cost control SaaS for hospitality
    2011 : ECI Partners invests (UK PE backing begins)
    2012 : Adaco acquired (inventory management)
    2014 : Team Hours acquired (scheduling)
    2015 : Insight Venture Partners acquires from ECI Partners
    2019 : Merger with HotSchedules (Jul 2019); Marlin Equity Partners + Insight Partners back merged entity; "Fourth Enterprises" formed
    2020 : Universal rebrand to "Fourth" (Nov 2020)
    2026 : Fourth iQ AI platform launched; Scott Collison appointed CEO (Mar 2026)
```

---

## M&A Feasibility Assessment

### Is Fourth an Acquisition Target for SolStein?

**Answer: No. PE-backed; US/UK; far above SolStein's criteria.**

| Factor | Assessment |
|---|---|
| **Scale** | Hundreds of employees; global hospitality footprint — far above SolStein's range |
| **Ownership** | Marlin Equity Partners + Insight Partners — no founder-owned angle; active PE ownership |
| **Geography** | US/UK primary; NL/BE incidental only |
| **Succession** | Professional CEO (Collison, new in Mar 2026); no succession gap |
| **Exit pathway** | PE-driven exit at substantial valuation; not accessible to SolStein |

### Role for SolStein

1. **Workforce management benchmark**: Fourth defines the enterprise end of workforce/scheduling for HORECA.
2. **Valuation reference**: UK/US workforce management SaaS for hospitality commands premium multiples (likely 5–8x revenue).
3. **Competitive context**: NL/BE workforce scheduling companies (e.g., Planax, Cures Werkt) are the NL equivalents — these represent SolStein's opportunity.

---

*Sources: marlinequity.com (press release Jul 2019), ecipartners.com (portfolio), fourth.com, tracxn.com, dcp.com, sortisinvest.com.*
