# Fourth

**Category**: Workforce/F&B
**Country**: UK
**City**: London
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Fourth @HORECA_IT/fourth/
@research-horeca-company Fourth @HORECA_IT/fourth/
```
