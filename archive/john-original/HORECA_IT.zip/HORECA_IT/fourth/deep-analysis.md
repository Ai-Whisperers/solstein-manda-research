# Fourth — Deep Analysis

**Category**: Workforce / Inventory Management (F&B Hospitality)
**Country**: UK (London, England; dual HQ with Austin, Texas, USA)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; PE-backed US/UK hybrid)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Operating name | Fourth | fourth.com | Confirmed |
| HQ | London, UK + Austin, TX, USA (dual) | marlinequity.com | Confirmed |
| Founded | 1999 (London) | tracxn.com, ecipartners.com | Confirmed |
| Ownership | Marlin Equity Partners (lead PE) + Insight Partners | marlinequity.com | Confirmed |
| CEO (2026) | Scott Collison (appointed March 2026) | tracxn.com | Confirmed |
| Employees | Not disclosed; estimated 500–1,000+ | Estimated | Estimated |
| Revenue | Not publicly disclosed | — | Unknown |
| Business model | SaaS workforce/inventory management subscriptions | fourth.com | Confirmed |
| Merger history | Merged with HotSchedules (Jul 2019) | marlinequity.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary markets | USA + UK (dominant); global hospitality | fourth.com | Confirmed |
| Verticals | Restaurants, pubs, hotels, QSR chains | fourth.com | Confirmed |
| NL/BE presence | Not confirmed; likely not a focused market | fourth.com | Estimated |
| EU presence | Available; not a stated priority vs US/UK | fourth.com | Estimated |
| Customer size | Mid-market to enterprise chains (50+ locations) | fourth.com | Confirmed |
| Key UK customers | Pubs, restaurants, hotel groups | fourth.com | Estimated |
| US market position | Leading (HotSchedules was #1 US restaurant scheduling) | marlinequity.com | Confirmed |

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Workforce management | Scheduling, rota management, HR, payroll integration | fourth.com | Confirmed |
| Inventory management | Procurement, food cost control, inventory tracking (via Adaco heritage) | fourth.com | Confirmed |
| AI platform | Fourth iQ (launched 2026 — AI-driven hospitality operations) | tracxn.com | Confirmed |
| Deployment | Cloud SaaS | fourth.com | Confirmed |
| Mobile app | iOS/Android for staff scheduling | fourth.com | Confirmed |
| Integrations | POS systems, payroll, accounting | fourth.com | Confirmed |
| Tech stack | Cloud-native; API-first | fourth.com | Estimated |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| PE backing | Marlin Equity Partners + Insight Partners (since Jul 2019) | marlinequity.com | Confirmed |
| Prior PE | ECI Partners (2011–2015), Insight Venture Partners (2015–2019) | ecipartners.com | Confirmed |
| Founder status | Original founders long departed; fully professional management | Inferred from PE history | Estimated |
| CEO continuity | Third CEO since founding; Scott Collison (new Mar 2026) | tracxn.com | Confirmed |
| PE exit horizon | Unknown; Marlin typically holds 5–7 years (invested 2019) | Marlin Equity profile | Estimated |
| Succession gap | None — professional management structure | Inferred | Estimated |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Not publicly disclosed | — | Unknown |
| Employee count | 500–1,000 estimated | Scale inference | Estimated |
| Growth trajectory | Positive; AI product (Fourth iQ) suggests investment phase | tracxn.com | Estimated |
| Profitability | Unknown | — | Unknown |
| Marlin hold period | ~7 years (invested Jul 2019; exit expected ~2024–2026?) | Standard PE lifecycle | Estimated |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK payroll compliance | UK PAYE, National Insurance, auto-enrolment pension | fourth.com | Confirmed |
| UK scheduling compliance | Working Time Regulations, break entitlements | fourth.com | Confirmed |
| US compliance | US labor law, FLSA, tip reporting | fourth.com | Confirmed |
| Food cost management | Gross profit analysis, waste reduction, recipe costing | fourth.com | Confirmed |
| Allergen management | Limited; not a core product | fourth.com | Estimated |
| Tipping | Tip allocation features (UK + US) | fourth.com | Estimated |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | Per-employee or per-location SaaS subscription | fourth.com | Confirmed |
| ARR estimate | £30M–£100M+ (estimated; not disclosed) | Scale inference | Estimated |
| Valuation | Not disclosed; likely $200M–$500M+ at PE level | Industry comparables | Estimated |
| SolStein fit | No — PE-backed; wrong geography; above target range | — | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 1 | PE-backed (Marlin + Insight); professional management; not founder-owned | marlinequity.com |
| Revenue scale fit | High | 1 | Estimated £30M–£100M+ — well above SolStein's €1–15M target | Scale inference |
| Geographic fit | High | 1 | US/UK primary; no NL/BE market strategy | fourth.com |
| Tech stack modernity | Medium | 5 | Cloud-native SaaS + AI platform (Fourth iQ) | fourth.com, tracxn.com |
| Customer lock-in | Medium | 5 | Workforce management creates high switching costs; payroll integration | fourth.com |
| Vertical depth | Medium | 4 | Deep UK/US hospitality workforce + inventory expertise | fourth.com |
| Integration potential | Low | 4 | POS integrations; API-first; broad ecosystem | fourth.com |
| Growth trajectory | Low | 3 | Growth stage; AI investment; exact trajectory unknown | tracxn.com |

### Composite Score

**Weighted Composite: 2.1 / 5.0**

*(High-weight dimensions score 1: ownership, revenue, geographic fit)*

**Confidence Band**: Low-Medium — corporate structure confirmed; financials unknown.

### Overall M&A Assessment

Fourth is **not an acquisition target** for SolStein. It is a PE-backed US/UK workforce management platform, well above SolStein's target profile in scale, ownership structure, and geography. Its value is as a **category benchmark** and a pointer to NL/BE workforce scheduling companies (Planax, Cures Werkt) that serve the same function in SolStein's target geography.

### Recommended Next Step

No pursuit. Use as workforce management benchmark for NL/BE equivalents. Monitor for PE exit — if Marlin exits in 2025–2027, the acquirer may be a strategic buyer who accelerates EU expansion, creating indirect competitive pressure.

---

*Sources: marlinequity.com, ecipartners.com, fourth.com, tracxn.com, dcp.com.*
