# kassensysteme.de — Deep Analysis

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Tier**: 3 — Reference / Landscape (DE)
**M&A Role**: DE POS market reference; insufficient data for meaningful analysis

---

## Research Limitations

**Critical note**: kassensysteme.de has essentially no public data footprint. This analysis is largely placeholder with Unknown confidence levels throughout. The company appears to be a small regional POS reseller operating in Neu-Isenburg, Germany. Without access to German commercial registries (Handelsregister direct query) or the company website, meaningful analysis is not possible from public sources.

---

## 1. Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | No public source | Unknown |
| HQ | Neu-Isenburg, Hesse, Germany (reported) | SolStein brief | Estimated |
| Founded | Unknown | No public source | Unknown |
| CEO / Owner | Unknown | No public source | Unknown |
| Ownership | Unknown | No public source | Unknown |
| Employees | Unknown (likely <20 for a regional reseller) | Estimated | Estimated |
| Revenue | Unknown | No public source | Unknown |
| Countries | Germany (assumed) | SolStein brief | Estimated |

---

## 2. HORECA Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Market segment | POS systems and cash registers for gastronomy | SolStein brief | Estimated |
| Customer count | Unknown | No public source | Unknown |
| DACH presence | Germany (assumed; likely local/regional) | Estimated | Estimated |
| NL/BE presence | None expected | Assessment | Estimated |

---

## 3. Product & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Product type | POS hardware and software for gastronomy (reseller model likely) | SolStein brief | Estimated |
| Proprietary software | Unknown — may resell third-party POS software | Assessment | Unknown |
| TSE compliance | Required for any German POS sold post-2020 | German law (KassenSichV) | Confirmed |
| Cloud vs. on-premise | Unknown | No source | Unknown |

---

## 4–7. M&A, Financial, Vertical, Valuation

All data points are **Unknown** due to absence of public information. No financial data, no M&A history, no ownership details confirmed.

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | — | Unknown | No source |
| Revenue scale fit | High | 1 | Likely micro-business (<€1M revenue); below SolStein's threshold | Estimated |
| Geographic fit | High | 1 | Germany-only; no NL/BE | SolStein brief |
| Tech stack modernity | Medium | 1 | Appears to be a reseller, not a SaaS developer | Estimated |
| Customer lock-in | Medium | — | Unknown | No source |
| Vertical depth | Medium | 2 | Gastronomy POS focus but likely shallow as reseller | Estimated |
| Integration potential | Low | — | Unknown | No source |
| Growth trajectory | Low | — | Unknown | No source |

**Composite Score**: ~1.2 / 5.0 (very limited data; assumed micro-scale reseller)

**Confidence Band**: Very Low — nearly all data Unknown

**Overall M&A Assessment**: kassensysteme.de is **not a relevant SolStein acquisition target** based on available information. The company appears to be a small regional POS reseller — not a SaaS developer — and is located in Germany rather than NL/BE. Insufficient public data for meaningful due diligence without direct company engagement.

**Recommended Next Step**: No action. Remove from active research list unless company website or Handelsregister data becomes available.

---

*Sources: SolStein research brief only; no independent public sources confirmed*
