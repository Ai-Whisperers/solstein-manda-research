# kassensysteme.de — Corporate History

**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research
**Purpose**: M&A Landscape Reference — Tier 3 (DE Reference/Landscape)
**Status**: Unknown — very limited public data

---

## Executive Summary

kassensysteme.de is a German POS system reseller and dealer operating primarily in the gastronomy sector, reportedly based in Neu-Isenburg (Hesse). The company appears to operate under the domain kassensysteme.de and serves restaurants, hotels, and other hospitality businesses. Public data is extremely limited — no Handelsregister entries have been confirmed, no founding year or founders identified, and no financial data is available. This appears to be a small regional POS hardware/software reseller rather than a software developer. Research attempts were made but yielded minimal results.

---

## Corporate Identity

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Trade name | kassensysteme.de | SolStein research brief | Estimated |
| Legal entity name | Unknown | No public source found | Unknown |
| Handelsregister number | Unknown | No public source found | Unknown |
| Registered address | Neu-Isenburg, Hesse, Germany (reported) | SolStein research brief | Estimated |
| Legal form | Unknown (likely GmbH or sole trader) | No public source found | Unknown |
| Country | Germany | SolStein research brief | Estimated |
| Primary activity | POS systems and cash registers for gastronomy | SolStein research brief | Estimated |
| Website | kassensysteme.de (reported) | SolStein research brief | Estimated |

---

## Founding & Early History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founding year | Unknown | No public source found | Unknown |
| Founders | Unknown | No public source found | Unknown |
| Origin | Unknown | No public source found | Unknown |
| Employee count | Unknown | No public source found | Unknown |

---

## Ownership & Investment History

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Ownership type | Unknown | No public source found | Unknown |
| PE involvement | Unknown | No public source found | Unknown |
| External funding | Unknown | No public source found | Unknown |
| Shareholders | Unknown | No public source found | Unknown |

---

## M&A History

| Date | Event Type | Detail | Source | Confidence |
|---|---|---|---|---|
| Unknown | No M&A events identified | No public source | No public source found | Unknown |

---

## Research Methodology & Limitations

The following searches were conducted without returning specific information about kassensysteme.de as a company:

- Web search: "kassensysteme.de Neu-Isenburg company history"
- Web search: "kassensysteme.de GmbH Handelsregister"
- Handelsregister searches for entities in Neu-Isenburg

**Likely explanation**: kassensysteme.de appears to be either:
1. A small regional POS hardware/software reseller operating under a domain-based trade name without a prominent corporate registration
2. A micro-business or sole trader with minimal online footprint
3. A company operating under a different legal name than the domain suggests

The domain name "kassensysteme.de" is a generic German term meaning "cash register systems" and may refer to multiple companies or a reseller aggregator.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Availability** | Unknown — no ownership data available |
| **Ownership structure** | Unknown — likely small private owner |
| **SolStein thesis fit** | Very poor — appears to be a hardware/software reseller, not a SaaS company; Germany-only; no NL/BE presence |
| **Research confidence** | Very low — insufficient public data for meaningful assessment |

**Verdict**: kassensysteme.de is likely a **small regional POS reseller** with insufficient scale and wrong profile for SolStein's M&A thesis. If further research is required, direct company contact or German commercial registry search is recommended.

---

## Sources

| Source | URL | Type |
|---|---|---|
| SolStein research brief | Internal document | Internal |
| Web search results (inconclusive) | Multiple URLs searched; no match found | Negative result |
| Northdata.de search (inconclusive) | https://www.northdata.de | Negative result |
