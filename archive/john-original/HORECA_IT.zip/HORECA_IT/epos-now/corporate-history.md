# Epos Now — Corporate History

**Category**: POS / Restaurant & Retail
**Country**: UK (Norwich, England)
**Research Date**: 2026-04-30
**M&A Role**: Reference / Landscape — Tier 3 (UK; not a primary SolStein target)

---

## Summary Assessment

Epos Now is a **founder-owned, Norwich-based SaaS and payments** company serving 80,000+ merchant locations across 70+ countries. With reported FY2025 turnover of £113.57M and a target valuation of up to $1.5B (stake sale exploration, May 2024), it is orders of magnitude above SolStein's acquisition criteria. It serves as a **market benchmark** for cloud EPOS in the UK hospitality and retail sectors.

---

## Data Points Registry

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name (primary) | EPOS NOW (UK) LTD | Companies House 07666961 | Confirmed |
| Legal name (holding) | Epos Now Ltd | Companies House 10784763 | Confirmed |
| Companies House No. (primary) | 07666961 | gov.uk Companies House | Confirmed |
| Companies House No. (holding) | 10784763 | gov.uk Companies House | Confirmed |
| Registered address | 2 Whiting Road, Norwich Business Park, Norwich, NR4 6DJ | Companies House | Confirmed |
| Incorporated (primary entity) | 13 June 2011 | Companies House 07666961 | Confirmed |
| Incorporated (holding entity) | 23 May 2017 | Companies House 10784763 | Confirmed |
| Founder / CEO | Jacyn Heavens | Wikipedia, company website, Reuters | Confirmed |
| HQ | Norwich, Norfolk, UK | eposnow.com, Companies House | Confirmed |
| Ownership | Founder-owned (Jacyn Heavens), privately held | Reuters May 2024, Wikipedia | Confirmed |
| PE backing | None as of April 2026; exploring minority stake sale | Reuters May 2024 | Confirmed |
| Revenue FY2025 | £113.57M (turnover, period ending May 2025) | Endole, Companies House filing | Confirmed |
| Revenue FY2023 | £59.6M | Companies House filing, Reuters | Confirmed |
| Revenue growth FY23→FY25 | ~90% over two years | Derived from above filings | Estimated |
| Reported revenue (press) | >$150M annually (2025) | Wikipedia | Estimated |
| Employees | ~500 | PitchBook, Endole | Estimated |
| Merchant locations | 80,000+ | eposnow.com/about-us | Confirmed |
| Countries | 70+ | eposnow.com/about-us | Confirmed |
| Debt financing raised | $63.8M | PitchBook | Estimated |
| Valuation explored (2024) | Up to $1.5 billion | Reuters May 2024 | Estimated |
| Strategic process (2024) | Exploring minority stake sale with advisers | Reuters May 2024 | Confirmed |
| SIC code | 6201 — Computer programming activities | Companies House | Confirmed |

---

## Founding & Early History

Jacyn Heavens founded Epos Now in **Norwich in 2011** after recognising that small and medium-sized hospitality and retail businesses were locked out of affordable, modern EPOS solutions dominated by expensive legacy hardware vendors. The company built a cloud-native EPOS platform from the outset, enabling any business to run full POS functionality on standard tablet hardware.

The company grew steadily in the UK hospitality and retail sectors before expanding internationally. By 2017 a holding company (Epos Now Ltd, Companies House 10784763) was incorporated to support the group structure as international revenues became material.

Growth accelerated through the 2020s: from £59.6M revenue in FY2023 to £113.57M in FY2025 (a near-doubling in two years). In **May 2024**, Reuters reported that Epos Now was working with advisers to explore a **minority stake sale**, targeting a valuation of up to **$1.5 billion** — positioning the company for growth capital while Heavens retains control.

---

## Funding / Capital Events

| Event | Date | Amount | Details |
|---|---|---|---|
| Self-funded founding | 2011 | — | Bootstrapped by Jacyn Heavens |
| Debt financing | Various | $63.8M total | PitchBook; specific tranches undisclosed |
| Minority stake sale exploration | May 2024 | Target: up to $1.5B valuation | Reuters report; process ongoing; outcome undisclosed |

---

## M&A History

No confirmed acquisitions. The company has grown organically, adding payments (embedded fintech) and integrations, rather than through acquisition.

---

## Corporate Structure (Mermaid)

```mermaid
graph TD
    A["Jacyn Heavens (Founder / CEO)"]
    B["Epos Now Ltd<br/>(Companies House 10784763)<br/>(Holding, incorporated May 2017)"]
    C["EPOS NOW (UK) LTD<br/>(Companies House 07666961)<br/>(Operating entity, incorporated Jun 2011)"]

    A -->|"Founder-owner"| B
    B -->|"Subsidiary"| C
    C -->|"Serves"| D["80,000+ merchants — UK + 70 countries"]
```

---

## Timeline of Critical Events

```mermaid
timeline
    title Epos Now — Key Milestones
    2011 : Founded by Jacyn Heavens in Norwich UK; Companies House 07666961
    2017 : Holding entity (Epos Now Ltd) incorporated; Companies House 10784763
    2020 : International expansion accelerates; cloud EPOS + embedded payments
    2023 : FY2023 revenue £59.6M; 25% YoY growth
    2024 : Explores minority stake sale at up to $1.5B valuation (Reuters May 2024)
    2025 : FY2025 revenue £113.57M; 80,000+ merchants; 70+ countries; ~500 employees
```

---

## M&A Feasibility Assessment

### Is Epos Now an Acquisition Target for SolStein?

**Answer: No. Definitively outside SolStein's criteria.**

| Factor | Assessment |
|---|---|
| **Scale** | £113M revenue / potential $1.5B valuation — far above SolStein's €1M–€15M ARR target |
| **Geography** | UK/Global (70+ countries); minimal confirmed NL/BE customer base |
| **Ownership** | Founder-owned (positive), but scale excludes a full acquisition; minority stake process targets PE/strategic buyers |
| **Exit pathway** | Exploring minority PE sale at $1.5B — not a private founder-to-founder acquisition |
| **Vertical** | Cloud EPOS + embedded payments — relevant category for benchmarking only |

### Role for SolStein

1. **Valuation benchmark**: Epos Now at ~£113M revenue / $1.5B valuation implies ~12–13x revenue multiple for a cloud EPOS leader. NL/BE niche EPOS players likely command 3–5x.
2. **Technology reference**: Defines cloud-native EPOS + embedded payments expectations.
3. **Competitive signal**: UK hospitality venues on Epos Now not accessible via NL/BE focused SolStein strategy.

---

*Sources: Companies House (07666961, 10784763), Endole (open.endole.co.uk), Reuters (May 2024), Wikipedia (en.wikipedia.org/wiki/Epos_Now), eposnow.com/about-us, PitchBook.*
