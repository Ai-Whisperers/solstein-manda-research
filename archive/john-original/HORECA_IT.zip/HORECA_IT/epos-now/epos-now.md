# Epos Now

**Category**: POS/Restaurant
**Country**: UK
**City**: Norwich
**Research Status**: Pending

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history Epos Now @HORECA_IT/epos-now/
@research-horeca-company Epos Now @HORECA_IT/epos-now/
```
