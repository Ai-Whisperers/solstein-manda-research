# Epos Now — Deep Analysis

**Category**: POS / Restaurant & Retail (Cloud EPOS + Payments)
**Country**: UK (Norwich, England)
**Research Date**: 2026-04-30
**Tier**: 3 — Reference / Landscape (UK; not a primary SolStein acquisition target)

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | EPOS NOW (UK) LTD / Epos Now Ltd (holding) | Companies House 07666961 / 10784763 | Confirmed |
| HQ | Norwich, Norfolk, UK | Companies House, eposnow.com | Confirmed |
| Founded | 2011 | Companies House filing date | Confirmed |
| Founder / CEO | Jacyn Heavens | Reuters, Wikipedia, eposnow.com | Confirmed |
| Ownership | Founder-owned; no PE investment as of Apr 2026 | Reuters May 2024 | Confirmed |
| Employees | ~500 | PitchBook, Endole | Estimated |
| Revenue (FY2025) | £113.57M | Endole / Companies House filing | Confirmed |
| Revenue (FY2023) | £59.6M | Companies House via Reuters | Confirmed |
| Debt financing | $63.8M | PitchBook | Estimated |
| Target valuation (2024) | Up to $1.5B | Reuters May 2024 | Estimated |
| Business model | SaaS EPOS subscription + embedded payments processing | eposnow.com | Confirmed |
| Product | Cloud POS for hospitality + retail; payment processing; integrations | eposnow.com | Confirmed |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK merchant locations | 80,000+ | eposnow.com/about-us | Confirmed |
| Countries served | 70+ | eposnow.com/about-us | Confirmed |
| UK market vertical | Hospitality (restaurants, cafes, bars, hotels) + retail | eposnow.com | Confirmed |
| NL/BE presence | Not confirmed; likely some NL/BE merchants via self-serve | Unknown | Unknown |
| EU presence | Sold via self-serve globally; EU presence unquantified | Estimated | Estimated |
| Market share (UK EPOS) | Significant; one of top 3 UK cloud EPOS providers | Multiple industry comparisons | Estimated |
| Target customer size | SMB to mid-market (1–50 locations) | eposnow.com | Confirmed |

Epos Now primarily serves the UK hospitality and retail SMB market. Its 80,000+ merchant count suggests meaningful UK HORECA penetration. NL/BE presence is likely incidental (self-serve sign-ups) rather than deliberate market development.

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product | Cloud EPOS platform (POS software + hardware) | eposnow.com | Confirmed |
| Payments | Embedded payment processing (fintech layer) | Reuters, eposnow.com | Confirmed |
| Deployment | Cloud-native SaaS; web + iOS/Android app | eposnow.com | Confirmed |
| Hardware | Standard tablets (iPad, Android); own branded terminals | eposnow.com | Confirmed |
| Integration marketplace | 100+ integrations (accounting, loyalty, inventory, etc.) | eposnow.com | Confirmed |
| Tech stack | Cloud-native; API-first | Inferred from product | Estimated |
| Key differentiators | Affordable SMB pricing; embedded payments; self-serve onboarding | eposnow.com | Confirmed |
| Vertical specialisation | Both hospitality and retail (dual vertical) | eposnow.com | Confirmed |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Current ownership | 100% founder-owned (Jacyn Heavens) | Reuters May 2024 | Confirmed |
| PE backing | None | Reuters May 2024 | Confirmed |
| Strategic process | Minority stake sale exploration (May 2024); outcome unknown | Reuters May 2024 | Confirmed |
| Succession signal | Founder active as CEO; no succession gap identified | Public leadership profile | Estimated |
| Acquisition risk | Would require $1.5B+ valuation; no strategic buyer confirmed | Reuters | Estimated |

---

## 5. Financial Growth & Trajectory

| Year | Revenue | Growth | Source | Confidence |
|---|---|---|---|---|
| FY2023 | £59.6M | +25% YoY | Reuters / Companies House | Confirmed |
| FY2025 | £113.57M | ~90% vs FY2023 | Endole / Companies House | Confirmed |
| Trajectory | Strong growth; accelerating payments revenue | Reuters | Estimated |

Revenue nearly doubled from £59.6M to £113.57M in two fiscal years — driven by both EPOS subscription growth and embedded payments volume (transaction take-rate). The company is on a clear scale-up trajectory heading toward a potential liquidity event.

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| UK-specific compliance | UK VAT-compliant EPOS; Making Tax Digital (MTD) compatible | eposnow.com | Confirmed |
| UK payment methods | Chip & PIN, contactless, Apple Pay, Google Pay, online | eposnow.com | Confirmed |
| Hospitality features | Table management, takeaway, delivery integration, split bills | eposnow.com | Confirmed |
| Allergen/menu management | Basic menu management; not deep allergen specialisation | eposnow.com | Estimated |
| Loyalty | Built-in loyalty and gift card module | eposnow.com | Confirmed |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue model | SaaS subscription + payment processing take-rate | eposnow.com | Confirmed |
| ARR estimate | ~£110M+ (recurring subscription + payments) | Derived from FY2025 revenue | Estimated |
| Valuation explored | Up to $1.5B (minority stake, 2024) | Reuters | Estimated |
| Implied revenue multiple | ~11–12x (at $1.5B / ~$140M revenue) | Derived | Estimated |
| Acquisition price estimate | $1B–$1.5B+ for full acquisition | Reuters | Estimated |
| SolStein fit | No — 75–150x above SolStein's target range | Derived | Confirmed |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | 3 | Founder-owned (positive signal), but exploring PE-level stake sale at $1.5B valuation — not accessible for SolStein | Reuters May 2024 |
| Revenue scale fit | High | 1 | £113M ARR — 7–100x above SolStein's €1–15M target | Companies House FY2025 |
| Geographic fit | High | 1 | UK/Global focus; no confirmed NL/BE strategy | eposnow.com |
| Tech stack modernity | Medium | 5 | Cloud-native SaaS from day 1; embedded payments; modern stack | eposnow.com |
| Customer lock-in | Medium | 4 | 80,000+ merchants; payment processing creates high switching costs | eposnow.com |
| Vertical depth | Medium | 4 | Strong UK hospitality + retail EPOS; dual vertical | eposnow.com |
| Integration potential | Low | 4 | 100+ integrations; API marketplace | eposnow.com |
| Growth trajectory | Low | 5 | £59.6M → £113.57M in 2 years; strong momentum | Companies House |

### Composite Score

**Weighted Composite: 2.3 / 5.0**

*(High-weight dimensions drag score: revenue scale = 1, geographic fit = 1)*

**Confidence Band**: Medium — core financial data confirmed from Companies House. Ownership/PE process details from Reuters (reliable secondary source).

### Overall M&A Assessment

Epos Now is **not an acquisition target** for SolStein. It is a high-growth UK EPOS leader heading toward a PE minority stake event or eventual IPO/trade sale at $1B+ valuation. Its only value to SolStein is as a **valuation benchmark** (cloud EPOS multiples), a **technology reference** (cloud-native EPOS architecture), and a **competitive signal** (UK market penetration).

### Recommended Next Step

No pursuit. Use as benchmark: cloud EPOS leaders in UK command 10–13x revenue multiples; NL/BE niche equivalents likely 3–5x. Monitor whether any NL/BE resellers or integrators in the Epos Now ecosystem could be acquisition candidates.

---

*Sources: Companies House (07666961, 10784763), Reuters (May 2024), Endole (open.endole.co.uk), Wikipedia (Epos Now), eposnow.com/about-us, PitchBook.*
