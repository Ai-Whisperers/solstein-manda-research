# Misterbook — Deep Analysis

**Category**: Hotel PMS
**Research Date**: 2026-04-30
**Analyst**: SolStein M&A Research

---

## Research Methodology

Extensive web research was conducted on 2026-04-30 using 12+ targeted searches across OpenKvK.nl, kvk.nl, LinkedIn, Crunchbase, Dealroom, Tracxn, Google, and direct website fetches. OpenKvK returned zero results for "misterbook". The domain misterbook.nl returns a 503 error (server alive, no content served). The domain misterbook.com is a parked for-sale domain. No LinkedIn company page was found for a Dutch hotel PMS company named "Misterbook".

**Critical disambiguation**: The best-known company with a similar name is **Misterbooking** (France, est. 2003, owned by Septeo PE group). That company is explicitly excluded from this analysis as it does not match SolStein's thesis (not NL/BE, PE-backed). This analysis concerns the Dutch entity "Misterbook" as referenced in SolStein's brief.

---

## 1. Company Fundamentals

| Field | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Unknown | OpenKvK.nl — zero results | Unknown |
| HQ address | Amsterdam, NL (per brief) | Brief only | Estimated |
| Founded | Unknown | No public record | Unknown |
| CEO / MD | Unknown | No LinkedIn or company page found | Unknown |
| Ownership structure | Unknown | No KvK or investor data | Unknown |
| Employees (FTE) | Unknown | No LinkedIn company page | Unknown |
| Revenue (latest estimate) | Unknown | No financial data | Unknown |
| Profitability | Unknown | No financial data | Unknown |
| Website | misterbook.nl (per brief) — currently returning 503 Service Unavailable | Direct fetch 2026-04-30 | Estimated |

---

## 2. HORECA Market Position

| Field | Value | Source | Confidence |
|---|---|---|---|
| Primary countries | NL (per brief) | Brief only | Estimated |
| Customer count | Unknown | No data | Unknown |
| Target verticals | Hotel / accommodation PMS (per brief) | Brief only | Estimated |
| Market share estimate | Unknown | No data | Unknown |
| Key competitors | Mews (Amsterdam, est. 2012), Room Raccoon (Breda, est. 2014), Maxxton (Middelburg, est. 1998), Booking Experts (NL), Valk Solutions (NL), Cubilis (BE) | Tracxn, web research | Confirmed |

### NL Hotel PMS Competitive Landscape

The Dutch hotel PMS market has several well-established incumbents that Misterbook would compete against:
- **Mews** (Amsterdam): Global cloud PMS leader; €350M+ raised; Series C-stage; serving 5,000+ properties worldwide. Not a realistic acquisition for SolStein thesis scale.
- **Room Raccoon** (Breda): Dutch cloud PMS for independent hotels; B2B SaaS; multiple funding rounds; ~100 employees.
- **Maxxton** (Middelburg): Dutch vacation rental + hotel PMS; est. 1998; likely founder-owned.
- **Booking Experts** (NL): Cloud PMS for holiday parks and hotels; 100+ staff; Dutch founder-owned.
- **Valk Solutions** (Barneveld): HORECA management software; part of Van der Valk group ecosystem.
- **Cubilis** (Ghent, BE): Channel manager + PMS; Belgian, acquired by Stardekk.
- **Misterbooking** (France, NOT NL): Cloud PMS; acquired by Septeo PE; ~1,800 hotels; French-market focused.

---

## 3. Product & Technology

| Field | Value | Source | Confidence |
|---|---|---|---|
| Core product(s) | Hotel PMS / property management system (per brief) | Brief only | Estimated |
| Tech stack | Unknown | No product website accessible | Unknown |
| Deployment model | Unknown — likely cloud-native given brief description | Brief inference | Estimated |
| API availability | Unknown | No data | Unknown |
| Key integrations | Unknown | No data | Unknown |
| Mobile app | Unknown | No app store listing found | Unknown |

---

## 4. M&A Ownership & Succession

| Field | Value | Source | Confidence |
|---|---|---|---|
| Founder-owned | Unknown | No ownership data | Unknown |
| Investor type | Unknown | No Crunchbase / Dealroom record for NL Misterbook | Unknown |
| PE ownership | Unknown; likely PE-free if very small/early stage | Inference from zero public profile | Estimated |
| Succession signals | Unknown | No leadership data | Unknown |
| Last funding date | Unknown | No fundraise records | Unknown |

---

## 5. Financial Growth & Trajectory

| Field | Value | Source | Confidence |
|---|---|---|---|
| Revenue trend | Unknown | No financial data | Unknown |
| Employee growth | Unknown | No headcount data | Unknown |
| New markets | Unknown | No data | Unknown |
| Recent product launches | Unknown | No press or product pages found | Unknown |

---

## 6. HORECA Vertical Depth

| Field | Value | Source | Confidence |
|---|---|---|---|
| Specific HORECA verticals | Hotel / accommodation (per brief) | Brief only | Estimated |
| GDPR/AVG compliance | Unknown | No privacy policy found | Unknown |
| Allergen management | Not applicable (PMS focus) | N/A | N/A |
| Fiscal compliance NL | Unknown | No product details available | Unknown |
| iDEAL/Bancontact/Tikkie support | Unknown | No payment documentation found | Unknown |

---

## 7. Valuation & Business Model

| Field | Value | Source | Confidence |
|---|---|---|---|
| Pricing model | Unknown — hotel PMS typically SaaS per-room-per-month | Market knowledge (comparable: Misterbooking starts €110/mo) | Estimated |
| Estimated ARR | Unknown | No financial data | Unknown |
| Estimated acquisition value | Unknown | Cannot estimate without revenue or headcount | Unknown |
| Revenue per employee | Unknown | No data on either metric | Unknown |

---

## 8. M&A Attractiveness Scorecard

| Dimension | Weight | Score (1-5) | Rationale | Key Source |
|---|---|---|---|---|
| Ownership attractiveness | High | N/A | Cannot assess — no ownership data | — |
| Revenue scale fit | High | N/A | Cannot assess — no revenue data | — |
| Geographic fit | High | 3 | Amsterdam NL per brief; .nl domain confirms NL orientation | Brief + domain check |
| Tech stack modernity | Medium | N/A | No product information accessible; brief says "cloud-native or migrating" | Brief |
| Customer lock-in | Medium | 4 | Hotel PMS has high switching costs — staff retraining, channel manager reconfiguration, integration rebuild | Market knowledge |
| Vertical depth | Medium | N/A | Hotel PMS niche is well-defined and sticky; but NL hotel PMS market is already competitive | Market knowledge |
| Integration potential | Low | N/A | Unknown without product information | — |
| Growth trajectory | Low | N/A | No data | — |

**Composite Score**: Insufficient data — N/A
**Confidence Band**: Wide (zero accessible public information; server alive suggests company is operational)
**Overall M&A Assessment**: Misterbook exists as a domain (misterbook.nl) with a live but non-responsive server, suggesting the company is operational but maintains minimal public presence. No KvK registration was found under "misterbook" or "mister book" in the Dutch trade register. The hotel PMS category in the Netherlands is attractive for SolStein's thesis (high switching costs, niche HORECA focus, cloud-native potential), but without confirmed revenue, employee count, or ownership data, acquisition feasibility cannot be assessed. This company warrants a direct outreach attempt before further research investment.
**Recommended Next Step**: (1) WHOIS lookup for misterbook.nl to identify registrant legal entity. (2) Direct outreach via any discoverable contact (LinkedIn search for "Misterbook Amsterdam hotel PMS"). (3) Re-attempt misterbook.nl fetch in 48 hours — 503 may be temporary. (4) Cross-reference Tracxn hotel IT startup list for Amsterdam to check if Misterbook appears under a different listed name.
