# Misterbook — Corporate History

**Category**: Hotel PMS
**Country**: NL (per brief)
**Research Date**: 2026-04-30

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity Name | Unknown | OpenKvK.nl — "misterbook" returned zero results; "mister book" returned unrelated entities | Unknown |
| KvK Number | Unknown | OpenKvK.nl — no matching entry for hotel PMS company | Unknown |
| Registered City | Amsterdam (per brief) | Brief only — not confirmed via primary source | Estimated |
| Founding Year | Unknown | No public record found | Unknown |
| Founders | Unknown | No public record found | Unknown |
| Current Ownership | Unknown | No public record found | Unknown |
| PE/Investor Ownership | Unknown | No Crunchbase / Dealroom record for NL "Misterbook" | Unknown |
| Employees (FTE) | Unknown | No LinkedIn company page found for NL entity | Unknown |
| Estimated Revenue | Unknown | No financial data found | Unknown |
| M&A History | None found | No public record | Unknown |
| Investment Rounds | None found | No investor tracking data | Unknown |
| Name Changes | Unknown | No KvK record available | Unknown |

---

## Research Notes

Extensive web research (10+ searches) conducted on 2026-04-30 yielded no publicly discoverable Dutch company registered as "Misterbook" providing a hotel PMS. Key findings:

- **OpenKvK.nl** (misterbook): Search returned **zero results**. Confirmed via direct page fetch.
- **OpenKvK.nl** (mister book): Returned unrelated entities — no hotel software company.
- **misterbook.nl**: Returns **503 Service Unavailable** — server exists but is not responding. Domain is live but product/company not accessible.
- **misterbook.com**: Domain is **for sale** via Afternic (parked page, Spanish-language GoDaddy domain marketplace). Not a live product site.
- **LinkedIn**: No company page found for "Misterbook" as a Netherlands hotel PMS company.
- **Crunchbase / Dealroom**: No Dutch hotel software startup named "Misterbook" found.

### Important Disambiguation: Misterbooking vs. Misterbook

The closest publicly documented entity is **Misterbooking** (misterbooking.net / misterbooking.com), which is a **French company**:
- Founded: 2003 by David Glineur
- HQ: Bouc-Bel-Air, France (not Amsterdam or NL)
- Product: Cloud PMS for hotels — all-in-one PMS + Channel Manager + Booking Engine
- Scale: ~1,800 hotels; 20+ years in market
- Ownership: Acquired by **Septeo** (French legal-tech / SaaS PE group) — PE-backed, not founder-owned
- KvK: None (French entity, not NL-registered)
- This company does NOT match SolStein's thesis (not NL/BE, PE-backed, non-Dutch)

The Dutch company "Misterbook" (misterbook.nl), if it exists, is a distinct and separate entity from Misterbooking.

---

## Corporate Structure

```mermaid
graph TD
    A[Unknown — Founder / Parent] --> B[Operating Company NL — Legal Entity Unknown]
    B --> C[Misterbook Hotel PMS Platform]
```

---

## Timeline

```mermaid
timeline
    title Misterbook Key Events
    Unknown : Founded — year not publicly available
    2026-04-30 : SolStein M&A research initiated — misterbook.nl returning 503; no KvK found
```

---

## M&A Feasibility Assessment

| Criterion | Assessment | Notes |
|---|---|---|
| Founder-owned | Unknown | Ownership structure not publicly available |
| PE-free | Unknown | No investor data found; likely PE-free if very small |
| Revenue in thesis range (€1M–€15M ARR) | Unknown | No financial data; likely sub-scale given zero public presence |
| Geographic fit (NL/BE) | Estimated Yes | Brief states Amsterdam, NL; domain misterbook.nl confirms NL orientation |
| Succession signal | Unknown | No leadership data found |
| Overall feasibility | Unknown | Insufficient data; server exists (503) suggesting company is alive |

---

## Recommended Next Steps

1. WHOIS lookup for misterbook.nl to identify the registrant legal entity and contact details.
2. Search OpenKvK.nl for Amsterdam hotel software companies using NACE 6201/6202 + founding year 2015–2024.
3. Check if misterbook.nl becomes responsive — 503 may be temporary maintenance; re-attempt in 24–48 hours.
4. Search Dutch trade press (Hospitality Management NL, Hoteliers.nl, Entree Magazine) for any articles mentioning "Misterbook" hotel software.
5. Search Tracxn for hotel IT startups in Amsterdam — they list Mews, RUNNR.ai, Userguest, Oaky, and others; check if Misterbook appears.
