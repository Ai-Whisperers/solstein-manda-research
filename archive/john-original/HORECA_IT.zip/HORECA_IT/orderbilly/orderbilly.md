# OrderBilly

**Category**: B2B Ordering
**Country**: BE
**Research Status**: Pending — newly surfaced lead

**Discovery Source**: BE batch research (2026-04-30) — identified as the real Belgian B2B foodservice ordering platform; acquired Smartendr in 2025. Surfaced as the correct replacement for the invalid "OrderGrid" entry.

---

## Research Files

| File | Status |
|---|---|
| `corporate-history.md` | Not started |
| `deep-analysis.md` | Not started |
| `financial-growth.md` | Not started |

---

## How to Run Research

```
@research-horeca-company-history OrderBilly @HORECA_IT/orderbilly/
@research-horeca-company OrderBilly @HORECA_IT/orderbilly/
```
