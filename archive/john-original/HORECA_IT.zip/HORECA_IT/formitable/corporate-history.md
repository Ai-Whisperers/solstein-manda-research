# Formitable — Corporate History

**Category**: Restaurant Reservations & Marketing Platform
**Country**: Netherlands (NL)
**City**: Amsterdam
**Research Date**: 2026-04-30
**Research Status**: Complete

---

## M&A Feasibility Verdict

> **OFF-MARKET — NOT ACQUIRABLE**
>
> Formitable is fully integrated into **Zenchef**, a PE-backed European restaurant tech group majority-owned by **PSG Equity** (growth equity, €50M+ invested in 2022). The brand still exists as a customer-facing product (formitable.com redirects to Zenchef), but Formitable B.V. is a subsidiary of the Zenchef group. No acquisition by TheFork or TripAdvisor ever occurred — that premise was false. SolStein cannot acquire Formitable.

---

## Key Data Points

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal name | Formitable B.V. | Formitable Impressum | Confirmed |
| KvK number | 67619665 | Formitable Impressum (formitable.com/de/impressum) | Confirmed |
| Registered address | Elandsstraat 44, 1016 SG Amsterdam, Netherlands | Formitable Impressum | Confirmed |
| VAT number | NL857095821B01 | Formitable Impressum | Confirmed |
| Founding year | 2017 (platform launch); roots from 2010 via Pocketmenu | formitable.com/de/about-us, MTSprout article | Confirmed |
| Founders | Raymond Wilders (CEO), Cyril Mestrom, Milan van de Goor | MTSprout.nl interview with Raymond Wilders | Confirmed |
| Precursor company | Pocketmenu — launched 2010, world's first mobile website builder for restaurants; sold prior to 2017 | formitable.com/de/about-us | Confirmed |
| CEO at merger | Raymond Wilders | Silicon Canals (Jan 2023), EU-Startups (Sep 2022) | Confirmed |
| Merger date | January 25, 2023 — merger with Zenchef announced | Silicon Canals, PitchBook | Confirmed |
| Post-merger brand unification | January 2024 — Formitable, Zenchef, Resengo unified under single Zenchef brand / ZenchefOS | formitable.com (homepage), Zenchef Help Center | Confirmed |
| Current status | Subsidiary of Zenchef group; formitable.com redirects to Zenchef | formitable.com | Confirmed |
| Majority shareholder (post-merger) | PSG Equity (growth private equity, Boston-based) | Silicon Canals Jan 2023, Resengo acquisition press release | Confirmed |
| PSG Equity investment in Zenchef | €50M+ invested in Zenchef in September 2022 | PrivSource, Elaia.com, PSG Equity portfolio page | Confirmed |
| Key investor in Formitable (pre-merger) | Adriaan Mol (Mollie/MessageBird founder), via investment vehicle Spacetime — €8M growth capital, September 2022 | EU-Startups Sep 2022 | Confirmed |
| Other early investors | Nalden, Wobbe Storms, Marten Post | StartupIntros, CBInsights | Estimated |
| Total funding raised (Formitable standalone) | ~$9.4M / ~€8.8M | PitchBook, CBInsights | Estimated |
| Restaurants at time of merger | 3,500+ restaurants in NL and Europe | Silicon Canals Jan 2023 | Confirmed |
| Table app downloads at time of merger | 150,000+ (NL and BE market) | Silicon Canals Jan 2023 | Confirmed |
| Horecava Innovation Award | 2018 — Digital, Apps & Social Media category | formitable.com/de/about-us | Confirmed |
| Resengo acquisition by Zenchef\|Formitable | September 12, 2023 — acquired Dutch-Belgian platform Resengo (3,500+ restaurants) | Resengo blog, Silicon Canals | Confirmed |
| Tablebooker acquisition | February 2024 — Zenchef acquired Belgian platform Tablebooker | Zenchef press release | Confirmed |
| Combined group size (post-Resengo) | 15,000+ restaurants, 200+ employees, offices in Paris, Amsterdam, Antwerp, Copenhagen, Berlin, Lisbon | Resengo acquisition press release | Confirmed |
| TheFork/TripAdvisor acquisition | **Never occurred** — premise in research brief was false | All sources; no evidence found | Confirmed |
| Deal value (Formitable–Zenchef merger) | Not disclosed publicly | All sources | Unknown |
| Deal value (Resengo acquisition) | Not disclosed publicly | All sources | Unknown |
| Formitable standalone revenue (pre-merger) | Estimated $19.9M (Growjo model, likely overestimated); more likely €3M–€8M ARR | Growjo.com (modeled estimate) | Estimated |
| Formitable employee count (at merger) | ~60–64 (PitchBook); Growjo estimates 114 | PitchBook; Growjo | Estimated |

---

## Ownership History

### Phase 1 — Precursor: Pocketmenu (2010–2016)
Raymond Wilders, Cyril Mestrom, and Milan van de Goor launched **Pocketmenu** in 2010 as the world's first mobile website builder for restaurants. In 2012, Pocketmenu integrated with SeatMe and Livebookings to add reservation functionality. The team eventually sold Pocketmenu and began reimagining a next-generation reservation system in 2016.

### Phase 2 — Formitable Launch & Bootstrap Growth (2017–2022)
Formitable launched in 2017. Early angel backers included Nalden, Wobbe Storms, and Marten Post. The company grew to 1,000 restaurants by 2019, reached 2,000 restaurants by 2020 (achieving NL market leadership), and 3,000+ by 2022. In 2021, the **Table** consumer app launched, reaching 150,000 downloads by 2022.

### Phase 3 — Strategic Investment (September 2022)
Serial entrepreneur **Adriaan Mol** (founder of Mollie and MessageBird) invested **€8M** in Formitable via his investment vehicle **Spacetime**. This was growth capital, not a controlling acquisition. Mol had been a strategic partner prior to formalising the investment. Simultaneously, **PSG Equity** invested **€50M+** in Zenchef.

### Phase 4 — Merger with Zenchef (January 25, 2023)
Formitable merged with Paris-based **Zenchef** (founded 2010 by Xavier Zeitoun, Thomas Zeitoun, and Julien Balmont). The deal created a combined entity of ~11,000 restaurants across 30 European countries. **PSG Equity** became majority shareholder of the merged entity. Raymond Wilders continued as CEO of Formitable; Xavier Zeitoun as CEO of Zenchef. Both brands initially maintained separate operations.

### Phase 5 — Resengo Acquisition (September 12, 2023)
Zenchef | Formitable acquired Dutch-Belgian platform **Resengo** (founded 20+ years prior, CEO Dirk Gypen). Resengo added 3,500+ restaurants and strengthened NL/BE presence. Combined entity reached 15,000+ restaurants.

### Phase 6 — Brand Unification (January 2024)
Formitable, Zenchef, and Resengo unified under the single brand **Zenchef** and the **ZenchefOS** platform. Formitable.com now redirects to Zenchef. CoverManager and Tablebooker were subsequently folded in.

---

## All M&A and Investment Events

| Date | Event | Parties | Value | Source | Confidence |
|---|---|---|---|---|---|
| 2010 | Pocketmenu founded | Wilders, Mestrom, Van de Goor | — | formitable.com/de/about-us | Confirmed |
| ~2015–2016 | Pocketmenu sold | Founders sell to undisclosed buyer | Undisclosed | MTSprout.nl | Estimated |
| 2017 | Formitable B.V. incorporated | Founders | — | KvK 67619665 | Confirmed |
| 2017–2021 | Early angel rounds | Nalden, Wobbe Storms, Marten Post | ~$1.4M est. | StartupIntros, CBInsights | Estimated |
| Sep 2022 | Growth investment | Adriaan Mol / Spacetime → Formitable | €8M | EU-Startups Sep 2022 | Confirmed |
| Sep 2022 | PE investment in Zenchef | PSG Equity → Zenchef | €50M+ | PrivSource, PSG Equity | Confirmed |
| Jan 25, 2023 | Merger | Formitable + Zenchef → Zenchef\|Formitable | Undisclosed | Silicon Canals Jan 2023 | Confirmed |
| Sep 12, 2023 | Acquisition | Zenchef\|Formitable acquires Resengo | Undisclosed | Resengo blog, Silicon Canals | Confirmed |
| Feb 2024 | Acquisition | Zenchef acquires Tablebooker (BE) | Undisclosed | Zenchef press release | Confirmed |
| Jan 2024 | Brand unification | Formitable + Zenchef + Resengo → Zenchef | — | formitable.com, Zenchef Help Center | Confirmed |

---

## Corporate Structure (Post-Merger)

```mermaid
graph TD
    PSG["PSG Equity\n(Growth PE, Boston)\nMajority shareholder since Sep 2022"]
    ZENCHEF["Zenchef Group\n(Paris, France)\nCEO: Xavier Zeitoun"]
    FM["Formitable B.V.\n(Amsterdam, NL)\nKvK: 67619665\nCEO: Raymond Wilders (until integration)"]
    RESENGO["Resengo\n(Antwerp, BE)\nCEO: Dirk Gypen\nAcquired Sep 2023"]
    TB["Tablebooker\n(BE)\nAcquired Feb 2024"]
    CM["CoverManager\n(ES)\nJoined Zenchef group"]
    BRAND["ZenchefOS\n(Unified Brand & Platform\nsince Jan 2024)"]

    PSG -->|"€50M+ investment Sep 2022\nMajority shareholder"| ZENCHEF
    ZENCHEF -->|"Merger Jan 2023"| FM
    ZENCHEF -->|"Acquisition Sep 2023"| RESENGO
    ZENCHEF -->|"Acquisition Feb 2024"| TB
    ZENCHEF -->|"Partnership/acquisition"| CM
    FM --> BRAND
    RESENGO --> BRAND
    TB --> BRAND
    CM --> BRAND
```

---

## Corporate Timeline

```mermaid
timeline
    title Formitable Corporate Timeline
    2010 : Pocketmenu launched
         : World's first mobile restaurant website builder
    2012 : Pocketmenu + SeatMe/Livebookings integration
         : First reservation capability
    2016 : Pocketmenu sold
         : Team begins reimagining reservation platform
    2017 : Formitable B.V. incorporated (KvK 67619665)
         : Platform launches in Amsterdam
    2018 : Horecava Innovation Award — Digital category
    2019 : 1,000 restaurants milestone
    2020 : 2,000 restaurants — NL market leader
         : Covid pivot — takeaway features added
    2021 : Table consumer app launched
    2022 : 3,000+ restaurants — 150k Table app downloads
         : September — €8M from Adriaan Mol / Spacetime
         : September — PSG Equity invests €50M+ in Zenchef
    2023 : January 25 — Merger with Zenchef announced
         : PSG Equity becomes majority shareholder of combined entity
         : September 12 — Resengo acquired
    2024 : January — Unified under Zenchef brand / ZenchefOS
         : February — Tablebooker acquired
         : Formitable brand effectively subsumed into Zenchef
```

---

## Correction of Research Brief Premise

The research brief stated: *"reportedly acquired by TheFork (TripAdvisor group) in 2021."*

**This is incorrect.** No evidence exists of any acquisition of Formitable by TheFork or TripAdvisor at any point. The facts are:
- TheFork (formerly La Fourchette) was itself acquired by **TripAdvisor in 2014** — it is not an acquirer, it is an acquired entity within Tripadvisor.
- In 2021, Formitable was an independent Dutch startup that launched its Table consumer app.
- Formitable's actual acquisition event was the **January 2023 merger with Zenchef**, backed by PSG Equity.
- The TheFork/TripAdvisor premise likely arose from confusion between TheFork (the consumer booking platform competing with Formitable's Table app) and a supposed ownership link.

---

## M&A Feasibility Assessment

| Factor | Assessment |
|---|---|
| **Independent?** | No — fully integrated into Zenchef group since Jan 2024 |
| **Founder-owned?** | No — PSG Equity is majority owner since Jan 2023 |
| **PE overhang?** | Yes — PSG Equity (growth PE) controls the group |
| **Acquirable by SolStein?** | No — off-market, PE-backed, integrated into a European-scale platform |
| **TheFork/TripAdvisor link?** | None — the premise in the research brief was false |
| **What SolStein can learn** | NL restaurant reservation market structure; Formitable's product benchmarks for competitors; Zenchef as a consolidator (Resengo, Tablebooker also absorbed — reducing NL reservation target pool) |
| **Alternative targets in same category** | Resengo (now also Zenchef); Tablebooker (now also Zenchef); smaller NL/BE reservation startups |

**Conclusion**: Formitable is irreversibly off-market. It is a useful market reference and competitive benchmark, but cannot be considered for acquisition by SolStein.
