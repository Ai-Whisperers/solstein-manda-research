# Formitable — Deep Analysis

**Category**: Restaurant Reservations & Marketing Platform
**Country**: Netherlands (NL)
**City**: Amsterdam
**Research Date**: 2026-04-30
**M&A Verdict**: **OFF-MARKET** — Integrated into Zenchef (PE-backed by PSG Equity)

---

## Executive Summary

Formitable was an Amsterdam-based SaaS reservation and guest marketing platform for restaurants, founded in 2017 by Raymond Wilders, Cyril Mestrom, and Milan van de Goor. It became the **market leader in the Netherlands** for restaurant reservations by 2020 and grew to 3,500+ restaurants by early 2023. In **January 2023**, Formitable merged with Paris-based Zenchef to form a joint European group backed by **PSG Equity** (majority owner via €50M+ investment). By **January 2024**, all brands were unified under a single **Zenchef** identity and **ZenchefOS** platform.

Formitable is **not acquirable** by SolStein. It is a PE-owned, fully integrated subsidiary of a European restaurant tech consolidator. The premise in the research brief — that Formitable was acquired by TheFork/TripAdvisor in 2021 — is factually incorrect; no such acquisition occurred.

---

## 1. Company Fundamentals

| Attribute | Value | Source | Confidence |
|---|---|---|---|
| Legal entity | Formitable B.V. | KvK, Formitable Impressum | Confirmed |
| KvK number | 67619665 | formitable.com/de/impressum | Confirmed |
| Registered address | Elandsstraat 44, 1016 SG Amsterdam | Formitable Impressum | Confirmed |
| VAT | NL857095821B01 | Formitable Impressum | Confirmed |
| Founded | 2017 (platform); team roots from 2010 via Pocketmenu | formitable.com/de/about-us | Confirmed |
| Founders | Raymond Wilders (CEO), Cyril Mestrom, Milan van de Goor | MTSprout.nl | Confirmed |
| Current legal ownership | Subsidiary of Zenchef group; PSG Equity majority shareholder | Silicon Canals, Resengo press release | Confirmed |
| Current brand status | Subsumed into Zenchef / ZenchefOS (since Jan 2024) | formitable.com homepage | Confirmed |
| **TheFork/TripAdvisor acquisition** | **Never occurred — premise was false** | All sources reviewed | Confirmed |
| Independent operation | No — fully integrated since Jan 2024 | Zenchef Help Center, formitable.com | Confirmed |

**Current ownership chain**: PSG Equity (majority PE) → Zenchef Group → Formitable B.V. + Resengo + Tablebooker + CoverManager → ZenchefOS unified platform.

---

## 2. HORECA Market Position

### Netherlands Restaurant Reservations Market

Formitable achieved **NL market leadership** by 2020 with 2,000 restaurants and held that position through the 2023 merger. At the time of the Zenchef merger, Formitable claimed:
- 3,500+ restaurants on its platform
- Market leader in the Netherlands
- Meaningful growth in Germany, Sweden, Denmark

| Market Indicator | Value | Source | Confidence |
|---|---|---|---|
| NL market leadership claim | Confirmed as market leader in NL by 2020 | EU-Startups Sep 2022, Silicon Canals Jan 2023 | Confirmed |
| Restaurants on platform at merger | 3,500+ | Silicon Canals Jan 2023 | Confirmed |
| Restaurants by 2022 milestone | 3,000+ | EU-Startups Sep 2022 | Confirmed |
| Restaurants by 2021 milestone | 2,000+ | formitable.com/de/about-us | Confirmed |
| Consumer Table app users | 150,000+ downloads (2022) | Silicon Canals Jan 2023 | Confirmed |
| Table app NL/BE position | Leading restaurant app in NL and BE | EU-Startups Sep 2022 | Confirmed |
| International reach | Active in 15 countries across Europe | EU-Startups Sep 2022 | Confirmed |
| Combined group post-Resengo | 15,000+ restaurants | Resengo acquisition press release Sep 2023 | Confirmed |
| Combined group employees | 200+ (post-Resengo) | Resengo acquisition press release | Confirmed |

### Competitive Landscape (NL Reservations)
The Dutch restaurant reservation market had three significant SaaS players that have now all consolidated into Zenchef:
- **Formitable** (NL market leader) → now Zenchef
- **Resengo** (NL/BE, ~3,500 restaurants) → acquired by Zenchef | Formitable Sep 2023
- **Tablebooker** (BE) → acquired by Zenchef Feb 2024

**Implication for SolStein**: The NL/BE restaurant reservation SaaS category has been substantially consolidated by Zenchef. Remaining independent targets in this sub-vertical are smaller and less established.

---

## 3. Product & Technology

### Product Portfolio

| Product | Description | Source | Confidence |
|---|---|---|---|
| Reservation system | Online table booking with yield management and prepayments | formitable.com/de/about-us | Confirmed |
| Ticketing | Sell ticketed dining events and experiences | EU-Startups Sep 2022 | Confirmed |
| Loyalty/CRM | Guest relationship management, marketing automation | Silicon Canals Jan 2023 | Confirmed |
| No-show management | Prepayments and guarantees to eliminate no-shows | formitable.com/de/about-us | Confirmed |
| Gift vouchers | Digital gift card sales via restaurant's own channel | EU-Startups Sep 2022 | Confirmed |
| Table app (B2C) | Consumer discovery and booking app — 150k+ downloads | Silicon Canals Jan 2023 | Confirmed |
| Payment integration | Frictionless post-meal payment via Table app | EU-Startups Sep 2022 | Confirmed |
| ZenchefOS | Successor platform integrating all Zenchef group tools | Zenchef Help Center 2024 | Confirmed |

### Technology Positioning

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Deployment model | Cloud-native SaaS | Product behavior, pricing model | Confirmed |
| Pricing model | Subscription (reported from ~€69/month entry) | restaurantbookingsystem.com 2026 | Estimated |
| Commission model | No commissions on reservations (owner-centric) | formitable.com, Silicon Canals | Confirmed |
| Mobile | B2C app (Table); restaurant-facing mobile tools | EU-Startups 2022 | Confirmed |
| API/integrations | Integrated with SeatMe, Livebookings historically; ZenchefOS API ecosystem | formitable.com/de/about-us | Confirmed |
| Stack specifics | Not publicly disclosed | — | Unknown |

**Award**: Horecava Innovation Award 2018, Digital/Apps/Social Media category — jury cited "easy-to-use software" and "smart yield management and promotion tool."

---

## 4. M&A Ownership & Succession

This is the central question for SolStein's due diligence.

### Definitive Answer: Formitable is Off-Market

| Question | Answer | Source | Confidence |
|---|---|---|---|
| Acquired by TheFork/TripAdvisor? | **No — this never occurred** | All research; no evidence found | Confirmed |
| Independent company? | **No — subsidiary of Zenchef since Jan 2023** | PitchBook, Silicon Canals | Confirmed |
| Founder-controlled? | **No — PSG Equity controls the group** | Silicon Canals Jan 2023 merger announcement | Confirmed |
| PE overhang? | **Yes — PSG Equity (growth PE) is majority shareholder** | PSG Equity portfolio, PrivSource | Confirmed |
| Succession gap? | **Not applicable — founders absorbed into PE-backed structure** | — | Confirmed |
| Can SolStein acquire? | **No** | — | Confirmed |

### M&A Event Sequence (Key Facts)
1. **Sep 2022**: Adriaan Mol invests €8M (growth capital, not control acquisition)
2. **Sep 2022**: PSG Equity invests €50M+ in Zenchef — sets up the merger dynamic
3. **Jan 25, 2023**: Formitable merges with Zenchef; PSG Equity becomes majority owner of merged entity — **Formitable ceases to be independent**
4. **Jan 2024**: Brand unification — Formitable identity absorbed into Zenchef / ZenchefOS

The deal structure of the Jan 2023 merger was not publicly disclosed (neither price nor equity split). Based on the Silicon Canals reporting: "PSG Equity will own the majority of the stock in the merged entity." This indicates PSG Equity's pre-existing Zenchef investment position was extended to cover the combined entity.

---

## 5. Financial Growth & Trajectory

| Metric | Value | Source | Confidence |
|---|---|---|---|
| Total funding raised (standalone) | ~$9.4M / ~€8.8M | PitchBook, CBInsights | Estimated |
| Key investment | €8M from Adriaan Mol / Spacetime, Sep 2022 | EU-Startups Sep 2022 | Confirmed |
| Earlier angel funding | ~$1.4M est. from Nalden, Wobbe Storms, Marten Post | StartupIntros, CBInsights | Estimated |
| Revenue estimate (standalone, pre-merger) | €3M–€8M ARR (estimated; Growjo model shows $19.9M but likely over-estimates for private SaaS) | Growjo.com (model-based) | Estimated |
| Employee count at merger | ~60–64 (PitchBook); Growjo est. 114 | PitchBook; Growjo | Estimated |
| Restaurant growth trajectory | 1,000 (2019) → 2,000 (2020) → 3,000 (2022) → 3,500+ (Jan 2023) | formitable.com timeline | Confirmed |
| Revenue per restaurant (implied) | ~€1,000–2,500/year per restaurant (typical SaaS pricing for this category) | Industry benchmark | Estimated |
| PSG Equity investment in Zenchef | €50M+ (Sep 2022) | PrivSource, PSG Equity | Confirmed |
| Combined group revenue target | Not disclosed; group claims 4x revenue growth post-PSG | Clipperton report ref | Estimated |
| Profitability | Not disclosed | — | Unknown |

**Revenue estimation note**: With 3,500 restaurants at ~€1,500–2,500 ARR/restaurant, Formitable's standalone ARR at merger time was likely **€5M–€9M**. The Growjo $19.9M figure appears to be a modeled estimate that likely inflates the number. The SolStein thesis range (€1M–€15M) would have been met if Formitable were independent.

---

## 6. HORECA Vertical Depth

| Dimension | Assessment | Source | Confidence |
|---|---|---|---|
| Primary vertical | Restaurant reservations and guest marketing | formitable.com | Confirmed |
| Sub-verticals covered | Reservations, ticketing, loyalty, CRM, payment, no-show management | EU-Startups, Silicon Canals | Confirmed |
| Customer segment | Independent restaurants to Michelin-starred groups | Silicon Canals Jan 2023 | Confirmed |
| Michelin clients | 200+ Michelin-starred chefs across Zenchef group | Silicon Canals Jan 2023 | Confirmed |
| Notable NL clients | Implicit from market leadership; RIJKS® in Amsterdam (via Resengo) | Resengo press release | Estimated |
| HORECA specificity | Purpose-built for restaurants; no hotel/retail crossover | Product analysis | Confirmed |
| Competitive positioning | Anti-commission, owner-centric (vs. TheFork/OpenTable commission model) | formitable.com, Silicon Canals | Confirmed |
| Guest data ownership | Restaurants own their guest data — key differentiator | formitable.com vision section | Confirmed |

**Differentiator**: Formitable's core thesis was that restaurants should **own their marketing** and guest relationships, not rent them from intermediary platforms. This anti-commission model positioned it directly against TheFork and OpenTable. This was a meaningful strategic advantage in the NL market.

---

## 7. Valuation & Business Model

### Business Model

| Element | Detail | Source | Confidence |
|---|---|---|---|
| Revenue model | Monthly SaaS subscription per restaurant | Pricing pages, Capterra | Confirmed |
| Entry price point | ~€69/month (ZenchefOS / Formitable pricing, 2026) | restaurantbookingsystem.com | Estimated |
| Commission on reservations | None — key differentiator | formitable.com | Confirmed |
| Upsell modules | Ticketing, loyalty, payment, marketing | Product pages | Confirmed |
| B2C revenue (Table app) | Not separately disclosed; likely cross-subsidised | — | Unknown |

### Valuation Benchmarks

| Reference | Value | Source | Confidence |
|---|---|---|---|
| PSG Equity investment in Zenchef | €50M+ for majority stake | PrivSource | Confirmed |
| Implied Zenchef valuation at investment | ~€80M–€120M (estimate based on typical growth PE majority structures) | Industry benchmark | Estimated |
| Formitable standalone valuation at merger | Not disclosed; est. €15M–€40M based on revenue multiples and deal context | Industry benchmark | Estimated |
| Post-merger combined entity value | Likely €100M–€200M range (PSG backed, 15k restaurants, European scale) | Industry benchmark | Estimated |
| Dealroom.co enterprise value range | $26M–$40M (likely pre-PSG investment, Zenchef only) | Dealroom.co | Estimated |

**Note**: All valuation figures for the merged/private entity are modeled estimates. Deal terms were not publicly disclosed.

---

## 8. M&A Attractiveness Scorecard

> **Note**: Scores reflect Formitable's fit as a SolStein acquisition target. Given the company is off-market and PE-owned, scores are largely academic — the ownership dimension alone disqualifies it. Scores are provided for completeness and benchmarking.

| Dimension | Weight | Score (1–5) | Rationale | Key Source |
|---|---|---|---|---|
| **Ownership attractiveness** | High | **1** | PSG Equity majority owner; Formitable fully integrated into Zenchef; no founder control; PE-backed consolidator — polar opposite of SolStein's target profile | Silicon Canals Jan 2023; PSG Equity portfolio |
| **Revenue scale fit** | High | **3** | Standalone ARR was likely €5M–€9M (within thesis range), but now part of a €50M+ PE-backed group — not separable | Estimated from restaurant count × ARPU |
| **Geographic fit** | High | **5** | NL market leader; Amsterdam HQ; NL and BE core markets — perfect geographic fit if it were independent | EU-Startups, Silicon Canals |
| **Tech stack modernity** | Medium | **4** | Cloud-native SaaS, mobile-first, modern web architecture; ZenchefOS demonstrates continued investment | Product analysis, awards, pricing model |
| **Customer lock-in** | Medium | **4** | 3,500+ restaurants with deep integration into guest data, CRM, and payment flows; Horecava award-winning UX; high retention implied by growth trajectory | formitable.com, EU-Startups |
| **Vertical depth** | Medium | **4** | Purpose-built for restaurants; full guest lifecycle coverage (reservation → loyalty → payment); anti-commission differentiation | formitable.com product pages |
| **Integration potential** | Low | **3** | SaaS architecture with API integrations (SeatMe, Livebookings historically); ZenchefOS ecosystem; specific API docs not public | formitable.com/de/about-us |
| **Growth trajectory** | Low | **4** | Strong pre-merger growth (1k→3.5k restaurants in 4 years); Table app traction; international expansion underway | formitable.com timeline, EU-Startups |

### Composite Score Calculation

| Weight | Dimensions | Weighted Score |
|---|---|---|
| High (×3) | Ownership (1) + Revenue scale (3) + Geographic fit (5) | (1+3+5) × 3 = 27 |
| Medium (×2) | Tech stack (4) + Customer lock-in (4) + Vertical depth (4) | (4+4+4) × 2 = 24 |
| Low (×1) | Integration potential (3) + Growth trajectory (4) | (3+4) × 1 = 7 |
| **Total** | | **58 raw points** |
| **Max possible** | (5×3)×3 + (5×3)×2 + (5×2)×1 | 45+30+10 = **85** |
| **Composite (weighted avg)** | 58 / 85 × 5 | **3.4 / 5.0** |

**Confidence Band**: **Narrow** — most key facts are Confirmed (ownership, merger dates, restaurant counts, funding). Revenue is Estimated. The score of 3.4 reflects that Formitable would have been an attractive target on most dimensions *except the one that matters most* — ownership.

### Overall Assessment

**Score: 3.4 / 5.0 — BLOCKED by ownership**

Formitable scores well on geography (NL market leader), tech modernity, customer lock-in, and vertical depth — all dimensions that would make it an excellent SolStein target. However, the ownership dimension (score: 1/5) is disqualifying and non-negotiable. PSG Equity controls the combined Zenchef group, which has absorbed Formitable, Resengo, and Tablebooker into a single platform. No part of this group is available for acquisition by a SolStein-style buyer.

The scoring exercise is useful as a **benchmarking reference**: Formitable establishes a quality benchmark for what a "5/5" NL restaurant reservation target would look like on product, geography, and market depth. SolStein should use Formitable as a reference model when evaluating smaller, genuinely independent NL/BE reservation players.

### Recommended Next Step

**Do not pursue.** Formitable / Zenchef is off-market.

Redirect attention to:
1. **Identify remaining independent NL/BE reservation players** — the Formitable/Resengo/Tablebooker consolidation has absorbed the three largest platforms; any remaining independents are likely smaller (<500 restaurants) and worth screening
2. **Monitor Zenchef's NL/BE market position** — as a consolidated entity, Zenchef creates a vacuum for a boutique competitor to serve restaurants that prefer an independent, local alternative
3. **TheFork strategic review** — Tripadvisor has announced exploration of strategic alternatives for TheFork (as of early 2026); if TheFork is sold or wound down in NL, it could create further market displacement opportunities
4. **Benchmark Formitable's product** for any SolStein portfolio company or acquisition target in the reservation category

---

## Source Log

| Source | Type | URL / Reference | Key Data Extracted |
|---|---|---|---|
| formitable.com/de/impressum | Primary — company website | formitable.com/de/impressum | KvK 67619665, address, CEO, VAT |
| formitable.com/de/about-us | Primary — company website | formitable.com/de/about-us | Timeline 2010–2023, milestones, vision |
| formitable.com (homepage) | Primary — company website | formitable.com | Brand unification Jan 2024 under Zenchef |
| Silicon Canals (Jan 25, 2023) | Secondary — news | siliconcanals.com/formitable-unite-with-zenchef | Merger date, deal structure, PSG Equity majority, CEO quotes |
| EU-Startups (Sep 15, 2022) | Secondary — news | eu-startups.com/2022/09/entrepreneur-adriaan-mol... | €8M Mol investment, product details, CEO quote, growth metrics |
| Resengo acquisition blog | Secondary — press release | pro.resengo.com/en/blog/zenchef-formitable-acquires-resengo | Sep 2023 acquisition, 200+ employees, 15k restaurants |
| PitchBook | Secondary — database | pitchbook.com/profiles/company/459188-11 | Founding 2017, 64 employees, acquired/merged status, Zenchef parent |
| PrivSource / PSG Equity | Secondary — deal record | privsource.com, psgequity.com/portfolio/zenchef | PSG Equity €50M+ in Zenchef Sep 2022 |
| MTSprout.nl | Secondary — NL tech media | mtsprout.nl/groei/the-founder/raymond-wilders-formitable | Co-founders: Wilders, Mestrom, Van de Goor |
| Growjo.com | Secondary — modeled estimate | growjo.com/company/Formitable | $19.9M revenue est. (model-based); 114 employees est. |
| CBInsights | Secondary — database | cbinsights.com/company/formitable | Total funding $9.42M, ZenchefOS reference |
| StartupIntros | Secondary — aggregator | startupintros.com/orgs/formitable | Funding history, investor names |
| Zenchef Help Center | Primary — company website | help.zenchef.com/hc/en-gb/articles/14638580012701 | Jan 2024 unification under Zenchef brand |
| restaurantbookingsystem.com (2026) | Third-party review | restaurantbookingsystem.com/compare/zenchef-vs-resos | Pricing reference ~€69/month |
| Tripadvisor IR | Primary — investor relations | ir.tripadvisor.com | TheFork acquired by TripAdvisor in 2014 (not Formitable) — confirms false premise |
