# Formitable

**Category**: Reservations
**Country**: NL
**Research Status**: Done 2026-04-30
**M&A Verdict**: OFF-MARKET — integrated into Zenchef (PSG Equity majority owner since Jan 2023)

---

## Research Files

| File | Status |
|---|---|
| corporate-history.md | Done 2026-04-30 |
| deep-analysis.md | Done 2026-04-30 |

---

## How to Run Research

```
@research-horeca-company-history Formitable @HORECA_IT/formitable/
@research-horeca-company Formitable @HORECA_IT/formitable/
```
