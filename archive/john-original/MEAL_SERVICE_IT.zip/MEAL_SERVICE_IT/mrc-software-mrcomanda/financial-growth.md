# Financial & Growth Deep-Dive — MRC Software / Mr. Comanda

**Research Date**: 2026-05-04
**Player Type**: Tech-vendor (hybrid POS + ERP software — gastronomy and retail; on-prem + optional cloud)
**Domicile Country**: Argentina (Córdoba)
**Reporting Currency**: ARS (Argentina); USD used for international comparability
**Inflation Adjustment Status**: ARS — severe inflation distortion from 2018 onward; USD figures use official rate where specified; MEP/CCL rate divergence noted
**Data Availability**: Low (private, no public filings, no Crunchbase entry, no AFIP revenue disclosure; revenue entirely proxy-based)

---

### Revenue Timeline

| Year | Revenue Basis | Currency | Approx FX (ARS/USD) | Revenue (USD M) | YoY Growth (USD-Real) | Source | Confidence |
|---|---|---|---|---|---|---|---|
| 2026 (est.) | 5,000 clients × USD 80–120/mo avg license fee × 12 | ARS + USD | ~1,000 ARS/USD (official) | ~USD 4.8–7.2M ARR | ~flat in USD | Proxy: 5,000 clients @ USD 100/mo avg | Estimated proxy |
| 2025 | Same basis; ~5,000 clients assumed stable | ARS + USD | ~900 ARS/USD | ~USD 4.5–6.5M ARR | ~+5–10% USD | Interpolation | Estimated proxy |
| 2024 | ~4,500 clients (interpolated) | ARS + USD | ~800 ARS/USD | ~USD 4.0–6.0M ARR | ~+5% USD | Interpolation | Estimated proxy |
| 2023 | ~4,000 clients; ARS hyperinflation | ARS | ~350 ARS/USD | ~USD 3.5–5.0M (USD-real) | -15 to -20% USD (ARS inflation offset) | ARS hyperinflation context | Estimated proxy |
| 2022 | ~4,000 clients | ARS | ~200 ARS/USD | ~USD 3.5–5.0M | ~flat | Proxy | Estimated proxy |
| 2021 | COVID recovery; ~3,500 clients | ARS | ~100 ARS/USD | ~USD 3.0–4.5M | ~+10–15% | Post-COVID recovery | Estimated proxy |

**Proxy Construction**:
- **License count**: 8,000+ licenses installed; 5,000+ active clients (MRC website) — using 5,000 active clients
- **Pricing**: POS software in LATAM restaurant market estimated at USD 60–150/month/location; mix of legacy perpetual licenses + subscription + hardware; midpoint USD 100/month × 12 = USD 1,200/client/yr
- **Total ARR estimate**: 5,000 × USD 1,200 = USD 6.0M ARR (high case); 5,000 × USD 800 = USD 4.0M (low case); **midpoint USD 5.0M**
- **Hardware/distribution margin**: add ~20% for hardware bundling and distribution margin → USD 5.0M × 1.2 = ~USD 6.0M total annual revenue
- **ARS inflation caution**: Argentine clients likely pay in ARS; USD-equivalent revenue collapsed in 2018–2019 (Macri crisis) and 2023 (Milei transition/hyperinflation). International clients (CL, CO, PY) probably pay USD or USD-pegged rates — these may now be the more stable revenue streams.

**Revenue CAGR (3yr, USD-real)**: ~+5–8% (2023→2026) — low; inflation distortion masks nominal AR$ growth
**Revenue CAGR (5yr, USD-real)**: ~+5% (2021→2026) — modest

#### Revenue Trend Chart (USD, estimated)

```mermaid
xychart-beta
    title "MRC Software Revenue Trend (USD M, estimated proxy)"
    x-axis [2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "USD Millions" 0 --> 8
    line [3.5, 4.5, 4.0, 5.0, 5.5, 6.0]
```

*2023 dip reflects ARS hyperinflation USD-real compression. All values estimated proxy — wide confidence band (±40%).*

---

### Profitability

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| EBITDA | Unknown | No source | Unknown |
| EBITDA Margin | Estimated 15–30% (mature software business; low capex; distribution model reduces sales cost) | Industry benchmark | Estimated proxy |
| Net Profit / Loss | Unknown — likely profitable (37yr survival without external funding) | No source | Unknown |
| Recurring Revenue % | Estimated 40–60% (mix of perpetual licenses + annual maintenance + subscription; transition to full SaaS incomplete) | Product architecture; InfoGastronómica | Estimated proxy |
| SaaS Revenue % | Estimated <30% (cloud option available but not cloud-native; legacy perpetual license base) | Product architecture | Estimated proxy |
| Revenue per Employee | Unknown headcount; if 50 employees: USD 6M ÷ 50 = USD 120K/employee (high for LATAM SaaS → suggests lean team) | Proxy | Estimated proxy |

---

### Funding & Investment History

| Date | Round | Amount (USD) | Lead Investor(s) | Capital Source Type | Valuation (USD) | Source | Confidence |
|---|---|---|---|---|---|---|---|
| 1989 | Bootstrap / Founder | Unknown | Unknown founder(s) | Founder / Family | N/A | MRC website | Estimated |

**Total Raised**: No external funding identified in 37 years — fully bootstrapped
**Latest Valuation**: Not applicable; estimated valuation: USD 15–30M (3–5× ARR of USD 6M → USD 18–30M high; Argentine market discount + hybrid architecture discount → realistic USD 12–18M)
**Current Investors**: Unknown founder(s) / family
**War Chest Signals**: None identified; 37yr bootstrapped operation suggests conservative cash management; no PE or VC dry powder

---

### Employee Timeline

| Year | LATAM Total (est.) | AR (est.) | CL + CO (est.) | Distributors (contractors) | YoY Growth | Source | Confidence |
|---|---|---|---|---|---|---|---|
| 2026 (current) | ~50–100 est. | ~35–70 | ~15–30 | 100+ (independent) | Unknown | Proxy from company scale | Estimated proxy |
| 2022 | ~40–80 est. | ~30–60 | ~10–20 | ~80+ | Unknown | Extrapolation | Estimated proxy |

**Employee CAGR**: Unknown — no reliable multi-year data
**Current Open Positions**: Not identified on Bumeran (AR), Computrabajo, or LinkedIn Jobs
**Hiring Hotspots**: Córdoba (primary); Santiago de Chile; Bogotá
**Recent Layoff / Restructuring**: None identified; Argentine macroeconomic volatility makes layoffs plausible but unconfirmed

#### Employee Growth Chart

*Insufficient data — fewer than 2 reliable data points; chart omitted.*

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
|---|---|---|---|---|---|
| 1989 | Founded | AR (Córdoba) | Argentine restaurant market | MRC website | Confirmed |
| ~2000s | Distributor network | AR (national) | Buenos Aires office + nationwide AR distributors | MRC website | Confirmed |
| ~2006 | Paraguay distribution | PY | Carlos V. Roldán as PY distributor | Infonegocios PY | Confirmed |
| ~2010 | Multi-country distributors | BO, EC, MX, PE, UY, VE | 100+ resellers across LATAM | MRC website | Confirmed |
| ~2013 | Chile entity | CL (Santiago) | MRC Software SpA incorporated | chilepymes.com | Confirmed |
| ~2015 | Colombia office | CO (Bogotá) | Own office; direct sales | MRC website | Confirmed |

**Primary Market**: Argentina (home market; largest revenue base)
**International Revenue %**: Estimated 20–35% (CL + CO direct + PY + distributor royalties from 8 countries)
**Country Footprint Strategy**: Pan-LATAM via hybrid model — own offices in AR/CL/CO; distributor network in BO/EC/MX/PY/PE/UY/VE
**Expansion Trajectory**: Stable at current footprint; no new country entries identified in last 3yr; focus on deepening existing markets

---

### M&A Activity

No M&A activity identified.

**M&A Pattern**: Zero M&A in 37 years — purely organic; conservative family-funded build. No indication of acquisition ambitions.

---

### Digitalization / SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Deployment Model | Hybrid — on-premise core with optional cloud/online components | InfoGastronómica; MRC website | Confirmed |
| Cloud Revenue % | Estimated <30% (cloud is add-on; not cloud-native) | Product architecture | Estimated proxy |
| Recurring Revenue % | Estimated 40–60% (mix of perpetual + annual maintenance + subscription) | Product architecture | Estimated proxy |
| Database | Microsoft SQL Server (since 2008) — modern for its era; not cloud-native | InfoGastronómica | Confirmed |
| Multi-location Centralization | Yes — since 2003; manages chains with 100+ locations | InfoGastronómica | Confirmed |
| Real-time Central Reporting | Yes — since 2008 SQL Server migration | InfoGastronómica | Confirmed |
| Customer-Facing App | Unknown — no mobile app mentioned in public sources | No source | Unknown |
| ERP Integration | Yes — generates interfaces with external ERP systems | InfoGastronómica | Confirmed |
| Payment Integrations | Bancard PY (via PY distributor); Mercado Pago AR likely; others unconfirmed | No source | Unknown |
| Delivery Integrations | Not mentioned in any source — unlikely to be native | No source | Unknown |
| API Availability | No developer portal identified | No source | Unknown |
| Migration Status | In-progress (partial cloud capabilities); no confirmed full SaaS migration timeline | MRC website | Estimated |

**Digitalization Maturity Assessment**: Medium — SQL Server backbone is solid; multi-location centralization is proven; but architecture is fundamentally on-prem with cloud optionality bolted on. Cloud-native competitors (Toast, Restroworks, Lightspeed, E-karú) are now architecturally superior. MRC's moat is 37 years of LATAM market relationships and deep restaurant-specific features — not its technology stack.

---

### Public-Sector Revenue & Tender Activity

Not applicable — private restaurant + retail clients only.

**Estimated Public-Sector Revenue %**: ~0%
**Lava Jato / Corruption Investigation Exposure**: None identified

---

### Growth Scorecard

| Dimension | Score (1-10) | Evidence Summary |
|---|---|---|
| Revenue Growth (USD-real) | **3** | Estimated USD 3.5M→6.0M (2021→2026) = ~11% USD CAGR; modest; ARS inflation distortion masks nominal AR$ growth; international diversification partially mitigates |
| Funding Momentum | **1** | No external funding in 37 years; fully bootstrapped; no PE/VC signals |
| Employee Growth | **2** | No data; estimated stable small team; no hiring announcements; likely flat |
| Geographic Expansion | **4** | 10 countries represented; 4 own offices; but no new countries in last 3yr; footprint is broad but mature |
| M&A Activity | **1** | No M&A in 37 years; zero acquisition history |
| Digitalization Maturity | **4** | Hybrid on-prem + cloud; SQL Server since 2008; multi-location since 2003; cloud is bolt-on not native; modernization incomplete; no delivery or mobile-first features identified |
| Public-Sector Position | **1** | No public sector; private restaurant + retail clients only |
| **COMPOSITE SCORE** | **2.3** | **Dinosaur** — long-established, stable, profitable operator but investing minimally in growth, technology transformation, or geographic expansion |

**Classification**: **Dinosaur** (avg 2.3) — conservative, self-sustaining, but not transforming

**Nuance for SolStein**: MRC is a "sustainable dinosaur" — it will likely continue operating profitably for many years without transforming. The risk for SolStein is not that MRC will disrupt; it is that MRC's PY distributor (Roldán) occupies the channel and creates inertia among PY restaurant clients already using Mr. Comanda. The competitive strategy is not to partner with or acquire MRC, but to displace it in PY through the E-karú/Innovasys acquisition route (cloud-native product, PY-first brand) and then outcompete MRC's hybrid model on modernity and local support quality.

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "MRC Software Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "Digital", "Public-Sector"]
    y-axis "Score" 0 --> 10
    bar [3, 1, 2, 4, 1, 4, 1]
```
