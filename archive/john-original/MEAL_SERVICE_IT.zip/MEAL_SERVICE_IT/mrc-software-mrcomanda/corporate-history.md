# Corporate History — MRC Software / Mr. Comanda

**Research Date**: 2026-05-04
**Genealogy Confidence**: Low-Medium (Argentine private company; CUIT/AFIP data limited; primary sources are company website + trade press)
**Country of Domicile**: Argentina (Córdoba)
**Family-Conglomerate Parent**: None identified — appears founder-owned / SME

---

### Current Ownership & Key Parties

| Stakeholder | Role | Stake % | Type | Since | Source |
|---|---|---|---|---|---|
| Unknown founder(s) | Owner(s) | Unknown | Founder / Family (probable) | 1989 | [MRC website](https://mrcomanda.com/nosotros/); [InfoGastronómica AR](https://www.infogastronomica.com.ar/conociendo-los-proveedores-del-sector-el-quienes-somos-de-mrc-software-restaurante/) |
| Carlos V. Roldán | PY Country Representative | — | Distributor / Country partner | ~2006 | [Infonegocios PY](https://infonegocios.com.py/default/mr-comanda-la-aplicacion-para-empresas-gastronomicas-y-de-retail) |

*Note*: MRC Software's ownership structure is not publicly disclosed. The company has been operating since 1989 with no external funding rounds identified — strongly suggests founder/family ownership, potentially first or second generation. Specific founder names are not available from public sources.

**Corporate Structure** (Mermaid):

```mermaid
graph TD
    Founders["Unknown Founder(s)<br/>Córdoba, Argentina (1989)"]
    MRC["MRC Software SRL / MRC Argentina SRL<br/>Córdoba + Buenos Aires — Argentina"]
    ChileSPA["MRC Software SpA<br/>Santiago de Chile — Chile (est. ~2010)"]
    Colombia["MRC Colombia Office<br/>Bogotá, Colombia"]
    Distributors["100+ Distributors<br/>AR, BO, EC, MX, PY, PE, UY, VE"]
    Founders --> MRC
    MRC --> ChileSPA
    MRC --> Colombia
    MRC --> Distributors
```

---

### Origin Story

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founded | 1989 | [MRC website](https://mrcomanda.com/nosotros/) | Confirmed |
| Original Name | Unknown — possibly "MRC" or "Comanda" from inception; "Mr. Comanda" is the product brand | MRC website | Unknown |
| Founders | Unknown — not disclosed in any public source | No source | Unknown |
| City / Country of Founding | Córdoba, Argentina | MRC website; InfoGastronómica | Confirmed |
| Original Mission | Software for the Argentine gastronomic sector (restaurants, cafes, bars) | InfoGastronómica AR | Confirmed |
| Original Product | Mr. Comanda — POS system for restaurant order management and billing | InfoGastronómica AR | Confirmed |
| First Sub-Vertical | Restaurant / gastronomy (Argentina) | MRC website | Confirmed |
| Early Technology | Unknown — likely Delphi / FoxPro / Visual Basic (standard Argentine desktop software stack of the 1990s) | No source | Unknown |

---

### Corporate Identity Changes

| # | Date | From | To | Reason | Source |
|---|---|---|---|---|---|
| 1 | 2008 | Proprietary DB engine | Microsoft SQL Server | Technology modernization; real-time multi-location data sync | MRC website; InfoGastronómica |
| 2 | ~2013 | MRC Software (AR-only) | MRC Software SpA (Chile) | Geographic expansion; local legal entity for Chilean market | chilepymes.com (SpA registered 2013) |

*No full corporate name changes identified — "MRC Software" and "Mr. Comanda" have been consistent brand identities since at least the early 1990s.*

---

### Mergers & Acquisitions Timeline

#### Acquisitions Made (as buyer)

No acquisitions identified.

#### Acquired By (as target)

No acquisition of MRC Software identified. Appears to remain fully independent.

#### Joint Ventures & Strategic Partnerships

| Date | Partner | Type | Country | Outcome | Source |
|---|---|---|---|---|---|
| ~2006 (est.) | Carlos V. Roldán (PY) | Exclusive distribution agreement | PY | Active — Roldán distributes Mr. Comanda in Paraguay | Infonegocios PY |
| ~2013 | Local partners (CL) | SpA incorporation; distribution | CL | MRC Software SpA — own legal entity in Chile | chilepymes.com |
| ~2015 (est.) | Local partner (CO) | Office / distribution | CO | Bogotá office established | MRC website |
| Ongoing | 100+ hardware/distributor partners | Reseller / VAR network | AR, BO, EC, MX, PY, PE, UY, VE | Active multi-country distribution channel | InfoGastronómica |

---

### Investment & Financial Events

| Date | Event Type | Details | Investors / Counterparty | Investor Type | Amount | Source |
|---|---|---|---|---|---|---|
| 1989 | Company founding | MRC Software founded in Córdoba, AR | Unknown founder(s) | Founder / Bootstrap | Unknown | MRC website |
| 2003 | Product milestone | Added multi-location centralization for chain customers | Internal R&D | Internal | Unknown | InfoGastronómica |
| 2008 | Tech migration | Full migration to Microsoft SQL Server for all products | Internal R&D | Internal | Unknown | InfoGastronómica |
| ~2013 | Geographic expansion | Incorporated MRC Software SpA in Chile | Internal | Internal | Unknown | chilepymes.com |
| ~2015 | Geographic expansion | Opened Bogotá, Colombia office | Internal | Internal | Unknown | MRC website |

*No external funding rounds found on Crunchbase, LAVCA, Dealroom, or Argentine trade press. Fully bootstrapped over 37 years.*

---

### Splits, Spin-offs & Divestitures

No splits or divestitures identified.

*MRC Software SpA (Chile) and the Colombian office are local incorporations of the parent, not spin-offs.*

---

### Critical Events & Milestones

| Date | Event | Impact | Source |
|---|---|---|---|
| 1989 | MRC Software founded in Córdoba; develops first restaurant POS (Mr. Comanda) | Founding event; establishes 35+ year product identity | MRC website |
| ~1990s | Argentine restaurant sector growth; Mr. Comanda gains AR market share | Core market built during Argentine economic growth period | InfoGastronómica |
| 2001 | Argentine economic crisis (corralito) | Restaurant sector contracts sharply; likely survival test for MRC; many competitors exited | Historical context |
| 2003 | Multi-location centralization feature added | Strategic expansion to chain customers; enables franchise/chain revenue | InfoGastronómica |
| 2008 | Full SQL Server migration; real-time central reporting | Technology modernization; competitive differentiation at the time | InfoGastronómica |
| ~2006 | Paraguay distribution begins via Carlos V. Roldán | First international market penetration | Infonegocios PY |
| ~2010 | Expansion to Bolivia, Ecuador, Mexico, Peru, Uruguay, Venezuela via distributors | Regional scale-out through asset-light distribution model | MRC website |
| ~2013 | Chile office (MRC Software SpA) incorporated | First own legal entity outside Argentina | chilepymes.com |
| ~2015 | Colombia office (Bogotá) opened | Direct presence in Pacific Alliance market | MRC website |
| 2018 | Argentine economic crisis (IMF + ARS devaluation) | Revenue in USD likely fell dramatically in 2018–2019; existing ARS-priced contracts worth less in USD | Historical context |
| 2020–2021 | COVID-19: restaurant closures across LATAM | Primary market severely affected; survival pressure; possible acceleration toward SaaS/cloud pricing | Industry context |
| 2026 | Current: 5,000+ clients, 8,000+ licenses, 4 own offices, 100+ distributors | Established LATAM restaurant tech player; legacy architecture increasingly challenged by cloud-native competitors (Restroworks, E-karú, Toast, etc.) | MRC website |

---

### Public-Sector Tender History

Not applicable — tech-vendor (restaurant POS software). No public sector tender participation identified.

---

### Corporate Timeline (Visual)

```mermaid
timeline
    title MRC Software / Mr. Comanda — Corporate History
    section Founding & Argentina Era (1989–2000)
        1989 : Founded in Córdoba, Argentina
               : Develops Mr. Comanda restaurant POS
               : Builds Argentine client base through 1990s
        2001 : Argentine corralito crisis
               : Restaurant sector contracts; company survives
    section Modernization & Regional Expansion (2003–2015)
        2003 : Adds multi-location centralization feature
               : Enables chain/franchise client segment
        2008 : Full migration to Microsoft SQL Server
               : Real-time multi-location reporting
        ~2006 : Paraguay distribution begins (Roldán)
        ~2010 : Distributor network expands: BO, EC, MX, PE, UY, VE
        ~2013 : MRC Software SpA incorporated in Chile
        ~2015 : Bogotá, Colombia office opened
    section Maturity & Challenge (2016–2026)
        2018 : Argentine macroeconomic crisis (ARS devaluation)
               : USD revenue compressed; challenges in home market
        2020–2021 : COVID-19: restaurant closures across LATAM
                  : Market contraction; possible SaaS/cloud pricing evolution
        2026 : 5,000+ clients, 8,000+ licenses, 4 own offices, 100+ distributors
               : Facing competitive pressure from cloud-native entrants
```

---

### M&A Genealogy (Visual)

No M&A genealogy — MRC Software built purely organically.

---

### Corporate Timeline (Text Summary)

```text
1989 — Founded in Córdoba, Argentina; creates Mr. Comanda restaurant POS
~1990s — Builds Argentine restaurant client base through 1990s economic growth
2001 — Survives Argentine corralito crisis; restaurant sector contracts
2003 — Adds multi-location centralization for chain/franchise customers
~2006 — Begins international expansion; Paraguay distribution via Carlos V. Roldán
2008 — Full Microsoft SQL Server migration; real-time central reporting across locations
~2010 — Asset-light international growth: distributors in BO, EC, MX, PE, UY, VE
~2013 — Incorporates MRC Software SpA in Chile (own legal entity)
~2015 — Opens Bogotá, Colombia office (own presence)
2018 — Argentine macroeconomic crisis; USD revenue squeezed
2020–2021 — COVID-19 impacts primary restaurant market across LATAM
2026 — 5,000+ clients, 8,000+ licenses, 100+ distributors; 4 country offices
       Legacy hybrid architecture (on-prem core + optional cloud) challenged by cloud-native competitors
```

---

### Pattern Analysis

**Ownership Type**: Founder/family — 37 years with no external funding; identity and ownership undisclosed but long tenure suggests family-controlled

**Decision Authority**: Córdoba HQ — Argentine founders or family; country managers (Chile/Colombia) have operational autonomy; PY via distributor (Roldán)

**Growth Strategy**: Organic + distribution network — asset-light international model using 100+ resellers/VARs to avoid direct cost; own offices only in highest-value markets (AR, CL, CO)

**Tech Evolution**: Started with 1989-era AR restaurant software → 2003 multi-location → 2008 SQL Server → current hybrid (on-prem + cloud-optional). Cloud-native competitors are now leapfrogging the architecture. No evidence of full cloud migration.

**Country Footprint Strategy**: Pan-LATAM via distributors (10 countries represented); own offices in 3 countries outside Argentina; hybrid direct + indirect model

**Public-Tender Dependence**: None — private restaurant + retail client base

---

### Customer / Partnership / Acquisition Feasibility Assessment from History

**Commercial Outreach Entry Point**:
- Primary: Carlos V. Roldán (PY distributor) — for PY market intelligence and indirect influence
- Secondary: MRC Software Córdoba HQ (unknown owner/CEO — names not publicly available)
- Caution: MRC decision-making center is Córdoba HQ, not PY; SolStein PY positioning cannot bypass the AR center

**Decision-Making Dynamics**:
- Founder/family-driven over 37 years — extremely conservative and slow; no external investor pressure
- Large distributor network = high switching costs and loyalty constraints if SolStein wants to acquire PY clients
- Argentine economic instability creates ongoing sensitivity around pricing and cash flow

**Feasibility Signals from History**:
- Signal 1: 37-year company with undisclosed founders — succession is an unknown but probable latent dynamic; founders may be 55–70+ years old
- Signal 2: No external investment in 37 years signals strong self-sufficiency but also organizational inertia
- Signal 3: Architecture increasingly legacy (hybrid on-prem); new entrants are cloud-native — competitive erosion pressure is building

**Feasibility Blockers from History**:
- Blocker 1: Ownership not publicly known — no entry point for M&A conversation without intermediary
- Blocker 2: PY operations via distributor (Roldán) — not direct Comepar/SolStein relationship; disrupting this requires working around the distribution contract
- Blocker 3: 100+ distributor network creates contractual complexity for any acquirer
- Blocker 4: Argentine legal and tax environment complicates cross-border acquisition

**Integration / Partnership Risk from History**:
- Risk 1: Hybrid architecture (on-prem + optional cloud) means migration effort for any SolStein integration
- Risk 2: 5,000 clients across 10 countries = massive support obligation; integration would require inheriting multi-country support structure
- Risk 3: Distribution network relationships would need renegotiation post-acquisition

**Trajectory Prediction**:
MRC Software is most likely to continue on its current trajectory: gradual erosion of market position in Argentina (economic instability + cloud-native competition) while maintaining strength in distributor-network countries. A strategic sale to a regional PE or technology consolidator within 5–10 years is plausible if founder(s) approach retirement age. SolStein's most realistic engagement: compete directly in PY via E-karú acquisition rather than attempting to acquire or partner with MRC; monitor MRC's PY distributor (Roldán) for potential channel partner conversion.
