# Deep Analysis — MRC Software / Mr. Comanda

**Research Date**: 2026-05-04
**Player Type**: Tech-vendor (POS and restaurant management software; Argentine origin; distributed in Paraguay via local partner)
**Confidence Level**: Medium (product details and geographic coverage well-documented; PY-specific financials unknown)
**Geographic Footprint**: Argentina, Chile, Colombia + distribution in 8+ LATAM countries including Paraguay
**Paraguay Presence**: Yes — active distribution via Carlos V. Roldán (since 2006); 8,000+ licenses regionally; PY operations through distributor

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Comanda Argentina S.A. | [mrcomanda.com/nosotros](https://mrcomanda.com/nosotros/) | Confirmed |
| CUIT (Argentina) | 30-70972182-4 | mrcomanda.com/nosotros | Confirmed |
| HQ Address (global) | Córdoba, Argentina (founded and headquartered) | [InfoGastronómica](https://www.infogastronomica.com.ar/conociendo-los-proveedores-del-sector-el-quienes-somos-de-mrc-software-restaurante/) | Confirmed |
| Additional own offices | Buenos Aires AR; Santiago de Chile CL; Bogotá CO | InfoGastronómica | Confirmed |
| PY Distribution Entity | Distribuidora MRC — Carlos V. Roldán (owner since March 2006) | [LinkedIn: Carlos V. Roldán](https://linkedin.com/in/carlos-v-roldan-a8541735) | Confirmed |
| Founded | 1989 (Córdoba, Argentina) — 36+ years | InfoGastronómica | Confirmed |
| CEO / LATAM | Jorge Prieto (CEO MRC Software LA) | [Infonegocios PY](https://infonegocios.com.py/plus/mr-comanda-la-aplicacion-para-empresas-gastronomicas-y-de-retail) | Confirmed |
| Ownership | Private — Comanda Argentina S.A.; no PE/VC investment identified | mrcomanda.com/nosotros | Estimated |
| Investor Type | None identified — self-funded | No source | Unknown |
| Employees — LATAM | Unknown; implied small-to-medium team (100+ distributors/partners managed) | No source | Unknown |
| Employees — PY | Unknown; distributor model means PY headcount is at Distribuidora MRC level | No source | Unknown |
| Revenue — LATAM | Unknown; 5,000+ clients across LATAM (estimated ARR: see Valuation) | InfoGastronómica | Estimated |
| Revenue — PY | Unknown; portion of LATAM total via distributor | No source | Unknown |
| Profitability | Unknown; 36 years in operation and no VC suggests sustained profitability | No source | Estimated |
| Last Funding Round | None identified | No source | Unknown |

---

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Tech-vendor — POS + restaurant management SaaS/software; no physical food operations | mrcomanda.com | Confirmed |
| Sub-Verticals Served | Restaurants; fast food; delivery; bakeries; ice cream shops; mini-shops; retail; kiosks; casinos | [mrcomanda.com/mercados](https://mrcomanda.com/mercados/) | Confirmed |
| Countries Active (own offices) | Argentina, Chile, Colombia | InfoGastronómica | Confirmed |
| Countries Active (distribution) | Bolivia, Ecuador, Mexico, Paraguay, Peru, Uruguay, Venezuela | InfoGastronómica | Confirmed |
| Total Licenses Installed | 8,000+ licenses | mrcomanda.com/nosotros | Confirmed |
| Total Clients | 5,000+ clients operating applications across LATAM | InfoGastronómica | Confirmed |
| Distribution Partners | 100+ distributors and hardware partners across LATAM | InfoGastronómica | Confirmed |
| Notable PY Customers | Not published | No source | Unknown |
| Notable LATAM Customers | Not published | No source | Unknown |
| Government / Institutional Contracts | None identified | No source | Unknown |
| Market Share — PY | Unknown; shares PY market with E-karú, Cogent, and others | No source | Unknown |
| Market Share — LATAM | Niche regional player; not top-tier by international standards but respected LATAM restaurant POS vendor | Estimated | Estimated |
| Awards / Certifications | None identified | No source | Unknown |
| Sustainability Claims | None identified | No source | Unknown |

---

### Product / Service & Technology

#### Tech-vendor profile

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Product Portfolio | Mr. Comanda — 4-tier POS + restaurant management product (Free / Express / Professional / Corporate) | [Infonegocios PY](https://infonegocios.com.py/plus/mr-comanda-la-aplicacion-para-empresas-gastronomicas-y-de-retail) | Confirmed |
| MRC Free | Basic POS; no-cost; for small single-location operations | Infonegocios PY | Confirmed |
| MRC Express | Adds management reports; multi-terminal; inventory management | Infonegocios PY | Confirmed |
| MRC Professional | Full management suite for 1–several large locations | Infonegocios PY | Confirmed |
| MRC Corporate | Centralized management for 10+ locations; chain operations | Infonegocios PY | Confirmed |
| Core Feature Set | POS (order entry, tables, pre-accounts, bill splitting); inventory + purchasing; QR menu; mobile waiter app; e-invoicing; multiple payment methods; offline mode; real-time reporting; ERP integration; up to 100+ location chain management | [mrcomanda.com/mercados](https://mrcomanda.com/mercados/) | Confirmed |
| Mobile App | iOS + Android (explicitly stated); mobile order-taking for waitstaff | mrcomanda.com/mercados | Confirmed |
| Offline Capability | Yes — explicitly stated; system operates without internet connection | mrcomanda.com/mercados | Confirmed |
| Deployment Model | Client-server with cloud reporting (hybrid); offline-capable local mode | mrcomanda.com/mercados; mrc307.com | Estimated |
| Tech Stack | Legacy-origin (1989 codebase) with modern mobile app layer; likely hybrid Windows server + mobile front-end | Job posting analysis; mrc307.com (older domain) | Estimated |
| API Strategy | Unknown — no developer docs found; ERP integration mentioned as capability | mrcomanda.com/mercados | Estimated |
| Key Integrations — Payments | Electronic payment integration (stated); Bancard (PY) implied by PY deployment | mrcomanda.com/mercados | Estimated |
| Key Integrations — E-invoicing | Electronic invoicing module present; AFIP (AR) compliance implied; PY e-Kuatia compliance: not confirmed but required for PY market | mrcomanda.com/mercados | Estimated |
| Key Integrations — Delivery | Not confirmed; no iFood/Rappi/PedidosYa/Monchis integration explicitly mentioned | No source | Unknown |
| Payment Options in Product | Multiple payment methods per transaction; split bills; card + cash | mrcomanda.com/mercados | Confirmed |
| Languages Supported | Spanish (LATAM) | All sources | Confirmed |
| Portuguese | Not mentioned — no BR presence | No source | Unknown |
| Tech Modernity Signal | Hybrid: mobile-first on front-end, legacy server architecture on back-end; offline capability = strength for PY connectivity environments; no cloud-native SaaS signal | mrcomanda.com; mrc307.com | Estimated |

---

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Likely — private Argentine company since 1989; no PE investor identified | InfoGastronómica | Estimated |
| PE or VC Backed | No — no external investment identified | No source | Estimated |
| Government-Related Shareholders | None identified | No source | Unknown |
| Founder Still Active | Unknown — founder identity not published; Jorge Prieto is current CEO-LA | No source | Unknown |
| Succession Signal | None identified | No source | Unknown |
| PE Exit Horizon | N/A | — | — |
| Family-Owned Dynamics | Unknown — Argentine private company, typical family-owned structure possible | No source | Unknown |
| Group Structure | Standalone; PY presence via distributor (Distribuidora MRC / Carlos V. Roldán) — not owned subsidiary | LinkedIn; mrcomanda.com | Confirmed |

---

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Unknown | No source | Unknown |
| Employee Growth YoY | Unknown | No source | Unknown |
| Geographic Expansion (3yr) | Added Colombia (own office) — previously AR/CL only; now also CO | InfoGastronómica | Estimated |
| Service Launches (2yr) | No major new product identified; ongoing version updates | No source | Unknown |
| Acquisitions (3yr) | None identified | No source | Unknown |
| Funding Rounds (3yr) | None | No source | Unknown |
| Currency Exposure | Multi-currency: ARS (AR), PYG (PY distributor), CLP (CL), COP (CO); USD for international invoicing | mrcomanda.com AreaClientes (USD payment link) | Confirmed |
| Argentine Inflation Impact | Company is AR-headquartered — ARS revenue subject to high inflation distortion; USD pricing used for international clients | mrcomanda.com (USD PayPal link) | Confirmed |
| Customer Count Growth | 5,000+ clients / 8,000+ licenses — no historical baseline to calculate growth rate | InfoGastronómica | Estimated |
| Tender Win Rate | N/A — private sector only | — | — |

---

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Restaurants (sit-down + delivery); fast food chains; hospitality-adjacent retail | mrcomanda.com/mercados | Confirmed |
| Vertical Breadth | Broad within HORECA-retail: restaurants, bakeries, ice cream, casinos, kiosks, retail | mrcomanda.com/mercados | Confirmed |
| Food Safety Compliance | No HACCP / INAN / food-safety module identified — POS/ERP focus only | No source | Unknown |
| Fiscal e-Invoicing | Electronic invoicing module present; AFIP (AR) compliance stated; PY e-Kuatia: not confirmed but distributors must handle compliance | mrcomanda.com/mercados | Estimated |
| Allergen / Dietary | Not mentioned | No source | Unknown |
| Voucher / Benefit Integrations | Not identified | No source | Unknown |
| Payment Integrations | Multiple payment methods stated; electronic payments integrated; Bancard PY implied | mrcomanda.com/mercados | Estimated |
| Delivery Integrations | Not confirmed | No source | Unknown |
| Languages Localized | Spanish (LATAM); no Portuguese | All sources | Confirmed |

---

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | 4-tier SaaS/license model: Free (no cost) → Corporate (high-end); USD pricing for international clients | Infonegocios PY; mrcomanda.com | Confirmed |
| Price Range | Not published — contact-based; USD payment option exists (PayPal); typical LATAM restaurant SaaS = USD 50–200/month | mrcomanda.com AreaClientes | Estimated |
| Recurring vs Project | High recurring — annual/monthly software license model | mrcomanda.com | Estimated |
| Estimated ARR (LATAM) | 5,000 clients × estimated avg USD 80/month = USD 4.8M ARR (wide confidence band) | LATAM SaaS benchmark proxy | Estimated proxy |
| Comparable M&A | Goomer (BR restaurant SaaS) raised $2.83M at similar scale; LATAM restaurant SaaS trades at 3–6× ARR | Tracxn (Goomer) | Estimated proxy |
| Estimated Acquisition Value | USD 10–25M (if 3–5× estimated ARR; discount for hybrid-legacy architecture and distributor model) | Proxy | Estimated proxy |
| Implementation Timeline | Fast — software license model; minimal deployment friction | mrcomanda.com | Estimated |
| Services vs Product Split | ~85% product (license + SaaS); ~15% services (support, customization, training) | mrcomanda.com | Estimated |

---

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | Multi-currency; USD used for international billing; ARS for domestic AR market | mrcomanda.com AreaClientes | Confirmed |
| Cross-Border PY-AR-BR-UY | AR-based with PY distributor; typical Mercosur software distribution model | LinkedIn; mrcomanda.com | Confirmed |
| Itaipú / Yacyretá Exposure | None | No source | Unknown |
| Public-Sector Dependence | None — purely private sector | All sources | Confirmed |
| Mining / Agri Camp Exposure | None — restaurant/HORECA focus | All sources | Confirmed |
| US / European Strategic Parent | None — Argentine private company | All sources | Confirmed |
| Family Conglomerate Parent | None identified | No source | Unknown |
| ESG / Sustainability | None | No source | Unknown |
| Local Content / Nationalization | Distributes via local PY partner (Carlos V. Roldán) — standard LATAM channel strategy | LinkedIn | Confirmed |
| Argentine HQ Risk | ARS inflation erodes domestic revenue; USD international pricing used as hedge; political volatility risk for AR-HQ companies | mrcomanda.com | Confirmed |

---

### Landscape Relevance Scorecard

**Scoring**: 1 (low relevance) → 5 (high relevance for SolStein landscape map)

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **3** | Active PY distribution via Distribuidora MRC since 2006 and stated PY market presence; not own office — distributor model limits direct PY intelligence | LinkedIn; mrcomanda.com |
| LATAM regional reach | Medium | Both | **4** | 4 own-office countries (AR, CL, CO + HQ); 8+ distribution countries including Bolivia, Mexico, Peru — strong LATAM reach | InfoGastronómica |
| Competitive overlap with SolStein | High | Competition | **4** | Direct product overlap: POS + restaurant management + inventory + HR + e-invoicing; serves the same foodservice operators SolStein targets; 36 years + 8,000+ licenses = entrenched | mrcomanda.com/mercados |
| Customer-fit potential | High | Customer | **1** | Competitor, not customer; would not purchase a competing platform | Classification |
| Scale | Medium | Both | **3** | Estimated ARR USD 4–5M; 5,000+ clients; 8,000+ licenses; significant regional player but not large-cap | Estimated proxy |
| Tech modernity / digitization | Medium | Both | **3** | Mobile apps (iOS/Android) and offline mode are positives; but 1989 AR codebase, hybrid client-server, no confirmed cloud-native or API-first architecture | mrcomanda.com; mrc307.com |
| Acquisition / partnership feasibility | Low | Strategic | **3** | Private AR company; no PE; likely founder/management-owned; possible acquisition by SolStein or by larger player to consolidate LATAM; AR HQ creates complexity | InfoGastronómica |
| Growth trajectory | Low | Both | **2** | Stable but slow-growing; added CO office; no new major product; 36-year-old company with steady but not high-growth profile; ARS inflation headwind | All sources |

**Competition Composite** (Competitive overlap ×2, PY ×1, Scale ×1, Tech ×1): (4×2 + 3 + 3 + 3) / 6 = **3.5 / 5.0**

**Customer Composite** (Customer-fit ×2, PY ×1, Tech ×1, Growth ×1): (1×2 + 3 + 3 + 2) / 6 = **1.7 / 5.0**

**Overall Landscape Composite**: (3×2 + 4×1.5 + 4×2 + 1×2 + 3×1.5 + 3×1.5 + 3×1 + 2×1) / 13.5 ≈ **2.8 / 5.0**

**Confidence Band**: Medium (~40% Confirmed, ~45% Estimated, ~15% Unknown — LATAM geographic/product data confirmed; PY-specific and financial data estimated)

**Overall Landscape Assessment**:
MRC Software / Mr. Comanda is SolStein's most established LATAM competitor in foodservice POS and management software: 36 years in operation, 5,000+ clients across 10+ countries, and an active PY presence via a distributor since 2006. Its 4-tier pricing model (including a free entry tier) and offline capability make it highly competitive in markets like Paraguay with connectivity constraints. From a competition lens it is the primary benchmark — direct product-to-product comparison is warranted. As a customer it is not a fit. As an acquisition or partnership target, the AR-headquarters creates complexity (ARS inflation, regulatory friction) and the distributor model in PY limits depth, but a consolidation scenario (SolStein acquiring PY distribution rights or the whole company) could fast-track PY market penetration. The core risk for SolStein is MRC's entrenched installed base and long market history; the core opportunity is MRC's aging architecture (1989 codebase, hybrid deployment) versus SolStein's potential for a more modern cloud-native offering.

**Recommended Next Step**: **Approach as competitor** — structured win-loss analysis in PY and LATAM-wide; benchmark all product features against SolStein roadmap; identify PY customers where SolStein can displace MRC by leading with cloud-native, HACCP, or institutional-feeding capabilities not in MRC's portfolio.

**Primary Tier**: **Tier 2** (Overall Composite 2.8; Competition Composite 3.5 — high competition relevance, watch-list priority)
