# Deep Analysis — Espy's Catering

**Research Date**: 2026-05-04
**Player Type**: Operator (events catering — US-based Bolivian company; NOT a Paraguay entity)
**Confidence Level**: High for disqualification (US-based origin confirmed; no PY operations found)
**Geographic Footprint**: United States (founded 2017 in the US by Bolivian entrepreneurs)
**Paraguay Presence**: No — no evidence of Paraguay operations

---

### ⚠️ CLASSIFICATION CORRECTION

**This company was incorrectly catalogued as a PY-native Tier 1 candidate.**

Research confirms:
- **Espy's Catering** was founded in 2017 **in the United States** by Esperanza Copa and Wilson Murillo, both from Cochabamba, Bolivia.
- The company operates in the US market (weddings, social events, corporate events).
- No Paraguay address, DNCP registration, SET RUC, PY press coverage, or PY client base was found.
- The espyscatering.com domain does not reference any Paraguay operations.
- The 1,500+ clients and 250+ events are US-market figures.

**Action**: This entry should be **removed from the Tier 1 pipeline** or reclassified as "Misidentified — US entity, no PY connection."

---

### Company Fundamentals (for completeness)

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Espy's Catering (US entity, state unknown) | [espyscatering.com](https://espyscatering.com/) | Confirmed |
| HQ Location | United States | espyscatering.com | Confirmed |
| Founded | 2017, United States | espyscatering.com/sobre-nosotros | Confirmed |
| Founders | Esperanza Copa + Wilson Murillo (Bolivian nationals) | espyscatering.com | Confirmed |
| PY Connection | None identified | No source | Confirmed |
| DNCP Registration | None | DNCP | Confirmed |
| SET RUC (PY) | None | SET | Confirmed |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **1** | No PY operations; US-based | espyscatering.com |
| All other dimensions | — | — | **N/A** | Entity not relevant to LATAM meal-service landscape | — |

**Overall Landscape Composite**: **1.0** / 5.0
**Confidence Band**: Narrow (high confidence this is not a PY entity)

**Recommended Next Step**: **Remove from pipeline** — re-run discovery search for PY catering operators to find the company that was intended to be captured in this slot. The PY catering market likely has other small operators that triggered the initial identification; search "catering empresarial Paraguay" in DNCP and ARPY member list to find the correct entity.

**Primary Tier**: **Reclassify → Not applicable** (US entity with no PY connection)
