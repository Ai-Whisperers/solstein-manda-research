# Deep Analysis — MyM Alimentos Corporativos

**Research Date**: 2026-05-04
**Player Type**: Operator (B2B corporate catering + mining/construction camp feeding)
**Confidence Level**: Low (company website available; no DNCP registration confirmed; no financial data; PY vs Peru ambiguity)
**Geographic Footprint**: Paraguay (claimed); Peru operations also identified (alimentosyserviciosmym.com)
**Paraguay Presence**: Claimed — website mentions PY operations; no DNCP or SET registry confirmation found

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | M&M Alimentos Corporativos / MyM Alimentos y Servicios (exact legal name unconfirmed) | [alimentosyserviciosmym.com](https://alimentosyserviciosmym.com/) | Estimated |
| Tax ID / RUC | Unknown — no SET PY record identified | No source | Unknown |
| HQ Address | Unknown — website does not disclose address | No source | Unknown |
| Founded | Unknown | No source | Unknown |
| Founders | Unknown | No source | Unknown |
| Ownership | Unknown — likely founder/family | No source | Unknown |
| Employee Count | Not disclosed; professional team structure described (RRHH, QA, nutrition, security) | alimentosyserviciosmym.com | Estimated |
| Revenue | Unknown | No source | Unknown |
| Profitability | Unknown | No source | Unknown |
| Last Funding Round | None identified | No source | Unknown |

**⚠️ Classification Note**: The alimentosyserviciosmym.com website mentions Paraguay but also shows Peruvian corporate clients (Yobel SCM, Yobel P&G), which are Lima-based companies. There is a possibility this is a Peru-based operator with PY aspirations or marketing, rather than a genuine PY-native company. A separate entity "Good Service M&M" (goodservicemym.com) also exists with similar positioning. No DNCP registration or PY press coverage found. SolStein should verify PY presence before engaging.

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — B2B corporate catering + mining/construction camp | alimentosyserviciosmym.com | Confirmed |
| Sub-Verticals Served | Corporate (companies, embassies), mining/construction camps, schools/institutes/universities, clinics/hospitals | alimentosyserviciosmym.com | Confirmed |
| Countries Active | Paraguay (claimed); Peru (Yobel clients identified) | alimentosyserviciosmym.com | Estimated |
| Service Hours | 24/7, 365 days | alimentosyserviciosmym.com | Confirmed |
| Notable PY Customers | Not named | No source | Unknown |
| Government / Institutional | No DNCP contracts identified | No source | Unknown |
| Market Share — PY | Unknown — no public data | No source | Unknown |
| Awards / Certifications | Not stated | No source | Unknown |
| Sustainability | Not mentioned | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Corporate catering (desayunos, almuerzos, cenas), concesionario de alimentos (24/7), mining/construction camp feeding | alimentosyserviciosmym.com | Confirmed |
| Menu Philosophy | Criolla e international; personalized menus; nutritional supervision | alimentosyserviciosmym.com | Confirmed |
| Nutritionist Supervision | Yes — nutritionists supervise all menus for dietary balance | alimentosyserviciosmym.com | Confirmed |
| Cold-Chain & Logistics | Unknown; 24/7 operations implies logistics capability | No source | Unknown |
| Internal Tech Stack | Unknown | No source | Unknown |
| End-Customer App / Portal | None identified | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Unknown | No source | Unknown |
| PE or VC Backed | No | No source | Estimated |
| Government-Related | No | No source | Estimated |
| Founder Still Active | Unknown | No source | Unknown |
| Group Structure | Unknown — possible separate legal entities across PY/PE | No source | Unknown |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Unknown | No source | Unknown |
| Geographic Expansion | Unknown; possibly PY + Peru dual presence | No source | Unknown |
| Acquisitions | None identified | No source | Unknown |
| Currency Exposure | PYG and/or PEN (Peruvian sol) | No source | Unknown |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Corporate catering + camp feeding | alimentosyserviciosmym.com | Confirmed |
| Food Safety | Nutritionist supervision mentioned; formal certification unknown | alimentosyserviciosmym.com | Estimated |
| Fiscal e-Invoicing | Unknown | No source | Unknown |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Per-headcount / per-meal corporate; cost-plus camp contracts | alimentosyserviciosmym.com | Estimated |
| Estimated Revenue | Unknown — insufficient data | No source | Unknown |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| PY vs Peru Ambiguity | Website serves both PY and PE market — genuine PY operations not independently confirmed | alimentosyserviciosmym.com | Estimated |
| Mining / Camp Exposure | Yes — explicitly targets campamentos mineros y constructoras | alimentosyserviciosmym.com | Confirmed |
| Public-Sector Dependence | Unknown; likely private-sector focused | No source | Unknown |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **2** | PY presence claimed but unconfirmed; no DNCP, no SET registry, no PY press coverage | No confirmed source |
| LATAM regional reach | Medium | Both | **2** | Possible PY + PE dual presence; unconfirmed | alimentosyserviciosmym.com |
| Competitive overlap | High | Competition | **1** | Operator; no tech overlap | alimentosyserviciosmym.com |
| Customer-fit potential | High | Customer | **3** | Camp + corporate feeding = right profile; but unconfirmed PY scale limits scoring | alimentosyserviciosmym.com |
| Scale | Medium | Both | **1** | Scale unknown; insufficient evidence to score higher | No source |
| Tech modernity | Medium | Both | **1** | No digital tools identified | No source |
| Acquisition / partnership | Low | Strategic | **2** | Cannot assess without ownership/legal entity confirmation | No source |
| Growth trajectory | Low | Both | **1** | No growth data | No source |

**Competition Composite**: (1×2 + 2×1 + 1×1 + 1×1) / 5 = **1.2** / 5.0
**Customer Composite**: (3×2 + 2×1 + 1×1 + 1×1) / 5 = **2.0** / 5.0
**Overall Landscape Composite**: (2+2+1+3+1+1+2+1) / 8 = **1.6** / 5.0
**Confidence Band**: Wide (>80% Unknown — insufficient data)

**Overall Landscape Assessment**:
MyM Alimentos Corporativos presents significant data uncertainty — the PY presence is claimed on the website but not independently confirmed via DNCP, SET, or PY press. The mining/camp and corporate catering vertical positioning is relevant to SolStein's target customer profile, but without confirming the PY entity exists and operates at meaningful scale, no commercial action is warranted.

**Recommended Next Step**: **Verify PY entity first** — search SET PY registry for "MyM" or "M&M Alimentos"; check DNCP for any registered provider under that name. If confirmed active in PY, re-score as potential customer for institutional catering IT.

**Primary Tier**: **Tier 3** (Overall 1.6 — insufficient evidence; re-classify pending PY confirmation)
