# Deep Analysis — Masapan

**Research Date**: 2026-05-04
**Player Type**: Hybrid (bakery + rotisserie + catering + events; consumer-facing and B2B)
**Confidence Level**: Medium (Infonegocios PY article + company website confirmed; financials unknown)
**Geographic Footprint**: Paraguay (Asunción metropolitan area)
**Paraguay Presence**: Yes — founded and headquartered in Asunción

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Masapan (legal entity name not confirmed — likely SRL or SA) | [masapan.com.py](https://www.masapan.com.py/) | Estimated |
| Tax ID / RUC | Unknown | No source | Unknown |
| HQ Address | Eusebio Lillo 2782 esq. Coronel Cabrera, barrio Herrera, Asunción | [buscoinfo.com.py](https://www.buscoinfo.com.py/local/masapan-panaderia-y-confiteria/LOC706020001) | Confirmed |
| Founded | 4 May 1993 (31 years ago) | [Infonegocios PY](https://infonegocios.com.py/conosur/masapan-festeja-aniversario-con-nuevos-productos-y-una-app-para-ejecutivos) | Confirmed |
| Founders | Estela Villar (production) + son René Villar (finance, commercialization, brand) | Infonegocios PY | Confirmed |
| Ownership | Family-owned (Villar family) | Infonegocios PY | Confirmed |
| Employee Count — PY | Not specified; estimated 30–80 based on 10 daily events + 3 production areas | No direct source | Estimated proxy |
| Revenue — PY | Unknown; 10 events/day = significant catering revenue; bakery retail daily | No source | Unknown |
| Profitability | Unknown; consistent growth signal from Infonegocios | No source | Unknown |
| Last Funding Round | None identified — family-owned, self-funded | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Hybrid — Bakery/confectionery (B2C) + catering/events (B2B) + rotisserie | masapan.com.py | Confirmed |
| Sub-Verticals Served | Corporate events, social events, rotisserie/lunch, bakery retail | Infonegocios PY | Confirmed |
| Countries Active | Paraguay (Asunción metro) only | masapan.com.py | Confirmed |
| Event Volume | ~10 catering events/day | Infonegocios PY | Confirmed |
| Event Venue | Salón de eventos (180 pax capacity, 2nd floor) | Infonegocios PY | Confirmed |
| Notable PY Customers | Not named; "corporate and sporting events" | Infonegocios PY | Estimated |
| Government / Institutional | Unknown — no DNCP contracts identified | No source | Unknown |
| Market Share — PY | #3 top-of-mind in bakery/catering segment (Google ranking cited) | Infonegocios PY | Estimated |
| Awards / Certifications | None cited | No source | Unknown |
| Sustainability Claims | Own organic garden (huerta) in Emboscada; quality control on all products | Infonegocios PY | Confirmed |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Bakery (bread varieties), confectionery (masas dulces, cakes), rotisserie (minutas, buffet), catering (events, corporate, sports), heladería artesanal, cafetería, sandwichería | Infonegocios PY | Confirmed |
| Menu Philosophy | Quality-focused; own organic vegetables (huerta in Emboscada); artisanal positioning | Infonegocios PY | Confirmed |
| Cold-Chain & Logistics | Unknown — likely own vehicle for event deliveries | No source | Unknown |
| Internal Tech Stack | Has a **mobile app for executives** (launched around anniversary) — tech-forward signal for a PY SME | Infonegocios PY | Confirmed |
| End-Customer App | Yes — executive app launched (functionality unspecified); likely ordering + menu | Infonegocios PY | Confirmed |
| Meal-Voucher Card Integration | Unknown | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Yes — Villar family (Estela + René) | Infonegocios PY | Confirmed |
| PE or VC Backed | No | No source | Estimated |
| Government-Related Shareholders | No | No source | Estimated |
| Founder Still Active | Yes — René Villar handles finance/brand; Estela Villar handles production | Infonegocios PY | Confirmed |
| Succession Signal | René is the second generation — management transition already in progress | Infonegocios PY | Confirmed |
| PE Exit Horizon | N/A | — | — |
| Family-Owned Dynamics | Two-generation family business; mother (founder) + son (growth driver) | Infonegocios PY | Confirmed |
| Group Structure | Standalone — no parent or holding | No source | Estimated |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Consistent growth cited; new products launched at anniversary | Infonegocios PY | Estimated |
| Employee Growth YoY | Unknown | No source | Unknown |
| Geographic Expansion (3yr) | No expansion beyond Asunción metro | No source | Estimated |
| Service Launches (2yr) | New products + executive app launched at anniversary | Infonegocios PY | Confirmed |
| Acquisitions (3yr) | None | No source | Unknown |
| Funding Rounds (3yr) | None | No source | Unknown |
| Currency Exposure | PYG only | No source | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Bakery/confectionery (consumer) + catering events (B2B) | masapan.com.py | Confirmed |
| Vertical Breadth | 5 segments: bakery, confectionery, rotisserie, heladería, catering/events | Infonegocios PY | Confirmed |
| Food Safety Compliance | INAN compliance required — status unknown; own quality control system | Infonegocios PY | Estimated |
| Fiscal e-Invoicing | SET e-Kuatia required — assumed compliant as formal business | No specific source | Estimated |
| Allergen / Dietary | Unknown; breadth of products suggests some allergen awareness | No source | Unknown |
| Voucher / Benefit Integrations | Unknown | No source | Unknown |
| Payment Integrations | Standard PY (Bancard likely for retail); no specific integration data | No source | Unknown |
| Delivery Integrations | Unknown; 10 events/day implies delivery capability | No source | Unknown |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Retail per-item (bakery); per-event/per-pax (catering) | masapan.com.py | Estimated |
| Price Range | Catering: G. 80,000–200,000/pax for events; retail: standard PY bakery pricing | Proxy | Estimated proxy |
| Recurring vs Project | ~30% recurring (bakery walk-in + standing corporate accounts); ~70% event-based | Proxy | Estimated proxy |
| Estimated Revenue | USD 200K–600K/yr (10 events/day × avg G. 5M/event × 250 days + retail) | Proxy | Estimated proxy |
| Estimated Acquisition Value | USD 500K–2M (revenue multiple for small PY food SME) | Benchmark | Estimated proxy |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG only | No source | Estimated |
| Cross-Border | PY-only | No source | Confirmed |
| Itaipú / Yacyretá Exposure | None | No source | Unknown |
| Public-Sector Dependence | Low — primarily private corporate + social events | No source | Estimated |
| Mining / Agri Camp | None | No source | Unknown |
| US / European Parent | None | No source | Confirmed |
| Family Conglomerate | None | No source | Confirmed |
| ESG | Organic garden (huerta) — genuine sustainability commitment for PY SME | Infonegocios PY | Confirmed |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | PY-native, Asunción-based, 33yr operation | Infonegocios PY |
| LATAM regional reach | Medium | Both | **1** | Asunción-only; no LATAM footprint | masapan.com.py |
| Competitive overlap | High | Competition | **1** | Bakery + catering operator; zero tech overlap with SolStein | masapan.com.py |
| Customer-fit potential | High | Customer | **2** | Small scale (est. USD 200–600K revenue); event + bakery focus; limited institutional complexity; executive app shows tech appetite | Infonegocios PY |
| Scale | Medium | Both | **1** | Micro-player; single location + events arm | Infonegocios PY |
| Tech modernity | Medium | Both | **3** | Executive app launched = strong tech signal for a PY bakery SME; own app is unusual at this scale | Infonegocios PY |
| Acquisition / partnership feasibility | Low | Strategic | **3** | Family-owned, 2nd generation active, no PE, <USD 2M valuation — acquirable but small | Infonegocios PY |
| Growth trajectory | Low | Both | **3** | New products, app launch, consistent growth cited — but from small base | Infonegocios PY |

**Competition Composite**: (1×2 + 5×1 + 1×1 + 3×1) / 5 = **2.0** / 5.0
**Customer Composite**: (2×2 + 5×1 + 3×1 + 3×1) / 5 = **3.0** / 5.0
**Overall Landscape Composite**: (5+1+1+2+1+3+3+3) / 8 = **2.4** / 5.0
**Confidence Band**: Medium (~50% Confirmed)

**Overall Landscape Assessment**:
Masapan is a 33-year-old Asunción family bakery/catering hybrid with genuine tech ambition (executive mobile app) unusual for a PY SME at this scale. It has no competitive overlap with SolStein and is too small to be a strong customer target on its own, but it represents the "digital-ready PY SME caterer" segment that SolStein could target as a group with a freemium/low-cost offering. The organic garden and quality-first positioning suggest management sophistication above average for the segment.

**Recommended Next Step**: **De-prioritise** as individual account — but track as a representative of the PY SME catering digitalization segment. If SolStein develops a small-business tier of its platform, Masapan is a good pilot candidate and brand validator given their #3 top-of-mind position.

**Primary Tier**: **Tier 2** (Overall 2.4 — watch list; not immediate priority)
