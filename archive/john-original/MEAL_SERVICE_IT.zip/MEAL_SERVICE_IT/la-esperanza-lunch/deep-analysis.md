# Deep Analysis — La Esperanza Servicios de Lunch

**Research Date**: 2026-05-04
**Player Type**: Operator (micro-scale institutional catering / corporate lunch service)
**Confidence Level**: Low (minimal public data; single DNCP tender participation identified; company directory listing only)
**Geographic Footprint**: Paraguay (Asunción metropolitan area)
**Paraguay Presence**: Yes — PY-native micro-player

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | La Esperanza Servicios de Lunch (formal legal name/RUC unconfirmed) | [paraguay.gugadir.com](https://paraguay.gugadir.com/la-esperanza-sericios-de-lunch-e2075.html) | Estimated |
| Tax ID / RUC | Unknown | No source | Unknown |
| HQ Address | Asunción metropolitan area | gugadir.com; filas.com.py | Estimated |
| Founded | Unknown | No source | Unknown |
| Founders | Unknown | No source | Unknown |
| Ownership | Unknown — likely family/founder-owned micro-business | No source | Unknown |
| Employee Count | Very small — estimated <20 | Proxy | Estimated proxy |
| Revenue — PY | Very small — single DNCP small tender (Ministerio del Ambiente, 2015) | DNCP SICP | Estimated |
| Profitability | Unknown | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — micro institutional catering | gugadir.com | Confirmed |
| Sub-Verticals Served | Corporate lunch/cantina, events, catering, government catering | gugadir.com | Confirmed |
| Countries Active | Paraguay (Asunción metro only) | gugadir.com | Confirmed |
| Government Contracts | Participated in DNCP tender "Servicios de Catering y Ceremonial - Segundo Llamado" (Ministerio del Ambiente, 2015) | DNCP SICP | Confirmed |
| Market Share — PY | Micro — not a significant player | No source | Unknown |
| Awards / Certifications | None identified | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Catering, cantina/comedor, events, corporate lunch | gugadir.com | Confirmed |
| Food Philosophy | Fresh, quality, fitosanitario compliant; metropolitan area service | gugadir.com | Confirmed |
| Internal Tech Stack | None identified | No source | Unknown |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Estimated Revenue | USD <100K/yr (micro operator; single identified DNCP tender 2015) | Proxy | Estimated proxy |
| Scale Assessment | Below SolStein minimum customer threshold | — | Estimated |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Public-Sector Dependence | Government tender participation (2015) | DNCP | Confirmed |
| Cross-Border | PY-only | — | Confirmed |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **4** | PY-native; Asunción metro | gugadir.com |
| LATAM regional reach | Medium | Both | **1** | PY-only | — |
| Competitive overlap | High | Competition | **1** | Micro operator; no overlap | — |
| Customer-fit potential | High | Customer | **1** | Too small to be a viable SolStein customer | Proxy |
| Scale | Medium | Both | **1** | Micro-player; below minimum threshold | Proxy |
| Tech modernity | Medium | Both | **1** | No digital evidence | No source |
| Acquisition / partnership | Low | Strategic | **2** | Unknown ownership; too small to be strategic | No source |
| Growth trajectory | Low | Both | **1** | No growth signals; limited DNCP participation | DNCP |

**Overall Landscape Composite**: (4+1+1+1+1+1+2+1) / 8 = **1.5** / 5.0
**Confidence Band**: Wide (>80% Unknown)

**Overall Landscape Assessment**:
La Esperanza is a micro-scale PY institutional catering operator with insufficient public data to score meaningfully across most dimensions. It is not a viable customer, partner, or competitor for SolStein at current scale.

**Recommended Next Step**: **De-prioritise** — too small. If SolStein develops a micro-SME tier in the future, add to a long-tail prospect list.

**Primary Tier**: **Tier 3** (Overall 1.5 — reference only)
