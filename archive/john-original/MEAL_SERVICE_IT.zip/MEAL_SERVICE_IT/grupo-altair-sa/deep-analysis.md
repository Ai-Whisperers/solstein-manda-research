# Deep Analysis — Grupo Altair SA

**Research Date**: 2026-05-04
**Player Type**: Operator (school feeding / almuerzo escolar — Hambre Cero program)
**Confidence Level**: Medium (DNCP + ABC Color + RCC press confirmed; financials estimated from contract values)
**Geographic Footprint**: Paraguay (Lambaré HQ; national school coverage including Concepción, Villa Elisa, Alto Paraguay)
**Paraguay Presence**: Yes — native PY operator

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Grupo Altair S.A. | [DNCP](https://www.contrataciones.gov.py/proveedor/grupo-altair.html) | Confirmed |
| Tax ID / RUC | 80098783-7 | DNCP provider record | Confirmed |
| HQ Address | Jacques Balanza Nº 1530, Lambaré, Departamento Central, Paraguay | DNCP | Confirmed |
| Founded / DNCP Inscription | 25 August 2017 | DNCP | Confirmed |
| Key Leadership | Amado Javier Guerrero Ayala + Víctor Daniel Mendoza Larroza (legal representatives) | DNCP | Confirmed |
| Ownership | Founder-owned / private SA — no PE identified | No source | Estimated |
| Employee Count — PY | Not disclosed; operating 144 school sites in Concepción alone — estimated 200–600 field staff | Proxy from contract scope | Estimated proxy |
| Revenue — PY | G. 113.825B (Concepción) + G. 714.6M (Villa Elisa, 2022) as confirmed contracts; other contracts likely — estimated total G. 15–30B/yr | DNCP; El Independiente; ABC Color | Estimated |
| Revenue — PY (USD) | ~USD 2–5M/yr | Proxy | Estimated proxy |
| Profitability | Unknown; payment arrears (G. 8.2B) signal cash flow stress | ABC Color 2026 | Estimated |
| Last Funding Round | None identified | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — institutional school feeding | DNCP; ABC Color | Confirmed |
| Sub-Verticals Served | School feeding (almuerzo escolar, Hambre Cero program) | ABC Color; RCC | Confirmed |
| Countries Active | Paraguay only | DNCP | Confirmed |
| Student Coverage | 4,500+ students in multiple departments (Concepción: 144 institutions) | ABC Color | Confirmed |
| School Preparation Model | Cooks in the schools (on-site kitchen service) + supplies kitchen equipment to institutions | ABC Color | Confirmed |
| Notable PY Customers | Gobernación de Concepción (G. 113B contract); Municipalidad de Villa Elisa (G. 714M, 2022); Alto Paraguay (Chaco) | DNCP; El Independiente | Confirmed |
| Government / Institutional | Multiple DNCP contracts; Hambre Cero participant (Ministry of Social Development) | DNCP | Confirmed |
| Market Share — PY | Tier 2 school feeding operator (behind Comepar and Ladero); growing since 2017 | Press context | Estimated |
| Awards / Certifications | None cited | No source | Unknown |
| Sustainability | None identified | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Almuerzo escolar (cooked on-site in schools); kitchen equipment supply; rural school coverage | ABC Color; RCC | Confirmed |
| Menu Philosophy | Institutional nutrition; government-mandated nutritional standards | Regulatory context | Estimated |
| Cold-Chain & Logistics | On-site cooking model (in schools) reduces cold-chain needs; supplies/ingredients delivery required | ABC Color | Estimated |
| Internal Tech Stack | Unknown — likely manual/Excel; no IT system referenced | No source | Unknown |
| End-Customer App | None | No source | Unknown |
| Meal-Voucher Integration | None | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Likely — 2017 founding, two named legal reps (Guerrero Ayala + Mendoza Larroza) | DNCP | Estimated |
| PE or VC Backed | No | No source | Estimated |
| Government-Related | No; but operationally dependent on government contracts | No source | Estimated |
| Founder Still Active | Both legal representatives active | DNCP | Confirmed |
| Succession Signal | No signal | No source | Unknown |
| Group Structure | Standalone SA | DNCP | Confirmed |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Strong 2017→2024 (founded 2017; national coverage 2022–2024) | DNCP contract history | Estimated |
| Employee Growth YoY | Growing proportional to new school contracts | Proxy | Estimated |
| Geographic Expansion (3yr) | Expanded from Central to Concepción and Chaco (Alto Paraguay) | ABC Color | Confirmed |
| Acquisitions (3yr) | None | No source | Unknown |
| Funding Rounds (3yr) | None | No source | Unknown |
| Cash Flow Risk | Gobernación de Concepción owes G. 8.179B (Oct + Nov 2025 payments) — common risk in PY school feeding | ABC Color 2026 | Confirmed |
| Tender Win Rate | Multiple DNCP wins since 2017; growing portfolio | DNCP | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | School feeding — almuerzo escolar | DNCP | Confirmed |
| Vertical Breadth | 1 (school feeding only — no diversification identified) | Press | Estimated |
| Food Safety Compliance | INAN required; government Hambre Cero quality standards apply | Regulatory context | Estimated |
| Fiscal e-Invoicing | SET e-Kuatia as DNCP provider — assumed compliant | DNCP | Estimated |
| Allergen / Dietary | Government nutritional standards compliance assumed | Regulatory context | Estimated |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Cost-plus public tender (DNCP); price per ración escolar | DNCP | Confirmed |
| Price Range | Standard PY school meal: G. 5,000–15,000/ración | DNCP benchmark | Estimated |
| Recurring vs Project | ~100% government contract (multi-year or annual renewal) | DNCP | Estimated |
| Estimated Revenue | USD 2–5M/yr (from confirmed DNCP contracts) | DNCP + proxy | Estimated |
| Estimated Acquisition Value | USD 2–8M (small operator; asset-light on-site cooking model; government-dependent) | Benchmark | Estimated proxy |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG only — all government contracts | DNCP | Confirmed |
| Public-Sector Dependence | 100% — entirely government school feeding | DNCP; ABC Color | Confirmed |
| Cash Flow Risk | G. 8.2B payment arrears (2025) from Gobernación de Concepción — systemic PY issue | ABC Color | Confirmed |
| Cross-Border | PY-only | No source | Confirmed |
| Family Conglomerate | None | No source | Unknown |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | PY-native, multiple departments covered (Central, Concepción, Chaco) | DNCP |
| LATAM regional reach | Medium | Both | **1** | PY-only | DNCP |
| Competitive overlap | High | Competition | **1** | Operator; no tech overlap with SolStein | DNCP |
| Customer-fit potential | High | Customer | **3** | 144 school sites + kitchen equipment management = complex logistics; genuine IT need; cash-flow stress may limit IT budget | ABC Color |
| Scale | Medium | Both | **2** | USD 2–5M/yr; growing but still a Tier 2 operator vs Comepar/Ladero | DNCP proxy |
| Tech modernity | Medium | Both | **1** | No IT system identified; on-site cooking model is manual | No source |
| Acquisition / partnership | Low | Strategic | **4** | Founded 2017; 2 founders; small valuation; acquirable; no PE | DNCP |
| Growth trajectory | Low | Both | **4** | Rapid national expansion 2017→2024 (Central → Concepción → Chaco); active Hambre Cero participant | ABC Color |

**Competition Composite**: (1×2 + 5×1 + 2×1 + 1×1) / 5 = **1.8** / 5.0
**Customer Composite**: (3×2 + 5×1 + 1×1 + 4×1) / 5 = **3.2** / 5.0
**Overall Landscape Composite**: (5+1+1+3+2+1+4+4) / 8 = **2.6** / 5.0
**Confidence Band**: Medium (~45% Confirmed)

**Overall Landscape Assessment**:
Grupo Altair is a fast-growing PY school feeding operator (founded 2017, national coverage by 2024) with 144 school sites and Hambre Cero participation. It has no competitive overlap with SolStein and represents a relevant — if financially stressed — potential customer for institutional catering IT. The on-site cooking model across 144+ sites creates genuine need for route planning, recipe management, procurement, and multi-site contract management. The founders are active and the company is acquisitively priced (<USD 8M). Cash flow risk from government payment delays is the main concern.

**Recommended Next Step**: **Approach as customer** — Altair's multi-site school feeding operation (cooking in schools across multiple departments) needs procurement, recipe, nutritional compliance, and billing IT. Outreach via CAEP or direct approach to Guerrero Ayala. Note cash flow stress — frame SolStein as cost-saving and compliance-enabling, not cost-adding.

**Primary Tier**: **Tier 1** (Customer Composite 3.2 — PY active; worth direct outreach)
