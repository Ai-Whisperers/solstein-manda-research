# Financial & Growth Deep-Dive — Comepar SA

**Research Date**: 2026-05-04
**Player Type**: Operator (hybrid — institutional caterer + branded retail products)
**Domicile Country**: Paraguay
**Reporting Currency**: PYG (guaraní); USD used in press and media
**Inflation Adjustment Status**: N/A — PY guaraní is relatively stable; no NIC 29 inflation adjustment needed
**Data Availability**: Low-Medium (no public filings; government contract values confirmed via DNCP/press; revenue constructed from contract proxy)

---

### Revenue Timeline

| Year | Revenue Basis | Currency | Approx FX Rate (PYG/USD) | Revenue (USD M) | YoY Growth (USD) | Source | Confidence |
|---|---|---|---|---|---|---|---|
| 2026 (est.) | Hambre Cero (~G. 633B/yr active) + private sector (~G. 70–100B) + plant ramp-up | PYG | ~7,600 | ~USD 95–100M | ~+10–15% | Contract proxy; Forbes PY | Estimated proxy |
| 2025 | Hambre Cero (partial + full-year) + Mil Platos + Madame Lunch + Natupar | PYG | ~7,400 | ~USD 85–95M | ~+200–250% | DNCP; ABC Color payments data | Estimated proxy |
| 2024 | MEC carryover (partial) + Hambre Cero start (Aug) + private | PYG | ~7,300 | ~USD 30–40M | ~+70–100% | MEC contract end; Hambre Cero start | Estimated proxy |
| 2023 | MEC post-2022 contract + private sector (Mil Platos) | PYG | ~7,200 | ~USD 15–25M | ~flat/slight growth | No specific data; MEC payment delays cited | Estimated proxy |
| 2022 | MEC G. 210B contract (partial year Nov close) + private | PYG | ~7,000 | ~USD 20–28M | — | ABC Color 2022 | Estimated proxy |
| 2020 | MEC G. 210B contract won (Feb start) | PYG | ~6,900 | ~USD 10–15M | — | ABC Color 2022 | Estimated proxy |

**Notes on construction**:
- 2024–2027 Hambre Cero: G. 1.9T / 3yr = G. 633B/yr ≈ USD 85M/yr at 7,500 PYG/USD. Payments from Oct 2024–Nov 2025 = G. 428.662B confirmed (~USD 57M in 13 months = ~USD 53M/yr annualized). Private sector revenue estimated at 10–15% of total.
- Pre-2024 revenue: DNCP contract totals 2012–2022 = G. 567.5B (Comepar) + G. 509.9B (Consorcio) = G. 1.077T over ~10yr ≈ G. 107B/yr average ≈ USD 14M/yr average

**Revenue CAGR (3yr, USD estimate)**: ~+80–100% CAGR 2022→2025 — driven entirely by Hambre Cero contract scale jump
**Revenue CAGR (5yr, USD estimate)**: ~+40–50% CAGR 2020→2025 — strong but contract-concentration driven

#### Revenue Trend Chart (USD)

```mermaid
xychart-beta
    title "Comepar SA Revenue Trend (USD M, estimated)"
    x-axis [2020, 2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "USD Millions" 0 --> 110
    line [12, 18, 25, 20, 35, 90, 98]
```

*All values estimated proxy — no audited financials available.*

---

### Profitability

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| EBITDA (current) | Unknown — no public filing | No source | Unknown |
| EBITDA Margin | Estimated 5–10% (typical LATAM catering operator: 5–12%) | Industry benchmark | Estimated proxy |
| Net Profit / Loss | Unknown | No source | Unknown |
| Long-Term Contract % | >70% estimated (Hambre Cero is G. 633B/yr → ~70–80% of total revenue) | DNCP contract data | Estimated |
| Revenue per Employee | ~USD 30K/employee (USD 90M ÷ 3,000 staff) — within LATAM catering benchmark of USD 25–45K | Calculated proxy | Estimated proxy |
| Cash Flow Signal | Positive — received monthly payments consistently (confirmed Oct 2024–Nov 2025); self-funded US$30M plant | ABC Color; Forbes PY | Estimated |
| Investment in New Capacity | US$30M capex (2026 plant) — signals strong cash flow and/or debt financing capacity | Forbes PY | Confirmed |

---

### Funding & Investment History

| Date | Round | Amount (USD) | Lead Investor(s) | Capital Source Type | Valuation (USD) | Source | Confidence |
|---|---|---|---|---|---|---|---|
| 2012 | Founder capital / Bootstrap | Unknown | Miguel Cardona + Mark Shakespeare | Family / Founder | Unknown | Forbes PY | Estimated |
| 2022 | Infrastructure reinvestment | >US$10M | Self-funded (revenue-financed) | Internal | N/A | ABC Color 2022 | Estimated |
| 2026 | Plant investment | US$30M | Self-funded or debt financed | Internal / Debt (bank unclear) | N/A | Forbes PY | Confirmed |

**Total Raised**: No external funding identified — bootstrapped and revenue-financed
**Latest Valuation**: Not applicable (private, no external investment)
**Current Investors**: Miguel Ángel Cardona (founder/owner) + Mark Shakespeare (co-investor)
**War Chest Signals**: Self-funded US$30M plant investment suggests significant retained earnings or bank credit line with PY commercial bank (Banco Continental, Banco Itaú, BBVA PY probable)

---

### Employee Timeline

| Year | PY Total | Country Distribution | YoY Growth | Source | Confidence |
|---|---|---|---|---|---|
| 2026 (current) | 3,000+ direct | All in Paraguay | ~+20–30% | Forbes PY; MarketData | Confirmed |
| 2024 | ~2,500 | All in Paraguay | ~+230% from 2022 | Radio La Clave | Estimated |
| 2022 | 752 | All in Paraguay | — | IPS registration data (ABC Color) | Confirmed |
| 2020 | ~400–500 (est.) | All in Paraguay | — | Proxy from contract scale | Estimated proxy |
| 2012 | ~50–100 (est.) | All in Paraguay | — | No source | Unknown |

**Employee CAGR (2022→2026, 4yr)**: ~+41% CAGR (752 → 3,000+)
**Current Open Positions**: Not tracked — operational roles dominated (kitchen staff, logistics, nutrition); tech roles unclear
**Hiring Hotspots**: Areguá (plant), Asunción (HQ), Ciudad del Este (new operation)
**Recent Layoff / Restructuring**: None identified — active hiring phase

#### Employee Growth Chart

```mermaid
xychart-beta
    title "Comepar SA Employee Growth (Paraguay)"
    x-axis [2020, 2021, 2022, 2023, 2024, 2025, 2026]
    y-axis "Headcount" 0 --> 3500
    line [450, 600, 752, 1200, 2500, 3000, 3100]
```

*2020–2021 and 2023 are estimated interpolations.*

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
|---|---|---|---|---|---|
| 2012 | Company founded | PY (Asunción + Areguá) | Initial operations in Asunción schools | Forbes PY | Confirmed |
| ~2015 | Expanded to Central Department | PY (Central) | Added 51 schools in 19 Central districts | ABC Color | Confirmed |
| ~2019 | Private sector launch | PY (national) | Mil Platos corporate catering; Madame Lunch retail | Infonegocios PY | Confirmed |
| 2024-08 | Expanded to Alto Paraná | PY (Ciudad del Este) | First operations outside Asunción/Central | cdehot.com.py | Confirmed |
| 2026 | New plant enables regional export ambitions | PY (Areguá) | "Regional reference" positioning; no confirmed cross-border operations yet | Forbes PY | Estimated |

**Primary Market**: Paraguay (100%)
**International Revenue %**: 0% (no cross-border operations)
**Country Footprint Strategy**: Single-country (PY); domestic expansion within PY (Asunción → Central → Ciudad del Este)
**Expansion Trajectory**: Deepening PY coverage by department; new plant capacity (300,000 meals/day) well beyond current PY demand — signals potential for future regional (LATAM) ambition, but no concrete cross-border steps identified

---

### M&A Activity

No acquisitions, mergers, or divestitures identified.

"Consorcio Comepar y Asociados" was a temporary bidding consortium for DNCP tenders — not a permanent corporate structure.

**M&A Pattern**: Purely organic growth — all expansion through internal investment and government contract wins

---

### Digitalization / SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Deployment Model | N/A — operator | — | — |
| Customer-Facing App | None identified — no mobile ordering app for B2B clients | No source | Unknown |
| Internal ERP Stack | Unknown — no ERP vendor or system named in any source | No source | Unknown |
| Production Technology | Advanced: automated ovens, intelligent transport systems, microbiological lab, continuous monitoring (new plant) | Forbes PY | Confirmed |
| HR / Payroll Digitization | Registered with IPS (Instituto de Previsión Social) for 752 employees (2022 data) — basic payroll compliance; system unknown | ABC Color 2022 | Confirmed |
| Voucher / Benefit Integration | None identified | No source | Unknown |
| Payment Integration | Government: direct treasury payment (DNCP); private: corporate invoicing | DNCP | Estimated |
| Delivery Platform Integration | Own distribution fleet; no third-party delivery platform identified | Forbes PY | Estimated |
| ERP Modernization Signals | No press or job posting evidence of ERP implementation — major IT gap | No source | Unknown |
| e-Invoicing (SET e-Kuatia) | As a DNCP-registered supplier, SET e-invoicing compliance is required | DNCP | Estimated |

**Digitalization Maturity Assessment**: Low for back-office IT; high for physical production technology. Massive gap between production automation (world-class new plant) and back-office IT systems (unknown, likely manual/Excel-driven). This is SolStein's primary opportunity.

---

### Public-Sector Revenue & Tender Activity

| Date Awarded | Tender / Contract | Awarding Entity | Value (USD) | Term | Status | Source |
|---|---|---|---|---|---|---|
| ~2013–2014 | Almuerzo escolar — early contracts | MEC | ~USD 5–8M est. | ~1–2yr | Expired | ABC Color (historical) |
| ~2015–2016 | Almuerzo escolar — Asunción (G.86B) + Central (G.21.3B) | MEC / Gobernación Central | ~USD 14M combined | 2yr | Expired | ABC Color |
| 2016-07 | Bid annulled after protest | MEC | N/A | — | Annulled (recovered via new tender) | ABC Color |
| 2020-02 | Almuerzo escolar — 188 institutions (G.210.322B) | MEC | ~USD 28M | 33 months (Feb 2020–Nov 2022) | Expired | ABC Color 2022 |
| 2024-08 | Hambre Cero — 4 lotes as sole bidder (G.1.9T) | Ministry of Social Development (MDS) | ~USD 250M | 3yr (Aug 2024–Jul 2027) | Active | ABC Color; MarketData |

**Estimated Public-Sector Revenue %**: >70% (Hambre Cero alone ~USD 85M/yr out of est. USD 90–100M total)
**Tender Win Rate (last 3yr)**: Very high — won 4 of 4 lotes contested in 2024; sole bidder in all; dominant position
**Lava Jato / Corruption-Investigation Exposure**: None — PY entity, no Brazilian operations
**Political Risk Exposure**: High — multiple press investigations (2022 Amarilla allegations; 2025 "amigo de Santi" coverage); proximity to current government is a double-edged asset

---

### Growth Scorecard

| Dimension | Score (1-10) | Evidence Summary |
|---|---|---|
| Revenue Growth (USD-real) | **9** | USD CAGR estimated ~200%+ in 2022→2025 driven by Hambre Cero scale jump; explosive even adjusting for one-contract concentration |
| Funding Momentum | **2** | No external funding; fully bootstrapped / revenue-financed; US$30M plant is self-funded but signals strong cash generation |
| Employee Growth | **8** | 752 (2022) → 3,000+ (2026) = ~+41% CAGR over 4yr; aggressive operational scaling |
| Geographic Expansion | **2** | Single-country PY only; internal expansion from Asunción → CDE; no international operations |
| M&A Activity | **1** | No acquisitions or divestitures; purely organic growth |
| Digitalization Maturity | **2** | Physical production highly modernized; back-office IT unidentified — likely manual/Excel; no app, no ERP, no delivery integration |
| Public-Sector Position | **10** | Dominant PY school feeding operator; active G. 1.9T / USD 250M Hambre Cero contract; ~70%+ revenue from government; very strong but concentrated |
| **COMPOSITE SCORE** | **4.9** | **Steady → Riser boundary** — massive tender-driven top-line growth offset by zero M&A, zero funding, zero digitalization, zero international |

**Classification**: **Steady** (avg 4.9) — borderline Riser on revenue alone, but concentration risk and absent digitalization/M&A/geography drag the composite down

**Nuance**: If viewed purely as a government-contract revenue machine, Comepar is a Rocket. If viewed as a diversified growth company, it is a Steady player making its first moves toward diversification (Mil Platos, Madame Lunch). The digitalization score (2/10) is the most actionable gap for SolStein.

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "Comepar SA Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "Digital", "Public-Sector"]
    y-axis "Score" 0 --> 10
    bar [9, 2, 8, 2, 1, 2, 10]
```
