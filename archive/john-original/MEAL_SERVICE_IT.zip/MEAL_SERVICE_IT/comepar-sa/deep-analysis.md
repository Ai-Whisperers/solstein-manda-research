# Deep Analysis — Comepar SA

**Research Date**: 2026-05-04
**Player Type**: Hybrid (Operator with branded product lines and corporate tech-enabled B2B arm)
**Confidence Level**: Medium (key financials estimated from contract data; internal tech stack unknown)
**Geographic Footprint**: Paraguay
**Paraguay Presence**: Yes — headquartered, all operations in PY

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity (local) | Comepar S.A. | [contrataciones.gov.py](https://www.contrataciones.gov.py/proveedor/comepar-s-a.html) | Confirmed |
| Legal Entity (parent / global) | None — standalone PY entity | No parent identified in search | Estimated |
| Tax ID — RUC | 80017044-0 | [contrataciones.gov.py](https://www.contrataciones.gov.py/proveedor/comepar-s-a.html) | Confirmed |
| HQ Address (LATAM) | Lugano 452 entre Alberdi y 14 de Mayo, Asunción, Paraguay | DNCP provider record | Confirmed |
| Production Plant | Areguá, Paraguay (US$30M new facility inaugurated 2026) | [Forbes PY](https://www.forbes.com.py/advertorial-contenido-patrocinado/comepar-invierte-us-30-millones-planta-modelo-posiciona-como-referente-regional-n89372); [Diario HOY](https://www.hoy.com.py/nacionales/2026/04/17/moderna-planta-de-comepar-marca-un-antes-y-un-despues-en-la-alimentacion-escolar) | Confirmed |
| Founded — LATAM ops | 2012 | [Infonegocios PY](https://infonegocios.com.py/default/comepar-la-firma-que-alimenta-a-empresas-puede-producir-mas-de-60-000-platos-diarios) | Confirmed |
| Founded — globally | 2012 (no parent; this is the global entity) | Same | Confirmed |
| Founder / Owner | Miguel Ángel Cardona (founder); Mark Shakespeare (co-investor) | [Forbes PY](https://www.forbes.com.py/advertorial-contenido-patrocinado/comepar-invierte-us-30-millones-planta-modelo-posiciona-como-referente-regional-n89372); [Diario Vanguardia](https://diariovanguardia.com.py/un-legado-familiar-a-una-industria-que-hoy-alimenta-a-miles-de-ninos-en-el-paraguay/) | Estimated |
| President / Legal Rep | Antolín Javier Genez Miranda (President); Yane Blames Dos Reis Wanzeller Sartori (second legal rep) | DNCP provider record | Confirmed |
| Ownership | Family-owned — Miguel Ángel Cardona family origin; private Paraguayan capital 100% | [Diario Vanguardia](https://diariovanguardia.com.py/un-legado-familiar-a-una-industria-que-hoy-alimenta-a-miles-de-ninos-en-el-paraguay/) | Estimated |
| Investor Type | No external VC/PE identified; self-funded + revenue-financed growth | No funding source found | Estimated |
| Employees — PY (current) | ~3,000 direct employees | [Forbes PY](https://www.forbes.com.py/advertorial-contenido-patrocinado/comepar-invierte-us-30-millones-planta-modelo-posiciona-como-referente-regional-n89372); [MarketData](https://marketdata.com.py/noticias/nacionales/con-inversion-de-usd-30-millones-empresa-proveedora-de-hambre-cero-inaugura-nueva-planta-152029/) | Estimated |
| Employees — indirect chain | 11,000+ (indirect supply chain impact) | Forbes PY | Estimated |
| Revenue — PY government contracts | ~US$80–100M/year estimated (Hambre Cero alone: ~US$83M/year from 4 lotes over 3yr contract) | [ABC Color](https://www.abc.com.py/nacionales/2024/07/15/hambre-cero-conocidas-proveedoras-fueron-adjudicadas-para-asuncion-central-y-presidente-hayes/); [ABC Color Aug 2024](https://www.abc.com.py/politica/2024/08/12/comepar-y-ladero-paraguay-lideran-las-adjudicaciones-de-hambre-cero/) | Estimated |
| Government contract payments received (Oct 2024–Nov 2025) | G. 428.662 million (~US$60M in 13 months) | [ABC Color Nov 2025](https://archivo.abc.com.py/politica/2025/11/13/proveedor-de-hambre-cero-amigo-de-santi-aparece-con-pagos-mes-a-mes/) | Confirmed |
| Revenue — total (PY) | Unknown; estimated US$90–120M/year (govt + private sector combined) | Proxy from contract data + private clients | Estimated |
| Profitability | Profitable — self-financed US$30M plant investment; regular monthly govt payments | Forbes PY | Estimated |
| Last Funding Round | None identified — self-funded | No source found | Unknown |

---

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator (hybrid: large-scale institutional caterer + branded retail products + corporate B2B arm) | Classification based on website + press | Confirmed |
| Sub-Verticals Served | School feeding (public); corporate catering (B2B); frozen consumer retail; packaged vegetable retail | [Infonegocios PY](https://infonegocios.com.py/default/comepar-la-firma-que-alimenta-a-empresas-puede-producir-mas-de-60-000-platos-diarios) | Confirmed |
| Countries Active | Paraguay only | All sources | Confirmed |
| Production Capacity | 300,000 rations/day (new plant); 100+ tons/day | Forbes PY; MarketData | Confirmed |
| Current Production Volume | ~21,000 meals/day (pre-new-plant reporting); capacity now 60,000–300,000/day | Infonegocios PY; Forbes PY | Estimated |
| Total Meals Served | 107 million+ meals delivered to date | MarketData | Confirmed |
| School Institutions Served | 650–700+ public educational institutions (Asunción, Central, Presidente Hayes) | ABC Color; Diario HOY | Confirmed |
| Notable PY Government Clients | Ministerio de Desarrollo Social (Hambre Cero); MEC (school feeding); Petropar (corporate) | ABC Color; Infonegocios PY | Confirmed |
| Notable PY Corporate Clients | Petrobras Paraguay; Banco Central del Paraguay (via Mil Platos brand) | [Infonegocios PY](https://infonegocios.com.py/default/comepar-incursiona-en-el-servicio-gastronomico-diario-a-empresas-privadas) | Confirmed |
| Government Contracts (DNCP) | Hambre Cero 4 lotes = ~G. 1.9 trillion (~US$250M) for Aug 2024–Jul 2027 | ABC Color + DNCP provider page | Confirmed |
| Estimated Market Share — PY institutional | Dominant in PY school feeding; leading Hambre Cero contract winner | ABC Color: "más del 60-65% del valor total de la licitación" | Estimated |
| Awards / Certifications | ISO 9001:2015; ISO 22000; ISO 45000; HACCP; BPM (Buenas Prácticas de Manufactura); BPA | Infonegocios PY | Confirmed |
| Own Laboratory | Yes — microbiological and physicochemical quality control lab | Forbes PY; Radio La Clave | Confirmed |
| Sustainability Claims | Planta de tratamiento de efluentes; environmental technology (Fabripar); near-zero-waste cooking model | [Diario Paraguayo](https://diarioparaguayo.com/noticia/comepar-inaugura-moderna-planta-de-alimentos-con-tecnologia-ambiental-de-fabripar) | Confirmed |

---

### Product / Service & Technology

#### Operator profile

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | (1) Institutional school feeding; (2) Corporate catering — Mil Platos brand; (3) Frozen consumer meals — Madame Lunch; (4) Packaged vegetables — Natupar | Infonegocios PY | Confirmed |
| Menu Philosophy | Nutritionally balanced menus; local/regional ingredient sourcing from Areguá valley; HACCP-controlled; hot meals produced same-day and distributed just-in-time | Forbes PY; La Nación PY | Estimated |
| Cold-Chain & Logistics | Own production + distribution; just-in-time model with no storage at destination; refrigerated transport implied | Forbes PY | Estimated |
| Internal Tech Stack (ERP) | Unknown — no ERP vendor identified; likely custom or specialty food-industry software | No source found | Unknown |
| End-Customer App / Portal | None identified (no mobile ordering app; B2B contracts with institutions, not end-user-facing) | No source found | Unknown |
| Meal-Voucher Card Integration | None identified — serves institutional contracts directly (government) or via negotiated corporate contracts (Petrobras, Banco Central) | No source found | Unknown |
| Production Technology | Intelligent ovens with transport systems; automated cooking lines; continuous monitoring; near just-in-time delivery model | Forbes PY; HOY | Confirmed |

---

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Yes — Miguel Ángel Cardona is founder and owner; family-origin enterprise going back nearly 50 years in Areguá community development | Diario Vanguardia | Estimated |
| PE or VC Backed | No external investment identified | No source found | Estimated |
| Government-Related Shareholders | None identified; notable that company has very strong government contracts which create political-cycle risk | DNCP records | Estimated |
| Founder Still Active | Unknown — Javier Genez Miranda appears as president/president-delegate; Miguel Cardona identified as owner in 2024 press | Forbes PY; DNCP | Estimated |
| Succession Signal | No explicit succession signal; Javier Genez Miranda appears as operational president | DNCP; Forbes PY | Unknown |
| PE Exit Horizon | N/A — not PE-backed | — | — |
| Family-Owned Dynamics | Yes — family enterprise; Cardona family linked to 50-year Areguá community origin | Diario Vanguardia | Estimated |
| Group Structure | Standalone; sister brands (Mil Platos, Madame Lunch, Natupar) appear to be product lines within same S.A. | Infonegocios PY | Estimated |

---

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Strong growth trajectory: new US$30M plant investment + major contract wins in 2024; not disclosed numerically | Forbes PY; HOY | Estimated |
| Employee Growth YoY | From ~752 (earlier reports) to 3,000+ (post-new plant); significant headcount growth | DNCP; Forbes PY | Estimated |
| Geographic Expansion (3yr) | None — PY-only; no LATAM expansion announced | All sources | Confirmed |
| Service Launches (2yr) | Mil Platos corporate catering brand launch; new Areguá plant with 100-ton/day capacity (2026) | Infonegocios PY; Forbes PY | Confirmed |
| Acquisitions (3yr) | None identified | No source | Unknown |
| Funding Rounds (3yr) | None — self-funded | No source | Estimated |
| Currency Exposure | PYG primary; USD used in contract value reporting; no cross-border exposure | All PY sources | Confirmed |
| Customer Count Growth | 188 institutions → 650–700+ institutions (post-Hambre Cero win); approximately 3.5× growth in 2yr | ABC Color; HOY | Estimated |
| Tender Win Rate | Very high — won 4 of 12 Hambre Cero lotes as sole bidder in all 4; dominant in school feeding DNCP tenders | ABC Color | Confirmed |

---

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Government-contracted school feeding (largest); secondary: corporate catering B2B; tertiary: retail frozen meals | Infonegocios PY | Confirmed |
| Vertical Breadth | 4 verticals: institutional/school, corporate B2B, frozen consumer, packaged produce | Infonegocios PY | Confirmed |
| Food Safety Compliance | INAN PY certified (implied via ISO 22000 and HACCP); BPM and BPA certifications | Infonegocios PY | Confirmed |
| Fiscal e-Invoicing | Registered DNCP supplier — e-Kuatia compliance assumed for government contracting | DNCP | Estimated |
| Allergen / Dietary | HACCP plan in place; lab for quality control; no allergen-specific module identified | Infonegocios PY | Estimated |
| Voucher / Benefit Integrations | None identified — direct institutional contracts | No source | Unknown |
| Payment Integrations | Direct government payment via treasury (not electronic voucher); private corporate direct billing | DNCP; Infonegocios PY | Estimated |
| Delivery Integrations | Own distribution fleet (just-in-time to schools); no public delivery platform integrations | Forbes PY | Estimated |
| Languages Localized | Spanish (PY); no tech product requiring language localization (operator, not SaaS) | N/A | — |

---

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Government: cost-plus tender (per-plate; G. 16,262–16,420 per plate in 2024 tenders); Corporate B2B: negotiated contract (price undisclosed) | ABC Color; DNCP | Confirmed |
| Price Range — school | ~G. 16,262–16,420 per plate (~USD 2.10–2.15 at current rates) for Hambre Cero | ABC Color 2024 | Confirmed |
| Recurring vs Project | >90% recurring (3-year government contracts + ongoing corporate accounts) | Contract terms | Estimated |
| Estimated Revenue | US$90–120M/year (government ~US$83M + private sector ~US$10–20M) | Proxy: contract value ÷ 3yr + private | Estimated proxy |
| Comparable M&A Transactions | No direct LATAM comparable; Elior/Newrest operator-type deals trade at 0.5–1.0× revenue (catering EBITDA-lean) | LAVCA; industry reference | Unknown |
| Estimated Acquisition Value | USD 60–90M range (if operator multiple: 0.5–0.8× revenue; discount for public-sector concentration risk) | Proxy | Estimated proxy |
| Implementation Timeline | N/A (operator, not software) | — | — |
| Services vs Product Split | ~85–90% services (institutional + corporate catering); ~10–15% retail products (Madame Lunch + Natupar) | Infonegocios PY | Estimated |

---

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG primary; USD used in media/press reporting of contract values | All PY sources | Confirmed |
| Cross-Border PY-AR-BR-UY | None identified — PY-only operations | All sources | Confirmed |
| Itaipú / Yacyretá Exposure | None identified — no tender wins on Itaipú or Yacyretá found | No source | Unknown |
| Public-Sector Dependence | Very high — estimated >70% of revenue from government contracts (school feeding + Hambre Cero); significant political-cycle risk | ABC Color; DNCP | Estimated |
| Mining / Agri Camp Exposure | None identified — focused on school + corporate, not mining camps | No source | Estimated |
| US / European Strategic Parent | None — 100% Paraguayan private capital | DNCP | Confirmed |
| Family Conglomerate Parent | No named conglomerate; Cardona family-origin enterprise, standalone | Diario Vanguardia | Estimated |
| ESG / Sustainability | Environmental wastewater treatment plant; zero-waste cooking model; local ingredient sourcing from Areguá | Diario Paraguayo; Forbes PY | Confirmed |
| Local Content / Nationalization | 100% PY capital; local production — strong alignment with PY government local-content preferences | DNCP | Confirmed |
| Political Risk | Covered by multiple investigative press stories questioning procurement concentration; "Hambre Cero amigo de Santi" | ABC Color; Radio La Clave | Confirmed |

---

### Landscape Relevance Scorecard

**Scoring**: 1 (low relevance) → 5 (high relevance for SolStein landscape map)

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | Headquartered in PY; all 3,000+ staff in PY; 100% PY operations | DNCP; Forbes PY |
| LATAM regional reach | Medium | Both | **1** | PY-only — no LATAM expansion planned or announced | All sources |
| Competitive overlap with SolStein | High | Competition | **2** | Operator, not tech-vendor; competes only if SolStein sells meal-service IT *to* competitors of Comepar; marginal SaaS overlap | Classification |
| Customer-fit potential | High | Customer | **5** | PY's largest institutional caterer; 3,000 staff; 300,000-ration/day plant; obvious IT system need (ERP, route management, menu planning, billing, HACCP tracking) | Forbes PY; HOY |
| Scale | Medium | Both | **4** | US$90–120M estimated revenue; dominant PY market position; 100+ ton/day plant; 3,000 employees | Estimated proxy |
| Tech modernity / digitization | Medium | Both | **2** | Physical production modernized (automated ovens, lab); but no identifiable tech stack, no ordering app, no API integration; likely manual/Excel-driven back-office | No tech source found |
| Acquisition / partnership feasibility | Low | Strategic | **3** | Family-owned, no PE, significant cash-flow from government contracts; but very high political risk, public-sector concentration, and no obvious founder succession gap yet | Diario Vanguardia; ABC Color |
| Growth trajectory | Low | Both | **5** | US$30M plant investment; 3.5× customer count growth in 2yr; Hambre Cero dominant position; new corporate B2B arm launched | Forbes PY; HOY |

**Competition Composite** (Competitive overlap ×2, PY ×1, Scale ×1, Tech ×1): (2×2 + 5 + 4 + 2) / 6 = **2.5 / 5.0**

**Customer Composite** (Customer-fit ×2, PY ×1, Tech ×1, Growth ×1): (5×2 + 5 + 2 + 5) / 6 = **3.7 / 5.0**

**Overall Landscape Composite** (all 8 weighted): (5×2 + 1×1.5 + 2×2 + 5×2 + 4×1.5 + 2×1.5 + 3×1 + 5×1) / 13.5 ≈ **3.4 / 5.0**

**Confidence Band**: Medium (approx. 40% Confirmed, 50% Estimated, 10% Unknown — government contract values confirmed; financial aggregates estimated)

**Overall Landscape Assessment**:
Comepar SA is Paraguay's dominant institutional caterer — producing up to 300,000 rations/day with a newly-inaugurated US$30M plant — making it the highest-priority potential *customer* for SolStein's meal-service IT products. Its back-office appears largely undigitized (no identified ERP, no ordering portal, no meal-management SaaS), which represents an immediate and large commercial opportunity. From a competition lens it is not a direct rival (it is an operator, not a tech vendor), though if it ever internalizes its own IT platform it could become a reference competitor. As a strategic / acquisition target it is constrained by very high government-contract concentration (estimated >70% revenue from public school feeding), which introduces significant political-cycle risk and makes valuation complex. The family-owned structure and self-funded growth profile suggest no external capital pressure, but also no obvious succession catalyst in the near term.

**Recommended Next Step**: **Approach as customer** — warm introduction for SolStein meal-service IT platform (menu planning, route management, HACCP digitization, billing/contract management). Comepar's scale, certification commitments, and rapid growth all create genuine IT system demand. Consider approaching via ARPY or APICAL shared events as first touchpoint.

**Primary Tier**: **Tier 1** (Customer Composite 3.7; Overall 3.4 — active landscape priority)
