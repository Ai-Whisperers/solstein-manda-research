# Corporate History — Comepar SA

**Research Date**: 2026-05-04
**Genealogy Confidence**: Medium (PY press well-documented; SET financials and pre-2015 contracts thin)
**Country of Domicile**: Paraguay
**Family-Conglomerate Parent**: None — standalone family-founded enterprise

---

### Current Ownership & Key Parties

| Stakeholder | Role | Stake % | Type | Since | Source |
|---|---|---|---|---|---|
| Miguel Ángel Cardona | Founder & Owner | Majority (est.) | Family / Founder | 2012 | [Forbes PY](https://www.forbes.com.py/advertorial-contenido-patrocinado/comepar-invierte-us-30-millones-planta-modelo-posiciona-como-referente-regional-n89372) |
| Mark Shakespeare | Co-investor / Partner | Minority (est.) | Partner / Investor | 2012 | Forbes PY |
| Antolín Javier Genez Miranda | President / Legal Rep | — | Operational leader | Unknown | [DNCP](https://www.contrataciones.gov.py/proveedor/comepar-s-a.html) |
| Yane Blames Dos Reis Wanzeller Sartori | Legal Rep | — | Legal | Unknown | DNCP |

**Board of Directors / Statutory Directors**:

| Name | Role | Represents | Source |
|---|---|---|---|
| Antolín Javier Genez Miranda | President / Director | Operational management | DNCP provider record |
| Yane Blames Dos Reis Wanzeller Sartori | Director / Legal Rep | Legal compliance | DNCP provider record |

**Corporate Structure** (Mermaid):

```mermaid
graph TD
    Cardona["Miguel Ángel Cardona<br/>(Founder / Owner)"]
    Shakespeare["Mark Shakespeare<br/>(Co-investor)"]
    Comepar["Comepar S.A.<br/>RUC 80017044-0<br/>Asunción, Paraguay — Operator"]
    MilPlatos["Mil Platos Brand<br/>Corporate Catering B2B"]
    MadameLunch["Madame Lunch Brand<br/>Frozen Consumer Retail"]
    Natupar["Natupar Brand<br/>Packaged Vegetables"]
    Cardona --> Comepar
    Shakespeare --> Comepar
    Comepar --> MilPlatos
    Comepar --> MadameLunch
    Comepar --> Natupar
```

---

### Origin Story

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founded | 2012 | [Infonegocios PY](https://infonegocios.com.py/default/comepar-la-firma-que-alimenta-a-empresas-puede-producir-mas-de-60-000-platos-diarios) | Confirmed |
| Original Name | Comepar S.A. (no name change identified) | DNCP registry | Confirmed |
| Founders | Miguel Ángel Cardona (Paraguay); Mark Shakespeare (nationality unknown) | Forbes PY | Confirmed |
| DNCP Registration Date | 04 December 2015 (DNCP inscription date) | DNCP provider record | Confirmed |
| Original Mission | Replace dehydrated meals in PY schools with hot, nutritious cooked lunches | Forbes PY; Diario Vanguardia | Confirmed |
| Original Product / Service | School feeding — cooked institutional meals for public schools | Infonegocios PY | Confirmed |
| First Sub-Vertical | Institutional school feeding (MEC contracts) | ABC Color; HOY PY | Confirmed |
| City / Country of Founding | Areguá + Asunción, Paraguay | Diario Vanguardia | Confirmed |
| Family Origin | Cardona family has ~50-year roots in Areguá community development; father founded local social/agricultural initiative; Miguel Cardona transformed it into industrial food production | [Diario Vanguardia](https://diariovanguardia.com.py/un-legado-familiar-a-una-industria-que-hoy-alimenta-a-miles-de-ninos-en-el-paraguay/) | Confirmed |
| Inspiration | US institutional food production model (studied and adapted for PY context) | Forbes PY | Confirmed |
| Initial Scale | Started serving 8,000 schoolchildren/day | Forbes PY | Confirmed |

---

### Corporate Identity Changes

No corporate identity changes identified. The company has operated as Comepar S.A. since 2012. Commercial brand expansions (Mil Platos, Madame Lunch, Natupar) are product lines within the same legal entity, not separate corporate identities.

---

### Mergers & Acquisitions Timeline

#### Acquisitions Made (as buyer)

No acquisitions identified. Growth has been entirely organic — capacity expansion via capital investment (US$30M plant), not M&A.

#### Acquired By (as target)

No acquisition of Comepar identified. Appears to remain fully independent, family-owned.

#### Joint Ventures & Strategic Partnerships

| Date | Partner | Type | Country | Outcome | Source |
|---|---|---|---|---|---|
| 2013–2022 (various) | Multiple local caterers | "Consorcio Comepar y Asociados" — joint bidding consortiums for school-feeding tenders | PY | Active for specific tender cycles; informal consortium structure for DNCP compliance | [HOY PY](https://www.hoy.com.py/nacionales/2024/01/29/las-empresas-adjudicadas-con-el-almuerzo-escolar-en-la-ultima-decada) |
| 2026 | Fabripar (PY) | Technology supply for environmental systems in new plant | PY | Active — plant operational | [Diario Paraguayo](https://diarioparaguayo.com/noticia/comepar-inaugura-moderna-planta-de-alimentos-con-tecnologia-ambiental-de-fabripar) |

*Note*: The "Consorcio Comepar y Asociados" was not a permanent JV but a temporary bidding consortium used for specific DNCP tender rounds, a common practice in PY public contracting.

---

### Investment & Financial Events

| Date | Event Type | Details | Investors / Counterparty | Investor Type | Amount | Source |
|---|---|---|---|---|---|---|
| 2012 | Company founding | Initial capital from Cardona + Shakespeare to launch school-feeding operations | Miguel Cardona + Mark Shakespeare | Family / founder | Unknown | Forbes PY |
| ~2015–2016 | Revenue milestone | MEC contracts for 70+ Asunción schools + 53 Central schools; ~30,000 daily meals | MEC/Gobernación Central | Govt revenue | G. 86B + G. 21.3B (two-year deals) | ABC Color |
| ~2020 | Major contract win | G. 210.322B contract for 188 institutions (Feb 2020–Nov 2022) — ~48,000 daily meals | Ministry of Education (MEC) | Govt revenue | ~USD 28M (2020 FX) | ABC Color 2022 |
| ~2022 | Infrastructure investment | Upgraded Lugano facility; capacity to 62,000 daily meals; US$10M+ infrastructure | Self-funded | Internal | >US$10M | ABC Color 2022 |
| 2024-08 | Major contract win | Hambre Cero (Min. Desarrollo Social) — 4 lotes; G. 1.9 trillion over 3 years | Ministry of Social Development (MDS) | Govt revenue | G. 1.9T (~USD 250M) 3yr | ABC Color; MarketData |
| 2026-04 | Capital investment | New Areguá plant inaugurated; automated production, ISO + HACCP certified | Self-funded | Internal | US$30M | Forbes PY; HOY PY |

*No external VC/PE funding identified. All investment is organic (revenue-financed) or bootstrapped.*

---

### Splits, Spin-offs & Divestitures

No splits or divestitures identified. Mil Platos, Madame Lunch, and Natupar are commercial brands within Comepar S.A. — not separate legal entities.

---

### Critical Events & Milestones

| Date | Event | Impact | Source |
|---|---|---|---|
| 2012 | Company founded by Cardona + Shakespeare; begins with 8,000 schoolchildren/day | Founding event; chose school feeding as primary vertical | Forbes PY |
| 2015-04 | Serving 30,000 students/day across 77 Asunción schools + 51 Central schools | First confirmed scale milestone | ABC Color |
| 2016-07 | DNCP annuls Comepar adjudication after protest for alleged non-compliance with tender requirements | First public controversy; signal of political exposure in school feeding market | ABC Color |
| ~2019 | Launches Mil Platos corporate catering brand; enters private sector B2B | Vertical diversification strategy — reduces public-sector concentration | Infonegocios PY |
| 2020-02 | Wins G. 210B MEC contract (188 institutions, 3yr); largest contract to date at that point | Scale inflection point; employee count reaches 752+ | ABC Color 2022 |
| 2022-07 | Miguel Cardona publicly refutes corruption allegations from Diputado Amarilla; affirms openness to external audit | Political risk event; high-visibility public-sector scrutiny | [RDN PY](https://www.rdn.com.py/2022/07/07/comepar-responde-a-amarilla-y-asegura-que-esta-abierta-al-control/) |
| 2024-06 | Supports Teletón Paraguay (corporate social responsibility) | CSR signal; brand-building outside institutional contracts | ABC Color 2024 |
| 2024-07 | Wins Hambre Cero: 4 of 12 lotes (G. 1.9T, 3yr) as sole bidder in all 4 lotes; reaches 650+ schools | Dominant public-sector contract; transforms revenue scale | ABC Color Aug 2024 |
| 2024-08 | Expands to Ciudad del Este (Alto Paraná) — first operations outside Asunción / Central region | Geographic expansion within PY | cdehot.com.py |
| 2025-01 | Hambre Cero begins in Asunción; monthly payments from MDS confirmed | Cash flow confirmation | ABC Color Nov 2025 |
| 2025-11 | ABC Color reports G. 298B payment arrears from MDS; Comepar disputes narrative, received monthly payments others did not | Political risk — press scrutiny of public-sector concentration and personal ties to President Peña | ABC Color; HOY PY |
| 2026-04 | Inaugurates US$30M Areguá plant; President Santiago Peña + VP Pedro Alliana attend; 300,000-ration/day capacity | Major industrial milestone; national attention; 3,000 direct jobs | Forbes PY; Diario Vanguardia |

---

### Public-Sector Tender History

| Date Awarded | Tender | Awarding Entity | Value (PYG) | Value (USD est.) | Term | Status | Source |
|---|---|---|---|---|---|---|---|
| ~2013–2015 | Almuerzo escolar Asunción (early contracts) | Ministry of Education (MEC) | ~G. 40–50B (est.) | ~USD 6–7M est. | ~2yr | Expired | ABC Color |
| ~2015–2016 | Almuerzo escolar Asunción + Central | MEC / Gobernación Central | G. 86B + G. 21.3B | ~USD 14M combined | 2yr | Expired | ABC Color |
| 2020–2022 | Almuerzo escolar — 188 institutions, Asunción + Central | Ministry of Education (MEC) | G. 210.322B | ~USD 28M | ~33 months (Feb 2020–Nov 2022) | Expired | ABC Color 2022 |
| 2024-08 | Hambre Cero — 4 lotes (Asunción, Capiatá, Itauguá, Ñemby, San Antonio, San Lorenzo, Lambaré, Limpio, MRA, Areguá + Asunción catering) | Ministry of Social Development (MDS) | G. 1.9T | ~USD 250M | 3yr (Aug 2024–Jul 2027) | Active | ABC Color; MarketData |

**Cumulative DNCP contracts 2012–2022 (as Comepar + as Consorcio)**:
- Comepar direct: G. 567.5B (~USD 80M at blended rates) — 4 contracts
- Consorcio Comepar y Asociados: G. 509.9B (~USD 72M) — 10 adjudications
- Combined: ~G. 1.08T (~USD 152M) over 10 years pre-Hambre Cero

---

### Corporate Timeline (Visual)

```mermaid
timeline
    title Comepar SA — Corporate History
    section Founding (2012)
        2012 : Founded by Miguel Cardona + Mark Shakespeare
               : Initial mission: replace dehydrated school meals with hot cooked food
               : First 8,000 schoolchildren served daily
    section Early Growth (2013–2019)
        2013 : First MEC contracts — Asunción schools
        2015 : Serving 30,000 students across 128 schools (Asunción + Central)
        2016 : First DNCP contract annulment (protest) — political exposure revealed
               : Rebuilt contract pipeline; won new adjudications
        ~2019 : Launched Mil Platos (corporate B2B catering brand)
               : Launches Madame Lunch (frozen consumer products)
               : Launches Natupar (packaged vegetables)
    section Scale-Up (2020–2023)
        2020 : Won G. 210B MEC contract — 188 schools, 48,000 meals/day
        2022 : 752 direct employees; US$10M+ infrastructure; capacity 62,000 meals/day
               : Public scrutiny from Diputado Amarilla — Cardona responds publicly
    section Dominant Position (2024–2026)
        2024-07 : Won Hambre Cero (G. 1.9T / 3yr) — sole bidder on 4 lotes
        2024-08 : Expanded to Ciudad del Este (first outside Asunción/Central)
        2025 : Monthly government payments confirmed; 3,000+ employees; 650+ schools
               : Press scrutiny on payment arrears and political proximity to Peña govt
        2026-04 : Inaugurated US$30M Areguá plant; 300,000 raciones/day capacity
                 : President Peña + VP Alliana attend inauguration
```

---

### Corporate Timeline (Text Summary)

```text
2012 — Founded as Comepar S.A. by Miguel Ángel Cardona + Mark Shakespeare in Areguá / Asunción, Paraguay
       Mission: replace dehydrated school meals with hot cooked food; started with 8,000 schoolchildren/day
~2013 — First Ministry of Education (MEC) contracts for Asunción schools
2015  — Serving 30,000 students/day across 128 schools; capacity growing
2016  — First DNCP annulment controversy; rebuilt pipeline; won new tenders
~2019 — Launched Mil Platos (corporate B2B), Madame Lunch (frozen retail), Natupar (vegetables)
2020  — Won G. 210B MEC contract (188 institutions, 3yr); largest deal to date
2022  — 752 employees; US$10M+ infrastructure; 62,000-meal/day capacity; political scrutiny begins
2024  — Won Hambre Cero G. 1.9T/3yr (4 lotes as sole bidder); expanded to Ciudad del Este; 3,000 employees
2026  — Inaugurated US$30M Areguá plant; 300,000-ration/day capacity; national-level recognition
       Current state: Paraguay's dominant institutional caterer; government-contract dependent; 3+ brands; US$250M active contract
```

---

### Pattern Analysis

**Ownership Type**: Founder-owned — Miguel Ángel Cardona with co-investor Mark Shakespeare; no external VC/PE; no signs of conglomerate parent

**Decision Authority**: Founder / owner (Cardona) + operational president (Genez Miranda); PY-only entity — all decisions made locally

**Growth Strategy**: Tender-driven primarily (government school feeding and social programs); supplemented by organic brand extension into private sector (Mil Platos) and consumer retail (Madame Lunch, Natupar)

**Tech Evolution**: Not applicable — operator, not tech vendor; production technology modernized via capital investment (automated ovens, lab, monitoring systems); back-office IT stack unknown

**Country Footprint Strategy**: Single-country (PY) — no LATAM expansion signals

**Public-Tender Dependence**: Very High — estimated >70% of revenue from government contracts; G. 1.9T active Hambre Cero contract runs to July 2027; significant political-cycle risk

---

### Customer / Partnership / Acquisition Feasibility Assessment from History

**Commercial Outreach Entry Point**:
- Contact: Antolín Javier Genez Miranda (President/legal rep) or directly Miguel Ángel Cardona (owner)
- Venue: Industry events — Gastronomik 2026 (May 19–20 in Asunción), ARPY events, or APICAL congresses
- Note: Cardona is relationship-oriented; the Diario Vanguardia article shows he values the "social mission" narrative — SolStein outreach should lead with impact and mission alignment

**Decision-Making Dynamics**:
- Family/founder-driven — slow, relationship-based; no PE or external pressure
- Single-country entity — no HQ approval needed; all decisions at Asunción level
- Very government-relationship-aware; political sensitivity high after 2022/2025 press scrutiny

**Feasibility Signals from History**:
- Signal 1: Family-founded, self-funded, no external investors — potentially open to partnership if framed as operational improvement (not a threat to control)
- Signal 2: Rapid scale-up (8,000 → 300,000 meals/day in 14yr) with manual/unknown IT suggests urgent ERP and management system need
- Signal 3: Three commercial brands (Mil Platos, Madame Lunch, Natupar) operating from one S.A. — classic back-office complexity requiring integrated IT systems

**Feasibility Blockers from History**:
- Blocker 1: Government contract concentration means any operational disruption is politically visible — risk-averse to new IT projects during active contracts
- Blocker 2: Tender-relationship political dynamic; SolStein must position as neutral tech enabler, not politically affiliated vendor
- Blocker 3: No succession signal visible — Cardona appears active and engaged; no near-term exit pressure

**Integration / Partnership Risk from History**:
- Risk 1: High public-sector scrutiny — any vendor partnership with Comepar inherits political visibility
- Risk 2: Parallel brand operations (school feeding + corporate + consumer) with unknown IT coherence — integration may require significant customization

**Trajectory Prediction**:
Most likely next move: Continue as dominant PY school feeding operator through 2027 (active contract). Possible private-sector B2B expansion via Mil Platos. No LATAM expansion expected. Potential IT system acquisition or modernization project coinciding with contract renewal cycle (2027). Acquisition by external party: low probability in current cycle; founder is active, profitable, and politically connected.
