# Deep Analysis — Inflight Catering (Inflight Group PY)

**Research Date**: 2026-05-04
**Player Type**: Operator (private aviation catering + premium corporate catering + events)
**Confidence Level**: Low-Medium (company website + Cultura PY contract confirmed; financials and ownership thin)
**Geographic Footprint**: Paraguay (Asunción)
**Paraguay Presence**: Yes — PY-native operator

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Nora Viviana Fuentes SA (trading as Inflight Catering / Inflight Group) | [DNCP](https://www.contrataciones.gov.py/proveedor/nora-viviana-fuentes-sa.html) | Confirmed |
| Tax ID / RUC | 1684979-5 (Nora Viviana Fuentes SA) | DNCP | Confirmed |
| DNCP Registration | 7 July 2016 | DNCP | Confirmed |
| HQ Address | Not published on website | No source | Unknown |
| Founded | ~2014–2016 (website states "almost a decade" as of ~2024) | [inflight.com.py](https://inflight.com.py/?page_id=227) | Estimated |
| Founders | Likely Nora Viviana Fuentes (sole director of legal entity) | DNCP | Estimated |
| Ownership | Likely founder-owned (individual SA) | DNCP | Estimated |
| Employee Count | Not disclosed; estimated 20–60 (premium catering niche) | Proxy | Estimated proxy |
| Revenue — PY | Not disclosed; Dinatran contract (G. 400M) + Cultura SNC contract (G. per contract 2021) — small government contracts; main revenue likely private aviation + premium corporate | DNCP; Cultura PY | Estimated |
| Profitability | Unknown | No source | Unknown |
| Last Funding Round | None identified | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — private aviation + premium corporate catering + events | inflight.com.py | Confirmed |
| Sub-Verticals Served | Private aviation (jets, helicopter), corporate catering, events (fairs, congresses, presidential summits), courier international (Inflight Box) | inflight.com.py | Confirmed |
| Countries Active | Paraguay (Asunción) — international aspirations via Inflight Box | inflight.com.py | Confirmed |
| Notable PY Customers | Dinatran (G. 400M catering contract); Secretaría Nacional de Cultura (2021); presidential summits and international fairs | DNCP; Cultura PY; inflight.com.py | Confirmed |
| Government / Institutional | G. 400M Dinatran contract; SNC 2021 contract; state-event catering | DNCP; ABC Color | Confirmed |
| Market Share — PY | Niche premium private aviation caterer; not industrial scale | inflight.com.py | Estimated |
| Awards / Certifications | None cited publicly | No source | Unknown |
| Sustainability | None identified | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Private aviation catering; corporate catering (events, meetings); event management (congresses, summits, fairs); Inflight Box (international courier/shopping) | inflight.com.py | Confirmed |
| Menu Philosophy | "Making the ordinary extraordinary"; premium quality positioning | inflight.com.py | Confirmed |
| Cold-Chain & Logistics | Unknown — private aviation requires strict temperature control | No source | Unknown |
| Internal Tech Stack | Unknown | No source | Unknown |
| End-Customer App | None identified | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Yes — Nora Viviana Fuentes SA (individual-named entity) | DNCP | Confirmed |
| PE or VC Backed | No | No source | Estimated |
| Government-Related | No | No source | Estimated |
| Founder Still Active | Likely — company is ~10yr old and actively contracting | DNCP | Estimated |
| Group Structure | Part of "Inflight Group" (portfolio of services: catering + courier) | inflight.com.py | Confirmed |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Unknown; government contracts small (G. 400M Dinatran); private aviation is main revenue | No source | Unknown |
| Geographic Expansion (3yr) | Inflight Box = international expansion aspiration (courier for purchases abroad) | inflight.com.py | Estimated |
| Acquisitions (3yr) | None | No source | Unknown |
| Currency Exposure | PYG (govt) + USD (private aviation clients) | No source | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Private aviation catering (niche premium) | inflight.com.py | Confirmed |
| Vertical Breadth | 3: aviation, corporate events, courier | inflight.com.py | Confirmed |
| Food Safety | Private aviation catering requires strict food safety; formal certification unknown | Industry standard | Estimated |
| Fiscal e-Invoicing | SET e-Kuatia as DNCP provider | DNCP | Estimated |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Per-event / per-flight; project-based premium pricing | inflight.com.py | Estimated |
| Price Range | Private aviation: USD 100–500/flight meal; corporate events: USD 30–150/pax | Proxy | Estimated proxy |
| Estimated Revenue | USD 200K–800K/yr (niche; private aviation limited at ASU) | Proxy | Estimated proxy |
| Estimated Acquisition Value | USD 300K–1.5M (small premium niche; individual-owned) | Benchmark | Estimated proxy |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG + USD | No source | Estimated |
| Public-Sector Dependence | Low (Dinatran + SNC = small portion of revenue; primarily private aviation) | DNCP | Estimated |
| Cross-Border | PY-only; Inflight Box aspiration | inflight.com.py | Estimated |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | PY-native; ~10yr Asunción operation | DNCP |
| LATAM regional reach | Medium | Both | **1** | PY-only | inflight.com.py |
| Competitive overlap | High | Competition | **1** | Premium aviation operator; no tech overlap | inflight.com.py |
| Customer-fit potential | High | Customer | **2** | Too small and niche (private aviation) for SolStein's institutional catering IT platform | inflight.com.py |
| Scale | Medium | Both | **1** | Micro-player; estimated USD 200–800K revenue | Proxy |
| Tech modernity | Medium | Both | **1** | No digital tools identified | No source |
| Acquisition / partnership | Low | Strategic | **3** | Founder-owned individual SA; small; acquirable but not strategically valuable | DNCP |
| Growth trajectory | Low | Both | **2** | Unknown; premium niche has growth ceiling at ASU airport volume | Proxy |

**Competition Composite**: (1×2 + 5×1 + 1×1 + 1×1) / 5 = **1.8** / 5.0
**Customer Composite**: (2×2 + 5×1 + 1×1 + 2×1) / 5 = **2.4** / 5.0
**Overall Landscape Composite**: (5+1+1+2+1+1+3+2) / 8 = **2.0** / 5.0
**Confidence Band**: Wide (~30% Confirmed)

**Overall Landscape Assessment**:
Inflight Catering is a small PY-native private aviation and premium events caterer with limited relevance to SolStein's core institutional meal-service platform. The private aviation niche is too small and specialized to justify SolStein IT investment. No competitive overlap. The government contracts identified are small one-off event catering, not institutional feeding. Low priority for both customer and competitive tracking.

**Recommended Next Step**: **De-prioritise** — too small and niche for SolStein's target segment. Note as reference for PY catering landscape map. If SolStein adds an aviation catering module, revisit.

**Primary Tier**: **Tier 3** (Overall 2.0 — reference only)
