# Deep Analysis — GCG Paraguay (Goddard Catering Group / LSG Group)

**Research Date**: 2026-05-04
**Player Type**: Operator (airline catering + institutional — HACCP-certified industrial scale)
**Confidence Level**: Medium (public GCG website + DNCP confirmed; revenue not public; LSG Group parent details limited)
**Geographic Footprint**: Paraguay (ASU base); part of LSG Group global network (60+ countries)
**Paraguay Presence**: Yes — full operations, 300-person team, industrial plant at Silvio Pettirossi Airport

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity (local) | Goddard Catering Group Paraguay S.A. | [DNCP](https://contrataciones.gov.py/proveedor/goddard-catering-group-paraguay-sa.html) | Confirmed |
| Legal Entity (parent) | GCG (Goddard Catering Group) — part of LSG Group (Lufthansa Service Gesellschaft) | [LSG Group](https://www.lsg-group.com/location/asuncion-asu/) | Confirmed |
| Tax ID / RUC | 80026071-6 | DNCP provider record | Confirmed |
| HQ Address (PY) | Antigua Terminal Aérea, Luque, Departamento Central, Paraguay | DNCP | Confirmed |
| HQ Address (global) | LSG Group HQ: Neu-Isenburg, Germany (Lufthansa-heritage; acquired by HNA Group 2019) | lsg-group.com | Estimated |
| Founded — PY ops | 1997 | [gcggroup.com/country/paraguay](https://gcggroup.com/country/paraguay/) | Confirmed |
| Key Leadership (PY) | Juan Pedro Lolas Escarate (legal representative) | DNCP | Confirmed |
| Ownership | GCG is part of LSG Group — owned by HNA Group (Chinese conglomerate) since 2020 acquisition from Lufthansa | Press; lsg-group.com | Estimated |
| Investor Type | Strategic (Chinese conglomerate HNA Group → Lufthansa Services Gesellschaft legacy) | LSG Group corporate | Estimated |
| Employees — PY | ~300 | [gcggroup.com/country/paraguay](https://gcggroup.com/country/paraguay/) | Confirmed |
| Employees — LATAM | LSG Group: ~27,000 globally; PY-specific = 300 | lsg-group.com | Confirmed |
| Revenue — PY | Not disclosed; proxy: 230,000 meals/yr × USD 8–15/meal = USD 1.8–3.5M/yr (conservative airline catering price) | Proxy | Estimated proxy |
| Revenue — LATAM/Global | LSG Group: ~EUR 3B+ globally (2019 pre-COVID); PY segment not disclosed | LSG Group annual report | Estimated |
| Profitability | Unknown for PY entity; COVID severely impacted airline catering globally | No source | Unknown |
| Last Funding Round | N/A — wholly owned subsidiary of LSG Group | — | — |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — airline catering (primary) + institutional + corporate | gcggroup.com | Confirmed |
| Sub-Verticals Served | Airline/aviation, institutional (schools/industry/ground transport), corporate dining | gcggroup.com; La Nación PY | Confirmed |
| Countries Active | Paraguay (own operation) + 60+ countries via LSG Group global network | lsg-group.com | Confirmed |
| Annual Meal Volume | 230,000+ meals/year (PY operation) ≈ ~630 meals/day average; but 5,000 meals/day peak capacity stated | gcggroup.com | Confirmed |
| Active Airline Clients (PY) | 19 clients since 1997; serving TAM, Copa Airlines, Air Europa, Gol, Avianca, and others | gcggroup.com | Confirmed |
| Notable PY Customers | All major carriers at Silvio Pettirossi Airport (ASU) | gcggroup.com | Confirmed |
| Government / Institutional | DNCP registered — institutional catering contracts (schools, industry) | DNCP | Confirmed |
| Market Share — PY | #1 in airline catering at ASU airport — monopoly position; ~1 of 2 industrial caterers for institutional | gcggroup.com | Confirmed |
| Awards / Certifications | HACCP; BPM (DINAVISA PY); LEAN; HSSE (Health, Safety, Security, Environment) | gcggroup.com | Confirmed |
| Sustainability Claims | HSSE certification; LSG Group has global sustainability framework | gcggroup.com | Estimated |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Sky dining (airline meal production), institutional catering (schools, industry, transport), airport dining, corporate catering | gcggroup.com | Confirmed |
| Menu Philosophy | Airline: portion-controlled, allergen-managed, multi-cuisine; Institutional: nutrition-led, HACCP-compliant | gcggroup.com | Confirmed |
| Cold-Chain & Logistics | 7 refrigerated trucks + 4 commissary trucks + 5 vans; 16,400 m² industrial park with cold rooms and freezers | gcggroup.com | Confirmed |
| Internal Tech Stack | LSG Group enterprise systems (SAP likely for global operations); local PY systems unknown | No specific source | Unknown |
| End-Customer App / Portal | None identified for PY institutional clients | No source | Unknown |
| Meal-Voucher Card Integration | None identified | No source | Unknown |
| Capital Investment | US$5M plant expansion/renovation (2016) | La Nación PY 2016 | Confirmed |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | No — wholly owned by LSG Group / GCG network | lsg-group.com | Confirmed |
| PE or VC Backed | HNA Group (Chinese conglomerate) — controlling shareholder of LSG Group since 2020 | LSG Group corporate | Estimated |
| Government-Related Shareholders | HNA Group has Chinese state-adjacent ownership structure | No direct source | Unknown |
| Founder Still Active | N/A — multinational subsidiary | — | — |
| Succession Signal | N/A — HQ-controlled | — | — |
| PE Exit Horizon | HNA Group restructuring (2020–2023 financial difficulties); potential divestiture of non-core units | Press | Estimated |
| Family-Owned Dynamics | N/A | — | — |
| Group Structure | Subsidiary of GCG (Goddard Catering Group) → member of LSG Group; HNA Group is majority LSG shareholder | lsg-group.com | Confirmed |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Unknown for PY; global LSG Group severely impacted by COVID (2020–2022): revenue fell ~70%; recovery 2023–2025 | LSG Group press | Estimated |
| Employee Growth YoY | 300 PY employees (current stable); COVID likely caused temporary reductions | gcggroup.com | Estimated |
| Geographic Expansion (3yr) | No new PY expansion; global LSG Group has network in 60+ countries | No source | Unknown |
| Service Launches (2yr) | Institutional catering expansion (schools, industry) added beyond airline segment | gcggroup.com | Confirmed |
| Acquisitions (3yr) | None identified for PY entity | No source | Unknown |
| Funding Rounds (3yr) | N/A — wholly owned | — | — |
| Currency Exposure | USD-linked (airline contracts typically in USD); PYG for local institutional | gcggroup.com | Estimated |
| Plant Investment (2016) | US$5M plant expansion — long-term signal of commitment to PY | La Nación PY | Confirmed |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Airline catering (aviation) — core; institutional secondary | gcggroup.com | Confirmed |
| Vertical Breadth | 3: airline, institutional (schools/industry/ground transport), corporate | gcggroup.com | Confirmed |
| Food Safety Compliance | HACCP (international standard); BPM (DINAVISA PY — local regulatory); HSSE | gcggroup.com | Confirmed |
| Fiscal e-Invoicing | SET e-Kuatia as DNCP provider — assumed compliant | DNCP | Estimated |
| Allergen / Dietary | Yes — airline catering requires full allergen management; multi-dietary (Kosher, Halal, vegan, diabetic) | Industry standard | Confirmed |
| Voucher / Benefit Integrations | None identified | No source | Unknown |
| Payment Integrations | USD direct with airlines; PYG for local | No source | Estimated |
| Delivery Integrations | Own refrigerated fleet (11 vehicles) | gcggroup.com | Confirmed |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Cost-plus for airlines (per tray/meal); cost-plus for institutional contracts | Industry standard | Estimated |
| Price Range | Airline: USD 8–25/meal; Institutional: USD 3–8/meal; PY institutional: G. 8,000–20,000/meal | Proxy | Estimated proxy |
| Recurring vs Project | >90% recurring — long-term airline contracts (typically 2–5yr); institutional contracts 1–3yr | Industry standard | Estimated |
| Estimated Revenue (PY) | USD 2–4M/yr (230,000 annual meals × USD 8–15 blended avg) — plus institutional supplement | Proxy | Estimated proxy |
| Comparable M&A | LSG Group sold 100+ locations globally during COVID restructuring | Press | Estimated |
| Estimated Acquisition Value | N/A — HQ-controlled subsidiary; PY entity not independently acquirable without LSG Group consent | — | — |
| Services vs Product Split | 100% services | — | Confirmed |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | USD (airlines) + PYG (local institutional); no inflation exposure | gcggroup.com | Estimated |
| Cross-Border PY | Part of LSG Group LATAM regional network (AR, BR, UY, CL have GCG/LSG operations) | lsg-group.com | Estimated |
| Itaipú / Yacyretá Exposure | No identified tender in binational camp catering | No source | Unknown |
| Public-Sector Dependence | Low — airline is primary (private sector); institutional supplementary | DNCP | Estimated |
| Mining / Agri Camp | None identified | No source | Unknown |
| US / European Strategic Parent | LSG Group (Lufthansa-heritage) — German corporate governance | lsg-group.com | Confirmed |
| Family Conglomerate | HNA Group (Chinese conglomerate parent) — complex ownership, financial restructuring 2020–2023 | Press | Estimated |
| ESG / Sustainability | LSG Group has global HSSE and sustainability program | lsg-group.com | Confirmed |
| Local Content | DNCP-registered; PY entity operates locally; partially counts as local supplier | DNCP | Confirmed |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | 300-person team at ASU airport; 27yr PY operations; DNCP registered | DNCP; gcggroup.com |
| LATAM regional reach | Medium | Both | **5** | LSG Group: 60+ countries; GCG network spans all major LATAM aviation hubs | lsg-group.com |
| Competitive overlap | High | Competition | **1** | Operator (aviation catering), not tech-vendor; zero product overlap with SolStein | gcggroup.com |
| Customer-fit potential | High | Customer | **3** | Multi-site, multi-client operation with complex logistics, allergen management, billing — genuine IT need; but LSG Group likely imposes global ERP (SAP); local IT autonomy limited | gcggroup.com |
| Scale | Medium | Both | **3** | 300 employees, 230,000 meals/yr, 5,000/day capacity, US$5M plant — mid-scale operator; globally significant parent | gcggroup.com |
| Tech modernity | Medium | Both | **3** | HACCP/LEAN systems in place; LSG Group likely uses enterprise tech; PY local IT stack unknown but institutional clients may use paper | gcggroup.com |
| Acquisition / partnership feasibility | Low | Strategic | **1** | HNA Group-owned subsidiary; no independent acquisition possible; HQ-controlled | lsg-group.com |
| Growth trajectory | Low | Both | **3** | COVID hurt (2020–2022); airline recovery 2023–2025; institutional catering expansion adds growth; stable long-term | Press |

**Competition Composite**: (1×2 + 5×1 + 3×1 + 3×1) / 5 = **2.4** / 5.0
**Customer Composite**: (3×2 + 5×1 + 3×1 + 3×1) / 5 = **3.4** / 5.0
**Overall Landscape Composite**: (5+5+1+3+3+3+1+3) / 8 = **3.0** / 5.0
**Confidence Band**: Medium (~45% Confirmed)

**Overall Landscape Assessment**:
GCG Paraguay is the dominant and sole industrial-scale airline caterer at ASU airport, operating since 1997 as part of the global LSG Group / GCG network (60+ countries). It has no competitive overlap with SolStein but represents a relevant potential customer for institutional catering IT — particularly allergen management, multi-client billing, and route logistics. However, as a multinational subsidiary, the PY entity has limited IT budget autonomy; global ERP decisions are made at GCG/LSG Group level. Acquisition is not feasible (HNA Group parent). The HNA Group's 2020–2023 financial restructuring creates some uncertainty about LSG Group's long-term commitment to non-core PY operations.

**Recommended Next Step**: **Monitor** — not a priority customer or partner in the short term. Track HNA Group restructuring for potential LSG Group PY divestiture signal. If SolStein develops airline-specific modules (inflight meal planning, allergen tracking), GCG PY becomes a relevant demonstration client.

**Primary Tier**: **Tier 1** (Overall 3.0 — PY active; strategic reference; low near-term action priority)
