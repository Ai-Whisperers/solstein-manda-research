# Deep Analysis — Organización Integral SRL

**Research Date**: 2026-05-04
**Player Type**: Operator (event management + protocol/ceremonial services + catering — primarily events, not institutional food)
**Confidence Level**: Medium (company website + ABC Color + Devex confirmed; financials not public)
**Geographic Footprint**: Paraguay (Asunción); international event coordination
**Paraguay Presence**: Yes — PY-native, 30+ year operation

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Organización Integral S.R.L. | [ointegral.com.py](https://ointegral.com.py/) | Confirmed |
| Website | ointegral.com.py | — | Confirmed |
| HQ Address | Asunción, Paraguay (exact address not published) | ointegral.com.py | Estimated |
| Founded | ~1990–1996 (30+ years of experience) | ointegral.com.py | Estimated |
| Director General | Rugel Alberto Ferreira | [ABC Color](https://www.abc.com.py/politica/2024/06/11/el-estado-gasta-millones-por-servicio-de-catering/) | Confirmed |
| Ownership | Likely founder-owned (Ferreira family) | No source | Estimated |
| Employee Count | Not disclosed; estimated 20–60 (event management firm) | Proxy | Estimated proxy |
| Revenue | Not disclosed; CSJ contract G. 300M (2024) is identified; other state event contracts | ABC Color | Estimated |
| Profitability | Unknown | No source | Unknown |
| Last Funding Round | None | No source | Unknown |
| International Partners | Devex lists as international events coordinator | [Devex](https://www.devex.com/organizations/organizacion-integral-s-r-l-131364) | Confirmed |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — event management + protocol services + food provision (catering is one component, not core) | ointegral.com.py | Confirmed |
| Sub-Verticals Served | International congresses, seminars, expositions, national and international meetings; presidential summits; catering as component of event services | ointegral.com.py | Confirmed |
| Countries Active | Paraguay (HQ); international event coordination scope | ointegral.com.py | Confirmed |
| Event Portfolio | 200+ events organized/coordinated in 30+ years | ointegral.com.py | Confirmed |
| Notable PY Customers | Corte Suprema de Justicia (CSJ, G. 300M contract 2024) | ABC Color | Confirmed |
| Government / Institutional | CSJ (G. 300M); likely other state entities for protocol events | ABC Color; DNCP | Confirmed |
| Market Share — PY | Niche — premium protocol/event management; not mass institutional catering | ointegral.com.py | Estimated |
| Awards / Certifications | None cited | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Integral event logistics: planning, ceremonial/protocol, tourism, social activities, audiovisual (sound, lights), simultaneous translation, decoration, catering (food + beverage as part of event) | ointegral.com.py | Confirmed |
| CSJ Contract Scope | "Logística ceremonial y protocolo" — guampas de plata para tereré, hamacas paraguayas, sujetacorbatas de plata, aros y pulseras de plata, bolsos artesanales + food items (embutidos, empanadas, sándwich, torta, café, gaseosas) | ABC Color | Confirmed |
| Menu Philosophy | Ceremonial and protocol-appropriate; not high-volume institutional feeding | CSJ contract | Confirmed |
| Internal Tech Stack | Unknown | No source | Unknown |
| End-Customer App | None identified | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Likely (Rugel Alberto Ferreira as Director General; 30+ yr company) | ABC Color | Estimated |
| PE or VC Backed | No | No source | Estimated |
| Founder Still Active | Rugel Alberto Ferreira identified as current Director General | ABC Color | Confirmed |
| Group Structure | Standalone SRL | ointegral.com.py | Estimated |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue | Unknown; G. 300M CSJ contract = ~USD 40K (small) | ABC Color | Confirmed |
| Estimated Annual Revenue | USD 200K–800K/yr (event management + catering fees) | Proxy | Estimated proxy |
| Geographic Expansion | No new country expansion identified | No source | Unknown |
| Currency Exposure | PYG + USD (international events) | No source | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Protocol/ceremonial event management (not institutional food service) | ointegral.com.py | Confirmed |
| Vertical Breadth | 5+ service lines: protocol, logistics, catering, audiovisual, translation, tourism | ointegral.com.py | Confirmed |
| Food Safety | N/A as primary focus — catering is a supplementary service | — | — |
| Fiscal e-Invoicing | SET e-Kuatia as formal SRL | No source | Estimated |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Per-event (bundled logistics + catering) | ointegral.com.py | Estimated |
| Estimated Revenue | USD 200K–800K/yr | Proxy | Estimated proxy |
| Estimated Acquisition Value | USD 200K–1M (event management brand + client relationships) | Benchmark | Estimated proxy |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Public-Sector Dependence | High (CSJ; likely other state entities for protocol events) | ABC Color | Estimated |
| Cross-Border | International event coordination scope | Devex | Estimated |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | PY-native, 30+ yr Asunción operation | ointegral.com.py |
| LATAM regional reach | Medium | Both | **2** | International event coordination but not LATAM food operations | Devex |
| Competitive overlap | High | Competition | **1** | Event management + protocol; not food IT; no overlap | ointegral.com.py |
| Customer-fit potential | High | Customer | **1** | Event management is not SolStein's core target segment; catering is ancillary, not industrial | ointegral.com.py |
| Scale | Medium | Both | **1** | Micro-player; USD 200–800K revenue | Proxy |
| Tech modernity | Medium | Both | **1** | No digital tools identified | No source |
| Acquisition / partnership | Low | Strategic | **2** | Founder-owned; too small; wrong vertical for SolStein | No source |
| Growth trajectory | Low | Both | **2** | 200+ events in 30yr = stable but slow; not scaling | ointegral.com.py |

**Overall Landscape Composite**: (5+2+1+1+1+1+2+2) / 8 = **1.9** / 5.0
**Confidence Band**: Medium (~45% Confirmed)

**Overall Landscape Assessment**:
Organización Integral is a respected 30-year PY event management and protocol company — Paraguay's equivalent of a PCO (Professional Congress Organizer). Catering is a supplementary service within their event logistics offering, not an institutional food service operation. Zero competitive overlap with SolStein and minimal customer-fit relevance. Low priority for the landscape map.

**Recommended Next Step**: **De-prioritise** — event management/protocol is outside SolStein's institutional catering IT scope. Keep as reference for PY government/event sector landscape.

**Primary Tier**: **Tier 3** (Overall 1.9 — reference only)
