# Deep Analysis — Ladero Paraguayo SA

**Research Date**: 2026-05-04
**Player Type**: Operator (institutional caterer — school feeding dominant)
**Confidence Level**: Medium (DNCP contract data confirmed; internal financials and ownership structure thin)
**Geographic Footprint**: Paraguay
**Paraguay Presence**: Yes — headquartered, all operations in PY

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Ladero Paraguayo S.A. | [DNCP](https://contrataciones.gov.py/proveedor/ladero-paraguayo-s-a.html) | Confirmed |
| Tax ID / RUC | 80018240-5 | DNCP provider record | Confirmed |
| HQ Address | Lambaré, Departamento Central, Paraguay | DNCP | Confirmed |
| Founded | 1998 (as consultancy); food specialization from 2009 | [ladero.com.py/nosotros](http://www.ladero.com.py/nosotros) | Confirmed |
| Key Leadership | Osvaldo Jean Pujol; Cándido Iván Da Silva Báez; Derlis Iván Espinola Galeano; José Luis Aquino; Hugo Cáceres; María Cristina Rivas | DNCP | Estimated |
| Ownership Structure | Founder-owned / private SA — no PE or public listing identified | No external source | Unknown |
| Employee Count — PY | ~30+ core staff + seasonal field workforce | ladero.com.py | Estimated |
| Employee Count — LATAM | PY-only | ladero.com.py | Estimated |
| Revenue — PY (historical) | G. 457.870B cumulative (2010–2022) = ~USD 65–72M over 12yr = avg ~USD 5–6M/yr | [El Independiente](https://independiente.com.py/ladero-paraguayo-el-zar-del-almuerzo-escolar/) | Estimated |
| Revenue — PY (2019 peak) | G. 59.639B (~USD 8.6M) — 40 contracts | El Independiente | Estimated |
| Revenue — PY (2020 peak) | G. 111.723B (~USD 16.2M) — 34 contracts — largest single year | El Independiente | Estimated |
| Profitability | Unknown; consistent multi-year govt contract wins suggest profitability | No source | Unknown |
| Last Funding Round | None identified — bootstrapped | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — institutional school feeding and corporate catering | ladero.com.py | Confirmed |
| Sub-Verticals Served | School feeding (primary), corporate catering, events, dietary services | ladero.com.py | Confirmed |
| Countries Active | Paraguay only | ladero.com.py | Confirmed |
| DNCP Contracts Won | 264 licitaciones since 2010 — largest DNCP contract count in school feeding sector | El Independiente | Estimated |
| Notable PY Customers | Multiple gobernaciones (Paraguarí, San Pedro, Cordillera), multiple municipalidades, MEC-linked school programs | El Independiente; ABC Color | Confirmed |
| Government / Institutional | G. 457.870B (~USD 65M) total since 2010; avg 22 contracts/yr | El Independiente | Estimated |
| Market Share — PY | Estimated #1 by DNCP contract volume/count (264 wins) — exceeds Comepar's contract count; lower per-unit revenue than Hambre Cero | El Independiente | Estimated |
| Awards / Certifications | Unknown — no HACCP or ISO certification cited in public sources | No source | Unknown |
| Sustainability Claims | None identified | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | School lunch (almuerzo escolar), corporate catering, events, dietary consulting | ladero.com.py | Confirmed |
| Menu Philosophy | Institutional nutrition-focused; seasonal menus for school programs | ladero.com.py | Estimated |
| Cold-Chain & Logistics | Unknown — likely own fleet given multi-departamento coverage | No source | Unknown |
| Internal Tech Stack | Unknown — no ERP or management system identified in public sources | No source | Unknown |
| End-Customer App / Portal | None identified | No source | Unknown |
| Meal-Voucher Card Integration | None identified | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Likely — multiple legal representatives suggest family/partners structure | DNCP | Estimated |
| PE or VC Backed | No | No source | Estimated |
| Government-Related Shareholders | Unknown | No source | Unknown |
| Founder Still Active | Multiple representatives active (Pujol, Da Silva, Espínola, Aquino) | DNCP | Confirmed |
| Succession Signal | No signal | No source | Unknown |
| PE Exit Horizon | N/A | — | — |
| Family-Owned Dynamics | Likely multi-partner family/associate structure; 5+ legal reps | DNCP | Estimated |
| Group Structure | Standalone — no parent identified | No source | Unknown |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | 2019: G. 59.6B; 2020: G. 111.7B (+87%); 2021: G. 41.0B (-63%) — volatile, contract-cycle driven | El Independiente | Estimated |
| Employee Growth YoY | Unknown multi-year | No source | Unknown |
| Geographic Expansion (3yr) | None — PY-only | No source | Estimated |
| Service Launches (2yr) | None identified | No source | Unknown |
| Acquisitions (3yr) | None identified | No source | Unknown |
| Funding Rounds (3yr) | None | No source | Unknown |
| Currency Exposure | PYG (government contracts); USD not used | DNCP | Confirmed |
| Tender Win Rate | 264 wins since 2010 = very high; exact bid-to-win ratio unknown | El Independiente | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | School feeding (almuerzo escolar) — dominant | DNCP; El Independiente | Confirmed |
| Vertical Breadth | 3: school, corporate, events | ladero.com.py | Confirmed |
| Food Safety Compliance | INAN (PY) required for food providers — status unknown | No specific source | Unknown |
| Fiscal e-Invoicing | SET e-Kuatia required as DNCP provider — assumed compliant | DNCP | Estimated |
| Allergen / Dietary | Nutritionist staff mentioned — scope unknown | ladero.com.py | Estimated |
| Voucher / Benefit Integrations | None identified | No source | Unknown |
| Payment Integrations | Government direct payment (DNCP/treasury) | DNCP | Confirmed |
| Delivery Integrations | None identified | No source | Unknown |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Cost-plus public tender; private corporate per-headcount | DNCP (contract values public) | Confirmed |
| Price Range | School: ~G. 5,000–15,000/meal (DNCP benchmark range); corporate: higher | DNCP tender values | Estimated |
| Recurring vs Project | ~80% government contract (multi-year with gobernaciones/municipalidades) | DNCP | Estimated |
| Estimated Revenue (current) | USD 3–8M/yr (post-Hambre Cero; Comepar now dominates that program) | Proxy from DNCP + press | Estimated proxy |
| Comparable M&A | No LATAM school-feeding M&A identified at this scale | No source | Unknown |
| Estimated Acquisition Value | USD 5–15M (1–2× revenue proxy; school feeding asset-light operator) | Benchmark | Estimated proxy |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG only — all government contracts in local currency | DNCP | Confirmed |
| Cross-Border | PY-only | No source | Confirmed |
| Itaipú / Yacyretá Exposure | None identified | No source | Unknown |
| Public-Sector Dependence | Very High — estimated >90% of revenue from DNCP public tenders | El Independiente | Estimated |
| Mining / Agri Camp | None identified | No source | Unknown |
| US / European Parent | None | No source | Confirmed |
| Family Conglomerate | None identified | No source | Unknown |
| ESG / Sustainability | None identified | No source | Unknown |
| Local Content / Nationalization | Registered PY supplier; DNCP local-supplier preference applies | DNCP | Confirmed |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | HQ in Lambaré, PY; all 264 contracts with PY public entities; 100% PY | DNCP |
| LATAM regional reach | Medium | Both | **1** | PY-only; no LATAM operations | ladero.com.py |
| Competitive overlap | High | Competition | **1** | Operator, not tech-vendor; zero product overlap with SolStein | ladero.com.py |
| Customer-fit potential | High | Customer | **4** | 264 DNCP contracts = very large institutional caterer with complex logistics/billing; strong IT system need; likely under-digitized | El Independiente |
| Scale | Medium | Both | **3** | USD 5–16M/yr government revenue; large by PY standards; micro by LATAM | El Independiente |
| Tech modernity | Medium | Both | **1** | No app, no ERP, no digital system identified; 100% paper/Excel likely | No source |
| Acquisition / partnership feasibility | Low | Strategic | **4** | Multi-partner family structure; no PE; PY-only; likely under USD 20M; no succession visible but feasible | DNCP |
| Growth trajectory | Low | Both | **2** | Volatile contract revenue; 2020 peak not sustained; Comepar Hambre Cero win likely displaced Ladero | El Independiente |

**Competition Composite**: (1×2 + 5×1 + 3×1 + 1×1) / 5 = **2.0** / 5.0
**Customer Composite**: (4×2 + 5×1 + 1×1 + 2×1) / 5 = **3.2** / 5.0
**Overall Landscape Composite**: (5+1+1+4+3+1+4+2) / 8 = **2.6** / 5.0
**Confidence Band**: Medium (~40% Confirmed data points)

**Overall Landscape Assessment**:
Ladero Paraguayo is Paraguay's highest-volume school-feeding operator by DNCP contract count (264 licitaciones since 2010), making it a very relevant potential customer for SolStein's institutional catering IT platform. It has zero competitive overlap with SolStein (operator, not tech vendor). The company is extremely government-dependent (>90% DNCP revenue) and almost certainly operates with no modern back-office IT system, creating a clear SolStein sales opportunity. The biggest risk is revenue volatility — Comepar's Hambre Cero dominance in 2024 likely displaced Ladero from its peak 2020 contract level, reducing budget for IT investment.

**Recommended Next Step**: **Approach as customer** — Ladero's 264-contract history with multiple gobernaciones and municipalidades requires complex contract management, route planning, and nutritional compliance. SolStein's platform addresses exactly this pain. Outreach via APICAL or ARPY industry events; alternatively via Cámara de Alimentación Escolar del Paraguay (CAEP) contacts.

**Primary Tier**: **Tier 1** (Customer Composite 3.2 — active PY customer prospect; Overall 2.6)
