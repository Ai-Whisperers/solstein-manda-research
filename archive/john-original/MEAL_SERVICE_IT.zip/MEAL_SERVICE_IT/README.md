# MEAL_SERVICE_IT — LATAM Meal Service Candidate Pipeline

**Last Updated**: 2026-05-04 (All Tier 1 deep-analyses complete: 12 companies researched)
**Total Candidates**: 44
**Tier 1 (PY Active/Native)**: 15  |  **Tier 2 (LATAM-Wide)**: 19  |  **Tier 3 (Reference)**: 10

---

## Candidate Table

| Company | Player Type | Country | PY Presence | Tier | How Found | Research Status |
|---|---|---|---|---|---|---|
| **Comepar SA** | Operator | PY | Native | 1 | Press (Infonegocios, ABC Color) + DNCP registry | Complete — full triplet (deep-analysis + corporate-history + financial-growth 2026-05-04) |
| **Ladero Paraguayo SA** | Operator | PY | Native | 1 | Press (Infonegocios) + DNCP registry | Complete (deep-analysis.md 2026-05-04) |
| **MyM Alimentos Corporativos** | Operator | PY | Native | 1 | Press (Infonegocios) + web search | Complete (deep-analysis.md 2026-05-04) — PY presence unconfirmed |
| **Talleyrand** | Operator | PY | Native | 1 | Press (Infonegocios) + ARPY member list | Complete (deep-analysis.md 2026-05-04) |
| **Masapan** | Hybrid | PY | Native | 1 | Press (Infonegocios) + event: ARPY | Complete (deep-analysis.md 2026-05-04) |
| **Espy's Catering** | Operator | PY | Native | 1 | Web search (catering Asunción) | Pending |
| **La Esperanza Servicios de Lunch** | Operator | PY | Native | 1 | Web search (catering Paraguay) | Complete (deep-analysis.md 2026-05-04) |
| **E-karú / Netsystem SA** | Tech-vendor | PY | Native | 1 | Press (Infonegocios, Revista CAP) | Complete — full triplet (deep-analysis + corporate-history + financial-growth 2026-05-04) |
| **Mr. Comanda / MRC Software** | Tech-vendor | AR/PY | Active | 1 | Press (Infonegocios) + web search | Complete — full triplet (deep-analysis + corporate-history + financial-growth 2026-05-04) |
| **Teknisa / TecFood** | Tech-vendor | BR | Unknown | 2 | Web search (B2B meal SaaS LATAM) | Pending |
| **Cookep** | B2B-Meal-as-a-Service | LATAM (CL base) | Unknown | 2 | Web search (SaaS catering colectiva LATAM) | Pending |
| **CookFlow** | Tech-vendor | LATAM | Unknown | 2 | Web search (SaaS catering colectiva LATAM) | Pending |
| **OrderEAT** | Tech-vendor | UY | Unknown | 2 | Award: Descubre VC; press (Wired, FoodNewsLatam) | Pending |
| **Fudu Company** | B2B-Meal-as-a-Service | AR | Unknown | 2 | Web search (viandas empresas LATAM) | Pending |
| **Foodology** | Ghost-kitchen | CO | Unknown | 2 | VC-db: Tracxn; Endeavor network | Pending |
| **Kitchenita** | Ghost-kitchen | AR | Unknown | 2 | VC-db: Tracxn + LatamList | Pending |
| **Frubana** | Marketplace | CO | Unknown | 2 | VC-db: Endeavor; Y Combinator | Pending |
| **Delly's** | Operator | BR | Unknown | 2 | Award: LAVCA 2025 Deal of the Year | Pending |
| **Greentable** | B2B-Meal-as-a-Service | BR | Unknown | 2 | Press: FoodBiz + Pipeline/Valor (BR Angels round) | Pending |
| **Nutriser** | Operator | CL | Unknown | 2 | Web search (catering campamento minería LATAM) | Pending |
| **ATA Alimentaria** | Operator | AR | Unknown | 2 | Web search (alimentación campamento minería Paraguay) | Pending |
| **Clicampo** | Marketplace | BR | Unknown | 2 | VC-db: IDB Lab portfolio; AgFunderNews | Pending |
| **Magnífica Food** | Operator | BR | Unknown | 2 | Web search (catering colectiva B2B Brazil) | Pending |
| **iFood Empresas / iFood Benefícios** | Canteen-card-platform | BR | Unknown | 3 | Press: Abrasel + ClienteSA (iFood B2B launch) | Pending |
| **Edenred (Ticket Restaurant / Alimentación)** | Canteen-card-platform | FR/LATAM | Mercosur | 3 | Web search (meal voucher LATAM Paraguay) | Pending |
| **Foody** | Aggregator | CO | Unknown | 3 | VC-db: Tracxn | Pending |
| **CaterUs** | Operator | AR | Unknown | 3 | VC-db: Tracxn | Pending |
| **Los Chefes** | Marketplace | MX | Unknown | 3 | VC-db: Tracxn | Pending |
| **FoodRise Hub** | Tech-vendor | UY | Active | 3 | Award: IDB Lab + Eatable Adventures (PY in scope) | Pending |
| **GCG Paraguay (Goddard Catering Group / LSG Group)** | Operator | Multinational/PY | Active | 1 | DNCP registry (contrataciones.gov.py); lsg-group.com; La Nación PY; El Omnívoro | Pending |
| **Grupo Altair SA** | Operator | PY | Native | 1 | DNCP registry; ABC Color; El Independiente PY; RCC | Complete (deep-analysis.md 2026-05-04) |
| **Alimentos y Servicios SRL (Todo Rico)** | Operator | PY | Native | 1 | DNCP registry (RUC 80022202-4); ABC Color 2024; ARPY member list | Complete (deep-analysis.md 2026-05-04) |
| **Inflight Catering (Inflight Group PY)** | Operator | PY | Native | 1 | DNCP registry; inflight.com.py; Secretaría Nacional de Cultura contract 2021 | Pending |
| **Procard SA (LunchCard)** | Canteen-card-platform | PY | Native | 1 | Web search (procard.com.py); PY-specific meal benefit product | Complete (deep-analysis.md 2026-05-04) |
| **Organización Integral SRL** | Operator | PY | Native | 1 | DNCP registry; ointegral.com.py; CSJ contract G. 300M 2024 | Pending |
| **Vloki** | Tech-vendor | CO | Mercosur | 2 | Web search (gestión comedores industriales LATAM 2025) | Pending |
| **Worki360** | Tech-vendor | LATAM | Unknown | 2 | Web search (ERP comedor LATAM IA payroll integration 2025) | Pending |
| **Genera (GenCasino)** | Tech-vendor | CL | Unknown | 2 | Web search (control casino comedor software Chile LATAM 2025) | Pending |
| **ManduHR (by Visma)** | Tech-vendor | AR/LATAM | Unknown | 2 | Web search (comedor software RRHH LATAM); manduhr.com | Pending |
| **Wuplify** | Tech-vendor | LATAM | Unknown | 2 | Web search (catering software LATAM SaaS 2025); wuplify.com | Pending |
| **GeoVictoria** | Tech-vendor | AR/CL | Unknown | 2 | Web search (control comedor acceso software LATAM 2025) | Pending |
| **Pluxee (formerly Sodexo Benefits & Incentives)** | Canteen-card-platform | FR/LATAM | Mercosur | 3 | Web search (Sodexo Paraguay); Pluxee confirmed PE/CL/CO/BR — PY unconfirmed | Pending |
| **Aramark LATAM** | Operator | US/LATAM | Mercosur | 3 | Web search (Aramark Paraguay); confirmed AR (~1,500 staff, 6,000 meals/day) — PY unconfirmed | Pending |
| **Sudameris Bank (Gourmet Card)** | Canteen-card-platform | PY | Active | 3 | Web search (tarjeta alimentacion Paraguay); sudameris.com.py — bank-issued voucher, not dedicated platform | Pending |

---

## Discovery Run Log

| Run Date | Channels Used | New Candidates | Notes |
|---|---|---|---|
| 2026-05-04 | VC databases (Tracxn, Crunchbase, LAVCA, Endeavor, AgFunderNews, IDB Lab), Events (Gastronomik/ARPY PY, HORECA PY), Awards (LAVCA 2025, BR Angels, IDB Lab/FoodRise, Descubre VC), PY registries (DNCP, Infonegocios, ABC Color), LATAM trade press (FoodNewsLatam, FoodBiz, Horeca.com.py) | 29 | First run — fresh pipeline. PY channel strongest: 9 native/active candidates confirmed. Tech-vendor gap in PY (only E-karú and MRC Software identified natively). No PY-specific meal voucher/canteen-card platform found — Edenred present in Mercosur but not confirmed in PY. Camp catering vertical underserved: only Comepar and MyM confirmed active for construction/institutional; ATA Alimentaria (AR) is regional specialist worth monitoring. |
| 2026-05-04 | Deep-analysis research (web search per prompt Category 1–9) | 3 deep-analyses complete | Comepar SA (customer — Tier 1), E-karú/Netsystem SA (competitor + acquisition target — Tier 1), MRC Software (competitor — Tier 2). Key findings: Comepar = US$90–120M revenue, 3,000 staff, $30M plant, dominant PY school feeding; E-karú = 1,200 PY locations, likely USD 430K–860K ARR, acquirable; MRC = 36yr old AR-based, 5,000 LATAM clients, hybrid legacy architecture. |
| 2026-05-04 | Deep-analysis research on remaining 12 Tier 1 companies (web search per prompt Category 1-9) | 12 deep-analyses complete | **Ladero Paraguayo SA** (customer — #1 by DNCP contract count, 264 licitaciones, G.457B cumulative); **GCG Paraguay/LSG Group** (monitor — 300 staff, 5,000 meals/day, airline monopoly ASU, HNA Group parent); **Grupo Altair SA** (customer — 144 schools Concepcion, Hambre Cero participant, 2017 fast-grower); **Masapan** (deprioritise — small hybrid bakery/catering SME, app signal); **Talleyrand** (deprioritise — premium events, not institutional); **MyM Alimentos** (verify PY presence — no DNCP confirmation); **Todo Rico / Alimentos y Servicios** (secondary customer — 300 staff, 10 locations, wholesale arm); **Procard SA/LunchCard** (partner — 300K cards, 30K merchants, ISO 9001, integration opportunity); **Inflight Catering** (deprioritise — micro private aviation); **La Esperanza** (deprioritise — micro player); **Organizacion Integral** (deprioritise — protocol/events, not food); **Espy's Catering** (REMOVE — misidentified as PY; US-based Bolivian company). |
| 2026-05-04 | Corporate-history + financial-growth research (full triplet completion for Tier 1 top-3) | 6 files | **corporate-history.md** + **financial-growth.md** written for Comepar SA, E-karu/Netsystem SA, MRC Software. Key findings: **Comepar** - founded 2012 Cardona family; USD 90-100M est. revenue (2025); Growth Scorecard 4.9 "Steady"; digitalization 2/10 = confirmed SolStein IT gap. **E-karu/Innovasys** - Netsystem SA ~1993; E-karu cloud-native ~2013; USD 1.15M ARR; Scorecard 2.4 "Dinosaur" financially but modern product; acquisition window open. **MRC Software** - founded 1989 Cordoba AR; USD 5-6M ARR; Scorecard 2.3 "Dinosaur"; 37yr bootstrapped; hybrid legacy; PY via distributor only - compete not acquire. |
| 2026-05-04 | **Run #2 — Wide-Scan Discovery Refresh**: PY registries (DNCP/contrataciones.gov.py, ABC Color adjudications), ARPY member list, airline caterer research (LSG/GCG), PY press (ABC Color, La Nación, El Independiente, RCC, Correo Comercial), LATAM comedor software search, PY meal-card/voucher search, multinational confirmation scan (Sodexo/Pluxee, Aramark, Compass, ISS, Gate Gourmet/GCG, Scolarest), VC/accelerator scan (IDB Lab FoodRise cohort, Eatable Adventures) | 15 new candidates | **Most productive channels**: DNCP adjudications (found GCG PY, Grupo Altair, Alimentos y Servicios, Inflight Catering, Coesa); PY meal-card web search (Procard LunchCard — fills PY voucher whitespace); LATAM comedor-software search (Vloki, Worki360, Genera, ManduHR, Wuplify, GeoVictoria — entire new tech sub-category). **Multinational scan results**: GCG Paraguay = LSG Group entity confirmed Active in PY (airline + institutional); Sodexo/Pluxee = Mercosur but PY unconfirmed; Aramark = AR confirmed, PY unconfirmed; Compass/Eurest/Scolarest = no PY evidence (Compass AR sold to Grupo L 2023); ISS Food = no PY evidence. **Key new insight**: PY canteen-card market is bank-dominated (Procard, Sudameris, Itaú) — no dedicated fintech platform exists, confirming white space for a SolStein-adjacent solution. CAEP (Cámara de Alimentación Escolar del Paraguay) identified as industry body for school feeding operators. |

---

## Research Status Legend

| Status | Meaning |
|---|---|
| Pending | Identified; deep-analysis not started |
| In Progress | Deep-analysis running (`deep-analysis.md` partial) |
| Complete | Full triplet done: `deep-analysis.md` + `corporate-history.md` + `financial-growth.md` |
| Deprioritised | Reviewed; not a fit — document reason |

---

## Player-Type Coverage

| Type | Count | Companies |
|---|---|---|
| Operator | 16 | Comepar SA, Ladero Paraguayo SA, MyM Alimentos Corporativos, Talleyrand, Espy's Catering, La Esperanza Servicios de Lunch, Delly's, Nutriser, ATA Alimentaria, Magnífica Food, GCG Paraguay, Grupo Altair SA, Alimentos y Servicios SRL (Todo Rico), Inflight Catering, Organización Integral SRL, Aramark LATAM |
| Tech-vendor | 13 | E-karú/Netsystem SA, Mr. Comanda/MRC Software, Teknisa/TecFood, CookFlow, OrderEAT, FoodRise Hub, Clicampo, Vloki, Worki360, Genera (GenCasino), ManduHR (by Visma), Wuplify, GeoVictoria |
| Hybrid | 1 | Masapan |
| Aggregator | 1 | Foody |
| Ghost-kitchen | 2 | Foodology, Kitchenita |
| B2B-Meal-as-a-Service | 3 | Cookep, Fudu Company, Greentable |
| Canteen-card-platform | 5 | iFood Empresas/Benefícios, Edenred, Procard SA (LunchCard), Pluxee, Sudameris (Gourmet Card) |
| Marketplace | 2 | Frubana, Los Chefes |
| Unknown | 1 | CaterUs |

---

## Company Profiles (Quick Reference)

### Tier 1 — PY Active / Native (Research Immediately)

#### Comepar SA
- **Country**: Paraguay | **Headquarters**: Lugano, PY
- **Scale**: 3,000+ employees; 60,000+ meals/day capacity; 188+ public school institutions served
- **Verticals**: School feeding (public contracts), corporate catering (Petrobras, Banco Central PY), frozen retail (Madame Lunch brand)
- **Certs**: ISO 9001, ISO 22000, ISO 45000, HACCP, BPM, BPA
- **SolStein Relevance**: Largest PY catering operator; government-contracted; runs own brand Mil Platos for corporate B2B
- **Source**: Infonegocios PY; ABC Color (Hambre Cero coverage); DNCP adjudications

#### Ladero Paraguayo SA
- **Country**: Paraguay | **HQ**: Lambaré, Departamento Central
- **Founded**: 1998 (consulting), specialized food supply since 2009; 28 years total
- **Verticals**: Corporate meal delivery, institutional government clients (ministerios, gobernaciones, municipalidades), dietetic/therapeutic catering
- **DNCP Status**: Registered provider on contrataciones.gov.py
- **SolStein Relevance**: Confirmed DNCP supplier + institutional focus = target customer for meal-service IT
- **Source**: DNCP registry; web search; Infonegocios PY

#### MyM Alimentos Corporativos (M&M Alimentos y Servicios)
- **Country**: Paraguay
- **Verticals**: Empresas públicas y privadas, colegios/universidades, clínicas/hospitales, **constructoras y campamentos mineros**, embajadas
- **Staff**: Nutritionist team on staff
- **SolStein Relevance**: Covers camp catering vertical + has breadth across institutional sub-sectors
- **Source**: Web search; alimentosyserviciosmym.com

#### Talleyrand
- **Country**: Paraguay | **Founded**: 1976 (48 years)
- **Scale**: 3 event centers in PY; capacity up to 2,000 persons; 40+ years experience
- **Verticals**: Corporate catering, weddings, large events; Avda. Mariscal López flagship
- **ARPY**: Member of ARPY (Asociación de Restaurantes del Paraguay)
- **SolStein Relevance**: Established market leader PY; multi-site operations = IT management need
- **Source**: ARPY member list; Infonegocios PY; talleyrand.com.py

#### Masapan
- **Country**: Paraguay | **Founded**: 1993 (33 years)
- **Verticals**: Corporate catering (~10 events/day), coffee break, event catering; 180-person internal salon
- **Tech Signal**: Launched a mobile app (iOS + Android) for corporate clients to order weekly meal plans digitally
- **SolStein Relevance**: Operator with own digital ordering layer → competitor or integration candidate
- **Source**: Infonegocios PY; Google Play

#### Espy's Catering
- **Country**: Paraguay
- **Scale**: 1,500+ clients; 250+ events organized
- **Verticals**: Corporate events, social events; Asunción and Chaco PY
- **SolStein Relevance**: Mid-size operator; corporate focus
- **Source**: Web search (espyscatering.com)

#### La Esperanza Servicios de Lunch
- **Country**: Paraguay
- **Verticals**: Corporate cafeteria/canteen services, fresh food provision for companies, gastronomic events
- **SolStein Relevance**: Canteen/comedor model = classic IT-system need
- **Source**: Web search (paraguay.gugadir.com)

#### E-karú / Netsystem SA
- **Country**: Paraguay | **Type**: 100% PY-native tech vendor
- **Scale**: 1,200+ locations; 17,000+ users; 14 departamentos; 11+ years
- **Platform**: Cloud SaaS for restaurants — stock, costs, billing, HR, delivery, self-service, digital menu
- **SolStein Relevance**: Direct competitor in PY restaurant/foodservice software market
- **Source**: Infonegocios PY; Revista CAP; restaurante.com.py; innovasys.com.py

#### Mr. Comanda / MRC Software
- **Country**: Paraguay | **Type**: PY-native tech vendor
- **Scale**: 25+ years; 8,000+ licenses; 4-tier SaaS model (Free → Corporate)
- **Platform**: POS + restaurant management (tables, delivery, QR menu, inventory, payroll, e-invoicing); works offline
- **Markets**: Restaurants, casinos, bakeries, ice cream shops, retail
- **SolStein Relevance**: Direct PY competitor in foodservice POS/management software
- **Source**: Infonegocios PY; mrcomanda.com

#### GCG Paraguay (Goddard Catering Group / LSG Group)
- **Country**: Paraguay | **Type**: Multinational with confirmed PY operations | **Founded PY**: 1997
- **Scale**: 5,000+ meals/day; 300 employees; 19 clients; 16,400 m² industrial park at Silvio Pettirossi Airport; operates 24/7
- **Verticals**: Airline catering (Copa Airlines, TAM, Gol, Avianca, Air Europa), corporate institutional (Casa Gusto brand for companies, schools, hospitals), event catering, transport catering
- **Certs**: BPM (DINAVISA), HACCP, LEAN, HSSE, MADES environmental license
- **DNCP Status**: Registered provider on contrataciones.gov.py
- **Parent**: LSG Group (global airline caterer, formerly LSG Sky Chefs); GCG is the PY entity; 28 kitchens worldwide
- **Brand**: Casa Gusto (institutional/corporate brand) — registered trademark PY, May 2024
- **SolStein Relevance**: Largest confirmed PY catering operator with diversified institutional reach; direct customer prospect for meal management software; HACCP + multi-site ops = strong IT system need
- **Source**: lsg-group.com/location/asuncion-asu/; gcggroup.com/country/paraguay/; DNCP; La Nación PY; El Omnívoro

#### Grupo Altair SA
- **Country**: Paraguay | **HQ**: Jacques Balanza 1530, Lambaré, Central | **Founded**: 2017 (registered Aug 25, 2017)
- **RUC**: 80098783-7 | **DNCP Status**: Registered provider; multiple adjudications
- **Scale**: G. 46bn+ contract through 2028 (Alto Paraguay dept); G. 113bn contract scope in Concepción; serves 4,500+ students in Alto Paraguay alone; 144 institutions in Concepción
- **Verticals**: School feeding (Programa Hambre Cero), complementary nutrition (snacks), institutional government catering
- **Industry role**: Legal representative Víctor Mendoza = President of CAEP (Cámara de Alimentación Escolar del Paraguay) — the PY school-feeding industry body
- **SolStein Relevance**: Major PY school-feeding operator with multi-year government contracts; institutional scale = IT management need; CAEP leadership = industry gateway
- **Source**: DNCP registry; ABC Color; El Independiente PY; RCC news

#### Alimentos y Servicios SRL (Todo Rico)
- **Country**: Paraguay | **HQ**: Carretera de López esq. 14 de Julio y Alas Paraguayas, Lambaré, Central
- **RUC**: 80022202-4 | **Founded**: March 10, 2009 | **Representatives**: Claudia María Kent de Escobar; Pío Miguel Ángel Escobar Arza
- **Brand**: Todo Rico (brand name; ARPY member under this brand)
- **DNCP Contracts**: DINAC (G. 29M, food & beverage supply); Honorable Chamber of Senators (G. 840M ceremonial/gastronomic, 2012)
- **Verticals**: Government institutional catering, ceremonial/protocol services, ARPY-member restaurant
- **SolStein Relevance**: DNCP-registered PY caterer with government track record; ARPY membership signals commercial restaurant operations alongside institutional; medium-size operator with IT gap
- **Source**: DNCP registry (contrataciones.gov.py/proveedor/alimentos-servicios-srl.html); ABC Color 2024; ARPY member list (todorico.com.py)

#### Inflight Catering (Inflight Group PY)
- **Country**: Paraguay | **Experience**: ~10 years
- **Verticals**: Flight catering (private aviation), first-class gastronomy, event organization (international fairs, congresses, presidential summits), international courier (Inflight Box)
- **DNCP Contracts**: Dinatran (G. 400M, bocaditos and food); Secretaría Nacional de Cultura (SNC No. 04/2021)
- **SolStein Relevance**: PY-native with confirmed airline + government catering; multi-vertical operator in premium segment; diversified portfolio suggests IT coordination need
- **Source**: inflight.com.py; DNCP registry; Secretaría Nacional de Cultura contract record 2021; ABC Color 2024

#### Procard SA (LunchCard)
- **Country**: Paraguay | **Type**: PY-native canteen-card / meal-benefit platform
- **Product**: LunchCard — B2B employee meal benefit card; accepted at any supermarket, restaurant, ice cream shop, or confectionery in PY; fixed daily refrigerio deposits by employer
- **Certification**: First card processor in Paraguay to achieve ISO 9001:2015 Quality Management certification
- **Business model**: Card processing platform (not a caterer); issues corporate benefit cards for employer-funded meal allowances; employee controls daily balance via purchase receipt
- **SolStein Relevance**: Fills confirmed PY canteen-card whitespace — the only dedicated PY-native meal benefit card processor; potential integration partner for IT meal management; direct analog to Edenred/Pluxee but PY-native
- **Source**: procard.com.py/procard_institucional/lunchcard2/

#### Organización Integral SRL
- **Country**: Paraguay | **HQ**: Ayala Velázquez 627 esq. Siria y Juan de Salazar, Asunción | **Director**: Lic. Alberto Ferreira
- **Experience**: 30+ years; 200+ events organized; DNCP-registered provider
- **Verticals**: National and international congress/seminar/summit organization; corporate events; coordinates external catering providers as part of integral event management
- **DNCP Contracts**: Corte Suprema de Justicia (G. 300M, "servicio de logística ceremonial y protocolo", 2024)
- **SolStein Relevance**: PY institutional event organizer that procures catering from external suppliers — a B2B procurement aggregator and potential customer for meal-service IT; government-contracted validates operational legitimacy
- **Source**: ointegral.com.py; DNCP registry; ABC Color June 2024

---

### Tier 2 — LATAM-Wide (Watch List / Research Next)

#### Teknisa / TecFood
- **Country**: Brazil | **Founded**: 1990 (35 years)
- **Platform**: Leading collective meal management ERP; covers corporate restaurants, school meals, hospitals, offshore, airlines, events; 10+ countries
- **Key Features**: AI-based headcount, menu workflow, purchase automation, contract billing; ~7% monthly cost savings claim
- **SolStein Relevance**: Benchmark competitor for B2B meal-service ERP; most comparable to SolStein's core value prop

#### Cookep
- **Country**: LATAM (Chile base) | **Type**: B2B-Meal-as-a-Service SaaS
- **Scale**: 2M+ meals managed; 10,000+ employees in 50+ sites simultaneously; 0% ordering errors
- **Platform**: Corporate meal subsidy management for HR + production/logistics digitalization for caterers; integrates with SAP, Buk, Rex+
- **Verticals**: Mining/oil (offline mode), industrial plants, corporate offices, hospitals
- **SolStein Relevance**: Very close to SolStein's addressable market (corporate, mining, industrial) — key competitive benchmark

#### CookFlow
- **Country**: LATAM | **Type**: Tech-vendor
- **Platform**: Industrial kitchen + corporate catering management; centralizes orders (WhatsApp, kiosk, POS, API), production, purchasing, delivery; multi-site/multi-brand
- **SolStein Relevance**: Direct functional competitor in B2B meal management SaaS

#### OrderEAT
- **Country**: Uruguay | **Founded**: 2019 | **Type**: Tech-vendor
- **Scale**: 10 LATAM countries; 500+ schools; 1M+ monthly orders; 200,000+ families; $2M+ revenue
- **Platform**: School cafeteria digitalization — mobile ordering, digital wallet, allergy management, demand forecasting
- **SolStein Relevance**: Institutional feeding tech; Uruguay-native expanding LATAM → potential PY entry

#### Fudu Company
- **Country**: Argentina | **Type**: B2B-Meal-as-a-Service
- **Platform**: Corporate meal delivery app (Fudu Nube), on-site comedor integration (Fudu Hybrid), corporate events (Fudu Event); 10+ years
- **SolStein Relevance**: Operator + platform hybrid; multi-product corporate meal model; Mercosur-adjacent

#### Foodology
- **Country**: Colombia | **Founded**: 2019 | **Type**: Ghost-kitchen
- **Scale**: $86.5M raised; 85 ghost kitchens; 20+ virtual brands; 4 countries (CO, MX, PE, BR); 2M+ orders
- **Investors**: Andreessen Horowitz, Base Partners, Maluma, Chimera
- **SolStein Relevance**: Ghost kitchen B2B scale model; potential aggregator partner

#### Kitchenita
- **Country**: Argentina | **Founded**: 2019 | **Type**: Ghost-kitchen
- **Scale**: $3.5M raised (FJ Labs, Magna Capital, Newtopia); AR, CO, CL; 26 virtual brands
- **Model**: Own dark kitchens + franchise model for traditional restaurants
- **SolStein Relevance**: Ghost kitchen operator; Mercosur-native; potential franchise partner

#### Frubana
- **Country**: Colombia | **Founded**: 2018 | **Type**: Marketplace
- **Scale**: 8 cities; CO, MX, BR; Y Combinator W19; Monashees + SoftBank + Tiger Global investors; 84,000+ restaurants served
- **Platform**: B2B fresh produce and ingredients marketplace for foodservice; Frupay embedded financing arm
- **SolStein Relevance**: Supply chain tech for restaurants/caterers; potential integration/partner

#### Delly's
- **Country**: Brazil | **Type**: Operator (B2B food distribution)
- **Scale**: 18,000+ orders/day; 105,000 monthly customers; 17 distribution centers; 46% BR municipalities covered; LAVCA 2025 Private Capital Deal of the Year
- **Investors**: Patria + CVC Capital Partners
- **SolStein Relevance**: Largest B2B food distribution network in BR; foodservice supply channel

#### Greentable
- **Country**: Brazil | **Founded**: 2019 | **Type**: B2B-Meal-as-a-Service
- **Scale**: R$2M funding (BR Angels, Oct 2025); 650,000 meals/month → target 1.3M; R$60M revenue target 2026
- **Model**: Healthy frozen corporate meals; supermarkets + delivery + B2B corporate accounts
- **SolStein Relevance**: B2B frozen corporate meal model; tech-enabled demand forecasting

#### Nutriser
- **Country**: Chile | **Founded**: 2006 | **Type**: Operator
- **Scale**: 10,000+ workers served; Antofagasta, Tarapacá, Atacama regions; Barrick Chile client
- **Verticals**: Mining camp catering — food service + cleaning + maintenance + hospitality
- **SolStein Relevance**: Regional benchmark for integrated mining camp catering

#### ATA Alimentaria (Alta Tecnología Alimentaria)
- **Country**: Argentina | **Type**: Operator
- **Verticals**: Mining camps, dam/pipeline construction projects, institutional, large-scale events; multi-service (food + hotel + laundry + maintenance + waste)
- **Notable projects**: Pascua Lama (2011-2014), Buenos Aires Youth Olympic Games 2018 (7,500 ppl/day), Gasoducto Perito Moreno (2023)
- **SolStein Relevance**: LATAM's remote-site catering benchmark; Mercosur operator to monitor for PY project entry

#### Clicampo
- **Country**: Brazil | **Founded**: 2021 | **Type**: Marketplace
- **Scale**: $7.5M raised (Valor Capital, MAYA Capital, IDB); Belo Horizonte, Campinas, São Paulo
- **Platform**: B2B digital marketplace connecting farmers to foodservice and retail; 12h delivery; pays farmers 3x market rates
- **SolStein Relevance**: Supply chain tech for foodservice; IDB-backed = institutional credibility

#### Magnífica Food
- **Country**: Brazil | **Type**: Operator
- **Scale**: 15+ years; 210,000+ meals/month; 70+ corporate clients; transported meals + cook-chill + corporate restaurants
- **SolStein Relevance**: Scale B2B operator in Brazil; collective meal model benchmark

#### Vloki
- **Country**: Colombia (HQ: Bogotá, Medellín, Cali) | **Markets**: CO, MX, US | **Type**: Tech-vendor
- **Platform**: Cloud software for comedores industriales and casinos empresariales; 460+ configurable features; self-service kiosks; mobile app pre-ordering; facial recognition, biometric, QR, HID card, barcode ID; virtual wallet; automated provider reconciliation; POS; real-time reporting
- **Key Metric**: Clients save up to 30% in operational costs; "pay for what you use" model
- **Verticals**: Banking, insurance, manufacturing, food, automotive; mining/remote sites
- **SolStein Relevance**: Direct functional competitor for comedor management module; strong feature benchmark for LATAM industrial/corporate segment; CO-native with LATAM expansion trajectory
- **Source**: vloki.com; web search 2025

#### Worki360
- **Country**: LATAM-wide (also US, Brazil, Spain) | **Type**: Tech-vendor (ERP)
- **Scale**: 500+ clients; covers LATAM, US, Brazil, Spain
- **Platform**: ERP-level comedor management integrated with payroll/nómina; AI fraud monitoring; POS + biometric + QR + cards; -90% manual reconciliation; parametrizable subsidy rules; employee portal; targets mining, retail, call center, manufacturing
- **SolStein Relevance**: Most feature-complete comedor ERP in LATAM; payroll integration is key differentiator vs. SolStein; benchmark for full-stack comedor management
- **Source**: worki360.com; web search 2025

#### Genera (GenCasino)
- **Country**: Chile | **Founded**: 40+ years | **Type**: Tech-vendor (HR + canteen)
- **Platform**: Integrated HR suite including GenCasino — canteen/casino management with biometric/proximity card access, multi-profile (employee/contractor/visitor), multi-ticket for guests, menu inscription, multi-site support; uses "Reloj Control Casino 10HR" device certified by Chile's Labor Dept
- **Verticals**: Chilean enterprises across industries
- **SolStein Relevance**: Long-established CL canteen software with hardware integration; relevant benchmark for casino/comedor control in mining-adjacent verticals; 40yr track record signals mature solution
- **Source**: genera.cl; web search 2025

#### ManduHR (by Visma)
- **Country**: Argentina (LATAM) | **Type**: Tech-vendor (HR platform with comedor module)
- **Scale**: 4,500+ clients; 4,000,000 active users; 30 years experience; part of Visma group (Norway)
- **Platform**: Full HR suite (payroll, time & attendance, access control, personnel admin) with comedor module — digital assignment, biometric/card/PIN/ID access, consumption reporting, waste reduction; works for internal and outsourced canteens
- **SolStein Relevance**: Largest LATAM HR platform with embedded comedor management; Visma ownership = enterprise credibility and funding; potential integration partner or indirect competitor
- **Source**: manduhr.com; web search 2025

#### Wuplify
- **Country**: LATAM-wide | **Type**: Tech-vendor (restaurant/foodservice platform)
- **Scale**: 125+ businesses in LATAM; clients include Scarola, Meaters, Mr Patty, Sushi Paradise, Presto Pasta
- **Platform**: All-in-one restaurant/foodservice platform — online storefront, order management, KDS (kitchen display system), QR table ordering, delivery zone management, cost control, CRM, loyalty; 0% commission model; WhatsApp order intake; integrates with Sinqro (POS/logistics)
- **SolStein Relevance**: LATAM-native restaurant tech with cost-control and operations management; relevant as a lighter-weight competitor in the B2B meal-tech space; 0% commission model resonates with smaller PY operators
- **Source**: wuplify.com; web search 2025

#### GeoVictoria
- **Country**: Argentina / Chile | **Type**: Tech-vendor (access control + comedor)
- **Scale**: 5,000–7,000+ enterprise clients
- **Platform**: Cloud workforce management (Microsoft Azure); comedor module with biometric/RFID/QR/facial recognition, "Box Comedor" device (8,000 fingerprints, 10,000 cards), real-time reporting, 6 ration types, automated ticketing; integrates with HR/ERP systems
- **SolStein Relevance**: Enterprise-grade comedor access control in AR/CL; large client base; hardware + software model; relevant benchmark for PY industrial/mining comedor management
- **Source**: geovictoria.com; web search 2025

---

### Tier 3 — Reference Only

#### iFood Empresas / iFood Benefícios
- **Country**: Brazil | **Type**: Canteen-card-platform / Aggregator
- **Platform**: iFood Office (corporate accounts), iFood Card (prepaid), iFood Benefícios (multi-benefit card, 11M+ merchants)
- **Note**: Mega-cap aggregator entering B2B; strategic context only

#### Edenred (Ticket Restaurant / Ticket Alimentação)
- **Country**: France (LATAM operations) | **Type**: Canteen-card-platform
- **PY Presence**: Mercosur — confirmed in AR, UY, CO, PE, BR; not confirmed in PY
- **Note**: Global canteen-card leader; competitor or integration partner for PY benefit management

#### Foody
- **Country**: Colombia | **Founded**: 2016 | **Type**: Aggregator
- **Funding**: 9 institutional investors (Solid Ventures)
- **Note**: Delivery aggregator; peripheral to SolStein's institutional catering focus

#### CaterUs
- **Country**: Argentina | **Founded**: 2019 | **Type**: Operator
- **Funding**: Funded (undisclosed)
- **Note**: Event catering platform; not institutional/corporate/camp focus

#### Los Chefes
- **Country**: Mexico | **Founded**: 2020 | **Type**: Marketplace
- **Note**: Event catering hiring platform; not relevant to institutional/camp vertical

#### FoodRise Hub (Eatable Adventures + IDB Lab)
- **Country**: Uruguay | **Type**: Accelerator (PY in scope)
- **Note**: Southern Cone accelerator explicitly including Paraguay; monitor for PY-native foodtech companies in future cohorts. Run #1 cohort (12 startups selected from 100+ across AR/CL/UY/PY): sole PY entrant was Smartsoil (agtech, not meal service); no meal-service tech in cohort 1

#### Pluxee (formerly Sodexo Benefits & Incentives)
- **Country**: France (LATAM: PE, CL, CO, BR confirmed) | **Type**: Canteen-card-platform
- **PY Presence**: NOT confirmed — Pluxee (Sodexo's rebrand of its benefits division in 2023) confirmed in Peru, Chile, Colombia, Brazil; no PY website or operation found
- **Note**: Global canteen-card/benefit leader; if Pluxee enters PY, would compete with Procard LunchCard and Sudameris Gourmet Card; SolStein should monitor for PY entry as it would reshape voucher landscape
- **Source**: pluxee.pe, pluxee.cl, pluxee.co, pluxee.com.br; web search confirmed no py.pluxee.com

#### Aramark LATAM
- **Country**: USA (LATAM operations: AR confirmed) | **Type**: Operator
- **PY Presence**: NOT confirmed — Aramark Argentina has ~1,500 employees and 6,000 daily meal portions (2023); no evidence of Paraguay operations found
- **Note**: Mega-cap foodservice operator; if Aramark entered PY (via AR expansion or direct), would be a major institutional competitor; currently Mercosur-adjacent; monitor for cross-border project wins
- **Source**: aramark.ar; aramark.cl; web search found no PY-specific operations

#### Sudameris Bank (Gourmet Card)
- **Country**: Paraguay | **Type**: Canteen-card-platform (bank-issued)
- **PY Presence**: Active — Sudameris is a PY bank offering employer-funded meal vouchers via the "Gourmet Card"; accepted at adherent merchants; monto acreditado por empresa = spending limit
- **Note**: Bank-operated meal voucher, not a dedicated fintech platform; confirms PY canteen-card market exists but is bank-dominated rather than fintech-native; positions alongside Procard LunchCard and Itaú Tarjeta Gourmet as the three main PY meal-benefit mechanisms
- **Source**: sudameris.com.py/elite-gourmet-card

---

## Data Quality Notes

| Confidence | Companies |
|---|---|
| **Confirmed** (registry/DNCP/event official) | Comepar SA, Ladero Paraguayo SA, E-karú/Netsystem SA, GCG Paraguay, Grupo Altair SA, Alimentos y Servicios SRL (Todo Rico), Inflight Catering, Organización Integral SRL, Procard SA |
| **Estimated** (press, website, LinkedIn, VC-db) | All others |

---

## Key Gaps Identified

### Gaps Partially or Fully Filled (Run #2)
1. **PY canteen-card / meal-voucher platform — PARTIALLY FILLED**: Procard SA (LunchCard) identified as PY-native dedicated meal benefit card processor; Sudameris Bank Gourmet Card also confirmed. However the market is bank-dominated — no dedicated fintech/SaaS voucher platform exists. Pluxee and Edenred both unconfirmed in PY. Opportunity remains for a modern PY-native digital meal-benefit platform.
2. **Multinational operators in PY — GCG CONFIRMED**: GCG Paraguay (LSG Group) confirmed as the active multinational operator in PY (airline + institutional). Sodexo/Pluxee, Aramark, Compass, ISS — none confirmed in PY. PY multinational gap is thus primarily in food-service management (non-airline) rather than airline catering.
3. **LATAM comedor-software sub-category — NOW MAPPED**: Vloki, Worki360, Genera/GenCasino, ManduHR, GeoVictoria all identified as the competitive set for comedor/casino management SaaS in LATAM. None confirmed in PY — represents an open-market entry opportunity.

### Persisting Gaps (Still Unresolved)
4. **PY camp catering tech (construction/hydroelectric/agro-industrial)**: MyM Alimentos Corporativos and Comepar cover this operationally in PY, but no IT system specifically designed for construction/camp feeding contexts has been identified in PY. Nutriser (CL) and ATA Alimentaria (AR) serve as regional operator benchmarks only.
5. **PY institutional food-procurement marketplace**: No Frubana/Clicampo equivalent found operating in PY. The raw-ingredient supply chain for PY caterers remains undigitised.
6. **CAEP-affiliated operators**: CAEP (Cámara de Alimentación Escolar del Paraguay) members beyond Grupo Altair not yet inventoried; further discovery needed via direct CAEP outreach.
7. **Hospitality-linked corporate catering**: Hotel chains in PY (Sheraton Asunción, NH Collection Asunción, Hotel Bourbon, etc.) offering corporate catering and event services not yet researched — likely Tier 1 candidates given their institutional scale.
8. **PY-native comedor software**: No PY-developed comedor/canteen management software identified. E-karú and MRC Software address restaurant POS but not the comedor-management / meal-subsidy-management use case specifically. This is a core SolStein product opportunity.
9. **Hydroelectric binational contractors (Itaipu/Yacyretá)**: No specific catering contractor for ongoing Itaipu or Yacyretá operations identified via DNCP or press. Likely handled via internal procurement; direct outreach to procurement departments needed.




