# Deep Analysis — Procard SA (LunchCard)

**Research Date**: 2026-05-04
**Player Type**: Canteen-card-platform (PY-native meal benefit card issuer and payment processor)
**Confidence Level**: Medium (company website confirmed; financial and ownership details not public)
**Geographic Footprint**: Paraguay (national — 30,000+ merchants)
**Paraguay Presence**: Yes — headquartered in Asunción; PY-only operation

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Procard S.A. | [procard.com.py](https://www.procard.com.py/) | Confirmed |
| Tax ID / RUC | Unknown | No source | Unknown |
| HQ Address | Avda. Brasilia 444, Asunción, Paraguay | [procard.com.py/acerca-de-nosotros](https://www.procard.com.py/procard_institucional/acerca-de-nosotros/) | Confirmed |
| Founded | 3 November 1997 | procard.com.py/acerca-de-nosotros | Confirmed |
| Founders | Unknown | No source | Unknown |
| Ownership | Unknown — likely private SA; banking or fintech-related | No source | Unknown |
| Employee Count — PY | Not disclosed; estimated 50–150 (payment processing company) | Proxy | Estimated proxy |
| Revenue — PY | Not disclosed; 300,000 cards × estimated G. 3,000–8,000 fee/card/yr = G. 900M–2.4B ≈ USD 120–325K; processing fees on G. transactions add significantly | Proxy | Estimated proxy |
| Profitability | Unknown | No source | Unknown |
| Last Funding Round | None identified | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Canteen-card-platform — meal benefit card issuer | procard.com.py | Confirmed |
| Sub-Verticals Served | Employee meal benefits (B2B — companies providing lunch/snack benefit to staff) | procard.com.py/lunchcard | Confirmed |
| Countries Active | Paraguay only | procard.com.py | Confirmed |
| Market Reach | 300,000+ LunchCard and related cards in market; 30,000+ affiliated merchants | procard.com.py | Confirmed |
| Notable PY Customers | B2B: companies, entities, organizations issuing LunchCard to employees — names not disclosed | procard.com.py | Estimated |
| Government / Institutional | Unknown — government entities may use LunchCard for staff benefits | No source | Unknown |
| Market Share — PY | PY's only dedicated card-based meal benefit processor; Bancard (debit/credit) and bank-issued cards compete | procard.com.py | Estimated |
| Awards / Certifications | ISO 9001:2015 (first PY payment processor to achieve this) | procard.com.py | Confirmed |
| Sustainability | None identified | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Product Portfolio | LunchCard (employee meal benefit card); Credicard (credit card for 46 entities, 16,000 merchants); debit card processing; other tech financial services | procard.com.py | Confirmed |
| LunchCard Features | Fixed daily/weekly meal amount loading; usable at supermercados, restaurantes, heladerías, confiterías; receipt shows remaining balance | procard.com.py/lunchcard | Confirmed |
| LunchCard Merchant Network | Accepted at 30,000+ merchants nationally | procard.com.py | Confirmed |
| Deployment Model | Card-based (physical magnetic/chip card); no app identified | procard.com.py | Confirmed |
| Tech Stack | Payment processing infrastructure; ISO 9001 processes; likely proprietary PY card system | procard.com.py | Estimated |
| End-Customer App | None identified — physical card only | procard.com.py | Estimated |
| Payment Integration | Bancard-compatible merchants (implied); own merchant network | procard.com.py | Estimated |
| API / Integration | Unknown — no developer portal identified | No source | Unknown |
| Bancard Relationship | Mentioned in "entidades" context; Procard operates alongside/within Bancard ecosystem | procard.com.py | Estimated |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Unknown — 28yr company; likely institutional ownership (bank/financial group) | No source | Unknown |
| PE or VC Backed | Unknown | No source | Unknown |
| Government-Related | Unknown — Banco Continental or similar PY bank may be a shareholder | No source | Unknown |
| Group Structure | Unknown | No source | Unknown |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Unknown; 300,000 cards is significant PY scale | No source | Unknown |
| Geographic Expansion | PY-only; no LATAM expansion identified | No source | Estimated |
| Service Launches (2yr) | Unknown | No source | Unknown |
| Acquisitions | None identified | No source | Unknown |
| Currency Exposure | PYG only (domestic payment processor) | No source | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Employee meal benefit card — employer-funded | procard.com.py | Confirmed |
| Vertical Breadth | 2: meal benefit (LunchCard) + general credit/debit processing (Credicard) | procard.com.py | Confirmed |
| Food Safety | N/A — payment processor, not food producer | — | — |
| Fiscal e-Invoicing | SET e-Kuatia — as financial services company, electronic billing required | Regulatory | Estimated |
| Payment Integrations | Own merchant network (30,000+ PY merchants); Bancard adjacency | procard.com.py | Confirmed |
| Regulatory | Banco Central del Paraguay (BCP) oversight as payment service provider | PY financial regulations | Estimated |
| Delivery Integrations | N/A | — | — |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | B2B: company pays Procard to load meal benefit amounts per employee; merchant pays transaction fee; company pays annual card fee | procard.com.py | Estimated |
| Price Range | Employee card fee: est. G. 5,000–15,000/yr; merchant transaction: 1–3% | Proxy | Estimated proxy |
| Recurring vs Project | >95% recurring (monthly employer top-ups; ongoing merchant fees) | Nature of business | Confirmed |
| Estimated Revenue | USD 500K–2M/yr (processing fees on meal card transactions across 300,000 cards) | Proxy | Estimated proxy |
| Comparable M&A | Edenred/Pluxee/Sodexo acquisition of regional canteen-card players at 5–10× revenue | Industry | Estimated |
| Estimated Acquisition Value | USD 3–10M (strong moat via merchant network + ISO cert + 28yr history; 5× revenue) | Benchmark | Estimated proxy |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG only | No source | Estimated |
| Cross-Border | PY-only | No source | Confirmed |
| Public-Sector Dependence | Unknown — government entities may be clients but not primary | No source | Unknown |
| US / European Parent | None identified; no Edenred/Pluxee/Sodexo affiliation found | No source | Unknown |
| Family Conglomerate | Unknown | No source | Unknown |
| ESG | None | No source | Unknown |
| Regulatory Moat | BCP oversight + ISO 9001 + 30,000 merchant network = high switching cost for any competitor | procard.com.py | Confirmed |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | PY-native, 28yr operation, 30,000+ merchants nationally | procard.com.py |
| LATAM regional reach | Medium | Both | **1** | PY-only | procard.com.py |
| Competitive overlap | High | Competition | **2** | Canteen-card platform is adjacent to SolStein's institutional catering IT; no direct product overlap but competing for the same employer meal-benefit spend | procard.com.py |
| Customer-fit potential | High | Customer | **2** | Payment processor — SolStein's software could integrate LunchCard as a payment method; not a direct customer for SolStein's core platform | procard.com.py |
| Scale | Medium | Both | **3** | 300,000 cards, 30,000 merchants — significant PY payment infrastructure; small in revenue | procard.com.py |
| Tech modernity | Medium | Both | **2** | ISO 9001 processes; physical card model; no app identified — modernization lag vs digital-first Edenred/Pluxee | procard.com.py |
| Acquisition / partnership feasibility | Low | Strategic | **3** | Unknown ownership — if private/founder-owned, acquisition feasible; ISO cert + merchant network = valuable PY asset | procard.com.py |
| Growth trajectory | Low | Both | **2** | Unknown; 300,000 cards implies establishment; limited public growth signals | No source |

**Competition Composite**: (2×2 + 5×1 + 3×1 + 2×1) / 5 = **2.8** / 5.0
**Customer Composite**: (2×2 + 5×1 + 2×1 + 2×1) / 5 = **2.6** / 5.0
**Overall Landscape Composite**: (5+1+2+2+3+2+3+2) / 8 = **2.5** / 5.0
**Confidence Band**: Medium (~40% Confirmed)

**Overall Landscape Assessment**:
Procard SA is Paraguay's only dedicated meal benefit card processor, holding a significant position (300,000 cards, 30,000 merchants, ISO 9001, 28yr history) in the PY employer meal benefit market. It is most relevant to SolStein as a **potential integration partner** — SolStein's institutional catering IT platform could integrate LunchCard as a payment method for corporate cafeteria or meal ordering workflows, creating a joint go-to-market for corporate dining clients. The physical card model (no app) represents a modernization gap that SolStein could help bridge. Acquisition feasibility is unknown due to ownership opacity.

**Recommended Next Step**: **Approach as partner** — propose API/integration partnership for LunchCard acceptance within SolStein's corporate catering portal. This creates distribution for SolStein (access to Procard's corporate client base) and value for Procard (digital upgrade of LunchCard). Contact: Avda. Brasilia 444, Asunción; ISO 9001 quality team as entry point.

**Primary Tier**: **Tier 1** (Partnership Composite 2.5 — PY-native, unique canteen-card asset, integration priority)
