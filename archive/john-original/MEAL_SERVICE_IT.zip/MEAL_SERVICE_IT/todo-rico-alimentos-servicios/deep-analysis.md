# Deep Analysis — Alimentos y Servicios SRL (Todo Rico)

**Research Date**: 2026-05-04
**Player Type**: Hybrid (food retail chain + catering + wholesale distribution)
**Confidence Level**: Medium (Infonegocios PY + company website confirmed; financials estimated)
**Geographic Footprint**: Paraguay (Lambaré HQ; 10+ locations across greater Asunción)
**Paraguay Presence**: Yes — native PY company

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Alimentos y Servicios SRL (trading as "Todo Rico") | [DNCP](https://www.contrataciones.gov.py/); Infonegocios PY | Estimated |
| Tax ID / RUC | 80022202-4 | DNCP registry | Confirmed |
| HQ Address | Lambaré, Departamento Central, Paraguay (Casa Central) | [buscoinfo.com.py](https://www.buscoinfo.com.py/local/todo-rico-casa-central/LOC866560001) | Confirmed |
| Founded | 1998 (by the Escobar Kent family) | [Infonegocios PY](https://infonegocios.com.py/infogourmet/todo-rico-sigue-expandiendose-hoy-cuenta-con-10-locales) | Confirmed |
| Founders | Escobar Kent family | Infonegocios PY | Confirmed |
| Ownership | Family-owned (Escobar Kent family) | Infonegocios PY | Confirmed |
| Employee Count — PY | ~300 | Infonegocios PY | Confirmed |
| Revenue — PY | Not disclosed; 10 locations + catering + wholesale; estimated USD 3–8M/yr | No direct source; proxy | Estimated proxy |
| Profitability | Unknown; consistent expansion to 10 locations suggests profitability | Infonegocios PY | Estimated |
| Last Funding Round | None identified — family-funded | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Hybrid — food retail (B2C) + catering (B2B) + wholesale distribution | Infonegocios PY | Confirmed |
| Sub-Verticals Served | Consumer food retail (restaurants/confectionery), B2B corporate catering, wholesale to food chains + service stations | Infonegocios PY | Confirmed |
| Countries Active | Paraguay only | Infonegocios PY | Confirmed |
| Branch Network | 10+ locations: Lambaré (HQ), Asunción downtown, Galería, Royal Plaza, Multiplaza, shopping centers, universities, clubs | Infonegocios PY | Confirmed |
| Notable PY Customers | Corporate catering clients not named; wholesale: food chains and service stations | Infonegocios PY | Estimated |
| Government / Institutional | Unknown; RUC 80022202-4 suggests DNCP registration but specific contracts unknown | DNCP | Unknown |
| Market Share — PY | Significant fast-casual food presence in Asunción area; known brand | Infonegocios PY | Estimated |
| Awards / Certifications | None cited | No source | Unknown |
| Sustainability | None identified | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Rotisserie, buffet, confectionery, bakery, sandwiches, pizza, pasta, burgers, juices, cocktails, plated dishes, ice cream (Italian machines), frozen food takeout, tea service, events catering, wholesale | Infonegocios PY | Confirmed |
| Menu Philosophy | Accessible prices + quality; diverse menu; artisanal ice cream; Brazilian-equipped | Infonegocios PY | Confirmed |
| Cold-Chain & Logistics | Own production + 3 distribution divisions (retail, catering, wholesale); logistics capability implied | Infonegocios PY | Estimated |
| Internal Tech Stack | Unknown; 10-location chain typically requires POS system; E-karú or similar PY restaurant software likely | No source | Unknown |
| End-Customer App / Portal | None identified | No source | Unknown |
| Meal-Voucher Card Integration | Unknown; likely Bancard/Procard LunchCard acceptance | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Yes — Escobar Kent family (founded 1998, 28yr history) | Infonegocios PY | Confirmed |
| PE or VC Backed | No | No source | Estimated |
| Government-Related | No | No source | Estimated |
| Founder Still Active | Likely — 28yr family operation; generational dynamics unknown | Infonegocios PY | Estimated |
| Succession Signal | No signal | No source | Unknown |
| Family-Owned Dynamics | Single family; possible multi-generation now | Infonegocios PY | Estimated |
| Group Structure | Standalone SRL | No source | Estimated |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Consistent expansion to 10 locations; specific YoY revenue unknown | Infonegocios PY | Estimated |
| Employee Growth YoY | ~300 employees (current); growth trajectory with location expansion | Infonegocios PY | Estimated |
| Geographic Expansion (3yr) | Expansion across Asunción metro; locations in universities and clubs | Infonegocios PY | Confirmed |
| Service Launches (2yr) | Wholesale division development | Infonegocios PY | Estimated |
| Acquisitions (3yr) | None identified | No source | Unknown |
| Funding Rounds (3yr) | None | No source | Unknown |
| Currency Exposure | PYG primarily; USD for some B2B contracts | No source | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Consumer food retail + B2B corporate catering | Infonegocios PY | Confirmed |
| Vertical Breadth | 3: retail, catering, wholesale | Infonegocios PY | Confirmed |
| Food Safety Compliance | INAN required; 10-location chain implies formal compliance | No source | Estimated |
| Fiscal e-Invoicing | SET e-Kuatia as formal business — assumed compliant | No source | Estimated |
| Allergen / Dietary | Unknown | No source | Unknown |
| Voucher / Benefit | Likely Bancard + Procard LunchCard acceptance as restaurant/confectionery operator | No source | Estimated |
| Payment Integrations | Bancard PY standard; likely POS with card reader | No source | Estimated |
| Delivery Integrations | Possibly Monchis PY / PedidosYa for retail locations | No source | Unknown |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Per-item retail (B2C); per-headcount catering (B2B); wholesale bulk | Infonegocios PY | Estimated |
| Price Range | Mid-market PY: G. 20,000–80,000/meal equivalent; accessible pricing | Infonegocios PY | Estimated |
| Recurring vs Project | ~60% recurring (retail locations + standing corporate accounts); 40% events/wholesale | Proxy | Estimated |
| Estimated Revenue | USD 3–8M/yr (10 locations + catering + wholesale; 300 employees) | Proxy (employee count × USD 10–25K) | Estimated proxy |
| Estimated Acquisition Value | USD 3–10M (10-location food chain; family brand; asset-based) | Benchmark | Estimated proxy |
| Services vs Product Split | ~60% food retail / 25% catering / 15% wholesale | Proxy | Estimated |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG primarily | No source | Estimated |
| Cross-Border | PY-only | No source | Confirmed |
| Public-Sector Dependence | Low — primarily private consumer and corporate | No source | Estimated |
| Family Conglomerate | None — Escobar Kent = standalone food family business | Infonegocios PY | Confirmed |
| ESG | None identified | No source | Unknown |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | PY-native, 10+ Asunción locations, 28yr operation | Infonegocios PY |
| LATAM regional reach | Medium | Both | **1** | PY-only | Infonegocios PY |
| Competitive overlap | High | Competition | **1** | Food retail operator; no tech overlap with SolStein | Infonegocios PY |
| Customer-fit potential | High | Customer | **3** | 10-location chain + catering + wholesale = multi-site, multi-channel complexity; genuine POS/ERP need; 300 staff requires HR/payroll; unclear if institutional enough for SolStein's core platform | Infonegocios PY |
| Scale | Medium | Both | **3** | 300 employees, 10+ locations, 3 divisions; significant for PY; micro by LATAM standards | Infonegocios PY |
| Tech modernity | Medium | Both | **2** | No visible app or digital system; 10-location chain likely on basic POS; gap exists | No source |
| Acquisition / partnership | Low | Strategic | **4** | Family-owned 28yr; no PE; PY-only; acquirable; 300-employee known brand | Infonegocios PY |
| Growth trajectory | Low | Both | **3** | Consistent expansion to 10 locations; wholesale division growth; steady trajectory | Infonegocios PY |

**Competition Composite**: (1×2 + 5×1 + 3×1 + 2×1) / 5 = **2.4** / 5.0
**Customer Composite**: (3×2 + 5×1 + 2×1 + 3×1) / 5 = **3.2** / 5.0
**Overall Landscape Composite**: (5+1+1+3+3+2+4+3) / 8 = **2.8** / 5.0
**Confidence Band**: Medium (~50% Confirmed)

**Overall Landscape Assessment**:
Todo Rico is a 28-year Asunción food brand with 300 employees and 10+ locations across retail, catering, and wholesale — a well-known PY institution with no competitive overlap with SolStein. It is primarily a consumer food retailer rather than an institutional B2B caterer, which makes it a secondary priority for SolStein's core platform (which targets school feeding operators, mining camp caterers, and corporate canteen managers). However, the multi-location chain management and wholesale distribution complexity create genuine ERP/POS system demand. Family-owned with no PE pressure makes it acquirable but also complacent about IT investment.

**Recommended Next Step**: **Approach as customer (secondary)** — Todo Rico is not SolStein's primary target segment (consumer food retail is different from institutional B2B catering), but the wholesale + corporate catering arms and multi-location management complexity justify an exploratory conversation. Lead with the catering/wholesale management angle rather than the retail POS story.

**Primary Tier**: **Tier 1** (Overall 2.8 — PY active; customer interest via catering/wholesale arm)
