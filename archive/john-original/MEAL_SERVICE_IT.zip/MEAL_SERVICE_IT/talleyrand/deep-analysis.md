# Deep Analysis — Talleyrand

**Research Date**: 2026-05-04
**Player Type**: Operator (premium events catering + event venue management)
**Confidence Level**: Medium (company website confirmed; financials and ownership not public)
**Geographic Footprint**: Paraguay (Asunción)
**Paraguay Presence**: Yes — headquartered in Asunción; 3 event venues

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity | Talleyrand (legal entity name unconfirmed — likely SA or SRL) | [talleyrand.com.py](https://talleyrand.com.py/) | Estimated |
| Tax ID / RUC | Unknown | No source | Unknown |
| HQ Address | Asunción, Paraguay (exact address not published publicly) | talleyrand.com.py | Estimated |
| Founded | 1976 (48 years of operation) | [talleyrand.com.py/quienes-somos](https://talleyrand.com.py/quienes-somos/) | Confirmed |
| Founders | Unknown — "built on the art of gastronomy" | talleyrand.com.py | Unknown |
| Ownership | Unknown — likely founder/family ownership | No source | Unknown |
| Employee Count — PY | Not specified; estimated 50–150 (venue + catering operations) | Proxy | Estimated proxy |
| Revenue — PY | Not disclosed; venues (up to 2,000 pax) + catering suggest significant revenue | No source | Unknown |
| Profitability | Unknown | No source | Unknown |
| Last Funding Round | None identified | No source | Unknown |

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Operator — premium events catering + event venue | talleyrand.com.py | Confirmed |
| Sub-Verticals Served | Corporate events, weddings, social events, cocktail receptions, asados paraguayos | talleyrand.com.py | Confirmed |
| Countries Active | Paraguay (Asunción) only | talleyrand.com.py | Confirmed |
| Venue Capacity | Salón Talleyrand (450 pax teatro); Talleyrand Costanera (2,000 pax teatro); Villa Morra venue | talleyrand.com.py | Confirmed |
| Notable PY Customers | Not named; corporate client base (events/catering) implied | talleyrand.com.py | Estimated |
| Government / Institutional | Unknown; no DNCP contracts identified | No source | Unknown |
| Market Share — PY | Likely a top-3 premium events caterer in Asunción by capacity (2,000 pax Costanera) | talleyrand.com.py | Estimated |
| Awards / Certifications | None cited | No source | Unknown |
| Sustainability Claims | None identified | No source | Unknown |

### Product / Service & Technology

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Service Portfolio | Coffee break, desayunos, almuerzos y cenas (at domicile), cocktail de pie, bodas y grandes eventos, eventos empresariales, asados paraguayos, mesas de quesos y antipastos, bebidas + vajillería + mantelería | talleyrand.com.py | Confirmed |
| Menu Philosophy | Premium, personalized, quality-driven; inspired by French gastronomic tradition (Talleyrand) | talleyrand.com.py | Confirmed |
| Cold-Chain & Logistics | Unknown; catering service delivery implied | No source | Unknown |
| Internal Tech Stack | Unknown | No source | Unknown |
| End-Customer App / Portal | None identified | No source | Unknown |
| Meal-Voucher Card Integration | None | No source | Unknown |

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Unknown — 48yr company; likely 2nd–3rd generation family | No source | Unknown |
| PE or VC Backed | No | No source | Estimated |
| Government-Related | No | No source | Estimated |
| Founder Still Active | Unknown | No source | Unknown |
| Succession Signal | No signal | No source | Unknown |
| Family-Owned Dynamics | Probable; 48yr independent operation with PY premium market position | No source | Estimated |
| Group Structure | Standalone | No source | Estimated |

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Unknown | No source | Unknown |
| Geographic Expansion (3yr) | None | No source | Unknown |
| Service Launches (2yr) | Talleyrand Costanera (2,000 pax) appears to be a relatively recent expansion | talleyrand.com.py | Estimated |
| Acquisitions (3yr) | None | No source | Unknown |
| Currency Exposure | PYG; premium events may invoice in USD for corporate clients | Proxy | Estimated |

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Premium events catering + venue management | talleyrand.com.py | Confirmed |
| Vertical Breadth | 2: events catering, venue management | talleyrand.com.py | Confirmed |
| Food Safety Compliance | INAN required — status unknown | No source | Unknown |
| Fiscal e-Invoicing | SET e-Kuatia assumed compliant | No source | Estimated |
| Allergen / Dietary | Unknown; premium positioning implies customization | No source | Unknown |
| Voucher / Benefit | None identified | No source | Unknown |

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | Per-event / per-pax; venue rental + catering bundle | talleyrand.com.py | Estimated |
| Price Range | Premium PY: G. 200,000–500,000/pax + venue fees | Proxy | Estimated proxy |
| Recurring vs Project | ~20% recurring (standing corporate accounts); ~80% per-event | Proxy | Estimated |
| Estimated Revenue | USD 300K–1M/yr (venue rental + premium catering; 3 venues) | Proxy | Estimated proxy |
| Estimated Acquisition Value | USD 1–3M (premium brand + 3 venues; asset-based valuation) | Benchmark | Estimated proxy |

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG; possibly USD for premium corporate events | Proxy | Estimated |
| Public-Sector Dependence | Low — private events focus | No source | Estimated |
| Family Conglomerate | None identified | No source | Unknown |

---

### Landscape Relevance Scorecard

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | PY-native, 48yr Asunción operation, 3 venues | talleyrand.com.py |
| LATAM regional reach | Medium | Both | **1** | Asunción-only | talleyrand.com.py |
| Competitive overlap | High | Competition | **1** | Premium events operator; no tech overlap | talleyrand.com.py |
| Customer-fit potential | High | Customer | **2** | Small scale; events not institutional; low IT system complexity; not SolStein's target segment | talleyrand.com.py |
| Scale | Medium | Both | **1** | Small operator; Costanera is impressive venue but revenue likely <USD 1M | Proxy |
| Tech modernity | Medium | Both | **1** | No digital presence beyond website; no app or integration | No source |
| Acquisition / partnership | Low | Strategic | **3** | 48yr independent; likely family-owned; small valuation; acquirable | No source |
| Growth trajectory | Low | Both | **2** | COVID likely hurt events business significantly; recovery pace unknown | Proxy |

**Competition Composite**: (1×2 + 5×1 + 1×1 + 1×1) / 5 = **1.8** / 5.0
**Customer Composite**: (2×2 + 5×1 + 1×1 + 2×1) / 5 = **2.4** / 5.0
**Overall Landscape Composite**: (5+1+1+2+1+1+3+2) / 8 = **2.0** / 5.0
**Confidence Band**: Medium (~45% Confirmed)

**Overall Landscape Assessment**:
Talleyrand is a 48-year Asunción premium events caterer with no competitive overlap with SolStein and limited customer-fit relevance (premium social events ≠ SolStein's institutional/B2B meal-service target). Its strong brand and venue infrastructure (up to 2,000 pax) give it unique PY market positioning, but its business model is entirely event-driven — not the recurring institutional catering complexity SolStein addresses. Low digitalization and unknown ownership make it a low-priority landscape entry.

**Recommended Next Step**: **De-prioritise** — not a meaningful customer, partner, or competitor for SolStein's institutional catering IT platform. Keep as reference for PY food market map.

**Primary Tier**: **Tier 3** (Overall 2.0 — reference only)
