# Corporate History — E-karú / Innovasys (Netsystem SA)

**Research Date**: 2026-05-04
**Genealogy Confidence**: Low-Medium (PY company; trade registry not confirmed; Infonegocios + Revista CAP are primary public sources)
**Country of Domicile**: Paraguay
**Family-Conglomerate Parent**: None identified — appears to be founder-owned / SME

---

### Current Ownership & Key Parties

| Stakeholder | Role | Stake % | Type | Since | Source |
|---|---|---|---|---|---|
| Carmen Crosa de Pomata | Executive Director, Netsystem SA | Unknown | Founder / Owner (probable) | ~1993 | [Infonegocios PY](https://infonegocios.com.py/conosur/software-100-paraguayo-promete-ser-una-solucion-para-los-negocios-gastronomicos) |
| E-karú development team | Creators of E-karú software | Unknown | Technical founders | ~2013 | [Revista CAP](https://revistacap.com.py/2019/01/29/software-gastronomico-ekaru/) |

*Note*: The exact legal relationship between Netsystem SA and Innovasys (operating brand) is unclear from public sources. Possible structures: (1) Innovasys is a new legal entity wholly owned by Netsystem SA founders; (2) Netsystem SA rebranded as Innovasys; (3) Innovasys is the commercial brand for E-karú/Ejapo products within Netsystem SA. Carmen Crosa de Pomata is identified as Netsystem's executive director; she may also be the Innovasys principal.

**Corporate Structure** (Mermaid):

```mermaid
graph TD
    Crosa["Carmen Crosa de Pomata<br/>(Executive Director / probable owner)"]
    Netsystem["Netsystem S.A.<br/>Paraguay — IT services + ERP (~1993)"]
    Innovasys["Innovasys<br/>Paraguay — Commercial brand (E-karú + Ejapo)"]
    Ekaru["E-karú Software<br/>Cloud POS/ERP — Gastronomy"]
    Ejapo["Ejapo Retail<br/>Cloud ERP — General retail"]
    Crosa --> Netsystem
    Netsystem --> Innovasys
    Innovasys --> Ekaru
    Innovasys --> Ejapo
```

---

### Origin Story

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Netsystem SA Founded | ~1993 (deduced: "26 years of vigencia" cited in Jan 2019 article) | Infonegocios PY 2019 | Estimated |
| Netsystem Original Mission | Integral IT solutions — hardware provisioning, ERP software, business process consulting | Infonegocios PY 2019 | Confirmed |
| E-karú Development | Created by "young Paraguayan developers / talented creatives" — exact team and year unclear; cloud-native from inception | Infonegocios PY 2019; Revista CAP 2019 | Estimated |
| E-karú Earliest Identified Year | ~2013–2015 (Innovasys claims "11+ years" as of 2026 website) | Innovasys website 2026 | Estimated |
| Original Product | Generic IT / ERP / hardware sales; E-karú added as gastronomy-specific product | Infonegocios PY | Confirmed |
| First Sub-Vertical | Restaurant / hospitality (E-karú) + general SME IT (Netsystem core) | Revista CAP; Innovasys website | Confirmed |
| City / Country of Founding | Asunción, Paraguay | Infonegocios PY | Confirmed |

---

### Corporate Identity Changes

| # | Date | From | To | Reason | Source |
|---|---|---|---|---|---|
| 1 | ~2013–2015 | Netsystem SA (pure IT services) | Netsystem SA + E-karú software | Strategic expansion into cloud POS software for gastronomy | Innovasys website; Infonegocios |
| 2 | ~2019–2022 | Netsystem SA | Innovasys (commercial brand) | Rebranding to unify product portfolio under modern SaaS brand; Netsystem SA legal entity likely still active | Innovasys website |

*The company website uses "Innovasys" as the brand but Netsystem SA is cited as the formal legal entity. The rebrand to Innovasys appears designed to emphasize the SaaS/cloud innovation positioning over the legacy hardware/IT services origin.*

---

### Mergers & Acquisitions Timeline

#### Acquisitions Made (as buyer)

No acquisitions identified. Growth is organic.

#### Acquired By (as target)

No acquisition of Netsystem SA / Innovasys identified. Appears to remain independent.

#### Joint Ventures & Strategic Partnerships

| Date | Partner | Type | Country | Outcome | Source |
|---|---|---|---|---|---|
| 2019-01 | Netsystem SA ↔ E-karú dev team | Exclusive distribution agreement | PY | Active — Netsystem SA became exclusive commercial distributor of E-karú software | Infonegocios PY; Revista CAP |
| ~2019 | Hardware vendors (unspecified) | Hardware + software bundle partnerships | PY | Active — Netsystem provides hardware + E-karú bundle | Infonegocios PY |

*Note*: The Jan 2019 "exclusive distribution agreement" is curious — if Netsystem SA created E-karú, a formal distribution agreement would be unusual. This suggests E-karú was developed by a separate team (possibly external or a spin-off group) and Netsystem SA acquired the exclusive distribution rights. The original E-karú developers may have remained as the technical team while Netsystem SA handles commercial operations — a common PY startup structure.

---

### Investment & Financial Events

| Date | Event Type | Details | Investors / Counterparty | Investor Type | Amount | Source |
|---|---|---|---|---|---|---|
| ~1993 | Company founding | Netsystem SA founded | Carmen Crosa de Pomata | Founder / Family | Unknown | Infonegocios PY |
| 2019-01 | Strategic agreement | Exclusive E-karú distribution | E-karú development team | Commercial agreement | Unknown | Revista CAP |
| 2022–2024 | Growth milestone | Expanded from initial installations to 1,200+ locations, 17,000 users, 14 departments | Organic growth | Internal | Unknown | Innovasys website |

*No external funding rounds identified on Crunchbase, LAVCA, Dealroom, or PY press. Company appears fully bootstrapped.*

---

### Splits, Spin-offs & Divestitures

No splits or divestitures identified.

*Ejapo Retail was added as a second product line within Innovasys — not a spin-off but an organic product extension.*

---

### Critical Events & Milestones

| Date | Event | Impact | Source |
|---|---|---|---|
| ~1993 | Netsystem SA founded by Carmen Crosa de Pomata in Asunción | Founding event — 30+ years of PY IT services history | Infonegocios PY |
| ~2013–2015 | E-karú software developed by Paraguayan developer team; cloud-native POS for gastronomy | Strategic pivot: from hardware/ERP services to proprietary cloud software product | Innovasys website |
| 2019-01 | Netsystem SA formalizes exclusive E-karú distribution agreement | Commercial inflection — Netsystem becomes the commercial channel for E-karú; accelerates PY market penetration | Revista CAP; Infonegocios PY |
| 2019–2022 | Rapid PY market expansion: 1,200+ locations, 17,000 users, 14 departments | Dominant PY restaurant POS market share; cross-department presence | Innovasys website |
| ~2020–2021 | COVID-19 impact | Restaurant closures (primary market); delivery pivot; likely forced feature development (delivery modules, online menus) | Industry context |
| ~2022 | Rebranded as Innovasys; launched Ejapo Retail | Portfolio expansion beyond gastronomy; brand modernization | Innovasys website |
| 2026 | Current state: 1,200+ locations, 17,000 users, 14 PY departments | Established leader in PY restaurant tech; preparing for either growth phase or exit | Innovasys website |

---

### Public-Sector Tender History

Not applicable — tech-vendor (SaaS/POS), not a food service operator. No DNCP public tender participation identified.

---

### Corporate Timeline (Visual)

```mermaid
timeline
    title E-karú / Netsystem SA / Innovasys — Corporate History
    section IT Services Era (~1993–2013)
        ~1993 : Netsystem SA founded by Carmen Crosa de Pomata in Asunción
               : Core business: hardware provisioning, ERP software, IT consulting
    section Software Development Era (~2013–2018)
        ~2013–2015 : E-karú cloud POS software developed by young Paraguayan team
                   : First restaurant clients onboarded in Asunción
    section Market Expansion (2019–2021)
        2019-01 : Netsystem SA formalizes exclusive E-karú distribution agreement
                 : Accelerates commercial rollout; press coverage begins
        2020–2021 : COVID-19: restaurant market disrupted
                  : Pivot support: delivery integrations, contactless menus
    section Rebranding & Scale (2022–2026)
        ~2022 : Rebrands as Innovasys; launches Ejapo Retail
        2022–2024 : Reaches 1,200+ locations, 17,000 users, 14 PY departments
        2026 : Evaluating next phase: growth financing or exit
```

---

### M&A Genealogy (Visual)

No M&A genealogy — Innovasys / Netsystem SA is a standalone organic build.

---

### Corporate Timeline (Text Summary)

```text
~1993 — Netsystem SA founded by Carmen Crosa de Pomata in Asunción, PY
        Core mission: hardware provisioning, ERP/software, IT consulting for PY SMEs
~2013 — E-karú software developed by separate Paraguayan developer team; cloud-native POS for restaurants
~2015 — First restaurant clients; growing quietly in Asunción market
2019-01 — Netsystem SA formalizes exclusive E-karú distribution agreement; market acceleration begins
2019    — Press coverage in Infonegocios PY, Revista CAP; positioned as "100% Paraguayan software"
2020–2021 — COVID-19 impacts restaurant base; product evolves to include delivery and digital menu features
~2022 — Rebrands as Innovasys; adds Ejapo Retail as second product
2024   — 1,200+ locations, 17,000 users, 14 departments
2026   — Current: dominant PY restaurant POS; evaluating next growth phase
```

---

### Pattern Analysis

**Ownership Type**: Founder-owned / SME — Carmen Crosa de Pomata (Netsystem SA) with possible technical co-founders; no VC/PE

**Decision Authority**: Local — Asunción-based; Carmen Crosa de Pomata holds executive decision-making

**Growth Strategy**: Organic — product-led growth through PY restaurant market; no M&A, no external funding

**Tech Evolution**: Cloud-native from founding of E-karú (~2013) — ahead of the regional curve for PY; Ejapo represents product diversification; Mermaid-ready feature set (mobile ordering, self-service, digital menu)

**Country Footprint Strategy**: Single-country (PY) — 14 of 17 departments covered; no LATAM expansion signals

**Public-Tender Dependence**: None — private restaurant client base only

---

### Customer / Partnership / Acquisition Feasibility Assessment from History

**Commercial Outreach Entry Point**:
- Carmen Crosa de Pomata (Executive Director, Netsystem SA / Innovasys) — primary contact
- Industry events: Gastronomik PY (ARPY, May 2026), Horeca PY events
- The "100% Paraguayan software" positioning is a strong brand identity — SolStein's PY native positioning would resonate

**Decision-Making Dynamics**:
- Founder-driven — relationship-based; likely slow and value-sensitive
- No external investors creating exit pressure; owner is probably mid-career (founded ~1993 = 30+ years active)
- Modest scale means acquisition conversations would need to be founder-to-founder (Cardona/SolStein → Crosa)

**Feasibility Signals from History**:
- Signal 1: Single-country, no LATAM expansion signals — suggests organic growth ceiling is near; acquisition or partnership would provide route to scale
- Signal 2: Bootstrapped 30+ years — likely no succession plan; founder aging is a latent signal
- Signal 3: Cloud-native product is technically acquirable (no legacy migration cost); 1,200 PY client base is high value
- Signal 4: 2019 "exclusive distribution agreement" structure suggests flexible commercial partnership mindset

**Feasibility Blockers from History**:
- Blocker 1: Founder identity is the brand ("100% Paraguayan software") — acquisition by non-PY entity may have brand risk
- Blocker 2: No external investors means no PE pressure to sell — founder decides timeline entirely
- Blocker 3: Technical team identity is unclear (are E-karú developers employees of Netsystem SA or independent?); retention risk in any acquisition

**Integration / Partnership Risk from History**:
- Risk 1: E-karú is cloud-native and PY-first — SolStein's institutional meal-service vertical would require feature extension (HACCP, nutritional planning, route management) that E-karú does not currently address
- Risk 2: Ejapo Retail overlaps with SolStein's back-office ERP scope — potential channel conflict in a partnership

**Trajectory Prediction**:
Without external investment: gradual deepening of PY market until market saturation (~2,000 restaurant locations) or until a competitor (MRC Software, a funded LATAM player) displaces them on price/features. Most likely next event: approach by a regional aggregator or SolStein-type acquirer in the 2026–2028 window, once PY market position is fully proven. The founder's 30+ year tenure makes proactive succession planning conversations relevant.
