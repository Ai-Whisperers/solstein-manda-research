# Deep Analysis — E-karú / Innovasys (Netsystem SA)

**Research Date**: 2026-05-04
**Player Type**: Tech-vendor (cloud SaaS for restaurant and foodservice management — PY-native)
**Confidence Level**: Medium (product detail well-documented; financials and ownership thin)
**Geographic Footprint**: Paraguay (primary); no confirmed international operations
**Paraguay Presence**: Yes — 100% PY-native company, all operations in Paraguay

---

### Company Fundamentals

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Legal Entity (brand) | E-karú (product brand) | [restaurante.com.py](https://www.restaurante.com.py/) | Confirmed |
| Legal Entity (distribution) | Netsystem S.A. — exclusive distributor of E-karú since 21 January 2019 | [Infonegocios PY](https://infonegocios.com.py/conosur/software-100-paraguayo-promete-ser-una-solucion-para-los-negocios-gastronomicos) | Confirmed |
| Legal Entity (developer/parent) | Innovasys — the operating brand visible at innovasys.com.py; likely the same corporate entity as or closely related to Netsystem SA | [innovasys.com.py](https://innovasys.com.py/) | Estimated |
| Tax ID — RUC | Not found in public search results | No source | Unknown |
| HQ Address | Asunción, Paraguay (exact address not published) | innovasys.com.py | Estimated |
| Founded | "11+ years" as of website; implies founded ~2013–2015; Netsystem SA described as "26 years in market" (implies ~1998–2000 founding) | [innovasys.com.py](https://innovasys.com.py/); [Infonegocios PY](https://infonegocios.com.py/conosur/software-100-paraguayo-promete-ser-una-solucion-para-los-negocios-gastronomicos) | Estimated |
| Executive Director | Carmen Crosa de Pomata (Netsystem SA executive director) | [Infonegocios PY](https://infonegocios.com.py/conosur/software-100-paraguayo-promete-ser-una-solucion-para-los-negocios-gastronomicos) | Confirmed |
| Ownership | Private Paraguayan — founder/owner identity not published; "young Paraguayan developers" origin | Infonegocios PY | Estimated |
| Investor Type | No VC/PE investment identified; likely self-funded or bootstrapped | No source | Unknown |
| Employees — PY | Unknown; small team implied by startup language in press; Innovasys appears to be a small/medium tech firm | No source | Unknown |
| Revenue — PY | Unknown; no revenue disclosed; estimated low-range (see Valuation section) | No source | Unknown |
| Profitability | Unknown | No source | Unknown |
| Last Funding Round | None identified | No source | Unknown |

---

### Meal Service Market Position

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Player Type | Tech-vendor — sells cloud SaaS to restaurants, delivery businesses, bars, cafés; does not operate kitchens | [restaurante.com.py](https://www.restaurante.com.py/) | Confirmed |
| Sub-Verticals Served | Restaurants; delivery; bars; cafés; (also: retailers via Ejapo Retail product) | restaurante.com.py; innovasys.com.py | Confirmed |
| Countries Active | Paraguay only — no international presence confirmed | All sources | Estimated |
| Customer / Site Count | 1,200+ locations; 17,000+ users; 14 departamentos | [innovasys.com.py](https://innovasys.com.py/) | Confirmed |
| Notable PY Customers | Not published; target market is independent restaurants and small chains | No source | Unknown |
| Notable LATAM Customers | None identified — PY-only | No source | Unknown |
| Government / Institutional Contracts | None identified; product targets private foodservice, not government institutional feeding | No source | Unknown |
| Market Share — PY restaurant tech | Significant — 1,200 locations in 14 of 18 departments is substantial coverage for PY restaurant software market | innovasys.com.py | Estimated |
| Market Share — LATAM | N/A — PY-only | — | — |
| Awards / Certifications | None identified | No source | Unknown |
| Sustainability Claims | None identified | No source | Unknown |

---

### Product / Service & Technology

#### Tech-vendor profile

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Product Portfolio | E-karú (restaurant/foodservice SaaS); Ejapo (retail ERP with e-invoicing) | [innovasys.com.py](https://innovasys.com.py/) | Confirmed |
| E-karú Modules | Ventas (mesas / delivery / carry-out); Compras y proveedores; Stock y Recetas; RRHH (salarios, horarios, vacaciones); Informes Gerenciales; Costos; Contabilidad; Producción; Mozos Smart; Self-Service; Menú Digital | [restaurante.com.py](https://www.restaurante.com.py/); [innovasys.com.py](https://innovasys.com.py/) | Confirmed |
| Deployment Model | Cloud (SaaS) — explicitly described as cloud-based; access from any device/location | Infonegocios PY; restaurante.com.py | Confirmed |
| Tech Stack | Unknown — no GitHub, no tech blog, no job postings identified | No source | Unknown |
| API Strategy | Unknown — no developer documentation identified | No source | Unknown |
| Key Integrations — Payments | Not confirmed; Bancard integration not explicitly stated | No source | Unknown |
| Key Integrations — Delivery | Not confirmed; PedidosYa/Monchis not explicitly stated | No source | Unknown |
| Key Integrations — E-invoicing | Ejapo product explicitly references PY e-invoicing (SET SIFEN/e-Kuatia) compliance; E-karú likely shares same compliance framework | [innovasys.com.py](https://innovasys.com.py/) | Estimated |
| Mobile App | Functional on iOS and Android browsers/apps; "Mozos Smart" module implies mobile ordering for waitstaff; "Self-Service" for customers | restaurante.com.py | Estimated |
| App Store Presence | Not found in search results | No source | Unknown |
| Languages Supported | Spanish (PY) | restaurante.com.py | Confirmed |
| Guaraní Support | Not mentioned | No source | Unknown |
| Tech Modernity Signal | Cloud-native SaaS (modern architecture implied); multi-device; real-time data protection; auto-updates | restaurante.com.py | Estimated |
| Offline Capability | Not mentioned (contrast: competitor MRC Software explicitly supports offline) | No source | Unknown |

---

### Ownership & Succession

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Founder-Owned | Likely — described as "young Paraguayan developers"; no corporate parent found | Infonegocios PY | Estimated |
| PE or VC Backed | No — no investment identified | No source | Estimated |
| Government-Related Shareholders | None identified | No source | Unknown |
| Founder Still Active | Unknown — founder identity not published | No source | Unknown |
| Succession Signal | None identified | No source | Unknown |
| PE Exit Horizon | N/A | — | — |
| Family-Owned Dynamics | Unknown | No source | Unknown |
| Group Structure | Appears standalone; Innovasys is the operating brand; Netsystem SA is the commercial distributor; relationship unclear | innovasys.com.py; Infonegocios PY | Estimated |

---

### Financial Growth & Trajectory

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Revenue Growth YoY | Unknown | No source | Unknown |
| Employee Growth YoY | Unknown | No source | Unknown |
| Geographic Expansion (3yr) | None identified — PY-only | All sources | Estimated |
| Service Launches (2yr) | Ejapo Retail (retail ERP) — visible alongside E-karú on Innovasys site; indicates product line expansion | innovasys.com.py | Estimated |
| Acquisitions (3yr) | None identified | No source | Unknown |
| Funding Rounds (3yr) | None | No source | Unknown |
| Currency Exposure | PYG — PY domestic market only | All PY sources | Confirmed |
| Customer Count Growth | Crossed 1,200 locations milestone — no historical baseline to calculate growth rate | innovasys.com.py | Estimated |

---

### Vertical & Regulatory Depth

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Primary Sub-Vertical | Independent restaurants (sit-down and delivery); cafés; bars | restaurante.com.py | Confirmed |
| Vertical Breadth | 2 product lines: E-karú (foodservice) + Ejapo (retail); moderate breadth within PY market | innovasys.com.py | Confirmed |
| Food Safety Compliance | No HACCP / INAN compliance module identified; product is POS/ERP, not food-safety management | No source | Unknown |
| Fiscal e-Invoicing | Ejapo confirmed for SET e-Kuatia; E-karú assumed compatible given same tech house | innovasys.com.py | Estimated |
| Allergen / Dietary | Not mentioned — not a feature of the product | No source | Unknown |
| Voucher / Benefit Integrations | Not identified — no Sodexo/Edenred/Pluxee integration mentioned | No source | Unknown |
| Payment Integrations | Not explicitly confirmed; Bancard assumed but not stated | No source | Unknown |
| Delivery Integrations | Not confirmed for PedidosYa or Monchis | No source | Unknown |
| Languages Localized | Spanish (PY) | restaurante.com.py | Confirmed |

---

### Valuation & Business Model

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Pricing Model | SaaS subscription (monthly/annual); no pricing page published | No pricing source | Estimated |
| Price Range | Unknown — contact-based pricing (WhatsApp 0981825580) | restaurante.com.py | Unknown |
| Recurring vs Project | High recurring ratio — SaaS subscription model | restaurante.com.py | Estimated |
| Estimated ARR | Low range estimate: 1,200 locations × estimated USD 30–60/month avg subscription = USD 430K–860K ARR | Proxy: LATAM SMB SaaS benchmark | Estimated proxy |
| Comparable M&A | Small PY tech firms: no direct comparable; LATAM restaurant SaaS comparables (Goomer BR: $2.83M seed at similar scale) suggest $3–8M valuation range | Tracxn (Goomer) | Estimated proxy |
| Estimated Acquisition Value | USD 1.5–5M range (small PY tech; limited international IP; strong local customer base asset) | Proxy | Estimated proxy |
| Implementation Timeline | Fast — "minimal training required"; cloud-based; immediate access | restaurante.com.py | Estimated |
| Services vs Product Split | ~90% product (SaaS); ~10% services (support, training) | restaurante.com.py | Estimated |

---

### LATAM-Specific Signals

| Signal | Finding | Source | Confidence |
|---|---|---|---|
| Currency Reporting | PYG domestic — no cross-border exposure | All PY sources | Confirmed |
| Cross-Border PY-AR-BR-UY | None — PY-only | All sources | Confirmed |
| Itaipú / Yacyretá Exposure | None | No source | Unknown |
| Public-Sector Dependence | None — purely private sector SMB customers | All sources | Confirmed |
| Mining / Agri Camp Exposure | None — restaurant/bar focus, not institutional/camp | All sources | Confirmed |
| US / European Strategic Parent | None — 100% PY origin | All sources | Confirmed |
| Family Conglomerate Parent | None identified | No source | Unknown |
| ESG / Sustainability | None claimed | No source | Unknown |
| Local Content / Nationalization | "100% paraguayo" positioning is a deliberate differentiation and procurement-tender-friendly signal | Infonegocios PY; restaurante.com.py | Confirmed |

---

### Landscape Relevance Scorecard

**Scoring**: 1 (low relevance) → 5 (high relevance for SolStein landscape map)

| Dimension | Weight | Lens | Score | Rationale | Key Source |
|---|---|---|---|---|---|
| Geographic relevance to PY | High | Both | **5** | 100% PY-native SaaS with 1,200+ active locations in 14 of 18 departments — maximum PY presence | innovasys.com.py |
| LATAM regional reach | Medium | Both | **1** | PY-only — no LATAM operations or presence | All sources |
| Competitive overlap with SolStein | High | Competition | **4** | Direct competitor in PY foodservice software market targeting the same restaurant/catering SMB segment; cloud SaaS model aligns with SolStein's approach | restaurante.com.py; Infonegocios PY |
| Customer-fit potential | High | Customer | **2** | It is a competitor, not a customer; unless SolStein could offer a platform this company would want to resell or integrate — unlikely at current scale | Classification |
| Scale | Medium | Both | **2** | Small PY-only firm; 1,200 locations is notable domestically but estimated ARR USD 430K–860K; limited scale | Estimated proxy |
| Tech modernity / digitization | Medium | Both | **4** | Cloud-native, multi-device, real-time data, auto-updates; modern SaaS positioning; unknown API depth | restaurante.com.py |
| Acquisition / partnership feasibility | Low | Strategic | **4** | Likely founder-owned, bootstrapped, small team; no PE; estimated sub-USD-5M valuation; PY customer base (1,200 locations) has strategic acqui-hire value for SolStein's PY market entry | Estimated |
| Growth trajectory | Low | Both | **3** | 1,200+ locations is meaningful PY scale; new Ejapo product line launched; no revenue growth data available; trajectory inferred as stable-to-growing | innovasys.com.py |

**Competition Composite** (Competitive overlap ×2, PY ×1, Scale ×1, Tech ×1): (4×2 + 5 + 2 + 4) / 6 = **3.2 / 5.0**

**Customer Composite** (Customer-fit ×2, PY ×1, Tech ×1, Growth ×1): (2×2 + 5 + 4 + 3) / 6 = **2.7 / 5.0**

**Overall Landscape Composite**: (5×2 + 1×1.5 + 4×2 + 2×2 + 2×1.5 + 4×1.5 + 4×1 + 3×1) / 13.5 ≈ **3.1 / 5.0**

**Confidence Band**: Wide (~30% Confirmed, ~50% Estimated, ~20% Unknown — product features confirmed; ownership/financials thin)

**Overall Landscape Assessment**:
E-karú / Innovasys is SolStein's primary direct competitor in the Paraguay restaurant and foodservice SaaS market — a 100% PY-native cloud platform with 1,200+ locations across 14 departments, built specifically for PY's tax and operational context. From a competition lens it warrants close monitoring: its "100% paraguayo" positioning is a differentiator that resonates locally, and its multi-module SaaS (POS, stock, HR, accounting, delivery, digital menu) covers overlapping functionality. As a customer it is not a fit — it is a rival. However, as an **acquisition or partnership target**, it is highly interesting: likely bootstrapped, founder-owned, sub-USD-5M valuation, with a ready PY customer base of 1,200 restaurants that SolStein could leverage for cross-sell or platform migration. The lack of integrations with Bancard, PedidosYa, and HACCP/food-safety modules is a gap that SolStein could exploit competitively or fill through acquisition.

**Recommended Next Step**: Dual approach — (a) **Deep competitive monitoring** (feature benchmarking, pricing intelligence, win/loss tracking); (b) **Acquisition / partnership exploration** — discreet founder outreach to assess acquisition or white-label interest. The 1,200-location PY installed base has significant strategic value.

**Primary Tier**: **Tier 1** (Competition Composite 3.2 / Customer 2.7 / Overall 3.1 — active competitive priority)
