# Financial & Growth Deep-Dive — E-karú / Innovasys (Netsystem SA)

**Research Date**: 2026-05-04
**Player Type**: Tech-vendor (cloud POS + ERP SaaS — gastronomy and retail)
**Domicile Country**: Paraguay
**Reporting Currency**: PYG / USD (no public filings; all data estimated)
**Inflation Adjustment Status**: N/A — PY guaraní; no IFRS NIC 29 needed
**Data Availability**: Low (private/bootstrapped; no public filings; no Crunchbase entry; revenue estimated from market proxy)

---

### Revenue Timeline

| Year | Revenue Basis | Currency | Approx FX (PYG/USD) | Revenue (USD M) | YoY Growth (USD) | Source | Confidence |
|---|---|---|---|---|---|---|---|
| 2026 (est.) | 1,200 locations × USD 80/mo avg SaaS fee × 12 | PYG | ~7,600 | ~USD 1.15M ARR | ~+10–15% | Proxy: 1,200 clients @ USD 80/mo | Estimated proxy |
| 2025 | 1,100 locations (interpolated) | PYG | ~7,400 | ~USD 1.0M ARR | ~+15% | Interpolation | Estimated proxy |
| 2024 | 1,000 locations (interpolated) | PYG | ~7,300 | ~USD 0.85M ARR | ~+20% | Interpolation | Estimated proxy |
| 2023 | ~800 locations | PYG | ~7,100 | ~USD 0.65M ARR | ~+25% | Interpolation | Estimated proxy |
| 2022 | ~600 locations | PYG | ~7,000 | ~USD 0.50M ARR | — | Extrapolation from 2026 website count | Estimated proxy |

**Proxy Construction**:
- Current: 1,200+ PY restaurant locations confirmed (Innovasys website 2026)
- Pricing proxy: PY restaurant SaaS subscriptions estimated at USD 60–100/month per location (industry benchmark; includes POS + cloud sync + support); USD 80/mo midpoint used
- 1,200 × USD 80 × 12 = USD 1.15M ARR
- Wide confidence band: USD 0.6M–1.8M depending on actual price tier and churn
- Hardware / hardware bundles (Netsystem legacy) could add USD 200–400K incremental annual revenue
- **Total estimated revenue 2026**: USD 1.2–1.6M (ARR + hardware)

**Revenue CAGR (3yr, USD estimate)**: ~+20–25% (2023→2026) — solid for a bootstrapped PY SaaS company
**Revenue CAGR (5yr, USD estimate)**: ~+18–22% (2021→2026)

#### Revenue Trend Chart (USD, estimated)

```mermaid
xychart-beta
    title "E-karú / Innovasys Revenue Trend (USD M ARR, estimated proxy)"
    x-axis [2022, 2023, 2024, 2025, 2026]
    y-axis "USD Millions" 0 --> 2
    line [0.5, 0.65, 0.85, 1.0, 1.15]
```

---

### Profitability

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| EBITDA | Unknown | No source | Unknown |
| EBITDA Margin | Estimated 20–40% (typical bootstrapped SaaS at SME scale with low capex) | Industry benchmark | Estimated proxy |
| Net Profit / Loss | Unknown — likely profitable given 30+ year operator survival | No source | Unknown |
| Recurring Revenue % | Est. ~80–90% (SaaS model; hardware sales ~10–20%) | Product architecture; Infonegocios PY | Estimated |
| ARR per Location | USD ~960/yr (~USD 80/mo) | Proxy | Estimated proxy |
| Revenue per Employee | Unknown headcount — est. 20–40 staff → USD 30–60K/employee | Proxy | Estimated proxy |

---

### Funding & Investment History

| Date | Round | Amount (USD) | Lead Investor(s) | Capital Source Type | Valuation (USD) | Source | Confidence |
|---|---|---|---|---|---|---|---|
| ~1993 | Bootstrap | Unknown | Carmen Crosa de Pomata | Founder | N/A | Infonegocios PY | Estimated |
| 2019 | Operational agreement | Unknown (non-financial) | Netsystem SA ↔ E-karú team | Commercial / distribution | N/A | Revista CAP; Infonegocios | Confirmed |

**Total Raised**: No external funding identified — fully bootstrapped
**Latest Valuation**: Not applicable; estimated acquirable valuation: USD 2.5–5M (5× ARR at USD 1.15M → ~USD 5.7M ceiling; acquirer discount for PY-only, no scalability proof → USD 2.5–4M realistic range)
**Current Investors**: Founder-owned (Carmen Crosa de Pomata + probable technical co-founders)
**War Chest Signals**: None — bootstrapped; no identified debt facility or external capital

---

### Employee Timeline

| Year | Est. Total (PY) | Country Distribution | YoY Growth | Source | Confidence |
|---|---|---|---|---|---|
| 2026 (current) | ~20–40 est. | PY only | Unknown | No source; proxy from company scale | Estimated proxy |
| 2022 | ~15–25 est. | PY only | — | No source | Estimated proxy |

**Employee CAGR**: Unknown — no multi-year headcount data
**Current Open Positions**: Not identified on Bumeran, Computrabajo, or LinkedIn Jobs
**Hiring Hotspots**: Asunción (100% PY operations)
**Recent Layoff / Restructuring**: None identified

#### Employee Growth Chart

*Insufficient data for multi-year chart — fewer than 2 reliable data points.*

---

### Geographic & Market Expansion

| Year | Expansion Event | Market | Details | Source | Confidence |
|---|---|---|---|---|---|
| ~2013 | E-karú launched | PY (Asunción) | Initial restaurant clients in capital | Innovasys website | Estimated |
| 2019 | Market acceleration | PY (national) | Post-distribution agreement; reach accelerates to multiple departments | Infonegocios PY | Confirmed |
| 2022–2024 | Full PY coverage | PY (14 departments) | 14 of 17 PY departments covered | Innovasys website | Confirmed |

**Primary Market**: Paraguay (100%)
**International Revenue %**: 0% (no LATAM expansion identified)
**Country Footprint Strategy**: Single-country (PY); 14/17 department coverage is near-complete national footprint for PY
**Expansion Trajectory**: PY saturation within ~2–3 years at current growth rate; next expansion would require new country or vertical (institutional/B2B meal service). No LATAM expansion signals found.

---

### M&A Activity

No M&A activity identified (neither as acquirer nor as acquisition target).

**M&A Pattern**: No M&A history — purely organic bootstrapped growth

---

### Digitalization / SaaS Transition Metrics

| Data Point | Value | Source | Confidence |
|---|---|---|---|
| Deployment Model | Cloud-native SaaS from inception (~2013); accessible from anywhere via browser/mobile | Infonegocios PY; Innovasys website | Confirmed |
| Cloud Revenue % | ~100% (cloud-only; no legacy on-prem version identified) | Product architecture | Confirmed |
| Recurring Revenue % | Est. ~80–90% (subscription model with monthly fees) | Product model | Estimated |
| Mobile POS Support | Yes — orders from tablets + mobile phones; "Mozos Smart" module | Infonegocios PY | Confirmed |
| Self-Service Kiosk | Yes — "Self Service" module listed | Innovasys website | Confirmed |
| Digital Menu | Yes — "Menú Digital" module | Innovasys website | Confirmed |
| Stock / Inventory | Yes — stock control, wastage, inter-branch transfers | Infonegocios PY | Confirmed |
| Accounting / Finance | Basic — included in ERP modules; scope unclear | Innovasys website | Estimated |
| SET e-invoicing (ekuatia) | Required by PY law for commercial businesses; likely integrated | PY regulation | Estimated |
| Payment Integrations | Bancard PY integration likely (dominant PY payment network); others unconfirmed | No specific source | Unknown |
| Delivery Integrations | Delivery modules mentioned; specific integrations (Monchis PY, PedidosYa) unconfirmed | No source | Unknown |
| API Availability | No developer portal or API documentation found publicly | No source | Unknown |
| Migration Status | N/A — cloud-native; no legacy migration needed | — | — |

**Digitalization Maturity Assessment**: High for the product itself (cloud-native, mobile, self-service, digital menu). Weak on ecosystem integrations (payment platforms, delivery aggregators, API openness). This is the classic PY SaaS pattern: strong core product, thin ecosystem.

---

### Public-Sector Revenue & Tender Activity

Not applicable — tech-vendor serving private restaurant businesses. No DNCP tender participation identified.

**Estimated Public-Sector Revenue %**: ~0% (private restaurant client base only)
**Tender Win Rate**: N/A
**Lava Jato / Corruption Investigation Exposure**: None

---

### Growth Scorecard

| Dimension | Score (1-10) | Evidence Summary |
|---|---|---|
| Revenue Growth (USD-real) | **4** | Estimated ~20–25% USD CAGR 3yr — solid for bootstrapped PY SaaS but small absolute scale (USD 1.15M ARR); no explosive growth driver identified |
| Funding Momentum | **1** | Fully bootstrapped; no external funding; no investment signals |
| Employee Growth | **2** | Insufficient data; likely small stable team; no hiring announcements |
| Geographic Expansion | **1** | Single-country PY only; no LATAM signals; 14/17 departments = near PY saturation |
| M&A Activity | **1** | No M&A history; purely organic |
| Digitalization Maturity | **7** | Cloud-native SaaS, mobile POS, self-service, digital menu — high product maturity; weak on ecosystem integrations and API openness |
| Public-Sector Position | **1** | No public sector; private restaurant clients only |
| **COMPOSITE SCORE** | **2.4** | **Dinosaur** classification by scorecard (low funding/geography/M&A), but misleading — the product itself is modern; the "dinosaur" rating reflects the business model immaturity, not the technology |

**Classification**: **Dinosaur** (avg 2.4) — primarily because of single-country focus, no funding, no M&A, no hiring data, and tiny absolute scale. The Digitalization score (7/10) is the bright spot.

**Nuance for SolStein**: This composite score understates strategic value. The 1,200-location PY client base is the key asset — it represents PY's dominant restaurant POS network. An acquirer (SolStein) would pay for this network, not the financial profile. The acquisition case rests on:
1. Client base (1,200 PY restaurants = distribution channel)
2. Cloud architecture (no technical debt)
3. Market position (PY restaurant tech leader)
4. Modest price (USD 2.5–5M estimated acquisition range)

#### Growth Scorecard Chart

```mermaid
xychart-beta
    title "E-karú / Innovasys Growth Scorecard"
    x-axis ["Revenue", "Funding", "Employees", "Geography", "M&A", "Digital", "Public-Sector"]
    y-axis "Score" 0 --> 10
    bar [4, 1, 2, 1, 1, 7, 1]
```
